# Admin Panel Rules

Apply these rules when editing admin configuration, user management, or system settings features.

## Access control
- Apply strict RBAC — admin, supervisor, agent roles with granular permissions.
- Log all admin actions in an audit trail.
- Require confirmation for destructive operations (delete, reset, revoke).
- Never expose system internals (DB queries, internal IPs) in the admin UI.

## Configuration management
- AI model configuration changes must not require restarts — support hot reload.
- Version all configuration changes and support rollback.
- Validate configuration changes before applying — prevent invalid states.
- Show the current active configuration alongside the edit form.

## Knowledge base management
- Support bulk operations: upload, re-index, delete with progress tracking.
- Show ingestion status, chunk counts, and embedding health per document.
- Allow preview of chunked content before publishing.

## Agent management
- Support skill tagging for routing purposes.
- Track agent availability and current workload.
- Allow supervisors to reassign tickets and adjust routing rules.

## API key management
- Generate, rotate, and revoke API keys from the admin panel.
- Show usage statistics per API key.
- Apply scoped permissions per key — never issue full-access keys by default.
- Mask key values after creation — show only prefix for identification.
