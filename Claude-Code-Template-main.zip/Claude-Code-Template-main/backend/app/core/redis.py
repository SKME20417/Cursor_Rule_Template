"""Redis client singleton."""

from redis.asyncio import Redis

from app.config import get_settings

settings = get_settings()

redis_client = Redis.from_url(
    settings.resolved_redis_url,
    decode_responses=True,
    socket_connect_timeout=5,
    retry_on_timeout=True,
)


async def get_redis() -> Redis:
    """Return the shared Redis client."""
    return redis_client
