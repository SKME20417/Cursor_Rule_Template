"""Standard response wrappers matching the frontend ApiResponse contract."""

from typing import Any


def success_response(data: Any, message: str | None = None) -> dict:
    """Build an ApiResponse<T> envelope."""
    resp: dict = {"success": True, "data": data}
    if message:
        resp["message"] = message
    return resp
