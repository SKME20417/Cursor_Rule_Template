"""FastAPI exception handlers for consistent JSON error responses."""

import structlog
from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import ORJSONResponse

from app.core.exceptions import AppException

logger = structlog.get_logger()


def register_error_handlers(app: FastAPI) -> None:
    """Register all exception handlers on the FastAPI app."""

    @app.exception_handler(AppException)
    async def app_exception_handler(_request: Request, exc: AppException) -> ORJSONResponse:
        logger.warning("app_exception", code=exc.code, message=exc.message)
        body: dict = {
            "success": False,
            "error": {"code": exc.code, "message": exc.message},
            "statusCode": exc.status_code,
        }
        if isinstance(exc, type) and hasattr(exc, "details"):
            body["error"]["details"] = getattr(exc, "details", None)
        return ORJSONResponse(status_code=exc.status_code, content=body)

    @app.exception_handler(RequestValidationError)
    async def validation_exception_handler(
        _request: Request, exc: RequestValidationError
    ) -> ORJSONResponse:
        details: dict[str, list[str]] = {}
        for error in exc.errors():
            field = ".".join(str(loc) for loc in error["loc"] if loc != "body")
            details.setdefault(field, []).append(error["msg"])
        return ORJSONResponse(
            status_code=422,
            content={
                "success": False,
                "error": {
                    "code": "VALIDATION_ERROR",
                    "message": "Request validation failed",
                    "details": details,
                },
                "statusCode": 422,
            },
        )

    @app.exception_handler(Exception)
    async def unhandled_exception_handler(
        _request: Request, exc: Exception
    ) -> ORJSONResponse:
        logger.exception("unhandled_exception", error=str(exc))
        return ORJSONResponse(
            status_code=500,
            content={
                "success": False,
                "error": {
                    "code": "INTERNAL_ERROR",
                    "message": "An unexpected error occurred",
                },
                "statusCode": 500,
            },
        )
