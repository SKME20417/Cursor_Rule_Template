"""Pagination utilities for list endpoints."""

import math
from typing import Any, TypeVar

from pydantic import BaseModel, Field

T = TypeVar("T")


class PaginationParams(BaseModel):
    """Query parameters for paginated endpoints."""

    page: int = Field(default=1, ge=1)
    page_size: int = Field(default=20, ge=1, le=100, alias="pageSize")

    class Config:
        populate_by_name = True

    @property
    def offset(self) -> int:
        return (self.page - 1) * self.page_size

    @property
    def limit(self) -> int:
        return self.page_size


def build_paginated_response(
    data: list[Any],
    total: int,
    page: int,
    page_size: int,
) -> dict:
    """Build a PaginatedResponse envelope matching the frontend contract."""
    return {
        "success": True,
        "data": data,
        "pagination": {
            "page": page,
            "pageSize": page_size,
            "totalItems": total,
            "totalPages": math.ceil(total / page_size) if page_size > 0 else 0,
        },
    }
