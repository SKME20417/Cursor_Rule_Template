"""Interaction model for customer interaction timeline."""

import uuid
from datetime import datetime
from typing import Optional

from sqlalchemy import DateTime, ForeignKey, Index, String
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.models.base import Base, TimestampMixin, UUIDMixin


class Interaction(Base, UUIDMixin, TimestampMixin):
    """Represents a single interaction in a customer's timeline."""

    __tablename__ = "interactions"

    customer_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("customers.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    channel: Mapped[str] = mapped_column(String(20), nullable=False)
    type: Mapped[str] = mapped_column(String(20), nullable=False)
    reference_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), nullable=False)
    summary: Mapped[Optional[str]] = mapped_column(String(1000), nullable=True)
    agent_id: Mapped[Optional[uuid.UUID]] = mapped_column(
        UUID(as_uuid=True), nullable=True,
    )
    occurred_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False,
    )

    # Relationships
    customer = relationship("Customer", back_populates="interactions", foreign_keys=[customer_id])

    __table_args__ = (
        Index("ix_interactions_customer_occurred", "customer_id", "occurred_at"),
    )

    def __repr__(self) -> str:
        return f"<Interaction(id={self.id}, type={self.type!r}, channel={self.channel!r})>"
