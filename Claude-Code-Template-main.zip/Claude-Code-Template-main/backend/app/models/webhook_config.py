"""WebhookConfig model for integration webhooks."""

import uuid
from datetime import datetime
from typing import Optional

from sqlalchemy import Boolean, DateTime, ForeignKey, Integer, String
from sqlalchemy.dialects.postgresql import ARRAY, JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.models.base import Base, TimestampMixin, UUIDMixin


class WebhookConfig(Base, UUIDMixin, TimestampMixin):
    """Represents a webhook configuration tied to an integration."""

    __tablename__ = "webhook_configs"

    integration_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("integrations.id", ondelete="CASCADE"),
        nullable=False,
    )
    url: Mapped[str] = mapped_column(String(2048), nullable=False)
    method: Mapped[str] = mapped_column(String(10), nullable=False, default="POST")
    headers: Mapped[Optional[dict]] = mapped_column(JSONB, nullable=True)
    events: Mapped[Optional[list[str]]] = mapped_column(
        ARRAY(String), nullable=True,
    )
    secret_key: Mapped[Optional[str]] = mapped_column(String(500), nullable=True)
    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)
    retry_count: Mapped[int] = mapped_column(Integer, nullable=False, default=3)
    last_triggered_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True), nullable=True,
    )

    # Relationships
    integration = relationship("Integration", back_populates="webhooks", foreign_keys=[integration_id])

    def __repr__(self) -> str:
        return f"<WebhookConfig(id={self.id}, url={self.url!r}, is_active={self.is_active})>"
