"""Ticket model for support tickets."""

import uuid
from datetime import datetime
from typing import Optional

from sqlalchemy import DateTime, ForeignKey, Index, String, Text
from sqlalchemy.dialects.postgresql import ARRAY, UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.models.base import Base, TimestampMixin, UUIDMixin


class Ticket(Base, UUIDMixin, TimestampMixin):
    """Represents a support ticket linked to a conversation or standalone."""

    __tablename__ = "tickets"

    conversation_id: Mapped[Optional[uuid.UUID]] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("conversations.id", ondelete="SET NULL"),
        nullable=True,
    )
    customer_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("customers.id", ondelete="CASCADE"),
        nullable=False,
    )
    assigned_agent_id: Mapped[Optional[uuid.UUID]] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("agents.id", ondelete="SET NULL"),
        nullable=True,
    )
    team_id: Mapped[Optional[uuid.UUID]] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("teams.id", ondelete="SET NULL"),
        nullable=True,
    )
    subject: Mapped[str] = mapped_column(String(500), nullable=False)
    description: Mapped[str] = mapped_column(Text, nullable=False)
    status: Mapped[str] = mapped_column(String(20), nullable=False, default="created")
    priority: Mapped[str] = mapped_column(String(10), nullable=False, default="medium")
    category_id: Mapped[Optional[uuid.UUID]] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("ticket_categories.id", ondelete="SET NULL"),
        nullable=True,
    )
    channel: Mapped[str] = mapped_column(String(20), nullable=False)
    tags: Mapped[Optional[list[str]]] = mapped_column(
        ARRAY(String), nullable=True, default=list,
    )
    sla_policy_id: Mapped[Optional[uuid.UUID]] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("sla_policies.id", ondelete="SET NULL"),
        nullable=True,
    )
    sla_breach_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True), nullable=True,
    )
    first_response_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True), nullable=True,
    )
    resolved_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True), nullable=True,
    )
    closed_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True), nullable=True,
    )

    # Relationships
    conversation = relationship("Conversation", back_populates="tickets", foreign_keys=[conversation_id])
    customer = relationship("Customer", back_populates="tickets", foreign_keys=[customer_id])
    assigned_agent = relationship("Agent", foreign_keys=[assigned_agent_id])
    team = relationship("Team", foreign_keys=[team_id])
    category = relationship("TicketCategory", foreign_keys=[category_id])
    sla_policy = relationship("SLAPolicy", foreign_keys=[sla_policy_id])
    comments = relationship("TicketComment", back_populates="ticket", lazy="selectin", cascade="all, delete-orphan")

    __table_args__ = (
        Index("ix_tickets_customer_id", "customer_id"),
        Index("ix_tickets_assigned_agent_id", "assigned_agent_id"),
        Index("ix_tickets_status_priority", "status", "priority"),
        Index("ix_tickets_sla_breach_at", "sla_breach_at"),
    )

    def __repr__(self) -> str:
        return f"<Ticket(id={self.id}, status={self.status!r}, priority={self.priority!r})>"
