"""TicketCategory model for categorizing tickets."""

import uuid
from typing import Optional

from sqlalchemy import ForeignKey, String
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.models.base import Base, TimestampMixin, UUIDMixin


class TicketCategory(Base, UUIDMixin, TimestampMixin):
    """Represents a category for organizing support tickets."""

    __tablename__ = "ticket_categories"

    name: Mapped[str] = mapped_column(String(100), nullable=False)
    description: Mapped[Optional[str]] = mapped_column(String(500), nullable=True)
    parent_id: Mapped[Optional[uuid.UUID]] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("ticket_categories.id", ondelete="SET NULL"),
        nullable=True,
    )

    # Relationships (self-referential)
    parent = relationship("TicketCategory", remote_side="TicketCategory.id", back_populates="children")
    children = relationship("TicketCategory", back_populates="parent", lazy="selectin")

    def __repr__(self) -> str:
        return f"<TicketCategory(id={self.id}, name={self.name!r})>"
