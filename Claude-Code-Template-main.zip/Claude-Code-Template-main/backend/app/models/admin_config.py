"""AdminConfig model for global admin settings."""

from typing import Optional

from sqlalchemy import Boolean, Integer, String
from sqlalchemy.dialects.postgresql import ARRAY, JSONB
from sqlalchemy.orm import Mapped, mapped_column

from app.models.base import Base, TimestampMixin, UUIDMixin


class AdminConfig(Base, UUIDMixin, TimestampMixin):
    """Stores global administrative configuration for the support platform."""

    __tablename__ = "admin_configs"

    max_concurrent_per_agent: Mapped[int] = mapped_column(
        Integer, nullable=False, default=5,
    )
    auto_assign_enabled: Mapped[bool] = mapped_column(
        Boolean, nullable=False, default=True,
    )
    business_hours_enabled: Mapped[bool] = mapped_column(
        Boolean, nullable=False, default=False,
    )
    business_hours: Mapped[Optional[dict]] = mapped_column(JSONB, nullable=True)
    default_language: Mapped[str] = mapped_column(
        String(10), nullable=False, default="en",
    )
    supported_languages: Mapped[Optional[list[str]]] = mapped_column(
        ARRAY(String), nullable=True, default=list,
    )

    def __repr__(self) -> str:
        return f"<AdminConfig(id={self.id}, auto_assign={self.auto_assign_enabled})>"
