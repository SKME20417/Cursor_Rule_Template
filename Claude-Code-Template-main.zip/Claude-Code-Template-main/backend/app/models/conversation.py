"""Conversation model for customer support conversations."""

import uuid
from datetime import datetime
from typing import Optional

from sqlalchemy import DateTime, ForeignKey, Index, Integer, String, Text
from sqlalchemy.dialects.postgresql import ARRAY, UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.models.base import Base, TimestampMixin, UUIDMixin


class Conversation(Base, UUIDMixin, TimestampMixin):
    """Represents a support conversation across any channel."""

    __tablename__ = "conversations"

    customer_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("customers.id", ondelete="CASCADE"),
        nullable=False,
    )
    assigned_agent_id: Mapped[Optional[uuid.UUID]] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("agents.id", ondelete="SET NULL"),
        nullable=True,
    )
    channel: Mapped[str] = mapped_column(String(20), nullable=False)
    status: Mapped[str] = mapped_column(String(20), nullable=False, default="open")
    subject: Mapped[Optional[str]] = mapped_column(String(500), nullable=True)
    tags: Mapped[Optional[list[str]]] = mapped_column(
        ARRAY(String), nullable=True, default=list,
    )
    last_message_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True), nullable=True,
    )
    last_message_preview: Mapped[Optional[str]] = mapped_column(String(500), nullable=True)
    message_count: Mapped[int] = mapped_column(Integer, nullable=False, default=0)

    # Relationships
    customer = relationship("Customer", back_populates="conversations", foreign_keys=[customer_id])
    assigned_agent = relationship("Agent", back_populates="conversations", foreign_keys=[assigned_agent_id])
    messages = relationship("Message", back_populates="conversation", lazy="selectin")
    tickets = relationship("Ticket", back_populates="conversation", lazy="selectin")
    suggestions = relationship("Suggestion", back_populates="conversation", lazy="selectin")
    drafts = relationship("Draft", back_populates="conversation", lazy="selectin")
    classification = relationship("Classification", back_populates="conversation", uselist=False, lazy="selectin")

    __table_args__ = (
        Index("ix_conversations_customer_id", "customer_id"),
        Index("ix_conversations_assigned_agent_id", "assigned_agent_id"),
        Index("ix_conversations_status", "status"),
        Index("ix_conversations_last_message_at", last_message_at.desc()),
    )

    def __repr__(self) -> str:
        return f"<Conversation(id={self.id}, channel={self.channel!r}, status={self.status!r})>"
