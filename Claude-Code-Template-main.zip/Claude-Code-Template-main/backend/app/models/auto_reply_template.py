"""AutoReplyTemplate model for automated reply templates."""

from typing import Optional

from sqlalchemy import Boolean, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from app.models.base import Base, TimestampMixin, UUIDMixin


class AutoReplyTemplate(Base, UUIDMixin, TimestampMixin):
    """Represents a template for automated replies."""

    __tablename__ = "auto_reply_templates"

    name: Mapped[str] = mapped_column(String(200), nullable=False)
    subject: Mapped[Optional[str]] = mapped_column(String(500), nullable=True)
    body: Mapped[str] = mapped_column(Text, nullable=False)
    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)

    def __repr__(self) -> str:
        return f"<AutoReplyTemplate(id={self.id}, name={self.name!r}, is_active={self.is_active})>"
