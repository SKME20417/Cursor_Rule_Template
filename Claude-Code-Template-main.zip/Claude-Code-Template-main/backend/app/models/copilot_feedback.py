"""CopilotFeedback model for agent feedback on AI suggestions."""

import uuid
from typing import Optional

from sqlalchemy import ForeignKey, String
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.models.base import Base, TimestampMixin, UUIDMixin


class CopilotFeedback(Base, UUIDMixin, TimestampMixin):
    """Represents agent feedback on an AI copilot suggestion."""

    __tablename__ = "copilot_feedback"

    suggestion_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("suggestions.id", ondelete="CASCADE"),
        nullable=False,
    )
    agent_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("agents.id", ondelete="CASCADE"),
        nullable=False,
    )
    rating: Mapped[str] = mapped_column(String(20), nullable=False)
    comment: Mapped[Optional[str]] = mapped_column(String(2000), nullable=True)

    # Relationships
    suggestion = relationship("Suggestion", back_populates="feedback", foreign_keys=[suggestion_id])

    def __repr__(self) -> str:
        return f"<CopilotFeedback(id={self.id}, rating={self.rating!r})>"
