"""Customer model for external support customers."""

import uuid
from typing import Optional

from sqlalchemy import Boolean, Index, String
from sqlalchemy.dialects.postgresql import ARRAY, UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.models.base import Base, TimestampMixin, UUIDMixin


class Customer(Base, UUIDMixin, TimestampMixin):
    """Represents an external customer who interacts with support."""

    __tablename__ = "customers"

    external_id: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    email: Mapped[str] = mapped_column(String(255), nullable=False, index=True)
    first_name: Mapped[str] = mapped_column(String(100), nullable=False)
    last_name: Mapped[str] = mapped_column(String(100), nullable=False)
    phone: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    avatar_url: Mapped[Optional[str]] = mapped_column(String(2048), nullable=True)
    segment: Mapped[str] = mapped_column(
        String(20), nullable=False, default="new",
    )
    tags: Mapped[Optional[list[str]]] = mapped_column(
        ARRAY(String), nullable=True, default=list,
    )
    is_verified: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)

    # Relationships
    conversations = relationship("Conversation", back_populates="customer", lazy="selectin")
    tickets = relationship("Ticket", back_populates="customer", lazy="selectin")
    interactions = relationship("Interaction", back_populates="customer", lazy="selectin")
    calls = relationship("Call", back_populates="customer", lazy="selectin")

    __table_args__ = (
        Index("ix_customers_external_id", "external_id", postgresql_where=external_id.isnot(None)),
    )

    def __repr__(self) -> str:
        return f"<Customer(id={self.id}, email={self.email!r}, segment={self.segment!r})>"
