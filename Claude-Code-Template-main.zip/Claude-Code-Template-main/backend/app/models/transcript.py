"""Transcript and TranscriptSegment models for call transcriptions."""

import uuid

from sqlalchemy import Float, ForeignKey, Index, Integer, String, Text
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.models.base import Base, TimestampMixin, UUIDMixin


class Transcript(Base, UUIDMixin, TimestampMixin):
    """Represents the full transcript of a voice call."""

    __tablename__ = "transcripts"

    call_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("calls.id", ondelete="CASCADE"),
        unique=True,
        nullable=False,
    )
    language: Mapped[str] = mapped_column(String(10), nullable=False, default="en")

    # Relationships
    call = relationship("Call", back_populates="transcript", foreign_keys=[call_id])
    segments = relationship(
        "TranscriptSegment", back_populates="transcript", lazy="selectin", cascade="all, delete-orphan",
    )

    def __repr__(self) -> str:
        return f"<Transcript(id={self.id}, call_id={self.call_id}, language={self.language!r})>"


class TranscriptSegment(Base, UUIDMixin, TimestampMixin):
    """Represents a single segment within a call transcript."""

    __tablename__ = "transcript_segments"

    transcript_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("transcripts.id", ondelete="CASCADE"),
        nullable=False,
    )
    speaker: Mapped[str] = mapped_column(String(100), nullable=False)
    text: Mapped[str] = mapped_column(Text, nullable=False)
    start_ms: Mapped[int] = mapped_column(Integer, nullable=False)
    end_ms: Mapped[int] = mapped_column(Integer, nullable=False)
    confidence: Mapped[float] = mapped_column(Float, nullable=False)

    # Relationships
    transcript = relationship("Transcript", back_populates="segments", foreign_keys=[transcript_id])

    __table_args__ = (
        Index("ix_transcript_segments_transcript_start", "transcript_id", "start_ms"),
    )

    def __repr__(self) -> str:
        return f"<TranscriptSegment(id={self.id}, speaker={self.speaker!r}, start_ms={self.start_ms})>"
