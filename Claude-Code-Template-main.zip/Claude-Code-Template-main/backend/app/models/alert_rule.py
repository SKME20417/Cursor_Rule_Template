"""AlertRule model for monitoring alert rules."""

from typing import Optional

from sqlalchemy import Boolean, Float, String
from sqlalchemy.dialects.postgresql import ARRAY
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.models.base import Base, TimestampMixin, UUIDMixin


class AlertRule(Base, UUIDMixin, TimestampMixin):
    """Defines a rule for triggering alerts based on metric thresholds."""

    __tablename__ = "alert_rules"

    name: Mapped[str] = mapped_column(String(200), nullable=False)
    description: Mapped[Optional[str]] = mapped_column(String(1000), nullable=True)
    metric: Mapped[str] = mapped_column(String(100), nullable=False)
    condition: Mapped[str] = mapped_column(String(5), nullable=False)
    threshold: Mapped[float] = mapped_column(Float, nullable=False)
    severity: Mapped[str] = mapped_column(String(10), nullable=False, default="warning")
    notify_channels: Mapped[Optional[list[str]]] = mapped_column(
        ARRAY(String), nullable=True,
    )
    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)

    # Relationships
    history = relationship("AlertHistory", back_populates="rule", lazy="selectin")

    def __repr__(self) -> str:
        return f"<AlertRule(id={self.id}, name={self.name!r}, metric={self.metric!r})>"
