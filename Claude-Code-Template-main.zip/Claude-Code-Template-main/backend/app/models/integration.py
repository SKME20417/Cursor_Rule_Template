"""Integration model for third-party integrations."""

from datetime import datetime
from typing import Optional

from sqlalchemy import DateTime, String
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.models.base import Base, TimestampMixin, UUIDMixin


class Integration(Base, UUIDMixin, TimestampMixin):
    """Represents a third-party integration (e.g., CRM, Slack, email provider)."""

    __tablename__ = "integrations"

    provider: Mapped[str] = mapped_column(String(100), nullable=False)
    name: Mapped[str] = mapped_column(String(200), nullable=False)
    status: Mapped[str] = mapped_column(String(20), nullable=False, default="pending")
    config: Mapped[Optional[dict]] = mapped_column(JSONB, nullable=True)
    last_sync_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True), nullable=True,
    )
    error_message: Mapped[Optional[str]] = mapped_column(String(2000), nullable=True)

    # Relationships
    webhooks = relationship("WebhookConfig", back_populates="integration", lazy="selectin", cascade="all, delete-orphan")

    def __repr__(self) -> str:
        return f"<Integration(id={self.id}, provider={self.provider!r}, status={self.status!r})>"
