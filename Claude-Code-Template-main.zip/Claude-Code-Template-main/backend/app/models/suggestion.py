"""Suggestion model for AI copilot suggestions."""

import uuid
from typing import Optional

from sqlalchemy import Float, ForeignKey, String, Text
from sqlalchemy.dialects.postgresql import ARRAY, UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.models.base import Base, TimestampMixin, UUIDMixin


class Suggestion(Base, UUIDMixin, TimestampMixin):
    """Represents an AI-generated suggestion for a conversation."""

    __tablename__ = "suggestions"

    conversation_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("conversations.id", ondelete="CASCADE"),
        nullable=False,
    )
    type: Mapped[str] = mapped_column(String(30), nullable=False)
    content: Mapped[str] = mapped_column(Text, nullable=False)
    confidence: Mapped[float] = mapped_column(Float, nullable=False)
    source_article_ids: Mapped[Optional[list[uuid.UUID]]] = mapped_column(
        ARRAY(UUID(as_uuid=True)), nullable=True,
    )

    # Relationships
    conversation = relationship("Conversation", back_populates="suggestions", foreign_keys=[conversation_id])
    feedback = relationship("CopilotFeedback", back_populates="suggestion", lazy="selectin")

    def __repr__(self) -> str:
        return f"<Suggestion(id={self.id}, type={self.type!r}, confidence={self.confidence})>"
