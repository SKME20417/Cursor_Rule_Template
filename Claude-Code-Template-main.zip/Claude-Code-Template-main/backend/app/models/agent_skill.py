"""AgentSkill model for agent competencies."""

import uuid

from sqlalchemy import ForeignKey, String
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.models.base import Base, TimestampMixin, UUIDMixin


class AgentSkill(Base, UUIDMixin, TimestampMixin):
    """Represents a skill or competency for a support agent."""

    __tablename__ = "agent_skills"

    agent_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("agents.id", ondelete="CASCADE"),
        nullable=False,
    )
    name: Mapped[str] = mapped_column(String(100), nullable=False)
    proficiency: Mapped[str] = mapped_column(String(20), nullable=False, default="intermediate")

    # Relationships
    agent = relationship("Agent", back_populates="skills", foreign_keys=[agent_id])

    def __repr__(self) -> str:
        return f"<AgentSkill(id={self.id}, name={self.name!r}, proficiency={self.proficiency!r})>"
