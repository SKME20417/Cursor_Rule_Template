"""Call model for voice calls."""

import uuid
from datetime import datetime
from typing import Optional

from sqlalchemy import DateTime, ForeignKey, Integer, String
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.models.base import Base, TimestampMixin, UUIDMixin


class Call(Base, UUIDMixin, TimestampMixin):
    """Represents a voice call between a customer and an agent."""

    __tablename__ = "calls"

    conversation_id: Mapped[Optional[uuid.UUID]] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("conversations.id", ondelete="SET NULL"),
        nullable=True,
    )
    customer_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("customers.id", ondelete="CASCADE"),
        nullable=False,
    )
    agent_id: Mapped[Optional[uuid.UUID]] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("agents.id", ondelete="SET NULL"),
        nullable=True,
    )
    direction: Mapped[str] = mapped_column(String(10), nullable=False)
    status: Mapped[str] = mapped_column(String(20), nullable=False, default="ringing")
    phone_number: Mapped[str] = mapped_column(String(50), nullable=False)
    started_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    connected_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True), nullable=True,
    )
    ended_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True), nullable=True,
    )
    duration_seconds: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    hold_duration_seconds: Mapped[int] = mapped_column(Integer, nullable=False, default=0)

    # Relationships
    customer = relationship("Customer", back_populates="calls", foreign_keys=[customer_id])
    recording = relationship("Recording", back_populates="call", uselist=False, lazy="selectin")
    transcript = relationship("Transcript", back_populates="call", uselist=False, lazy="selectin")

    def __repr__(self) -> str:
        return f"<Call(id={self.id}, direction={self.direction!r}, status={self.status!r})>"
