"""ServiceHealth model for monitoring service status."""

from datetime import datetime
from typing import Optional

from sqlalchemy import DateTime, Float, String
from sqlalchemy.orm import Mapped, mapped_column

from app.models.base import Base, TimestampMixin, UUIDMixin


class ServiceHealth(Base, UUIDMixin, TimestampMixin):
    """Tracks the health status of individual services in the platform."""

    __tablename__ = "service_health"

    service_name: Mapped[str] = mapped_column(String(100), unique=True, nullable=False)
    status: Mapped[str] = mapped_column(String(20), nullable=False, default="healthy")
    latency_ms: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    uptime_percent: Mapped[float] = mapped_column(Float, nullable=False, default=100.0)
    last_checked_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False,
    )
    details: Mapped[Optional[str]] = mapped_column(String(2000), nullable=True)

    def __repr__(self) -> str:
        return f"<ServiceHealth(id={self.id}, service_name={self.service_name!r}, status={self.status!r})>"
