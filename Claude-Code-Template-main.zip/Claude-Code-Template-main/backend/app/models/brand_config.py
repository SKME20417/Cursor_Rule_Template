"""BrandConfig model for branding and widget settings."""

from typing import Optional

from sqlalchemy import String
from sqlalchemy.orm import Mapped, mapped_column

from app.models.base import Base, TimestampMixin, UUIDMixin


class BrandConfig(Base, UUIDMixin, TimestampMixin):
    """Stores branding configuration for the customer-facing support widget and emails."""

    __tablename__ = "brand_configs"

    company_name: Mapped[str] = mapped_column(String(200), nullable=False)
    logo_url: Mapped[Optional[str]] = mapped_column(String(2048), nullable=True)
    favicon_url: Mapped[Optional[str]] = mapped_column(String(2048), nullable=True)
    primary_color: Mapped[str] = mapped_column(
        String(20), nullable=False, default="#0a66c2",
    )
    accent_color: Mapped[str] = mapped_column(
        String(20), nullable=False, default="#004182",
    )
    widget_position: Mapped[str] = mapped_column(
        String(20), nullable=False, default="bottom-right",
    )
    widget_greeting: Mapped[str] = mapped_column(String(500), nullable=False)
    email_from_name: Mapped[str] = mapped_column(String(200), nullable=False)
    email_from_address: Mapped[str] = mapped_column(String(255), nullable=False)

    def __repr__(self) -> str:
        return f"<BrandConfig(id={self.id}, company_name={self.company_name!r})>"
