"""Team model for agent teams."""

import uuid
from typing import Optional

from sqlalchemy import ForeignKey, Integer, String
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.models.base import Base, TimestampMixin, UUIDMixin


class Team(Base, UUIDMixin, TimestampMixin):
    """Represents a team of support agents."""

    __tablename__ = "teams"

    name: Mapped[str] = mapped_column(String(100), nullable=False)
    description: Mapped[Optional[str]] = mapped_column(String(500), nullable=True)
    lead_agent_id: Mapped[Optional[uuid.UUID]] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("agents.id", ondelete="SET NULL", use_alter=True),
        nullable=True,
    )
    member_count: Mapped[int] = mapped_column(Integer, nullable=False, default=0)

    # Relationships
    members = relationship("Agent", back_populates="team", foreign_keys="Agent.team_id", lazy="selectin")

    def __repr__(self) -> str:
        return f"<Team(id={self.id}, name={self.name!r}, member_count={self.member_count})>"
