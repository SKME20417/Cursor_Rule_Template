"""AuditEntry model for audit logging."""

import uuid
from typing import Optional

from sqlalchemy import ForeignKey, Index, String
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column

from app.models.base import Base, TimestampMixin, UUIDMixin


class AuditEntry(Base, UUIDMixin, TimestampMixin):
    """Represents an audit log entry for tracking user actions on resources."""

    __tablename__ = "audit_entries"

    user_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("users.id", ondelete="CASCADE"),
        nullable=False,
    )
    user_email: Mapped[str] = mapped_column(String(255), nullable=False)
    action: Mapped[str] = mapped_column(String(50), nullable=False)
    resource: Mapped[str] = mapped_column(String(100), nullable=False)
    resource_id: Mapped[Optional[uuid.UUID]] = mapped_column(
        UUID(as_uuid=True), nullable=True,
    )
    changes: Mapped[Optional[dict]] = mapped_column(JSONB, nullable=True)
    ip_address: Mapped[str] = mapped_column(String(45), nullable=False)
    user_agent: Mapped[str] = mapped_column(String(500), nullable=False)

    __table_args__ = (
        Index("ix_audit_entries_user_created", "user_id", "created_at"),
        Index("ix_audit_entries_resource", "resource", "resource_id"),
    )

    def __repr__(self) -> str:
        return f"<AuditEntry(id={self.id}, action={self.action!r}, resource={self.resource!r})>"
