"""Classification model for AI-driven conversation classification."""

import uuid
from typing import Optional

from sqlalchemy import ForeignKey, String
from sqlalchemy.dialects.postgresql import ARRAY, JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.models.base import Base, TimestampMixin, UUIDMixin


class Classification(Base, UUIDMixin, TimestampMixin):
    """Represents AI-generated classification of a conversation including intent, sentiment, and urgency."""

    __tablename__ = "classifications"

    conversation_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("conversations.id", ondelete="CASCADE"),
        unique=True,
        nullable=False,
    )
    intents: Mapped[Optional[dict]] = mapped_column(JSONB, nullable=True)
    sentiment: Mapped[Optional[dict]] = mapped_column(JSONB, nullable=True)
    urgency: Mapped[str] = mapped_column(String(10), nullable=False, default="low")
    topics: Mapped[Optional[list[str]]] = mapped_column(
        ARRAY(String), nullable=True, default=list,
    )

    # Relationships
    conversation = relationship("Conversation", back_populates="classification", foreign_keys=[conversation_id])

    def __repr__(self) -> str:
        return f"<Classification(id={self.id}, urgency={self.urgency!r})>"
