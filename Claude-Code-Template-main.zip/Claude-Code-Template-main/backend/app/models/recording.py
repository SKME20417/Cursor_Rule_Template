"""Recording model for call recordings."""

import uuid

from sqlalchemy import ForeignKey, Integer, String
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.models.base import Base, TimestampMixin, UUIDMixin


class Recording(Base, UUIDMixin, TimestampMixin):
    """Represents a recording of a voice call."""

    __tablename__ = "recordings"

    call_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("calls.id", ondelete="CASCADE"),
        unique=True,
        nullable=False,
    )
    file_url: Mapped[str] = mapped_column(String(2048), nullable=False)
    duration_seconds: Mapped[int] = mapped_column(Integer, nullable=False)
    file_size_bytes: Mapped[int] = mapped_column(Integer, nullable=False)

    # Relationships
    call = relationship("Call", back_populates="recording", foreign_keys=[call_id])

    def __repr__(self) -> str:
        return f"<Recording(id={self.id}, call_id={self.call_id}, duration_seconds={self.duration_seconds})>"
