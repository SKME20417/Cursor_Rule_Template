"""Model registry — imports every ORM model so Alembic can discover them."""

from app.models.base import Base, TimestampMixin, UUIDMixin

# Auth & users
from app.models.user import User, UserRole
from app.models.session import RefreshToken

# Customers
from app.models.customer import Customer

# Conversations & messaging
from app.models.conversation import Conversation
from app.models.message import Message
from app.models.attachment import Attachment

# Tickets
from app.models.ticket import Ticket
from app.models.ticket_comment import TicketComment
from app.models.ticket_category import TicketCategory
from app.models.sla_policy import SLAPolicy

# Agents & teams
from app.models.agent import Agent
from app.models.agent_skill import AgentSkill
from app.models.team import Team

# Calls & recordings
from app.models.call import Call
from app.models.recording import Recording
from app.models.transcript import Transcript, TranscriptSegment

# Video
from app.models.video_session import VideoSession
from app.models.participant import Participant

# Knowledge base
from app.models.article import Article
from app.models.category import Category
from app.models.document import Document

# AI copilot
from app.models.suggestion import Suggestion
from app.models.draft import Draft
from app.models.copilot_feedback import CopilotFeedback
from app.models.classification import Classification

# Automation
from app.models.workflow import Workflow
from app.models.auto_reply_template import AutoReplyTemplate
from app.models.escalation_rule import EscalationRule

# Integrations
from app.models.integration import Integration
from app.models.webhook_config import WebhookConfig

# Notifications
from app.models.notification import Notification

# Admin & config
from app.models.admin_config import AdminConfig
from app.models.brand_config import BrandConfig

# RBAC
from app.models.role import RoleModel
from app.models.permission import Permission

# Audit & security
from app.models.audit_entry import AuditEntry
from app.models.api_key import ApiKey

# Monitoring & alerts
from app.models.alert_rule import AlertRule
from app.models.alert_history import AlertHistory
from app.models.service_health import ServiceHealth

# Customer timeline
from app.models.interaction import Interaction

__all__ = [
    "Base",
    "TimestampMixin",
    "UUIDMixin",
    "User",
    "UserRole",
    "RefreshToken",
    "Customer",
    "Conversation",
    "Message",
    "Attachment",
    "Ticket",
    "TicketComment",
    "TicketCategory",
    "SLAPolicy",
    "Agent",
    "AgentSkill",
    "Team",
    "Call",
    "Recording",
    "Transcript",
    "TranscriptSegment",
    "VideoSession",
    "Participant",
    "Article",
    "Category",
    "Document",
    "Suggestion",
    "Draft",
    "CopilotFeedback",
    "Classification",
    "Workflow",
    "AutoReplyTemplate",
    "EscalationRule",
    "Integration",
    "WebhookConfig",
    "Notification",
    "AdminConfig",
    "BrandConfig",
    "RoleModel",
    "Permission",
    "AuditEntry",
    "ApiKey",
    "AlertRule",
    "AlertHistory",
    "ServiceHealth",
    "Interaction",
]
