"""Agent model for support agents."""

import uuid
from datetime import datetime
from typing import Optional

from sqlalchemy import DateTime, ForeignKey, Integer, String
from sqlalchemy.dialects.postgresql import ARRAY, UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.models.base import Base, TimestampMixin, UUIDMixin


class Agent(Base, UUIDMixin, TimestampMixin):
    """Represents a support agent who handles conversations and tickets."""

    __tablename__ = "agents"

    user_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("users.id", ondelete="CASCADE"),
        unique=True,
        nullable=False,
    )
    display_name: Mapped[str] = mapped_column(String(200), nullable=False)
    email: Mapped[str] = mapped_column(String(255), nullable=False)
    avatar_url: Mapped[Optional[str]] = mapped_column(String(2048), nullable=True)
    status: Mapped[str] = mapped_column(String(10), nullable=False, default="offline")
    team_id: Mapped[Optional[uuid.UUID]] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("teams.id", ondelete="SET NULL"),
        nullable=True,
    )
    supported_channels: Mapped[Optional[list[str]]] = mapped_column(
        ARRAY(String), nullable=True, default=list,
    )
    max_concurrent_conversations: Mapped[int] = mapped_column(
        Integer, nullable=False, default=5,
    )
    active_conversation_count: Mapped[int] = mapped_column(
        Integer, nullable=False, default=0,
    )
    last_active_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True), nullable=True,
    )

    # Relationships
    skills = relationship("AgentSkill", back_populates="agent", lazy="selectin", cascade="all, delete-orphan")
    conversations = relationship("Conversation", back_populates="assigned_agent", foreign_keys="Conversation.assigned_agent_id", lazy="selectin")
    team = relationship("Team", back_populates="members", foreign_keys=[team_id])

    def __repr__(self) -> str:
        return f"<Agent(id={self.id}, display_name={self.display_name!r}, status={self.status!r})>"
