"""Draft model for agent message drafts."""

import uuid
from typing import Optional

from sqlalchemy import Boolean, ForeignKey, Text
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.models.base import Base, TimestampMixin, UUIDMixin


class Draft(Base, UUIDMixin, TimestampMixin):
    """Represents a draft message being composed by an agent, optionally based on a suggestion."""

    __tablename__ = "drafts"

    conversation_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("conversations.id", ondelete="CASCADE"),
        nullable=False,
    )
    agent_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("agents.id", ondelete="CASCADE"),
        nullable=False,
    )
    content: Mapped[str] = mapped_column(Text, nullable=False)
    based_on_suggestion_id: Mapped[Optional[uuid.UUID]] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("suggestions.id", ondelete="SET NULL"),
        nullable=True,
    )
    is_edited: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)

    # Relationships
    conversation = relationship("Conversation", back_populates="drafts", foreign_keys=[conversation_id])

    def __repr__(self) -> str:
        return f"<Draft(id={self.id}, conversation_id={self.conversation_id}, is_edited={self.is_edited})>"
