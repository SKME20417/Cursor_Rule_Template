"""RoleModel for RBAC roles."""

from typing import Optional

from sqlalchemy import Boolean, String
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.models.base import Base, TimestampMixin, UUIDMixin


class RoleModel(Base, UUIDMixin, TimestampMixin):
    """Represents a role in the role-based access control system."""

    __tablename__ = "roles"

    name: Mapped[str] = mapped_column(String(50), unique=True, nullable=False)
    description: Mapped[Optional[str]] = mapped_column(String(500), nullable=True)
    is_system: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)

    # Relationships
    permissions = relationship(
        "Permission", back_populates="role", lazy="selectin", cascade="all, delete-orphan",
    )

    def __repr__(self) -> str:
        return f"<RoleModel(id={self.id}, name={self.name!r}, is_system={self.is_system})>"
