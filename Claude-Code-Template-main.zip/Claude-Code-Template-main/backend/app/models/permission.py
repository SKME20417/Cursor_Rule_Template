"""Permission model for RBAC permissions."""

import uuid

from sqlalchemy import ForeignKey, String
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.models.base import Base, TimestampMixin, UUIDMixin


class Permission(Base, UUIDMixin, TimestampMixin):
    """Represents a permission granted to a role for a specific resource and action."""

    __tablename__ = "permissions"

    role_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("roles.id", ondelete="CASCADE"),
        nullable=False,
    )
    resource: Mapped[str] = mapped_column(String(100), nullable=False)
    action: Mapped[str] = mapped_column(String(50), nullable=False)

    # Relationships
    role = relationship("RoleModel", back_populates="permissions", foreign_keys=[role_id])

    def __repr__(self) -> str:
        return f"<Permission(id={self.id}, resource={self.resource!r}, action={self.action!r})>"
