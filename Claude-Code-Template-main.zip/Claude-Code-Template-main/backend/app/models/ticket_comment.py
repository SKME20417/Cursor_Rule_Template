"""TicketComment model for comments on tickets."""

import uuid

from sqlalchemy import Boolean, ForeignKey, Text
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.models.base import Base, TimestampMixin, UUIDMixin


class TicketComment(Base, UUIDMixin, TimestampMixin):
    """Represents a comment on a support ticket."""

    __tablename__ = "ticket_comments"

    ticket_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("tickets.id", ondelete="CASCADE"),
        nullable=False,
    )
    author_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("users.id", ondelete="CASCADE"),
        nullable=False,
    )
    content: Mapped[str] = mapped_column(Text, nullable=False)
    is_internal: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)

    # Relationships
    ticket = relationship("Ticket", back_populates="comments", foreign_keys=[ticket_id])

    def __repr__(self) -> str:
        return f"<TicketComment(id={self.id}, ticket_id={self.ticket_id}, is_internal={self.is_internal})>"
