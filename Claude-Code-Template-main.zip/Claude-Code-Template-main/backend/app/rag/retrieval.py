"""Vector similarity search for RAG retrieval."""

import structlog

from app.ai.embeddings import EmbeddingClient
from app.config import get_settings
from app.rag.vector_store import VectorStore

logger = structlog.get_logger()
settings = get_settings()


async def retrieve_relevant_chunks(
    query: str,
    vector_store: VectorStore,
    top_k: int | None = None,
    embedding_client: EmbeddingClient | None = None,
    min_score: float = 0.3,
) -> list[dict]:
    """Retrieve the most relevant text chunks for a query.

    Returns list of {id, score, content, metadata}.
    """
    top_k = top_k or settings.rag_top_k
    client = embedding_client or EmbeddingClient()

    query_embedding = await client.embed_text(query)
    results = await vector_store.search(query_embedding, top_k=top_k)

    # Filter by minimum score
    filtered = [r for r in results if r.get("score", 0) >= min_score]

    if not filtered:
        logger.warning("rag_retrieval_no_results", query=query[:100], top_k=top_k)

    logger.info(
        "rag_retrieval",
        query_preview=query[:80],
        total_results=len(results),
        filtered_results=len(filtered),
    )
    return filtered
