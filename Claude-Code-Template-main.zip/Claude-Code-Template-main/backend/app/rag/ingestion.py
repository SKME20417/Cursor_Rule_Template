"""Document ingestion pipeline: read → chunk → embed → store."""

import structlog

from app.ai.embeddings import EmbeddingClient
from app.rag.chunking import chunk_text
from app.rag.embedding import embed_and_store_chunks
from app.rag.vector_store import VectorStore

logger = structlog.get_logger()


async def ingest_document(
    document_id: str,
    content: str,
    vector_store: VectorStore,
    chunk_size: int | None = None,
    chunk_overlap: int | None = None,
    embedding_client: EmbeddingClient | None = None,
) -> dict:
    """Ingest a document through the full RAG pipeline.

    Steps:
    1. Chunk the document text
    2. Generate embeddings for each chunk
    3. Store embeddings in the vector store

    Returns {"document_id": str, "chunk_count": int, "status": str}.
    """
    logger.info("ingestion_started", document_id=document_id, content_length=len(content))

    try:
        # Step 1: Chunk
        chunks = chunk_text(content, chunk_size=chunk_size, chunk_overlap=chunk_overlap)
        logger.info("chunking_complete", document_id=document_id, chunk_count=len(chunks))

        if not chunks:
            return {
                "document_id": document_id,
                "chunk_count": 0,
                "status": "completed",
            }

        # Step 2 & 3: Embed and store
        stored_count = await embed_and_store_chunks(
            chunks=chunks,
            document_id=document_id,
            vector_store=vector_store,
            embedding_client=embedding_client,
        )

        logger.info("ingestion_complete", document_id=document_id, chunks_stored=stored_count)

        return {
            "document_id": document_id,
            "chunk_count": stored_count,
            "status": "completed",
        }

    except Exception as exc:
        logger.exception("ingestion_failed", document_id=document_id, error=str(exc))
        return {
            "document_id": document_id,
            "chunk_count": 0,
            "status": "failed",
            "error": str(exc),
        }
