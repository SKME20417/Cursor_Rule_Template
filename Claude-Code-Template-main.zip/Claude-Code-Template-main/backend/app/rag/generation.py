"""RAG response generation with source attribution."""

import structlog

from app.ai.guardrails import sanitize_output
from app.ai.llm_client import LLMClient, get_llm_client

logger = structlog.get_logger()

RAG_SYSTEM_PROMPT = """You are a helpful customer support assistant. Answer the user's question based ONLY on the provided context. If the context does not contain enough information, say so clearly. Do not make up information.

Always cite the source when using information from the context."""

RAG_PROMPT = """Answer the following question using ONLY the provided context.

**Context:**
{context}

**Question:**
{question}

**Answer:**"""


async def generate_rag_response(
    question: str,
    retrieved_chunks: list[dict],
    llm_client: LLMClient | None = None,
) -> dict:
    """Generate a response using retrieved context.

    Returns {"answer": str, "sources": list[dict], "has_context": bool}.
    """
    client = llm_client or get_llm_client()

    if not retrieved_chunks:
        return {
            "answer": "I couldn't find relevant information to answer your question. Please contact our support team for further assistance.",
            "sources": [],
            "has_context": False,
        }

    # Build context from chunks
    context_parts = []
    sources = []
    for i, chunk in enumerate(retrieved_chunks):
        context_parts.append(f"[Source {i + 1}]: {chunk.get('content', '')}")
        sources.append({
            "id": chunk.get("id"),
            "score": chunk.get("score"),
            "document_id": chunk.get("metadata", {}).get("document_id"),
        })

    context = "\n\n".join(context_parts)
    prompt = RAG_PROMPT.format(context=context, question=question)

    answer = await client.generate(
        prompt=prompt,
        system_prompt=RAG_SYSTEM_PROMPT,
        temperature=0.3,
        max_tokens=1024,
    )

    answer = sanitize_output(answer)

    logger.info("rag_generation", question_preview=question[:80], sources_count=len(sources))

    return {
        "answer": answer,
        "sources": sources,
        "has_context": True,
    }
