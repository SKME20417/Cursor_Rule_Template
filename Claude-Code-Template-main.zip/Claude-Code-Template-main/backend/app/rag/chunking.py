"""Text chunking with configurable size and overlap."""

from app.config import get_settings

settings = get_settings()

DEFAULT_SEPARATORS = ["\n\n", "\n", ". ", " ", ""]


def chunk_text(
    text: str,
    chunk_size: int | None = None,
    chunk_overlap: int | None = None,
    separators: list[str] | None = None,
) -> list[str]:
    """Split text into overlapping chunks using hierarchical separators.

    Tries the first separator first. If a chunk is still too large,
    recursively splits with the next separator.
    """
    chunk_size = chunk_size or settings.rag_chunk_size
    chunk_overlap = chunk_overlap or settings.rag_chunk_overlap
    separators = separators or DEFAULT_SEPARATORS

    if not text or not text.strip():
        return []

    def _split_recursive(text: str, seps: list[str]) -> list[str]:
        if len(text) <= chunk_size:
            return [text.strip()] if text.strip() else []

        if not seps:
            # No separators left — hard split
            chunks = []
            for i in range(0, len(text), chunk_size - chunk_overlap):
                chunk = text[i : i + chunk_size].strip()
                if chunk:
                    chunks.append(chunk)
            return chunks

        sep = seps[0]
        remaining_seps = seps[1:]

        if sep not in text:
            return _split_recursive(text, remaining_seps)

        parts = text.split(sep)
        chunks: list[str] = []
        current = ""

        for part in parts:
            candidate = f"{current}{sep}{part}" if current else part
            if len(candidate) <= chunk_size:
                current = candidate
            else:
                if current.strip():
                    chunks.append(current.strip())
                # If the part itself is too big, split it further
                if len(part) > chunk_size:
                    sub_chunks = _split_recursive(part, remaining_seps)
                    chunks.extend(sub_chunks)
                    current = ""
                else:
                    current = part

        if current.strip():
            chunks.append(current.strip())

        # Apply overlap
        if chunk_overlap > 0 and len(chunks) > 1:
            overlapped: list[str] = [chunks[0]]
            for i in range(1, len(chunks)):
                prev_tail = chunks[i - 1][-chunk_overlap:]
                overlapped.append(prev_tail + chunks[i])
            return overlapped

        return chunks

    return _split_recursive(text, separators)
