"""Abstract vector store with pgvector implementation."""

from abc import ABC, abstractmethod
from uuid import UUID

import structlog

logger = structlog.get_logger()


class VectorStore(ABC):
    """Abstract vector store interface."""

    @abstractmethod
    async def upsert(self, id: str, embedding: list[float], metadata: dict) -> None:
        """Insert or update a vector."""
        ...

    @abstractmethod
    async def search(
        self, query_embedding: list[float], top_k: int = 5, filters: dict | None = None
    ) -> list[dict]:
        """Search for similar vectors. Returns list of {id, score, metadata}."""
        ...

    @abstractmethod
    async def delete(self, ids: list[str]) -> None:
        """Delete vectors by IDs."""
        ...


class PgVectorStore(VectorStore):
    """PostgreSQL pgvector implementation.

    Requires the pgvector extension and a 'document_chunks' table:
    CREATE TABLE document_chunks (
        id UUID PRIMARY KEY,
        document_id UUID,
        content TEXT,
        embedding vector(1536),
        metadata JSONB,
        created_at TIMESTAMPTZ DEFAULT now()
    );
    CREATE INDEX ON document_chunks USING ivfflat (embedding vector_cosine_ops);
    """

    def __init__(self, session_factory):
        self._session_factory = session_factory

    async def upsert(self, id: str, embedding: list[float], metadata: dict) -> None:
        async with self._session_factory() as session:
            embedding_str = "[" + ",".join(str(v) for v in embedding) + "]"
            await session.execute(
                """
                INSERT INTO document_chunks (id, document_id, content, embedding, metadata)
                VALUES (:id, :doc_id, :content, :embedding::vector, :metadata::jsonb)
                ON CONFLICT (id) DO UPDATE SET
                    embedding = EXCLUDED.embedding,
                    metadata = EXCLUDED.metadata
                """,
                {
                    "id": id,
                    "doc_id": metadata.get("document_id"),
                    "content": metadata.get("content", ""),
                    "embedding": embedding_str,
                    "metadata": metadata,
                },
            )
            await session.commit()

    async def search(
        self, query_embedding: list[float], top_k: int = 5, filters: dict | None = None
    ) -> list[dict]:
        async with self._session_factory() as session:
            embedding_str = "[" + ",".join(str(v) for v in query_embedding) + "]"
            result = await session.execute(
                """
                SELECT id, content, metadata,
                       1 - (embedding <=> :query::vector) AS score
                FROM document_chunks
                ORDER BY embedding <=> :query::vector
                LIMIT :top_k
                """,
                {"query": embedding_str, "top_k": top_k},
            )
            rows = result.fetchall()
            return [
                {"id": str(row.id), "score": float(row.score), "metadata": row.metadata, "content": row.content}
                for row in rows
            ]

    async def delete(self, ids: list[str]) -> None:
        if not ids:
            return
        async with self._session_factory() as session:
            await session.execute(
                "DELETE FROM document_chunks WHERE id = ANY(:ids)",
                {"ids": ids},
            )
            await session.commit()
