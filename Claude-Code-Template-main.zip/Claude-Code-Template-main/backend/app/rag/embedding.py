"""Chunk embedding and vector storage."""

import uuid

import structlog

from app.ai.embeddings import EmbeddingClient
from app.rag.vector_store import VectorStore

logger = structlog.get_logger()


async def embed_and_store_chunks(
    chunks: list[str],
    document_id: str,
    vector_store: VectorStore,
    embedding_client: EmbeddingClient | None = None,
) -> int:
    """Embed text chunks and store them in the vector store.

    Returns the number of chunks stored.
    """
    if not chunks:
        return 0

    client = embedding_client or EmbeddingClient()
    embeddings = await client.embed_batch(chunks)

    for i, (chunk, embedding) in enumerate(zip(chunks, embeddings)):
        chunk_id = str(uuid.uuid5(uuid.NAMESPACE_DNS, f"{document_id}:{i}"))
        metadata = {
            "document_id": document_id,
            "content": chunk,
            "chunk_index": i,
            "total_chunks": len(chunks),
        }
        await vector_store.upsert(chunk_id, embedding, metadata)

    logger.info("chunks_embedded", document_id=document_id, count=len(chunks))
    return len(chunks)
