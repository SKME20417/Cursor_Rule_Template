"""Twilio SMS and Voice adapter."""

import structlog

from app.config import get_settings
from app.integrations.base import BaseAdapter

logger = structlog.get_logger()
settings = get_settings()


class TwilioAdapter(BaseAdapter):
    """Twilio adapter for SMS and voice calls."""

    def __init__(self):
        super().__init__("twilio")

    def _get_client(self):
        from twilio.rest import Client

        return Client(settings.twilio_account_sid, settings.twilio_auth_token)

    async def test_connection(self) -> dict:
        try:
            client = self._get_client()
            account = client.api.accounts(settings.twilio_account_sid).fetch()
            self._record_success()
            return {"success": True, "message": f"Connected to {account.friendly_name}"}
        except Exception as exc:
            self._record_failure()
            return {"success": False, "message": str(exc)}

    async def sync(self) -> dict:
        return {"status": "ok"}

    async def send_sms(self, to: str, body: str) -> dict:
        """Send an SMS message."""
        try:
            client = self._get_client()
            message = client.messages.create(
                to=to,
                from_=settings.twilio_phone_number,
                body=body,
            )
            self._record_success()
            logger.info("sms_sent", to=to, sid=message.sid)
            return {"sid": message.sid, "status": message.status}
        except Exception as exc:
            self._record_failure()
            logger.error("sms_failed", to=to, error=str(exc))
            raise

    async def make_call(self, to: str, twiml_url: str) -> dict:
        """Initiate an outbound voice call."""
        try:
            client = self._get_client()
            call = client.calls.create(
                to=to,
                from_=settings.twilio_phone_number,
                url=twiml_url,
            )
            self._record_success()
            logger.info("call_initiated", to=to, sid=call.sid)
            return {"sid": call.sid, "status": call.status}
        except Exception as exc:
            self._record_failure()
            logger.error("call_failed", to=to, error=str(exc))
            raise
