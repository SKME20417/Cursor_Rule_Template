"""AWS SES email adapter."""

import structlog

from app.config import get_settings
from app.integrations.base import BaseAdapter

logger = structlog.get_logger()
settings = get_settings()


class SESAdapter(BaseAdapter):
    """AWS Simple Email Service adapter."""

    def __init__(self):
        super().__init__("ses")

    def _get_client(self):
        import boto3

        return boto3.client(
            "ses",
            aws_access_key_id=settings.aws_access_key_id,
            aws_secret_access_key=settings.aws_secret_access_key,
            region_name=settings.aws_region,
        )

    async def test_connection(self) -> dict:
        try:
            client = self._get_client()
            client.get_send_quota()
            self._record_success()
            return {"success": True, "message": "SES connection successful"}
        except Exception as exc:
            self._record_failure()
            return {"success": False, "message": str(exc)}

    async def sync(self) -> dict:
        return {"status": "ok"}

    async def send_email(
        self,
        to: list[str],
        subject: str,
        html_body: str,
        text_body: str | None = None,
        reply_to: str | None = None,
    ) -> dict:
        """Send an email via SES."""
        try:
            client = self._get_client()
            destination = {"ToAddresses": to}
            body: dict = {"Html": {"Charset": "UTF-8", "Data": html_body}}
            if text_body:
                body["Text"] = {"Charset": "UTF-8", "Data": text_body}

            kwargs: dict = {
                "Source": settings.aws_ses_sender_email,
                "Destination": destination,
                "Message": {
                    "Subject": {"Charset": "UTF-8", "Data": subject},
                    "Body": body,
                },
            }
            if reply_to:
                kwargs["ReplyToAddresses"] = [reply_to]

            response = client.send_email(**kwargs)
            message_id = response["MessageId"]
            self._record_success()
            logger.info("email_sent", to=to, message_id=message_id)
            return {"message_id": message_id}
        except Exception as exc:
            self._record_failure()
            logger.error("email_send_failed", to=to, error=str(exc))
            raise
