"""HubSpot CRM adapter."""

import httpx
import structlog

from app.config import get_settings
from app.integrations.base import BaseAdapter

logger = structlog.get_logger()
settings = get_settings()


class HubSpotAdapter(BaseAdapter):
    """HubSpot CRM integration."""

    def __init__(self):
        super().__init__("hubspot")
        self.base_url = "https://api.hubapi.com"

    def _headers(self) -> dict:
        return {
            "Authorization": f"Bearer {settings.hubspot_api_key}",
            "Content-Type": "application/json",
        }

    async def test_connection(self) -> dict:
        try:
            async with httpx.AsyncClient() as client:
                resp = await client.get(
                    f"{self.base_url}/crm/v3/objects/contacts?limit=1",
                    headers=self._headers(),
                )
            if resp.status_code == 200:
                self._record_success()
                return {"success": True, "message": "HubSpot connected"}
            self._record_failure()
            return {"success": False, "message": f"HTTP {resp.status_code}"}
        except Exception as exc:
            self._record_failure()
            return {"success": False, "message": str(exc)}

    async def sync(self) -> dict:
        return {"status": "ok"}
