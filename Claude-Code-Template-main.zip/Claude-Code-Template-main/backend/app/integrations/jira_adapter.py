"""Jira issue tracker adapter."""

import base64

import httpx
import structlog

from app.config import get_settings
from app.integrations.base import BaseAdapter

logger = structlog.get_logger()
settings = get_settings()


class JiraAdapter(BaseAdapter):
    """Jira integration for ticket escalation."""

    def __init__(self):
        super().__init__("jira")
        self.base_url = f"{settings.jira_base_url}/rest/api/3"

    def _headers(self) -> dict:
        creds = f"{settings.jira_email}:{settings.jira_api_token}"
        encoded = base64.b64encode(creds.encode()).decode()
        return {"Authorization": f"Basic {encoded}", "Content-Type": "application/json"}

    async def test_connection(self) -> dict:
        try:
            async with httpx.AsyncClient() as client:
                resp = await client.get(f"{self.base_url}/myself", headers=self._headers())
            if resp.status_code == 200:
                self._record_success()
                return {"success": True, "message": "Jira connected"}
            self._record_failure()
            return {"success": False, "message": f"HTTP {resp.status_code}"}
        except Exception as exc:
            self._record_failure()
            return {"success": False, "message": str(exc)}

    async def sync(self) -> dict:
        return {"status": "ok"}

    async def create_issue(self, project_key: str, summary: str, description: str) -> dict:
        """Create a Jira issue."""
        payload = {
            "fields": {
                "project": {"key": project_key},
                "summary": summary,
                "description": {"type": "doc", "version": 1, "content": [
                    {"type": "paragraph", "content": [{"type": "text", "text": description}]}
                ]},
                "issuetype": {"name": "Task"},
            }
        }
        async with httpx.AsyncClient() as client:
            resp = await client.post(f"{self.base_url}/issue", headers=self._headers(), json=payload)
        if resp.status_code == 201:
            self._record_success()
            return resp.json()
        self._record_failure()
        raise Exception(f"Jira issue creation failed: {resp.text}")
