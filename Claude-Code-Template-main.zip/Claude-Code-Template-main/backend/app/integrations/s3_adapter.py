"""AWS S3 file storage adapter."""

import uuid

import structlog

from app.config import get_settings
from app.integrations.base import BaseAdapter

logger = structlog.get_logger()
settings = get_settings()


class S3Adapter(BaseAdapter):
    """AWS S3 file upload and retrieval."""

    def __init__(self):
        super().__init__("s3")

    def _get_client(self):
        import boto3

        return boto3.client(
            "s3",
            aws_access_key_id=settings.aws_access_key_id,
            aws_secret_access_key=settings.aws_secret_access_key,
            region_name=settings.aws_region,
        )

    async def test_connection(self) -> dict:
        try:
            client = self._get_client()
            client.head_bucket(Bucket=settings.aws_s3_bucket)
            self._record_success()
            return {"success": True, "message": "S3 connection successful"}
        except Exception as exc:
            self._record_failure()
            return {"success": False, "message": str(exc)}

    async def sync(self) -> dict:
        return {"status": "not_applicable"}

    async def upload_file(
        self,
        file_content: bytes,
        file_name: str,
        content_type: str,
        folder: str = "uploads",
    ) -> dict:
        """Upload a file to S3. Returns {url, key, size}."""
        key = f"{folder}/{uuid.uuid4()}/{file_name}"

        try:
            client = self._get_client()
            client.put_object(
                Bucket=settings.aws_s3_bucket,
                Key=key,
                Body=file_content,
                ContentType=content_type,
            )
            url = f"https://{settings.aws_s3_bucket}.s3.{settings.aws_region}.amazonaws.com/{key}"
            self._record_success()
            logger.info("s3_upload_success", key=key, size=len(file_content))
            return {"url": url, "key": key, "size": len(file_content)}
        except Exception as exc:
            self._record_failure()
            logger.error("s3_upload_failed", error=str(exc))
            raise
