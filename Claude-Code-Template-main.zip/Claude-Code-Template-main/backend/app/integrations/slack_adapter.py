"""Slack Bot adapter."""

import httpx
import structlog

from app.config import get_settings
from app.integrations.base import BaseAdapter

logger = structlog.get_logger()
settings = get_settings()


class SlackAdapter(BaseAdapter):
    """Slack Bot integration for channel notifications and support."""

    def __init__(self):
        super().__init__("slack")
        self.base_url = "https://slack.com/api"

    def _headers(self) -> dict:
        return {
            "Authorization": f"Bearer {settings.slack_bot_token}",
            "Content-Type": "application/json; charset=utf-8",
        }

    async def test_connection(self) -> dict:
        try:
            async with httpx.AsyncClient() as client:
                resp = await client.post(
                    f"{self.base_url}/auth.test",
                    headers=self._headers(),
                )
                data = resp.json()
            if data.get("ok"):
                self._record_success()
                return {"success": True, "message": f"Connected as {data.get('user')}"}
            self._record_failure()
            return {"success": False, "message": data.get("error", "Unknown error")}
        except Exception as exc:
            self._record_failure()
            return {"success": False, "message": str(exc)}

    async def sync(self) -> dict:
        return {"status": "ok"}

    async def send_message(self, channel: str, text: str, blocks: list | None = None) -> dict:
        """Send a message to a Slack channel."""
        payload: dict = {"channel": channel, "text": text}
        if blocks:
            payload["blocks"] = blocks

        async with httpx.AsyncClient() as client:
            resp = await client.post(
                f"{self.base_url}/chat.postMessage",
                headers=self._headers(),
                json=payload,
            )
            data = resp.json()

        if data.get("ok"):
            self._record_success()
            logger.info("slack_message_sent", channel=channel)
            return {"ts": data.get("ts"), "channel": data.get("channel")}

        self._record_failure()
        logger.error("slack_message_failed", error=data.get("error"))
        raise Exception(f"Slack API error: {data.get('error')}")
