"""Zendesk helpdesk adapter."""

import base64

import httpx
import structlog

from app.config import get_settings
from app.integrations.base import BaseAdapter

logger = structlog.get_logger()
settings = get_settings()


class ZendeskAdapter(BaseAdapter):
    """Zendesk integration for ticket sync."""

    def __init__(self):
        super().__init__("zendesk")
        self.base_url = f"https://{settings.zendesk_subdomain}.zendesk.com/api/v2"

    def _headers(self) -> dict:
        creds = f"{settings.zendesk_email}/token:{settings.zendesk_api_token}"
        encoded = base64.b64encode(creds.encode()).decode()
        return {"Authorization": f"Basic {encoded}", "Content-Type": "application/json"}

    async def test_connection(self) -> dict:
        try:
            async with httpx.AsyncClient() as client:
                resp = await client.get(f"{self.base_url}/users/me.json", headers=self._headers())
            if resp.status_code == 200:
                self._record_success()
                return {"success": True, "message": "Zendesk connected"}
            self._record_failure()
            return {"success": False, "message": f"HTTP {resp.status_code}"}
        except Exception as exc:
            self._record_failure()
            return {"success": False, "message": str(exc)}

    async def sync(self) -> dict:
        return {"status": "ok"}
