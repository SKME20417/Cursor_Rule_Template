"""WhatsApp Business API adapter."""

import httpx
import structlog

from app.config import get_settings
from app.integrations.base import BaseAdapter

logger = structlog.get_logger()
settings = get_settings()


class WhatsAppAdapter(BaseAdapter):
    """Meta WhatsApp Business API integration."""

    def __init__(self):
        super().__init__("whatsapp")
        self.base_url = f"https://graph.facebook.com/v18.0/{settings.whatsapp_phone_number_id}"

    def _headers(self) -> dict:
        return {
            "Authorization": f"Bearer {settings.whatsapp_api_token}",
            "Content-Type": "application/json",
        }

    async def test_connection(self) -> dict:
        try:
            async with httpx.AsyncClient() as client:
                resp = await client.get(self.base_url, headers=self._headers())
            if resp.status_code == 200:
                self._record_success()
                return {"success": True, "message": "WhatsApp API connected"}
            self._record_failure()
            return {"success": False, "message": f"HTTP {resp.status_code}"}
        except Exception as exc:
            self._record_failure()
            return {"success": False, "message": str(exc)}

    async def sync(self) -> dict:
        return {"status": "ok"}

    async def send_text_message(self, to: str, text: str) -> dict:
        """Send a text message via WhatsApp."""
        payload = {
            "messaging_product": "whatsapp",
            "to": to,
            "type": "text",
            "text": {"body": text},
        }
        async with httpx.AsyncClient() as client:
            resp = await client.post(
                f"{self.base_url}/messages",
                headers=self._headers(),
                json=payload,
            )
            data = resp.json()

        if "messages" in data:
            self._record_success()
            msg_id = data["messages"][0]["id"]
            logger.info("whatsapp_message_sent", to=to, message_id=msg_id)
            return {"message_id": msg_id}

        self._record_failure()
        error = data.get("error", {}).get("message", "Unknown error")
        logger.error("whatsapp_send_failed", to=to, error=error)
        raise Exception(f"WhatsApp API error: {error}")
