"""Abstract integration adapter with circuit breaker pattern."""

from abc import ABC, abstractmethod
from enum import StrEnum

import structlog

logger = structlog.get_logger()


class IntegrationStatus(StrEnum):
    CONNECTED = "connected"
    DISCONNECTED = "disconnected"
    ERROR = "error"
    PENDING = "pending"


class BaseAdapter(ABC):
    """Base class for all third-party integration adapters."""

    def __init__(self, name: str):
        self.name = name
        self._failure_count = 0
        self._max_failures = 5
        self._circuit_open = False

    @abstractmethod
    async def test_connection(self) -> dict:
        """Test the connection to the external service.

        Returns {"success": bool, "message": str}.
        """
        ...

    @abstractmethod
    async def sync(self) -> dict:
        """Perform a sync operation with the external service."""
        ...

    def _record_success(self) -> None:
        self._failure_count = 0
        self._circuit_open = False

    def _record_failure(self) -> None:
        self._failure_count += 1
        if self._failure_count >= self._max_failures:
            self._circuit_open = True
            logger.error("circuit_breaker_open", adapter=self.name)

    @property
    def is_available(self) -> bool:
        return not self._circuit_open
