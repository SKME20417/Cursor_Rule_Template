"""Salesforce CRM adapter."""

import httpx
import structlog

from app.config import get_settings
from app.integrations.base import BaseAdapter

logger = structlog.get_logger()
settings = get_settings()


class SalesforceAdapter(BaseAdapter):
    """Salesforce CRM integration for contact and case sync."""

    def __init__(self):
        super().__init__("salesforce")
        self._access_token: str | None = None
        self._instance_url: str = settings.salesforce_instance_url

    async def _authenticate(self) -> str:
        """Obtain an OAuth2 access token."""
        async with httpx.AsyncClient() as client:
            resp = await client.post(
                f"{self._instance_url}/services/oauth2/token",
                data={
                    "grant_type": "client_credentials",
                    "client_id": settings.salesforce_client_id,
                    "client_secret": settings.salesforce_client_secret,
                },
            )
            data = resp.json()
        self._access_token = data["access_token"]
        self._instance_url = data.get("instance_url", self._instance_url)
        return self._access_token

    async def test_connection(self) -> dict:
        try:
            await self._authenticate()
            self._record_success()
            return {"success": True, "message": "Salesforce connected"}
        except Exception as exc:
            self._record_failure()
            return {"success": False, "message": str(exc)}

    async def sync(self) -> dict:
        return {"status": "ok"}

    async def create_contact(self, email: str, first_name: str, last_name: str) -> dict:
        """Create a contact in Salesforce."""
        if not self._access_token:
            await self._authenticate()
        async with httpx.AsyncClient() as client:
            resp = await client.post(
                f"{self._instance_url}/services/data/v59.0/sobjects/Contact",
                headers={"Authorization": f"Bearer {self._access_token}"},
                json={"Email": email, "FirstName": first_name, "LastName": last_name},
            )
        if resp.status_code == 201:
            self._record_success()
            return resp.json()
        self._record_failure()
        raise Exception(f"Salesforce create failed: {resp.text}")
