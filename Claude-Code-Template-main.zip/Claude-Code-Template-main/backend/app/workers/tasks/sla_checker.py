"""Periodic SLA breach detection task."""

import asyncio
from datetime import UTC, datetime

import structlog

from app.workers.celery_app import celery_app

logger = structlog.get_logger()


@celery_app.task
def check_sla_breaches() -> dict:
    """Check for tickets approaching or breaching SLA deadlines."""
    return asyncio.get_event_loop().run_until_complete(_check_breaches())


async def _check_breaches() -> dict:
    from sqlalchemy import select

    from app.core.database import async_session_factory
    from app.models.ticket import Ticket

    now = datetime.now(UTC)
    breached_count = 0
    warning_count = 0

    async with async_session_factory() as session:
        # Find tickets with SLA breach time in the past that aren't resolved/closed
        result = await session.execute(
            select(Ticket).where(
                Ticket.sla_breach_at.isnot(None),
                Ticket.sla_breach_at <= now,
                Ticket.status.notin_(["resolved", "closed"]),
            )
        )
        breached_tickets = result.scalars().all()
        breached_count = len(breached_tickets)

        for ticket in breached_tickets:
            logger.warning(
                "sla_breached",
                ticket_id=str(ticket.id),
                sla_breach_at=str(ticket.sla_breach_at),
            )

    logger.info(
        "sla_check_complete",
        breached=breached_count,
        warnings=warning_count,
    )

    return {"breached": breached_count, "warnings": warning_count}
