"""Background metrics computation task."""

import asyncio

import structlog

from app.workers.celery_app import celery_app

logger = structlog.get_logger()


@celery_app.task
def aggregate_analytics() -> dict:
    """Compute and cache dashboard metrics."""
    return asyncio.get_event_loop().run_until_complete(_aggregate())


async def _aggregate() -> dict:
    from sqlalchemy import func, select

    from app.core.database import async_session_factory
    from app.core.redis import redis_client
    from app.models.conversation import Conversation
    from app.models.ticket import Ticket

    async with async_session_factory() as session:
        # Count active conversations
        conv_result = await session.execute(
            select(func.count()).select_from(Conversation).where(
                Conversation.status.in_(["open", "assigned", "pending"])
            )
        )
        active_conversations = conv_result.scalar() or 0

        # Count open tickets
        ticket_result = await session.execute(
            select(func.count()).select_from(Ticket).where(
                Ticket.status.in_(["created", "assigned", "in_progress"])
            )
        )
        open_tickets = ticket_result.scalar() or 0

    # Cache metrics in Redis
    import json

    metrics = {
        "active_conversations": active_conversations,
        "open_tickets": open_tickets,
    }
    await redis_client.set("analytics:dashboard", json.dumps(metrics), ex=300)

    logger.info("analytics_aggregated", metrics=metrics)
    return metrics
