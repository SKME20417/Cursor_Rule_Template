"""Outbound webhook dispatch with retry."""

import hashlib
import hmac
import json

import httpx
import structlog

from app.workers.celery_app import celery_app

logger = structlog.get_logger()


@celery_app.task(bind=True, max_retries=5, default_retry_delay=30)
def deliver_webhook(
    self,
    webhook_url: str,
    method: str,
    payload: dict,
    headers: dict | None = None,
    secret_key: str | None = None,
) -> dict:
    """Send an outbound webhook with exponential backoff retry."""
    import asyncio

    try:
        return asyncio.get_event_loop().run_until_complete(
            _deliver(webhook_url, method, payload, headers or {}, secret_key)
        )
    except Exception as exc:
        retry_delay = 30 * (2 ** self.request.retries)
        logger.warning(
            "webhook_delivery_retry",
            url=webhook_url,
            attempt=self.request.retries + 1,
            next_retry_seconds=retry_delay,
        )
        raise self.retry(exc=exc, countdown=retry_delay)


async def _deliver(
    url: str, method: str, payload: dict, headers: dict, secret_key: str | None
) -> dict:
    body = json.dumps(payload, default=str)

    request_headers = {
        "Content-Type": "application/json",
        "User-Agent": "AI-Support-Copilot-Webhook/1.0",
        **headers,
    }

    # Sign the payload if a secret key is provided
    if secret_key:
        signature = hmac.new(
            secret_key.encode(), body.encode(), hashlib.sha256
        ).hexdigest()
        request_headers["X-Webhook-Signature"] = f"sha256={signature}"

    async with httpx.AsyncClient(timeout=30.0) as client:
        response = await client.request(
            method=method.upper(),
            url=url,
            content=body,
            headers=request_headers,
        )

    logger.info(
        "webhook_delivered",
        url=url,
        status_code=response.status_code,
        method=method,
    )

    if response.status_code >= 400:
        raise Exception(f"Webhook failed with status {response.status_code}: {response.text[:500]}")

    return {"status_code": response.status_code, "url": url}
