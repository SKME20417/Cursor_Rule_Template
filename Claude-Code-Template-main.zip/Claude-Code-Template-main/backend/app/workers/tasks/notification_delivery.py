"""Async notification delivery task."""

import asyncio

import structlog

from app.workers.celery_app import celery_app

logger = structlog.get_logger()


@celery_app.task(bind=True, max_retries=3, default_retry_delay=30)
def deliver_notification(self, user_id: str, notification_data: dict) -> dict:
    """Deliver a notification via WebSocket and persist it."""
    try:
        return asyncio.get_event_loop().run_until_complete(
            _deliver(user_id, notification_data)
        )
    except Exception as exc:
        logger.exception("notification_delivery_failed", user_id=user_id)
        raise self.retry(exc=exc)


async def _deliver(user_id: str, notification_data: dict) -> dict:
    from uuid import UUID

    from app.core.database import async_session_factory
    from app.models.notification import Notification
    from app.websockets.manager import ws_manager

    # Persist notification
    async with async_session_factory() as session:
        notification = Notification(
            user_id=UUID(user_id),
            type=notification_data.get("type", "system"),
            priority=notification_data.get("priority", "normal"),
            title=notification_data["title"],
            body=notification_data.get("body", ""),
            link_url=notification_data.get("link_url"),
        )
        session.add(notification)
        await session.commit()
        await session.refresh(notification)

    # Push via WebSocket
    await ws_manager.send_to_user(UUID(user_id), {
        "type": "notification",
        "payload": notification_data,
    })

    logger.info("notification_delivered", user_id=user_id, type=notification_data.get("type"))
    return {"status": "delivered", "notification_id": str(notification.id)}
