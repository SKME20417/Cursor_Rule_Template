"""Async call transcription task."""

import asyncio

import structlog

from app.workers.celery_app import celery_app

logger = structlog.get_logger()


@celery_app.task(bind=True, max_retries=2, default_retry_delay=120)
def transcribe_call(self, call_id: str, recording_url: str) -> dict:
    """Transcribe a call recording."""
    try:
        return asyncio.get_event_loop().run_until_complete(
            _transcribe(call_id, recording_url)
        )
    except Exception as exc:
        logger.exception("transcription_failed", call_id=call_id)
        raise self.retry(exc=exc)


async def _transcribe(call_id: str, recording_url: str) -> dict:
    """Run transcription using OpenAI Whisper API."""
    from uuid import UUID

    from app.core.database import async_session_factory

    logger.info("transcription_started", call_id=call_id)

    # In production, download audio and call Whisper or AWS Transcribe
    # For now, create a placeholder transcript
    async with async_session_factory() as session:
        from app.models.transcript import Transcript

        transcript = Transcript(
            call_id=UUID(call_id),
            language="en",
        )
        session.add(transcript)
        await session.commit()
        await session.refresh(transcript)

    logger.info("transcription_complete", call_id=call_id, transcript_id=str(transcript.id))

    return {
        "call_id": call_id,
        "transcript_id": str(transcript.id),
        "status": "completed",
    }
