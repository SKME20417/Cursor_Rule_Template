"""Background task for document ingestion through the RAG pipeline."""

import asyncio

import structlog

from app.workers.celery_app import celery_app

logger = structlog.get_logger()


@celery_app.task(bind=True, max_retries=3, default_retry_delay=60)
def ingest_document_task(self, document_id: str, content: str) -> dict:
    """Process a document through the RAG ingestion pipeline.

    This is a Celery task wrapper around the async ingestion pipeline.
    """
    logger.info("task_document_ingestion_started", document_id=document_id, task_id=self.request.id)

    try:
        result = asyncio.get_event_loop().run_until_complete(
            _run_ingestion(document_id, content)
        )
        return result
    except Exception as exc:
        logger.exception("task_document_ingestion_failed", document_id=document_id)
        raise self.retry(exc=exc)


async def _run_ingestion(document_id: str, content: str) -> dict:
    """Run the async ingestion pipeline."""
    from app.core.database import async_session_factory
    from app.rag.ingestion import ingest_document
    from app.rag.vector_store import PgVectorStore

    vector_store = PgVectorStore(async_session_factory)
    result = await ingest_document(
        document_id=document_id,
        content=content,
        vector_store=vector_store,
    )

    # Update document status in the database
    async with async_session_factory() as session:
        from app.models.document import Document

        doc = await session.get(Document, document_id)
        if doc:
            doc.status = result["status"]
            doc.chunk_count = result.get("chunk_count", 0)
            doc.error_message = result.get("error")
            await session.commit()

    return result
