"""Celery application configuration."""

from celery import Celery

from app.config import get_settings

settings = get_settings()

broker_url = settings.celery_broker_url or settings.resolved_redis_url
result_backend = settings.celery_result_backend or settings.resolved_redis_url

celery_app = Celery(
    "ai_support_copilot",
    broker=broker_url,
    backend=result_backend,
    include=[
        "app.workers.tasks.document_ingestion",
        "app.workers.tasks.sla_checker",
        "app.workers.tasks.analytics_aggregation",
        "app.workers.tasks.notification_delivery",
        "app.workers.tasks.webhook_delivery",
        "app.workers.tasks.transcription",
    ],
)

celery_app.conf.update(
    task_serializer="json",
    accept_content=["json"],
    result_serializer="json",
    timezone="UTC",
    enable_utc=True,
    task_track_started=True,
    task_acks_late=True,
    worker_prefetch_multiplier=1,
    task_soft_time_limit=300,
    task_time_limit=600,
)
