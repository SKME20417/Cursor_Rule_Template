"""Celery Beat periodic task schedule."""

from celery.schedules import crontab

from app.workers.celery_app import celery_app

celery_app.conf.beat_schedule = {
    "sla-checker-every-minute": {
        "task": "app.workers.tasks.sla_checker.check_sla_breaches",
        "schedule": 60.0,  # every 60 seconds
    },
    "analytics-aggregation-every-5-minutes": {
        "task": "app.workers.tasks.analytics_aggregation.aggregate_analytics",
        "schedule": 300.0,  # every 5 minutes
    },
}
