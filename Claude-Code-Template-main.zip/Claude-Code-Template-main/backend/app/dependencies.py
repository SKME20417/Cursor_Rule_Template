"""Shared FastAPI dependency providers."""

from typing import Annotated
from uuid import UUID

import structlog
from fastapi import Depends, Header, Query
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from jose import JWTError
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_session
from app.core.exceptions import ForbiddenException, UnauthorizedException
from app.core.pagination import PaginationParams
from app.core.security import decode_access_token

logger = structlog.get_logger()

bearer_scheme = HTTPBearer(auto_error=False)


async def get_db(session: AsyncSession = Depends(get_session)) -> AsyncSession:
    """Database session dependency."""
    return session


async def get_current_user(
    credentials: HTTPAuthorizationCredentials | None = Depends(bearer_scheme),
) -> dict:
    """Extract and validate the current user from the Authorization header.

    Returns a dict with 'user_id' (UUID) and 'role' (str).
    """
    if not credentials:
        raise UnauthorizedException()

    try:
        payload = decode_access_token(credentials.credentials)
    except JWTError:
        raise UnauthorizedException("Invalid or expired token")

    user_id_str = payload.get("sub")
    role = payload.get("role")

    if not user_id_str or not role:
        raise UnauthorizedException("Invalid token payload")

    return {"user_id": UUID(user_id_str), "role": role}


def require_role(*allowed_roles: str):
    """Factory for role-checking dependencies.

    Usage: Depends(require_role("admin", "supervisor"))
    """

    async def _check_role(current_user: dict = Depends(get_current_user)) -> dict:
        if current_user["role"] not in allowed_roles:
            raise ForbiddenException(
                f"Role '{current_user['role']}' cannot access this resource"
            )
        return current_user

    return _check_role


async def get_pagination(
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100, alias="pageSize"),
) -> PaginationParams:
    """Parse pagination query params."""
    return PaginationParams(page=page, pageSize=page_size)


# Type aliases for cleaner route signatures
DbSession = Annotated[AsyncSession, Depends(get_db)]
CurrentUser = Annotated[dict, Depends(get_current_user)]
Pagination = Annotated[PaginationParams, Depends(get_pagination)]
AdminUser = Annotated[dict, Depends(require_role("admin"))]
AgentOrAdmin = Annotated[dict, Depends(require_role("admin", "supervisor", "agent"))]
