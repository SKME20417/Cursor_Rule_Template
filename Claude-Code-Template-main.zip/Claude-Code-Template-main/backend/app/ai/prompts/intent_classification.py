"""Prompt templates for intent classification."""

INTENT_SYSTEM_PROMPT = """You are an NLP classifier for customer support messages. Classify user intent accurately."""

INTENT_PROMPT = """Classify the intent of the following customer message.

**Message:**
{text}

Respond with JSON:
```json
{{
  "intents": [
    {{
      "name": "intent_name",
      "confidence": 0.0-1.0,
      "parameters": {{}}
    }}
  ],
  "urgency": "low|medium|high|critical",
  "topics": ["topic1", "topic2"]
}}
```

Common intents: billing_inquiry, technical_support, account_access, feature_request, bug_report, cancellation, refund_request, general_inquiry, complaint, praise"""
