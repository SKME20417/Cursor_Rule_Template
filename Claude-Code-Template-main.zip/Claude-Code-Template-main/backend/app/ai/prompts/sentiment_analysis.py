"""Prompt templates for sentiment analysis."""

SENTIMENT_SYSTEM_PROMPT = """You are a sentiment analysis system for customer support messages."""

SENTIMENT_PROMPT = """Analyze the sentiment of the following text.

**Text:**
{text}

Respond with JSON:
```json
{{
  "label": "positive|neutral|negative",
  "score": 0.0-1.0,
  "magnitude": 0.0-1.0
}}
```

- score: confidence in the label (0-1)
- magnitude: intensity of the sentiment (0=mild, 1=intense)"""
