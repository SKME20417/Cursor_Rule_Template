"""Prompt templates for conversation summarization."""

SUMMARY_SYSTEM_PROMPT = """You are a conversation summarizer for a customer support platform. Create concise, structured summaries."""

SUMMARY_PROMPT = """Summarize the following customer support conversation in 2-3 paragraphs.

Include:
1. The customer's issue or request
2. Key steps taken by the agent
3. Current status and any pending actions

**Conversation:**
{conversation_history}

**Summary:**"""
