"""Prompt templates for language detection."""

LANGUAGE_SYSTEM_PROMPT = """You detect the language of text input and return structured JSON."""

LANGUAGE_PROMPT = """Detect the language of the following text.

**Text:**
{text}

Respond with JSON:
```json
{{
  "languageCode": "en",
  "languageName": "English",
  "confidence": 0.95
}}
```

Use ISO 639-1 codes."""
