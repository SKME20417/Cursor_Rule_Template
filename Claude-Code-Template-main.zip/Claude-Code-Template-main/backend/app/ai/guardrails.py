"""Output validation, confidence checks, and PII masking."""

import re

import structlog

logger = structlog.get_logger()

# Common PII patterns
_EMAIL_PATTERN = re.compile(r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}")
_PHONE_PATTERN = re.compile(r"\b\d{3}[-.]?\d{3}[-.]?\d{4}\b")
_SSN_PATTERN = re.compile(r"\b\d{3}-\d{2}-\d{4}\b")
_CREDIT_CARD_PATTERN = re.compile(r"\b\d{4}[\s-]?\d{4}[\s-]?\d{4}[\s-]?\d{4}\b")


def mask_pii(text: str) -> str:
    """Replace common PII patterns with masked placeholders."""
    text = _SSN_PATTERN.sub("[SSN_REDACTED]", text)
    text = _CREDIT_CARD_PATTERN.sub("[CARD_REDACTED]", text)
    text = _PHONE_PATTERN.sub("[PHONE_REDACTED]", text)
    text = _EMAIL_PATTERN.sub("[EMAIL_REDACTED]", text)
    return text


def check_confidence(confidence: float, threshold: float = 0.5) -> bool:
    """Return True if confidence meets the threshold."""
    return confidence >= threshold


def sanitize_output(text: str, max_length: int = 10000) -> str:
    """Sanitize LLM output: strip, truncate, and mask PII."""
    text = text.strip()
    if len(text) > max_length:
        text = text[:max_length] + "..."
        logger.warning("output_truncated", original_length=len(text), max_length=max_length)
    return mask_pii(text)


def validate_json_output(text: str) -> dict | None:
    """Try to parse JSON from LLM output, returning None on failure."""
    import json

    # Try to extract JSON from markdown code blocks
    json_match = re.search(r"```(?:json)?\s*\n?(.*?)\n?```", text, re.DOTALL)
    if json_match:
        text = json_match.group(1)

    try:
        return json.loads(text)
    except json.JSONDecodeError:
        logger.warning("invalid_json_output", text_preview=text[:200])
        return None
