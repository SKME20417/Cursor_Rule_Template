"""Embedding client for vector search."""

import structlog

from app.config import get_settings

logger = structlog.get_logger()
settings = get_settings()


class EmbeddingClient:
    """Generate text embeddings using OpenAI's embedding API."""

    def __init__(self, model: str | None = None):
        self.model = model or settings.openai_embedding_model

    async def embed_text(self, text: str) -> list[float]:
        """Generate embedding for a single text."""
        from openai import AsyncOpenAI

        client = AsyncOpenAI(api_key=settings.openai_api_key)
        response = await client.embeddings.create(
            model=self.model,
            input=text,
        )
        return response.data[0].embedding

    async def embed_batch(self, texts: list[str], batch_size: int = 100) -> list[list[float]]:
        """Generate embeddings for multiple texts in batches."""
        from openai import AsyncOpenAI

        client = AsyncOpenAI(api_key=settings.openai_api_key)
        all_embeddings: list[list[float]] = []

        for i in range(0, len(texts), batch_size):
            batch = texts[i : i + batch_size]
            response = await client.embeddings.create(
                model=self.model,
                input=batch,
            )
            batch_embeddings = [item.embedding for item in response.data]
            all_embeddings.extend(batch_embeddings)
            logger.debug("embeddings_batch", batch_index=i, batch_size=len(batch))

        return all_embeddings
