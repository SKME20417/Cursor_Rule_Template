"""Pydantic v2 schemas for tickets and SLA policies."""

from datetime import datetime
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field


# ── Response Schemas ───────────────────────────────────────────────


class TicketCategoryResponse(BaseModel):
    """Ticket category for routing and reporting."""

    model_config = ConfigDict(from_attributes=True, populate_by_name=True)

    id: UUID
    name: str
    description: str | None = Field(default=None)
    parent_id: UUID | None = Field(default=None, alias="parentId")
    created_at: datetime = Field(alias="createdAt")


class TicketResponse(BaseModel):
    """Support ticket."""

    model_config = ConfigDict(from_attributes=True, populate_by_name=True)

    id: UUID
    conversation_id: UUID | None = Field(default=None, alias="conversationId")
    customer_id: UUID = Field(alias="customerId")
    assigned_agent_id: UUID | None = Field(default=None, alias="assignedAgentId")
    team_id: UUID | None = Field(default=None, alias="teamId")
    subject: str
    description: str
    status: str
    priority: str
    category_id: UUID | None = Field(default=None, alias="categoryId")
    channel: str
    tags: list[str] = Field(default_factory=list)
    sla_policy_id: UUID | None = Field(default=None, alias="slaPolicyId")
    sla_breach_at: datetime | None = Field(default=None, alias="slaBreachAt")
    first_response_at: datetime | None = Field(
        default=None, alias="firstResponseAt"
    )
    resolved_at: datetime | None = Field(default=None, alias="resolvedAt")
    closed_at: datetime | None = Field(default=None, alias="closedAt")
    created_at: datetime = Field(alias="createdAt")
    updated_at: datetime = Field(alias="updatedAt")


class TicketCommentResponse(BaseModel):
    """Comment or internal note on a ticket."""

    model_config = ConfigDict(from_attributes=True, populate_by_name=True)

    id: UUID
    ticket_id: UUID = Field(alias="ticketId")
    author_id: UUID = Field(alias="authorId")
    content: str
    is_internal: bool = Field(alias="isInternal")
    created_at: datetime = Field(alias="createdAt")
    updated_at: datetime = Field(alias="updatedAt")


class SLAPolicyResponse(BaseModel):
    """SLA policy defining response and resolution time targets."""

    model_config = ConfigDict(from_attributes=True, populate_by_name=True)

    id: UUID
    name: str
    description: str | None = Field(default=None)
    first_response_minutes: int = Field(alias="firstResponseMinutes")
    resolution_minutes: int = Field(alias="resolutionMinutes")
    priority: str
    is_active: bool = Field(alias="isActive")
    created_at: datetime = Field(alias="createdAt")
    updated_at: datetime = Field(alias="updatedAt")


# ── Request Schemas ────────────────────────────────────────────────


class CreateTicketRequest(BaseModel):
    """Create a new ticket."""

    model_config = ConfigDict(populate_by_name=True)

    subject: str
    description: str
    priority: str
    channel: str
    customer_id: UUID = Field(alias="customerId")
    category_id: UUID | None = Field(default=None, alias="categoryId")
    tags: list[str] | None = Field(default=None)


class UpdateTicketRequest(BaseModel):
    """Update an existing ticket."""

    model_config = ConfigDict(populate_by_name=True)

    status: str | None = Field(default=None)
    priority: str | None = Field(default=None)
    assigned_agent_id: UUID | None = Field(default=None, alias="assignedAgentId")
    team_id: UUID | None = Field(default=None, alias="teamId")
    tags: list[str] | None = Field(default=None)


class CreateTicketCommentRequest(BaseModel):
    """Add a comment to a ticket."""

    model_config = ConfigDict(populate_by_name=True)

    content: str
    is_internal: bool = Field(default=False, alias="isInternal")
