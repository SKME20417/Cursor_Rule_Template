"""Pydantic v2 schema package for the AI Support Copilot backend."""
