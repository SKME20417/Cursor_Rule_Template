"""Pydantic v2 schemas for system monitoring, health checks, and alerting."""

from datetime import datetime
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field


# ── Response Schemas ───────────────────────────────────────────────


class ServiceHealthResponse(BaseModel):
    """Service health status."""

    model_config = ConfigDict(from_attributes=True, populate_by_name=True)

    id: UUID
    service_name: str = Field(alias="serviceName")
    status: str
    latency_ms: float | None = Field(default=None, alias="latencyMs")
    uptime_percent: float = Field(alias="uptimePercent")
    last_checked_at: datetime = Field(alias="lastCheckedAt")
    details: str | None = Field(default=None)


class QueueMetricResponse(BaseModel):
    """Queue depth and throughput metric."""

    model_config = ConfigDict(from_attributes=True, populate_by_name=True)

    queue_name: str = Field(alias="queueName")
    depth: int
    enqueue_rate: float = Field(alias="enqueueRate")
    dequeue_rate: float = Field(alias="dequeueRate")
    oldest_message_age: float | None = Field(
        default=None, alias="oldestMessageAge"
    )
    timestamp: datetime


class AlertRuleResponse(BaseModel):
    """Alert rule definition."""

    model_config = ConfigDict(from_attributes=True, populate_by_name=True)

    id: UUID
    name: str
    description: str | None = Field(default=None)
    metric: str
    condition: str
    threshold: float
    severity: str
    notify_channels: list[str] = Field(
        default_factory=list, alias="notifyChannels"
    )
    is_active: bool = Field(alias="isActive")
    created_at: datetime = Field(alias="createdAt")
    updated_at: datetime = Field(alias="updatedAt")


class AlertHistoryResponse(BaseModel):
    """Historical alert event."""

    model_config = ConfigDict(from_attributes=True, populate_by_name=True)

    id: UUID
    rule_id: UUID = Field(alias="ruleId")
    rule_name: str = Field(alias="ruleName")
    severity: str
    message: str
    metric_value: float = Field(alias="metricValue")
    acknowledged_by_id: UUID | None = Field(
        default=None, alias="acknowledgedById"
    )
    acknowledged_at: datetime | None = Field(
        default=None, alias="acknowledgedAt"
    )
    resolved_at: datetime | None = Field(default=None, alias="resolvedAt")
    triggered_at: datetime = Field(alias="triggeredAt")
