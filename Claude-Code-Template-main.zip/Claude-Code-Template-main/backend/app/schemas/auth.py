"""Pydantic v2 schemas for authentication and user management."""

import uuid
from datetime import datetime

from pydantic import BaseModel, ConfigDict, EmailStr, Field


# ── Response Schemas ────────────────────────────────────────────────


class UserResponse(BaseModel):
    """Public user representation returned by the API."""

    model_config = ConfigDict(from_attributes=True, populate_by_name=True)

    id: uuid.UUID
    email: str
    first_name: str = Field(alias="firstName")
    last_name: str = Field(alias="lastName")
    role: str
    avatar_url: str | None = Field(default=None, alias="avatarUrl")
    is_active: bool = Field(alias="isActive")
    last_login_at: datetime | None = Field(default=None, alias="lastLoginAt")
    created_at: datetime = Field(alias="createdAt")
    updated_at: datetime = Field(alias="updatedAt")


class SessionResponse(BaseModel):
    """Session payload returned after login or token refresh."""

    model_config = ConfigDict(from_attributes=True, populate_by_name=True)

    id: uuid.UUID
    user_id: uuid.UUID = Field(alias="userId")
    access_token: str = Field(alias="accessToken")
    refresh_token: str = Field(alias="refreshToken")
    expires_at: datetime = Field(alias="expiresAt")
    created_at: datetime = Field(alias="createdAt")


# ── Request Schemas ─────────────────────────────────────────────────


class LoginRequest(BaseModel):
    """Credentials for email/password login."""

    email: EmailStr
    password: str = Field(min_length=8, max_length=128)


class RegisterRequest(BaseModel):
    """New user registration payload."""

    email: EmailStr
    password: str = Field(min_length=8, max_length=128)
    first_name: str = Field(min_length=1, max_length=100, alias="firstName")
    last_name: str = Field(min_length=1, max_length=100, alias="lastName")
    role: str | None = Field(default=None)

    model_config = ConfigDict(populate_by_name=True)


class PasswordResetRequest(BaseModel):
    """Request a password reset email."""

    email: EmailStr


class PasswordResetConfirm(BaseModel):
    """Confirm a password reset with the emailed token."""

    token: str = Field(min_length=1)
    new_password: str = Field(min_length=8, max_length=128, alias="newPassword")

    model_config = ConfigDict(populate_by_name=True)
