"""Pydantic v2 schemas for admin configuration and branding."""

from datetime import datetime
from typing import Literal
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field


# ── Shared Types ───────────────────────────────────────────────────


class BusinessHoursEntry(BaseModel):
    """Business hours for a single day of the week."""

    model_config = ConfigDict(from_attributes=True, populate_by_name=True)

    day_of_week: int = Field(ge=0, le=6, alias="dayOfWeek")
    is_open: bool = Field(alias="isOpen")
    open_time: str = Field(alias="openTime")
    close_time: str = Field(alias="closeTime")


# ── Response Schemas ───────────────────────────────────────────────


class AdminConfigResponse(BaseModel):
    """Admin platform configuration."""

    model_config = ConfigDict(from_attributes=True, populate_by_name=True)

    id: UUID
    max_concurrent_conversations_per_agent: int = Field(
        alias="maxConcurrentConversationsPerAgent"
    )
    auto_assign_enabled: bool = Field(alias="autoAssignEnabled")
    business_hours_enabled: bool = Field(alias="businessHoursEnabled")
    business_hours: list[BusinessHoursEntry] = Field(
        default_factory=list, alias="businessHours"
    )
    default_language: str = Field(alias="defaultLanguage")
    supported_languages: list[str] = Field(
        default_factory=list, alias="supportedLanguages"
    )
    updated_at: datetime = Field(alias="updatedAt")


class BrandConfigResponse(BaseModel):
    """Brand customization configuration."""

    model_config = ConfigDict(from_attributes=True, populate_by_name=True)

    id: UUID
    company_name: str = Field(alias="companyName")
    logo_url: str | None = Field(default=None, alias="logoUrl")
    favicon_url: str | None = Field(default=None, alias="faviconUrl")
    primary_color: str = Field(alias="primaryColor")
    accent_color: str = Field(alias="accentColor")
    widget_position: Literal["bottom-left", "bottom-right"] = Field(
        alias="widgetPosition"
    )
    widget_greeting: str = Field(alias="widgetGreeting")
    email_from_name: str = Field(alias="emailFromName")
    email_from_address: str = Field(alias="emailFromAddress")
    updated_at: datetime = Field(alias="updatedAt")


# ── Request Schemas ────────────────────────────────────────────────


class UpdateAdminConfigRequest(BaseModel):
    """Partially update admin platform configuration."""

    model_config = ConfigDict(populate_by_name=True)

    max_concurrent_conversations_per_agent: int | None = Field(
        default=None, alias="maxConcurrentConversationsPerAgent"
    )
    auto_assign_enabled: bool | None = Field(
        default=None, alias="autoAssignEnabled"
    )
    business_hours_enabled: bool | None = Field(
        default=None, alias="businessHoursEnabled"
    )
    business_hours: list[BusinessHoursEntry] | None = Field(
        default=None, alias="businessHours"
    )
    default_language: str | None = Field(default=None, alias="defaultLanguage")
    supported_languages: list[str] | None = Field(
        default=None, alias="supportedLanguages"
    )


class UpdateBrandConfigRequest(BaseModel):
    """Partially update brand customization configuration."""

    model_config = ConfigDict(populate_by_name=True)

    company_name: str | None = Field(default=None, alias="companyName")
    logo_url: str | None = Field(default=None, alias="logoUrl")
    favicon_url: str | None = Field(default=None, alias="faviconUrl")
    primary_color: str | None = Field(default=None, alias="primaryColor")
    accent_color: str | None = Field(default=None, alias="accentColor")
    widget_position: Literal["bottom-left", "bottom-right"] | None = Field(
        default=None, alias="widgetPosition"
    )
    widget_greeting: str | None = Field(default=None, alias="widgetGreeting")
    email_from_name: str | None = Field(default=None, alias="emailFromName")
    email_from_address: str | None = Field(
        default=None, alias="emailFromAddress"
    )
