"""Pydantic v2 schemas for video sessions and participants."""

from datetime import datetime
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field


# ── Response Schemas ───────────────────────────────────────────────


class VideoSessionResponse(BaseModel):
    """Video session."""

    model_config = ConfigDict(from_attributes=True, populate_by_name=True)

    id: UUID
    conversation_id: UUID | None = Field(default=None, alias="conversationId")
    host_id: UUID = Field(alias="hostId")
    status: str
    room_url: str = Field(alias="roomUrl")
    started_at: datetime = Field(alias="startedAt")
    ended_at: datetime | None = Field(default=None, alias="endedAt")
    duration_seconds: int | None = Field(default=None, alias="durationSeconds")
    created_at: datetime = Field(alias="createdAt")


class ParticipantResponse(BaseModel):
    """Video session participant."""

    model_config = ConfigDict(from_attributes=True, populate_by_name=True)

    id: UUID
    session_id: UUID = Field(alias="sessionId")
    user_id: UUID = Field(alias="userId")
    display_name: str = Field(alias="displayName")
    status: str
    is_audio_enabled: bool = Field(alias="isAudioEnabled")
    is_video_enabled: bool = Field(alias="isVideoEnabled")
    joined_at: datetime = Field(alias="joinedAt")
    left_at: datetime | None = Field(default=None, alias="leftAt")


# ── Request Schemas ────────────────────────────────────────────────


class CreateVideoSessionRequest(BaseModel):
    """Create a new video session."""

    model_config = ConfigDict(populate_by_name=True)

    conversation_id: UUID | None = Field(default=None, alias="conversationId")
