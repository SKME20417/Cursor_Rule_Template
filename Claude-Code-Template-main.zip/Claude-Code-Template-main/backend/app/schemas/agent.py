"""Pydantic v2 schemas for agents, teams, and skills."""

from datetime import datetime
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field


# ── Response Schemas ───────────────────────────────────────────────


class AgentSkillResponse(BaseModel):
    """Agent skill with proficiency level."""

    model_config = ConfigDict(from_attributes=True, populate_by_name=True)

    id: UUID
    name: str
    proficiency: str


class AgentResponse(BaseModel):
    """Support agent."""

    model_config = ConfigDict(from_attributes=True, populate_by_name=True)

    id: UUID
    user_id: UUID = Field(alias="userId")
    display_name: str = Field(alias="displayName")
    email: str
    avatar_url: str | None = Field(default=None, alias="avatarUrl")
    status: str
    team_id: UUID | None = Field(default=None, alias="teamId")
    skills: list[AgentSkillResponse] = Field(default_factory=list)
    supported_channels: list[str] = Field(
        default_factory=list, alias="supportedChannels"
    )
    max_concurrent_conversations: int = Field(alias="maxConcurrentConversations")
    active_conversation_count: int = Field(alias="activeConversationCount")
    last_active_at: datetime | None = Field(default=None, alias="lastActiveAt")
    created_at: datetime = Field(alias="createdAt")
    updated_at: datetime = Field(alias="updatedAt")


class TeamResponse(BaseModel):
    """Agent team."""

    model_config = ConfigDict(from_attributes=True, populate_by_name=True)

    id: UUID
    name: str
    description: str | None = Field(default=None)
    lead_agent_id: UUID | None = Field(default=None, alias="leadAgentId")
    member_count: int = Field(alias="memberCount")
    created_at: datetime = Field(alias="createdAt")
    updated_at: datetime = Field(alias="updatedAt")


# ── Request Schemas ────────────────────────────────────────────────


class CreateAgentRequest(BaseModel):
    """Register a new support agent."""

    model_config = ConfigDict(populate_by_name=True)

    user_id: UUID = Field(alias="userId")
    display_name: str = Field(alias="displayName")
    email: str
    team_id: UUID | None = Field(default=None, alias="teamId")
    supported_channels: list[str] | None = Field(
        default=None, alias="supportedChannels"
    )
    max_concurrent_conversations: int | None = Field(
        default=None, alias="maxConcurrentConversations"
    )


class UpdateAgentRequest(BaseModel):
    """Update an existing agent."""

    model_config = ConfigDict(populate_by_name=True)

    display_name: str | None = Field(default=None, alias="displayName")
    team_id: UUID | None = Field(default=None, alias="teamId")
    status: str | None = Field(default=None)
    supported_channels: list[str] | None = Field(
        default=None, alias="supportedChannels"
    )
    max_concurrent_conversations: int | None = Field(
        default=None, alias="maxConcurrentConversations"
    )
