"""Pydantic v2 schemas for AI Copilot suggestions, drafts, and feedback."""

from datetime import datetime
from typing import Literal
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field


# ── Response Schemas ───────────────────────────────────────────────


class SuggestionResponse(BaseModel):
    """Copilot-generated suggestion."""

    model_config = ConfigDict(from_attributes=True, populate_by_name=True)

    id: UUID
    conversation_id: UUID = Field(alias="conversationId")
    type: str
    content: str
    confidence: float
    source_article_ids: list[UUID] = Field(
        default_factory=list, alias="sourceArticleIds"
    )
    created_at: datetime = Field(alias="createdAt")


class DraftResponse(BaseModel):
    """Draft reply composed by the copilot."""

    model_config = ConfigDict(from_attributes=True, populate_by_name=True)

    id: UUID
    conversation_id: UUID = Field(alias="conversationId")
    agent_id: UUID = Field(alias="agentId")
    content: str
    based_on_suggestion_id: UUID | None = Field(
        default=None, alias="basedOnSuggestionId"
    )
    is_edited: bool = Field(alias="isEdited")
    created_at: datetime = Field(alias="createdAt")
    updated_at: datetime = Field(alias="updatedAt")


class CopilotFeedbackResponse(BaseModel):
    """Agent feedback on a copilot suggestion."""

    model_config = ConfigDict(from_attributes=True, populate_by_name=True)

    id: UUID
    suggestion_id: UUID = Field(alias="suggestionId")
    agent_id: UUID = Field(alias="agentId")
    rating: Literal["helpful", "not_helpful", "incorrect"]
    comment: str | None = Field(default=None)
    created_at: datetime = Field(alias="createdAt")


# ── Request Schemas ────────────────────────────────────────────────


class CreateDraftRequest(BaseModel):
    """Request the copilot to generate a draft reply."""

    model_config = ConfigDict(populate_by_name=True)

    conversation_id: UUID = Field(alias="conversationId")
    suggestion_id: UUID | None = Field(default=None, alias="suggestionId")
    prompt: str | None = Field(default=None)


class CreateFeedbackRequest(BaseModel):
    """Submit feedback on a copilot suggestion."""

    model_config = ConfigDict(populate_by_name=True)

    suggestion_id: UUID = Field(alias="suggestionId")
    rating: Literal["helpful", "not_helpful", "incorrect"]
    comment: str | None = Field(default=None)
