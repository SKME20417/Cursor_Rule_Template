"""Pydantic v2 schemas for knowledge base articles, categories, and documents."""

from datetime import datetime
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field


# ── Response Schemas ───────────────────────────────────────────────


class CategoryResponse(BaseModel):
    """Knowledge base category."""

    model_config = ConfigDict(from_attributes=True, populate_by_name=True)

    id: UUID
    name: str
    slug: str
    description: str | None = Field(default=None)
    parent_id: UUID | None = Field(default=None, alias="parentId")
    sort_order: int = Field(alias="sortOrder")
    created_at: datetime = Field(alias="createdAt")
    updated_at: datetime = Field(alias="updatedAt")


class ArticleResponse(BaseModel):
    """Knowledge base article."""

    model_config = ConfigDict(from_attributes=True, populate_by_name=True)

    id: UUID
    title: str
    slug: str
    content: str
    category_id: UUID = Field(alias="categoryId")
    status: str
    author_id: UUID = Field(alias="authorId")
    tags: list[str] = Field(default_factory=list)
    view_count: int = Field(alias="viewCount")
    helpful_count: int = Field(alias="helpfulCount")
    not_helpful_count: int = Field(alias="notHelpfulCount")
    published_at: datetime | None = Field(default=None, alias="publishedAt")
    created_at: datetime = Field(alias="createdAt")
    updated_at: datetime = Field(alias="updatedAt")


class DocumentResponse(BaseModel):
    """Uploaded document for ingestion into the knowledge base."""

    model_config = ConfigDict(from_attributes=True, populate_by_name=True)

    id: UUID
    file_name: str = Field(alias="fileName")
    file_url: str = Field(alias="fileUrl")
    mime_type: str = Field(alias="mimeType")
    size_bytes: int = Field(alias="sizeBytes")
    status: str
    chunk_count: int | None = Field(default=None, alias="chunkCount")
    error_message: str | None = Field(default=None, alias="errorMessage")
    uploaded_by_id: UUID = Field(alias="uploadedById")
    created_at: datetime = Field(alias="createdAt")
    updated_at: datetime = Field(alias="updatedAt")


# ── Request Schemas ────────────────────────────────────────────────


class CreateArticleRequest(BaseModel):
    """Create a new knowledge base article."""

    model_config = ConfigDict(populate_by_name=True)

    title: str
    content: str
    category_id: UUID = Field(alias="categoryId")
    tags: list[str] | None = Field(default=None)


class UpdateArticleRequest(BaseModel):
    """Update an existing knowledge base article."""

    model_config = ConfigDict(populate_by_name=True)

    title: str | None = Field(default=None)
    content: str | None = Field(default=None)
    category_id: UUID | None = Field(default=None, alias="categoryId")
    status: str | None = Field(default=None)
    tags: list[str] | None = Field(default=None)
