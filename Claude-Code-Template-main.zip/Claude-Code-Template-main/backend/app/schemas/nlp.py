"""Pydantic v2 schemas for NLP, intent, sentiment, and classification."""

from datetime import datetime
from typing import Literal
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field


# ── Response Schemas ───────────────────────────────────────────────


class IntentResponse(BaseModel):
    """Detected customer intent."""

    model_config = ConfigDict(from_attributes=True, populate_by_name=True)

    id: UUID
    name: str
    confidence: float
    parameters: dict[str, str] = Field(default_factory=dict)


class SentimentScoreResponse(BaseModel):
    """Sentiment analysis result."""

    model_config = ConfigDict(from_attributes=True, populate_by_name=True)

    label: Literal["positive", "neutral", "negative"]
    score: float
    magnitude: float


class ClassificationResponse(BaseModel):
    """Message or conversation classification result."""

    model_config = ConfigDict(from_attributes=True, populate_by_name=True)

    id: UUID
    conversation_id: UUID = Field(alias="conversationId")
    intents: list[IntentResponse] = Field(default_factory=list)
    sentiment: SentimentScoreResponse
    urgency: str
    topics: list[str] = Field(default_factory=list)
    created_at: datetime = Field(alias="createdAt")


class LanguageDetectionResponse(BaseModel):
    """Language detection result."""

    model_config = ConfigDict(from_attributes=True, populate_by_name=True)

    language_code: str = Field(alias="languageCode")
    language_name: str = Field(alias="languageName")
    confidence: float


# ── Request Schemas ────────────────────────────────────────────────


class ClassifyRequest(BaseModel):
    """Classify text for intents, sentiment, and urgency."""

    model_config = ConfigDict(populate_by_name=True)

    text: str
    conversation_id: UUID | None = Field(default=None, alias="conversationId")


class SentimentRequest(BaseModel):
    """Analyze sentiment of text."""

    text: str


class DetectLanguageRequest(BaseModel):
    """Detect the language of text."""

    text: str
