"""Pydantic v2 schemas for common shared types."""

from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field


# ── Shared Types ───────────────────────────────────────────────────


class DateRange(BaseModel):
    """Date range filter matching frontend DateRange type."""

    model_config = ConfigDict(from_attributes=True, populate_by_name=True)

    from_: datetime = Field(alias="from")
    to: datetime


class ListParams(BaseModel):
    """Pagination and search parameters for list endpoints."""

    model_config = ConfigDict(from_attributes=True, populate_by_name=True)

    page: int = Field(default=1, ge=1)
    page_size: int = Field(default=20, ge=1, le=100, alias="pageSize")
    search: str | None = Field(default=None)
    filters: dict[str, str | list[str]] | None = Field(default=None)
