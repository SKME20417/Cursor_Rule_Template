"""Pydantic v2 schemas for workflow automation, triggers, and escalation."""

from datetime import datetime
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field


# ── Response Schemas ───────────────────────────────────────────────


class TriggerResponse(BaseModel):
    """Workflow trigger definition."""

    model_config = ConfigDict(from_attributes=True, populate_by_name=True)

    id: UUID
    type: str
    conditions: dict[str, str] = Field(default_factory=dict)


class ActionResponse(BaseModel):
    """Action executed by a workflow node."""

    model_config = ConfigDict(from_attributes=True, populate_by_name=True)

    id: UUID
    type: str
    config: dict[str, str | int | bool] = Field(default_factory=dict)


class WorkflowNodeResponse(BaseModel):
    """Single node in a workflow graph."""

    model_config = ConfigDict(from_attributes=True, populate_by_name=True)

    id: UUID
    workflow_id: UUID = Field(alias="workflowId")
    label: str
    action: ActionResponse
    position_x: float = Field(alias="positionX")
    position_y: float = Field(alias="positionY")


class WorkflowEdgeResponse(BaseModel):
    """Edge connecting two workflow nodes."""

    model_config = ConfigDict(from_attributes=True, populate_by_name=True)

    id: UUID
    workflow_id: UUID = Field(alias="workflowId")
    source_node_id: UUID = Field(alias="sourceNodeId")
    target_node_id: UUID = Field(alias="targetNodeId")
    condition_label: str | None = Field(default=None, alias="conditionLabel")


class WorkflowResponse(BaseModel):
    """Automation workflow."""

    model_config = ConfigDict(from_attributes=True, populate_by_name=True)

    id: UUID
    name: str
    description: str | None = Field(default=None)
    status: str
    trigger: TriggerResponse
    nodes: list[WorkflowNodeResponse] = Field(default_factory=list)
    edges: list[WorkflowEdgeResponse] = Field(default_factory=list)
    execution_count: int = Field(alias="executionCount")
    last_executed_at: datetime | None = Field(
        default=None, alias="lastExecutedAt"
    )
    created_by_id: UUID = Field(alias="createdById")
    created_at: datetime = Field(alias="createdAt")
    updated_at: datetime = Field(alias="updatedAt")


class AutoReplyTemplateResponse(BaseModel):
    """Auto-reply template for automated responses."""

    model_config = ConfigDict(from_attributes=True, populate_by_name=True)

    id: UUID
    name: str
    subject: str | None = Field(default=None)
    body: str
    is_active: bool = Field(alias="isActive")
    created_at: datetime = Field(alias="createdAt")
    updated_at: datetime = Field(alias="updatedAt")


class EscalationRuleResponse(BaseModel):
    """Escalation rule for priority routing."""

    model_config = ConfigDict(from_attributes=True, populate_by_name=True)

    id: UUID
    name: str
    description: str | None = Field(default=None)
    priority: str
    escalate_after_minutes: int = Field(alias="escalateAfterMinutes")
    target_team_id: UUID | None = Field(default=None, alias="targetTeamId")
    target_agent_id: UUID | None = Field(default=None, alias="targetAgentId")
    notify_ids: list[UUID] = Field(default_factory=list, alias="notifyIds")
    is_active: bool = Field(alias="isActive")
    created_at: datetime = Field(alias="createdAt")
    updated_at: datetime = Field(alias="updatedAt")


# ── Request Schemas ────────────────────────────────────────────────


class CreateWorkflowRequest(BaseModel):
    """Create a new automation workflow."""

    model_config = ConfigDict(populate_by_name=True)

    name: str
    description: str | None = Field(default=None)
    trigger: TriggerResponse
    nodes: list[WorkflowNodeResponse] | None = Field(default=None)
    edges: list[WorkflowEdgeResponse] | None = Field(default=None)


class UpdateWorkflowRequest(BaseModel):
    """Update an existing workflow."""

    model_config = ConfigDict(populate_by_name=True)

    name: str | None = Field(default=None)
    description: str | None = Field(default=None)
    status: str | None = Field(default=None)
    trigger: TriggerResponse | None = Field(default=None)
    nodes: list[WorkflowNodeResponse] | None = Field(default=None)
    edges: list[WorkflowEdgeResponse] | None = Field(default=None)
