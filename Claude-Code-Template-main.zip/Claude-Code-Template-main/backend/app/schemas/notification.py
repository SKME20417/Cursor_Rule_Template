"""Pydantic v2 schemas for notifications."""

from datetime import datetime
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field


# ── Response Schemas ───────────────────────────────────────────────


class NotificationResponse(BaseModel):
    """User notification."""

    model_config = ConfigDict(from_attributes=True, populate_by_name=True)

    id: UUID
    user_id: UUID = Field(alias="userId")
    type: str
    priority: str
    title: str
    body: str
    link_url: str | None = Field(default=None, alias="linkUrl")
    is_read: bool = Field(alias="isRead")
    read_at: datetime | None = Field(default=None, alias="readAt")
    created_at: datetime = Field(alias="createdAt")
