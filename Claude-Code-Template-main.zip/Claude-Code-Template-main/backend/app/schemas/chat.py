"""Pydantic v2 schemas for chat, messaging, and conversations."""

from datetime import datetime
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field


# ── Response Schemas ───────────────────────────────────────────────


class AttachmentResponse(BaseModel):
    """File attachment on a message."""

    model_config = ConfigDict(from_attributes=True, populate_by_name=True)

    id: UUID
    file_name: str = Field(alias="fileName")
    file_url: str = Field(alias="fileUrl")
    mime_type: str = Field(alias="mimeType")
    size_bytes: int = Field(alias="sizeBytes")


class MessageResponse(BaseModel):
    """Single chat message."""

    model_config = ConfigDict(from_attributes=True, populate_by_name=True)

    id: UUID
    conversation_id: UUID = Field(alias="conversationId")
    sender_id: UUID = Field(alias="senderId")
    sender_role: str = Field(alias="senderRole")
    type: str
    content: str
    attachments: list[AttachmentResponse] = Field(default_factory=list)
    is_read: bool = Field(alias="isRead")
    created_at: datetime = Field(alias="createdAt")
    updated_at: datetime = Field(alias="updatedAt")


class ConversationResponse(BaseModel):
    """Conversation between a customer and agent(s)."""

    model_config = ConfigDict(from_attributes=True, populate_by_name=True)

    id: UUID
    customer_id: UUID = Field(alias="customerId")
    assigned_agent_id: UUID | None = Field(default=None, alias="assignedAgentId")
    channel: str
    status: str
    subject: str | None = Field(default=None)
    tags: list[str] = Field(default_factory=list)
    last_message_at: datetime | None = Field(default=None, alias="lastMessageAt")
    last_message_preview: str | None = Field(
        default=None, alias="lastMessagePreview"
    )
    message_count: int = Field(alias="messageCount")
    created_at: datetime = Field(alias="createdAt")
    updated_at: datetime = Field(alias="updatedAt")


# ── Request Schemas ────────────────────────────────────────────────


class CreateConversationRequest(BaseModel):
    """Create a new conversation."""

    model_config = ConfigDict(populate_by_name=True)

    customer_id: UUID = Field(alias="customerId")
    channel: str
    subject: str | None = Field(default=None)


class UpdateConversationRequest(BaseModel):
    """Update an existing conversation."""

    model_config = ConfigDict(populate_by_name=True)

    status: str | None = Field(default=None)
    assigned_agent_id: UUID | None = Field(default=None, alias="assignedAgentId")
    tags: list[str] | None = Field(default=None)
    subject: str | None = Field(default=None)


class SendMessageRequest(BaseModel):
    """Send a message in a conversation."""

    model_config = ConfigDict(populate_by_name=True)

    content: str
    type: str = Field(default="text")
    attachments: list[str] | None = Field(default=None)
