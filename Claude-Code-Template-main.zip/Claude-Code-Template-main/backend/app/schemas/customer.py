"""Pydantic v2 schemas for customers and interactions."""

from datetime import datetime
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field


# ── Response Schemas ───────────────────────────────────────────────


class CustomerResponse(BaseModel):
    """Customer record."""

    model_config = ConfigDict(from_attributes=True, populate_by_name=True)

    id: UUID
    external_id: str | None = Field(default=None, alias="externalId")
    email: str
    first_name: str = Field(alias="firstName")
    last_name: str = Field(alias="lastName")
    phone: str | None = Field(default=None)
    avatar_url: str | None = Field(default=None, alias="avatarUrl")
    segment: str
    tags: list[str] = Field(default_factory=list)
    is_verified: bool = Field(alias="isVerified")
    created_at: datetime = Field(alias="createdAt")
    updated_at: datetime = Field(alias="updatedAt")


class CustomerProfileResponse(BaseModel):
    """Extended customer profile with computed data."""

    model_config = ConfigDict(from_attributes=True, populate_by_name=True)

    customer: CustomerResponse
    total_conversations: int = Field(alias="totalConversations")
    total_tickets: int = Field(alias="totalTickets")
    open_tickets: int = Field(alias="openTickets")
    average_satisfaction_score: float | None = Field(
        default=None, alias="averageSatisfactionScore"
    )
    last_contact_at: datetime | None = Field(default=None, alias="lastContactAt")
    preferred_channel: str | None = Field(default=None, alias="preferredChannel")
    metadata: dict[str, str] = Field(default_factory=dict)


class InteractionResponse(BaseModel):
    """Single customer interaction entry."""

    model_config = ConfigDict(from_attributes=True, populate_by_name=True)

    id: UUID
    customer_id: UUID = Field(alias="customerId")
    channel: str
    type: str
    reference_id: UUID = Field(alias="referenceId")
    summary: str | None = Field(default=None)
    agent_id: UUID | None = Field(default=None, alias="agentId")
    occurred_at: datetime = Field(alias="occurredAt")
