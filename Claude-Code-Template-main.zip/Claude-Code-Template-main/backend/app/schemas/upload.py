"""Pydantic v2 schemas for file uploads."""

from pydantic import BaseModel, ConfigDict


# ── Response Schemas ───────────────────────────────────────────────


class UploadResponse(BaseModel):
    """Upload result with URL and metadata."""

    model_config = ConfigDict(from_attributes=True, populate_by_name=True)

    url: str
    key: str
    size: int
