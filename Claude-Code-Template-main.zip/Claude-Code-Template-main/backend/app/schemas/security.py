"""Pydantic v2 schemas for security, RBAC, audit, and API keys."""

from datetime import datetime
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field


# ── Response Schemas ───────────────────────────────────────────────


class PermissionResponse(BaseModel):
    """Single permission entry."""

    model_config = ConfigDict(from_attributes=True, populate_by_name=True)

    id: UUID
    resource: str
    action: str


class RoleResponse(BaseModel):
    """Named role with a set of permissions."""

    model_config = ConfigDict(from_attributes=True, populate_by_name=True)

    id: UUID
    name: str
    description: str | None = Field(default=None)
    permissions: list[PermissionResponse] = Field(default_factory=list)
    is_system: bool = Field(alias="isSystem")
    created_at: datetime = Field(alias="createdAt")
    updated_at: datetime = Field(alias="updatedAt")


class AuditEntryResponse(BaseModel):
    """Audit log entry."""

    model_config = ConfigDict(from_attributes=True, populate_by_name=True)

    id: UUID
    user_id: UUID = Field(alias="userId")
    user_email: str = Field(alias="userEmail")
    action: str
    resource: str
    resource_id: UUID | None = Field(default=None, alias="resourceId")
    changes: dict | None = Field(default=None)
    ip_address: str = Field(alias="ipAddress")
    user_agent: str = Field(alias="userAgent")
    created_at: datetime = Field(alias="createdAt")


class ApiKeyResponse(BaseModel):
    """API key for programmatic access."""

    model_config = ConfigDict(from_attributes=True, populate_by_name=True)

    id: UUID
    name: str
    key_prefix: str = Field(alias="keyPrefix")
    permissions: list[PermissionResponse] = Field(default_factory=list)
    last_used_at: datetime | None = Field(default=None, alias="lastUsedAt")
    expires_at: datetime | None = Field(default=None, alias="expiresAt")
    is_active: bool = Field(alias="isActive")
    created_by_id: UUID = Field(alias="createdById")
    created_at: datetime = Field(alias="createdAt")


# ── Request Schemas ────────────────────────────────────────────────


class CreateApiKeyRequest(BaseModel):
    """Create a new API key."""

    model_config = ConfigDict(populate_by_name=True)

    name: str
    permissions: list[str] = Field(default_factory=list)
