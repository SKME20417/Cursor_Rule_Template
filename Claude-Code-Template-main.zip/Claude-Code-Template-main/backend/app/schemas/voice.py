"""Pydantic v2 schemas for voice calls, transcripts, and recordings."""

from datetime import datetime
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field


# ── Response Schemas ───────────────────────────────────────────────


class CallResponse(BaseModel):
    """Voice call record."""

    model_config = ConfigDict(from_attributes=True, populate_by_name=True)

    id: UUID
    conversation_id: UUID | None = Field(default=None, alias="conversationId")
    customer_id: UUID = Field(alias="customerId")
    agent_id: UUID | None = Field(default=None, alias="agentId")
    direction: str
    status: str
    phone_number: str = Field(alias="phoneNumber")
    started_at: datetime = Field(alias="startedAt")
    connected_at: datetime | None = Field(default=None, alias="connectedAt")
    ended_at: datetime | None = Field(default=None, alias="endedAt")
    duration_seconds: int | None = Field(default=None, alias="durationSeconds")
    hold_duration_seconds: int = Field(alias="holdDurationSeconds")
    created_at: datetime = Field(alias="createdAt")


class TranscriptSegmentResponse(BaseModel):
    """Single segment of a call transcript."""

    model_config = ConfigDict(from_attributes=True, populate_by_name=True)

    id: UUID
    speaker: str
    text: str
    start_ms: int = Field(alias="startMs")
    end_ms: int = Field(alias="endMs")
    confidence: float


class TranscriptResponse(BaseModel):
    """Full call transcript."""

    model_config = ConfigDict(from_attributes=True, populate_by_name=True)

    id: UUID
    call_id: UUID = Field(alias="callId")
    segments: list[TranscriptSegmentResponse] = Field(default_factory=list)
    language: str
    created_at: datetime = Field(alias="createdAt")


class RecordingResponse(BaseModel):
    """Call recording metadata."""

    model_config = ConfigDict(from_attributes=True, populate_by_name=True)

    id: UUID
    call_id: UUID = Field(alias="callId")
    file_url: str = Field(alias="fileUrl")
    duration_seconds: int = Field(alias="durationSeconds")
    file_size_bytes: int = Field(alias="fileSizeBytes")
    created_at: datetime = Field(alias="createdAt")


# ── Request Schemas ────────────────────────────────────────────────


class CreateCallRequest(BaseModel):
    """Initiate a new outbound call."""

    model_config = ConfigDict(populate_by_name=True)

    customer_id: UUID = Field(alias="customerId")
    phone_number: str = Field(alias="phoneNumber")
