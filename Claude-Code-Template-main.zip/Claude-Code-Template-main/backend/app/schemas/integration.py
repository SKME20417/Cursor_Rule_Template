"""Pydantic v2 schemas for third-party integrations and webhooks."""

from datetime import datetime
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field


# ── Response Schemas ───────────────────────────────────────────────


class IntegrationConfigResponse(BaseModel):
    """Integration configuration."""

    model_config = ConfigDict(from_attributes=True, populate_by_name=True)

    api_endpoint: str | None = Field(default=None, alias="apiEndpoint")
    scopes: list[str] = Field(default_factory=list)
    settings: dict[str, str | int | bool] = Field(default_factory=dict)


class IntegrationResponse(BaseModel):
    """Connected third-party integration."""

    model_config = ConfigDict(from_attributes=True, populate_by_name=True)

    id: UUID
    provider: str
    name: str
    status: str
    config: IntegrationConfigResponse
    last_sync_at: datetime | None = Field(default=None, alias="lastSyncAt")
    error_message: str | None = Field(default=None, alias="errorMessage")
    created_at: datetime = Field(alias="createdAt")
    updated_at: datetime = Field(alias="updatedAt")


class WebhookConfigResponse(BaseModel):
    """Webhook configuration for outbound event delivery."""

    model_config = ConfigDict(from_attributes=True, populate_by_name=True)

    id: UUID
    integration_id: UUID = Field(alias="integrationId")
    url: str
    method: str
    headers: dict[str, str] = Field(default_factory=dict)
    events: list[str] = Field(default_factory=list)
    secret_key: str | None = Field(default=None, alias="secretKey")
    is_active: bool = Field(alias="isActive")
    retry_count: int = Field(alias="retryCount")
    last_triggered_at: datetime | None = Field(
        default=None, alias="lastTriggeredAt"
    )
    created_at: datetime = Field(alias="createdAt")
    updated_at: datetime = Field(alias="updatedAt")


# ── Request Schemas ────────────────────────────────────────────────


class UpdateIntegrationRequest(BaseModel):
    """Update an existing integration."""

    model_config = ConfigDict(populate_by_name=True)

    config: IntegrationConfigResponse | None = Field(default=None)
    name: str | None = Field(default=None)
