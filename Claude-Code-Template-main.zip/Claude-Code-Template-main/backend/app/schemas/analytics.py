"""Pydantic v2 schemas for analytics, metrics, and reporting."""

from datetime import datetime
from typing import Literal
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field

from app.schemas.common import DateRange


# ── Response Schemas ───────────────────────────────────────────────


class TimeSeriesPoint(BaseModel):
    """Single data point in a time series."""

    model_config = ConfigDict(from_attributes=True, populate_by_name=True)

    timestamp: datetime
    value: float


class MetricCard(BaseModel):
    """Dashboard metric card data."""

    model_config = ConfigDict(from_attributes=True, populate_by_name=True)

    label: str
    value: float
    previous_value: float | None = Field(default=None, alias="previousValue")
    change_percent: float | None = Field(default=None, alias="changePercent")
    unit: str | None = Field(default=None)
    trend: Literal["up", "down", "flat"]


class AgentMetrics(BaseModel):
    """Per-agent performance metrics."""

    model_config = ConfigDict(from_attributes=True, populate_by_name=True)

    agent_id: UUID = Field(alias="agentId")
    agent_name: str = Field(alias="agentName")
    conversations_handled: int = Field(alias="conversationsHandled")
    average_response_time_seconds: float = Field(
        alias="averageResponseTimeSeconds"
    )
    average_resolution_time_seconds: float = Field(
        alias="averageResolutionTimeSeconds"
    )
    csat_score: float | None = Field(default=None, alias="csatScore")
    first_contact_resolution_rate: float = Field(
        alias="firstContactResolutionRate"
    )
    active_conversations: int = Field(alias="activeConversations")
    period: DateRange


class ChannelMetrics(BaseModel):
    """Metrics broken down by communication channel."""

    model_config = ConfigDict(from_attributes=True, populate_by_name=True)

    channel: str
    conversation_count: int = Field(alias="conversationCount")
    average_wait_time_seconds: float = Field(alias="averageWaitTimeSeconds")
    average_handle_time_seconds: float = Field(alias="averageHandleTimeSeconds")
    abandonment_rate: float = Field(alias="abandonmentRate")
    csat_score: float | None = Field(default=None, alias="csatScore")


class SLAMetrics(BaseModel):
    """SLA compliance metrics."""

    model_config = ConfigDict(from_attributes=True, populate_by_name=True)

    total_tickets: int = Field(alias="totalTickets")
    within_sla: int = Field(alias="withinSLA")
    breached: int
    compliance_rate: float = Field(alias="complianceRate")
    average_first_response_minutes: float = Field(
        alias="averageFirstResponseMinutes"
    )
    average_resolution_minutes: float = Field(alias="averageResolutionMinutes")
    period: DateRange


# ── Request Schemas ────────────────────────────────────────────────


class TimeSeriesRequest(BaseModel):
    """Request a time series for a given metric."""

    model_config = ConfigDict(populate_by_name=True)

    metric: str
    range: DateRange
    interval: Literal["hour", "day", "week", "month"] = Field(default="day")
