"""Voice call API routes."""

from uuid import UUID

from fastapi import APIRouter

from app.core.pagination import build_paginated_response
from app.core.response import success_response
from app.dependencies import AgentOrAdmin, DbSession, Pagination
from app.schemas.voice import CreateCallRequest
from app.services.voice_service import VoiceService

router = APIRouter(prefix="/calls", tags=["Calls"])


@router.get("/")
async def list_calls(
    db: DbSession,
    current_user: AgentOrAdmin,
    pagination: Pagination,
):
    """List calls with pagination."""
    service = VoiceService(db)
    data, total = await service.list_calls(
        offset=pagination.offset, limit=pagination.limit
    )
    return build_paginated_response(data, total, pagination.page, pagination.page_size)


@router.post("/")
async def create_call(
    body: CreateCallRequest,
    db: DbSession,
    current_user: AgentOrAdmin,
):
    """Initiate a new outbound call."""
    service = VoiceService(db)
    result = await service.create_call(body, current_user["user_id"])
    return success_response(result)


@router.get("/{call_id}")
async def get_call(
    call_id: UUID,
    db: DbSession,
    current_user: AgentOrAdmin,
):
    """Get a single call by ID."""
    service = VoiceService(db)
    result = await service.get_call(call_id)
    return success_response(result)


@router.post("/{call_id}/end")
async def end_call(
    call_id: UUID,
    db: DbSession,
    current_user: AgentOrAdmin,
):
    """End an active call."""
    service = VoiceService(db)
    result = await service.end_call(call_id)
    return success_response(result)


@router.get("/{call_id}/recording")
async def get_recording(
    call_id: UUID,
    db: DbSession,
    current_user: AgentOrAdmin,
):
    """Get the recording for a call."""
    service = VoiceService(db)
    result = await service.get_recording(call_id)
    return success_response(result)


@router.get("/{call_id}/transcript")
async def get_transcript(
    call_id: UUID,
    db: DbSession,
    current_user: AgentOrAdmin,
):
    """Get the transcript for a call."""
    service = VoiceService(db)
    result = await service.get_transcript(call_id)
    return success_response(result)
