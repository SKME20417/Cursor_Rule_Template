"""NLP API routes."""

from fastapi import APIRouter

from app.core.response import success_response
from app.dependencies import AgentOrAdmin, DbSession
from app.schemas.nlp import ClassifyRequest, DetectLanguageRequest, SentimentRequest
from app.services.nlp_service import NLPService

router = APIRouter(prefix="/nlp", tags=["NLP"])


@router.post("/classify")
async def classify(
    body: ClassifyRequest,
    db: DbSession,
    current_user: AgentOrAdmin,
):
    """Classify text for intents, sentiment, and urgency."""
    service = NLPService(db)
    result = await service.classify(body)
    return success_response(result)


@router.post("/sentiment")
async def analyze_sentiment(
    body: SentimentRequest,
    db: DbSession,
    current_user: AgentOrAdmin,
):
    """Analyze sentiment of text."""
    service = NLPService(db)
    result = await service.analyze_sentiment(body)
    return success_response(result)


@router.post("/detect-language")
async def detect_language(
    body: DetectLanguageRequest,
    db: DbSession,
    current_user: AgentOrAdmin,
):
    """Detect the language of text."""
    service = NLPService(db)
    result = await service.detect_language(body)
    return success_response(result)
