"""Authentication API routes."""

import structlog
from fastapi import APIRouter, Body

from app.core.response import success_response
from app.dependencies import CurrentUser, DbSession
from app.schemas.auth import (
    LoginRequest,
    PasswordResetConfirm,
    PasswordResetRequest,
    RegisterRequest,
)
from app.services.auth_service import AuthService

logger = structlog.get_logger()

router = APIRouter(prefix="/auth", tags=["auth"])


@router.post("/login")
async def login(body: LoginRequest, db: DbSession):
    """Authenticate with email and password. Returns session with tokens."""
    auth_service = AuthService(db)
    session_data = await auth_service.login(body.email, body.password)
    return success_response(session_data)


@router.post("/register")
async def register(body: RegisterRequest, db: DbSession):
    """Create a new user account."""
    auth_service = AuthService(db)
    user_data = await auth_service.register(body)
    return success_response(user_data, message="Registration successful")


@router.post("/logout")
async def logout(
    db: DbSession,
    current_user: CurrentUser,
    refresh_token: str = Body(..., embed=True, alias="refreshToken"),
):
    """Revoke the provided refresh token."""
    auth_service = AuthService(db)
    await auth_service.logout(refresh_token)
    return success_response(None, message="Logged out successfully")


@router.post("/refresh")
async def refresh(
    db: DbSession,
    refresh_token: str = Body(..., embed=True, alias="refreshToken"),
):
    """Exchange a valid refresh token for a new access token."""
    auth_service = AuthService(db)
    token_data = await auth_service.refresh_token(refresh_token)
    return success_response(token_data)


@router.get("/session")
async def get_session(db: DbSession, current_user: CurrentUser):
    """Return the currently authenticated user profile."""
    auth_service = AuthService(db)
    user_data = await auth_service.get_session(current_user["user_id"])
    return success_response(user_data)


@router.post("/forgot-password")
async def forgot_password(body: PasswordResetRequest, db: DbSession):
    """Initiate a password reset flow.

    Always returns success to avoid leaking whether an email exists.
    """
    logger.info("auth.forgot_password.requested", email=body.email)
    # In production this would enqueue an email via a background task.
    # The reset token would be generated, stored, and emailed to the user.
    # We deliberately return a generic success message regardless of whether
    # the email exists to prevent user enumeration.
    return success_response(
        {"message": "If that email is registered, a reset link has been sent."}
    )


@router.post("/reset-password")
async def reset_password(body: PasswordResetConfirm, db: DbSession):
    """Complete a password reset using the emailed token.

    In a full implementation this would:
    1. Decode / look up the reset token.
    2. Verify it has not expired.
    3. Hash the new password and update the user row.
    4. Invalidate all existing refresh tokens for the user.
    """
    logger.info("auth.reset_password.attempted")
    # Placeholder: a real implementation would validate the token against
    # a password_reset_tokens table and update the user's password_hash.
    # Returning a generic message to keep the endpoint contract stable
    # while the reset-token infrastructure is built out.
    return success_response(
        {"message": "If the token is valid, your password has been reset."}
    )
