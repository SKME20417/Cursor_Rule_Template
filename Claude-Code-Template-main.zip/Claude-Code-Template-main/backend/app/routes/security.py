"""Security, RBAC, and API key API routes."""

from uuid import UUID

from fastapi import APIRouter, Body

from app.core.pagination import build_paginated_response
from app.core.response import success_response
from app.dependencies import AdminUser, DbSession, Pagination
from app.schemas.security import CreateApiKeyRequest
from app.services.security_service import SecurityService

router = APIRouter(prefix="/security", tags=["Security"])


@router.get("/roles")
async def list_roles(
    db: DbSession,
    current_user: AdminUser,
):
    """List all roles (admin only)."""
    service = SecurityService(db)
    result = await service.list_roles()
    return success_response(result)


@router.get("/roles/{role_id}/permissions")
async def get_role_permissions(
    role_id: UUID,
    db: DbSession,
    current_user: AdminUser,
):
    """Get permissions for a specific role (admin only)."""
    service = SecurityService(db)
    result = await service.get_role_permissions(role_id)
    return success_response(result)


@router.put("/roles/{role_id}/permissions")
async def update_role_permissions(
    role_id: UUID,
    db: DbSession,
    current_user: AdminUser,
    permissions: list[dict] = Body(...),
):
    """Replace all permissions for a role (admin only)."""
    service = SecurityService(db)
    result = await service.update_role_permissions(role_id, permissions)
    return success_response(result)


@router.get("/audit-log")
async def get_audit_log(
    db: DbSession,
    current_user: AdminUser,
    pagination: Pagination,
):
    """Get paginated audit log entries (admin only)."""
    service = SecurityService(db)
    data, total = await service.get_audit_log(
        offset=pagination.offset, limit=pagination.limit
    )
    return build_paginated_response(data, total, pagination.page, pagination.page_size)


@router.get("/api-keys")
async def list_api_keys(
    db: DbSession,
    current_user: AdminUser,
):
    """List all API keys (admin only)."""
    service = SecurityService(db)
    result = await service.list_api_keys()
    return success_response(result)


@router.post("/api-keys")
async def create_api_key(
    body: CreateApiKeyRequest,
    db: DbSession,
    current_user: AdminUser,
):
    """Create a new API key (admin only). The full key is only returned once."""
    service = SecurityService(db)
    result = await service.create_api_key(body, current_user["user_id"])
    return success_response(result)


@router.delete("/api-keys/{api_key_id}")
async def revoke_api_key(
    api_key_id: UUID,
    db: DbSession,
    current_user: AdminUser,
):
    """Revoke an API key (admin only)."""
    service = SecurityService(db)
    await service.revoke_api_key(api_key_id)
    return success_response(None, message="API key revoked")
