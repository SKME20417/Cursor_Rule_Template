"""Conversation API routes."""

from uuid import UUID

from fastapi import APIRouter

from app.core.pagination import build_paginated_response
from app.core.response import success_response
from app.dependencies import CurrentUser, DbSession, Pagination
from app.schemas.chat import (
    CreateConversationRequest,
    SendMessageRequest,
    UpdateConversationRequest,
)
from app.services.chat_service import ChatService

router = APIRouter(prefix="/conversations", tags=["Conversations"])


@router.get("/")
async def list_conversations(
    db: DbSession,
    current_user: CurrentUser,
    pagination: Pagination,
):
    """List conversations with pagination."""
    service = ChatService(db)
    data, total = await service.list_conversations(
        offset=pagination.offset, limit=pagination.limit
    )
    return build_paginated_response(data, total, pagination.page, pagination.page_size)


@router.post("/")
async def create_conversation(
    body: CreateConversationRequest,
    db: DbSession,
    current_user: CurrentUser,
):
    """Create a new conversation."""
    service = ChatService(db)
    result = await service.create_conversation(body, current_user["user_id"])
    return success_response(result)


@router.get("/{conversation_id}")
async def get_conversation(
    conversation_id: UUID,
    db: DbSession,
    current_user: CurrentUser,
):
    """Get a single conversation by ID."""
    service = ChatService(db)
    result = await service.get_conversation(conversation_id)
    return success_response(result)


@router.patch("/{conversation_id}")
async def update_conversation(
    conversation_id: UUID,
    body: UpdateConversationRequest,
    db: DbSession,
    current_user: CurrentUser,
):
    """Update an existing conversation."""
    service = ChatService(db)
    result = await service.update_conversation(conversation_id, body)
    return success_response(result)


@router.get("/{conversation_id}/messages")
async def list_messages(
    conversation_id: UUID,
    db: DbSession,
    current_user: CurrentUser,
    pagination: Pagination,
):
    """List messages in a conversation."""
    service = ChatService(db)
    data, total = await service.list_messages(
        conversation_id, offset=pagination.offset, limit=pagination.limit
    )
    return build_paginated_response(data, total, pagination.page, pagination.page_size)


@router.post("/{conversation_id}/messages")
async def send_message(
    conversation_id: UUID,
    body: SendMessageRequest,
    db: DbSession,
    current_user: CurrentUser,
):
    """Send a message in a conversation."""
    service = ChatService(db)
    result = await service.send_message(
        conversation_id, body, current_user["user_id"], current_user["role"]
    )
    return success_response(result)
