"""AI Copilot API routes."""

from uuid import UUID

from fastapi import APIRouter, Query

from app.core.response import success_response
from app.dependencies import AgentOrAdmin, DbSession
from app.schemas.copilot import CreateDraftRequest, CreateFeedbackRequest
from app.services.copilot_service import CopilotService

router = APIRouter(prefix="/copilot", tags=["Copilot"])


@router.get("/suggestions")
async def get_suggestions(
    db: DbSession,
    current_user: AgentOrAdmin,
    conversation_id: UUID = Query(..., alias="conversationId"),
):
    """Get AI-generated suggestions for a conversation."""
    service = CopilotService(db)
    result = await service.get_suggestions(conversation_id)
    return success_response(result)


@router.post("/drafts")
async def create_draft(
    body: CreateDraftRequest,
    db: DbSession,
    current_user: AgentOrAdmin,
):
    """Create a draft reply using the copilot."""
    service = CopilotService(db)
    result = await service.create_draft(body, current_user["user_id"])
    return success_response(result)


@router.post("/feedback")
async def submit_feedback(
    body: CreateFeedbackRequest,
    db: DbSession,
    current_user: AgentOrAdmin,
):
    """Submit feedback on a copilot suggestion."""
    service = CopilotService(db)
    result = await service.submit_feedback(body, current_user["user_id"])
    return success_response(result)


@router.get("/summary")
async def get_summary(
    db: DbSession,
    current_user: AgentOrAdmin,
    conversation_id: UUID = Query(..., alias="conversationId"),
):
    """Get an AI-generated conversation summary."""
    service = CopilotService(db)
    result = await service.get_summary(conversation_id)
    return success_response(result)
