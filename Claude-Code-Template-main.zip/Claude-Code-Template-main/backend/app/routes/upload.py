"""File upload API route."""

from fastapi import APIRouter, UploadFile

from app.core.response import success_response
from app.dependencies import CurrentUser, DbSession
from app.services.upload_service import UploadService

router = APIRouter(prefix="", tags=["Upload"])


@router.post("/upload")
async def upload_file(
    file: UploadFile,
    db: DbSession,
    current_user: CurrentUser,
):
    """Upload a file (validates type and size)."""
    service = UploadService(db)
    result = await service.upload_file(file, current_user["user_id"])
    return success_response(result)
