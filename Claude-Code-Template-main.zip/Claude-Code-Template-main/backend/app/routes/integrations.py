"""Integration API routes."""

from uuid import UUID

from fastapi import APIRouter

from app.core.response import success_response
from app.dependencies import AdminUser, DbSession
from app.schemas.integration import UpdateIntegrationRequest
from app.services.integration_service import IntegrationService

router = APIRouter(prefix="/integrations", tags=["Integrations"])


@router.get("/")
async def list_integrations(
    db: DbSession,
    current_user: AdminUser,
):
    """List all integrations (admin only)."""
    service = IntegrationService(db)
    result = await service.list_integrations()
    return success_response(result)


@router.patch("/{integration_id}")
async def update_integration(
    integration_id: UUID,
    body: UpdateIntegrationRequest,
    db: DbSession,
    current_user: AdminUser,
):
    """Update an integration (admin only)."""
    service = IntegrationService(db)
    result = await service.update_integration(integration_id, body)
    return success_response(result)


@router.post("/{integration_id}/test")
async def test_integration(
    integration_id: UUID,
    db: DbSession,
    current_user: AdminUser,
):
    """Test an integration connection (admin only)."""
    service = IntegrationService(db)
    result = await service.test_integration(integration_id)
    return success_response(result)


@router.get("/{integration_id}/webhooks")
async def list_webhooks(
    integration_id: UUID,
    db: DbSession,
    current_user: AdminUser,
):
    """List webhooks for a specific integration (admin only)."""
    service = IntegrationService(db)
    result = await service.list_webhooks(integration_id)
    return success_response(result)
