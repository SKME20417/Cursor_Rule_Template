"""Developer tools API routes."""

from uuid import UUID

from fastapi import APIRouter, Body

from app.core.response import success_response
from app.dependencies import AdminUser, DbSession
from app.services.developer_service import DeveloperService

router = APIRouter(prefix="/developers", tags=["Developers"])


@router.get("/webhooks")
async def list_webhooks(
    db: DbSession,
    current_user: AdminUser,
):
    """List all webhook configurations (admin only)."""
    service = DeveloperService(db)
    result = await service.list_webhooks()
    return success_response(result)


@router.post("/webhooks")
async def create_webhook(
    db: DbSession,
    current_user: AdminUser,
    data: dict = Body(...),
):
    """Create a new webhook configuration (admin only)."""
    service = DeveloperService(db)
    result = await service.create_webhook(data)
    return success_response(result)


@router.put("/webhooks/{webhook_id}")
async def update_webhook(
    webhook_id: UUID,
    db: DbSession,
    current_user: AdminUser,
    data: dict = Body(...),
):
    """Update a webhook configuration (admin only)."""
    service = DeveloperService(db)
    result = await service.update_webhook(webhook_id, data)
    return success_response(result)


@router.delete("/webhooks/{webhook_id}")
async def delete_webhook(
    webhook_id: UUID,
    db: DbSession,
    current_user: AdminUser,
):
    """Delete a webhook configuration (admin only)."""
    service = DeveloperService(db)
    await service.delete_webhook(webhook_id)
    return success_response(None, message="Webhook deleted")


@router.post("/webhooks/{webhook_id}/test")
async def test_webhook(
    webhook_id: UUID,
    db: DbSession,
    current_user: AdminUser,
):
    """Send a test event to a webhook (admin only)."""
    service = DeveloperService(db)
    result = await service.test_webhook(webhook_id)
    return success_response(result)


@router.post("/sandbox")
async def execute_sandbox(
    db: DbSession,
    current_user: AdminUser,
    code: str = Body(..., embed=True),
):
    """Execute code in a sandboxed environment (admin only)."""
    service = DeveloperService(db)
    result = await service.execute_sandbox(code)
    return success_response(result)
