"""Knowledge base API routes."""

from uuid import UUID

from fastapi import APIRouter, Query

from app.core.pagination import build_paginated_response
from app.core.response import success_response
from app.dependencies import AgentOrAdmin, CurrentUser, DbSession, Pagination
from app.schemas.knowledge_base import CreateArticleRequest, UpdateArticleRequest
from app.services.knowledge_base_service import KnowledgeBaseService

router = APIRouter(prefix="/knowledge-base", tags=["Knowledge Base"])


@router.get("/articles")
async def list_articles(
    db: DbSession,
    current_user: CurrentUser,
    pagination: Pagination,
):
    """List knowledge base articles with pagination."""
    service = KnowledgeBaseService(db)
    data, total = await service.list_articles(
        offset=pagination.offset, limit=pagination.limit
    )
    return build_paginated_response(data, total, pagination.page, pagination.page_size)


@router.post("/articles")
async def create_article(
    body: CreateArticleRequest,
    db: DbSession,
    current_user: AgentOrAdmin,
):
    """Create a new knowledge base article."""
    service = KnowledgeBaseService(db)
    result = await service.create_article(body, current_user["user_id"])
    return success_response(result)


@router.get("/articles/search")
async def search_articles(
    db: DbSession,
    current_user: CurrentUser,
    pagination: Pagination,
    q: str = Query(..., min_length=1),
):
    """Search articles by title or content."""
    service = KnowledgeBaseService(db)
    data, total = await service.search_articles(
        q, offset=pagination.offset, limit=pagination.limit
    )
    return build_paginated_response(data, total, pagination.page, pagination.page_size)


@router.get("/articles/{article_id}")
async def get_article(
    article_id: UUID,
    db: DbSession,
    current_user: CurrentUser,
):
    """Get a single knowledge base article."""
    service = KnowledgeBaseService(db)
    result = await service.get_article(article_id)
    return success_response(result)


@router.patch("/articles/{article_id}")
async def update_article(
    article_id: UUID,
    body: UpdateArticleRequest,
    db: DbSession,
    current_user: AgentOrAdmin,
):
    """Update an existing knowledge base article."""
    service = KnowledgeBaseService(db)
    result = await service.update_article(article_id, body)
    return success_response(result)


@router.get("/categories")
async def list_categories(
    db: DbSession,
    current_user: CurrentUser,
):
    """List all knowledge base categories."""
    service = KnowledgeBaseService(db)
    result = await service.list_categories()
    return success_response(result)
