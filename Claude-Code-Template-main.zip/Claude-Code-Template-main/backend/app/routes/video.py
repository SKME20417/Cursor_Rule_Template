"""Video session API routes."""

from uuid import UUID

from fastapi import APIRouter

from app.core.response import success_response
from app.dependencies import CurrentUser, DbSession
from app.schemas.video import CreateVideoSessionRequest
from app.services.video_service import VideoService

router = APIRouter(prefix="/video", tags=["Video"])


@router.post("/sessions")
async def create_session(
    body: CreateVideoSessionRequest,
    db: DbSession,
    current_user: CurrentUser,
):
    """Create a new video session."""
    service = VideoService(db)
    result = await service.create_session(body, current_user["user_id"])
    return success_response(result)


@router.post("/sessions/{session_id}/join")
async def join_session(
    session_id: UUID,
    db: DbSession,
    current_user: CurrentUser,
):
    """Join an existing video session."""
    service = VideoService(db)
    result = await service.join_session(session_id, current_user["user_id"])
    return success_response(result)


@router.post("/sessions/{session_id}/end")
async def end_session(
    session_id: UUID,
    db: DbSession,
    current_user: CurrentUser,
):
    """End a video session."""
    service = VideoService(db)
    result = await service.end_session(session_id, current_user["user_id"])
    return success_response(result)
