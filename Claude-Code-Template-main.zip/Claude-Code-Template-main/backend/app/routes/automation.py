"""Automation workflow API routes."""

from uuid import UUID

from fastapi import APIRouter

from app.core.pagination import build_paginated_response
from app.core.response import success_response
from app.dependencies import AdminUser, DbSession, Pagination
from app.schemas.automation import CreateWorkflowRequest, UpdateWorkflowRequest
from app.services.automation_service import AutomationService

router = APIRouter(prefix="/automation", tags=["Automation"])


@router.get("/workflows")
async def list_workflows(
    db: DbSession,
    current_user: AdminUser,
    pagination: Pagination,
):
    """List workflows with pagination (admin only)."""
    service = AutomationService(db)
    data, total = await service.list_workflows(
        offset=pagination.offset, limit=pagination.limit
    )
    return build_paginated_response(data, total, pagination.page, pagination.page_size)


@router.post("/workflows")
async def create_workflow(
    body: CreateWorkflowRequest,
    db: DbSession,
    current_user: AdminUser,
):
    """Create a new automation workflow (admin only)."""
    service = AutomationService(db)
    result = await service.create_workflow(body, current_user["user_id"])
    return success_response(result)


@router.patch("/workflows/{workflow_id}")
async def update_workflow(
    workflow_id: UUID,
    body: UpdateWorkflowRequest,
    db: DbSession,
    current_user: AdminUser,
):
    """Update an existing workflow (admin only)."""
    service = AutomationService(db)
    result = await service.update_workflow(workflow_id, body)
    return success_response(result)


@router.get("/auto-replies")
async def list_auto_replies(
    db: DbSession,
    current_user: AdminUser,
):
    """List all auto-reply templates (admin only)."""
    service = AutomationService(db)
    result = await service.list_auto_replies()
    return success_response(result)


@router.get("/escalation-rules")
async def list_escalation_rules(
    db: DbSession,
    current_user: AdminUser,
):
    """List all escalation rules (admin only)."""
    service = AutomationService(db)
    result = await service.list_escalation_rules()
    return success_response(result)
