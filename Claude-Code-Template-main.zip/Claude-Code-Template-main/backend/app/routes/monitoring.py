"""System monitoring API routes."""

from fastapi import APIRouter

from app.core.response import success_response
from app.dependencies import AdminUser, DbSession
from app.services.monitoring_service import MonitoringService

router = APIRouter(prefix="/monitoring", tags=["Monitoring"])


@router.get("/health")
async def get_health(
    db: DbSession,
    current_user: AdminUser,
):
    """Get system service health status (admin only)."""
    service = MonitoringService(db)
    result = await service.get_health()
    return success_response(result)


@router.get("/queues")
async def get_queues(
    db: DbSession,
    current_user: AdminUser,
):
    """Get queue depth and throughput metrics (admin only)."""
    service = MonitoringService(db)
    result = await service.get_queues()
    return success_response(result)


@router.get("/alerts")
async def get_alerts(
    db: DbSession,
    current_user: AdminUser,
):
    """Get recent alert history (admin only)."""
    service = MonitoringService(db)
    result = await service.get_alerts()
    return success_response(result)


@router.get("/alert-rules")
async def get_alert_rules(
    db: DbSession,
    current_user: AdminUser,
):
    """Get all alert rules (admin only)."""
    service = MonitoringService(db)
    result = await service.get_alert_rules()
    return success_response(result)
