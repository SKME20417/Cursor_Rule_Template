"""Ticket API routes."""

from uuid import UUID

from fastapi import APIRouter

from app.core.pagination import build_paginated_response
from app.core.response import success_response
from app.dependencies import CurrentUser, DbSession, Pagination
from app.schemas.ticket import (
    CreateTicketCommentRequest,
    CreateTicketRequest,
    UpdateTicketRequest,
)
from app.services.ticket_service import TicketService

router = APIRouter(prefix="/tickets", tags=["Tickets"])


@router.get("/")
async def list_tickets(
    db: DbSession,
    current_user: CurrentUser,
    pagination: Pagination,
):
    """List tickets with pagination."""
    service = TicketService(db)
    data, total = await service.list_tickets(
        offset=pagination.offset, limit=pagination.limit
    )
    return build_paginated_response(data, total, pagination.page, pagination.page_size)


@router.post("/")
async def create_ticket(
    body: CreateTicketRequest,
    db: DbSession,
    current_user: CurrentUser,
):
    """Create a new ticket."""
    service = TicketService(db)
    result = await service.create_ticket(body, current_user["user_id"])
    return success_response(result)


@router.get("/{ticket_id}")
async def get_ticket(
    ticket_id: UUID,
    db: DbSession,
    current_user: CurrentUser,
):
    """Get a single ticket by ID."""
    service = TicketService(db)
    result = await service.get_ticket(ticket_id)
    return success_response(result)


@router.patch("/{ticket_id}")
async def update_ticket(
    ticket_id: UUID,
    body: UpdateTicketRequest,
    db: DbSession,
    current_user: CurrentUser,
):
    """Update an existing ticket."""
    service = TicketService(db)
    result = await service.update_ticket(ticket_id, body)
    return success_response(result)


@router.post("/{ticket_id}/comments")
async def add_comment(
    ticket_id: UUID,
    body: CreateTicketCommentRequest,
    db: DbSession,
    current_user: CurrentUser,
):
    """Add a comment to a ticket."""
    service = TicketService(db)
    result = await service.add_comment(ticket_id, body, current_user["user_id"])
    return success_response(result)


@router.get("/{ticket_id}/timeline")
async def get_timeline(
    ticket_id: UUID,
    db: DbSession,
    current_user: CurrentUser,
):
    """Get the timeline of comments for a ticket."""
    service = TicketService(db)
    result = await service.get_timeline(ticket_id)
    return success_response(result)
