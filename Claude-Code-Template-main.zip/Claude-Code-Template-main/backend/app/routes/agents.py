"""Agent and team API routes."""

from uuid import UUID

from fastapi import APIRouter

from app.core.pagination import build_paginated_response
from app.core.response import success_response
from app.dependencies import AdminUser, AgentOrAdmin, DbSession, Pagination
from app.schemas.agent import CreateAgentRequest, UpdateAgentRequest
from app.services.agent_service import AgentService

router = APIRouter(prefix="/agents", tags=["Agents"])


@router.get("/")
async def list_agents(
    db: DbSession,
    current_user: AdminUser,
    pagination: Pagination,
):
    """List agents with pagination (admin only)."""
    service = AgentService(db)
    data, total = await service.list_agents(
        offset=pagination.offset, limit=pagination.limit
    )
    return build_paginated_response(data, total, pagination.page, pagination.page_size)


@router.post("/")
async def create_agent(
    body: CreateAgentRequest,
    db: DbSession,
    current_user: AdminUser,
):
    """Register a new support agent (admin only)."""
    service = AgentService(db)
    result = await service.create_agent(body)
    return success_response(result)


@router.get("/teams")
async def list_teams(
    db: DbSession,
    current_user: AgentOrAdmin,
):
    """List all agent teams."""
    service = AgentService(db)
    result = await service.list_teams()
    return success_response(result)


@router.get("/{agent_id}")
async def get_agent(
    agent_id: UUID,
    db: DbSession,
    current_user: AgentOrAdmin,
):
    """Get a single agent by ID."""
    service = AgentService(db)
    result = await service.get_agent(agent_id)
    return success_response(result)


@router.patch("/{agent_id}")
async def update_agent(
    agent_id: UUID,
    body: UpdateAgentRequest,
    db: DbSession,
    current_user: AdminUser,
):
    """Update an existing agent (admin only)."""
    service = AgentService(db)
    result = await service.update_agent(agent_id, body)
    return success_response(result)
