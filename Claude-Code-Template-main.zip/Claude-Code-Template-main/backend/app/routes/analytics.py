"""Analytics API routes."""

from fastapi import APIRouter

from app.core.response import success_response
from app.dependencies import AgentOrAdmin, DbSession
from app.schemas.analytics import TimeSeriesRequest
from app.services.analytics_service import AnalyticsService

router = APIRouter(prefix="/analytics", tags=["Analytics"])


@router.get("/metrics")
async def get_metrics(
    db: DbSession,
    current_user: AgentOrAdmin,
):
    """Get dashboard metric cards."""
    service = AnalyticsService(db)
    result = await service.get_metrics()
    return success_response(result)


@router.post("/time-series")
async def get_time_series(
    body: TimeSeriesRequest,
    db: DbSession,
    current_user: AgentOrAdmin,
):
    """Get time-series data for a given metric."""
    service = AnalyticsService(db)
    result = await service.get_time_series(body)
    return success_response(result)


@router.get("/agents")
async def get_agent_metrics(
    db: DbSession,
    current_user: AgentOrAdmin,
):
    """Get per-agent performance metrics."""
    service = AnalyticsService(db)
    result = await service.get_agent_metrics()
    return success_response(result)


@router.get("/channels")
async def get_channel_metrics(
    db: DbSession,
    current_user: AgentOrAdmin,
):
    """Get metrics broken down by channel."""
    service = AnalyticsService(db)
    result = await service.get_channel_metrics()
    return success_response(result)


@router.get("/sla")
async def get_sla_metrics(
    db: DbSession,
    current_user: AgentOrAdmin,
):
    """Get SLA compliance metrics."""
    service = AnalyticsService(db)
    result = await service.get_sla_metrics()
    return success_response(result)
