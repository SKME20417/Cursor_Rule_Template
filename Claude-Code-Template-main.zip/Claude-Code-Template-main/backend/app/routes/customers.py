"""Customer API routes."""

from uuid import UUID

from fastapi import APIRouter, Query

from app.core.pagination import build_paginated_response
from app.core.response import success_response
from app.dependencies import AgentOrAdmin, DbSession, Pagination
from app.services.customer_service import CustomerService

router = APIRouter(prefix="/customers", tags=["Customers"])


@router.get("/")
async def list_customers(
    db: DbSession,
    current_user: AgentOrAdmin,
    pagination: Pagination,
    search: str | None = Query(default=None),
):
    """List customers with optional search."""
    service = CustomerService(db)
    data, total = await service.list_customers(
        offset=pagination.offset, limit=pagination.limit, search=search
    )
    return build_paginated_response(data, total, pagination.page, pagination.page_size)


@router.get("/{customer_id}")
async def get_customer(
    customer_id: UUID,
    db: DbSession,
    current_user: AgentOrAdmin,
):
    """Get a customer profile with aggregated data."""
    service = CustomerService(db)
    result = await service.get_profile(customer_id)
    return success_response(result)


@router.get("/{customer_id}/history")
async def get_customer_history(
    customer_id: UUID,
    db: DbSession,
    current_user: AgentOrAdmin,
    pagination: Pagination,
):
    """Get conversation history for a customer."""
    service = CustomerService(db)
    data, total = await service.get_history(
        customer_id, offset=pagination.offset, limit=pagination.limit
    )
    return build_paginated_response(data, total, pagination.page, pagination.page_size)
