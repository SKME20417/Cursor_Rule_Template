"""Admin configuration API routes."""

from fastapi import APIRouter

from app.core.response import success_response
from app.dependencies import AdminUser, DbSession
from app.schemas.admin import UpdateAdminConfigRequest, UpdateBrandConfigRequest
from app.services.admin_service import AdminService

router = APIRouter(prefix="/admin", tags=["Admin"])


@router.get("/config")
async def get_config(
    db: DbSession,
    current_user: AdminUser,
):
    """Get platform configuration (admin only)."""
    service = AdminService(db)
    result = await service.get_config()
    return success_response(result)


@router.patch("/config")
async def update_config(
    body: UpdateAdminConfigRequest,
    db: DbSession,
    current_user: AdminUser,
):
    """Update platform configuration (admin only)."""
    service = AdminService(db)
    result = await service.update_config(body)
    return success_response(result)


@router.get("/branding")
async def get_branding(
    db: DbSession,
    current_user: AdminUser,
):
    """Get branding configuration (admin only)."""
    service = AdminService(db)
    result = await service.get_branding()
    return success_response(result)


@router.patch("/branding")
async def update_branding(
    body: UpdateBrandConfigRequest,
    db: DbSession,
    current_user: AdminUser,
):
    """Update branding configuration (admin only)."""
    service = AdminService(db)
    result = await service.update_branding(body)
    return success_response(result)
