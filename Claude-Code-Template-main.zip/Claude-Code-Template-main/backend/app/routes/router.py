"""Main API router that mounts all sub-routers under /api/v1."""

from fastapi import APIRouter

from app.routes.admin import router as admin_router
from app.routes.agents import router as agents_router
from app.routes.analytics import router as analytics_router
from app.routes.auth import router as auth_router
from app.routes.automation import router as automation_router
from app.routes.calls import router as calls_router
from app.routes.conversations import router as conversations_router
from app.routes.copilot import router as copilot_router
from app.routes.customers import router as customers_router
from app.routes.developers import router as developers_router
from app.routes.integrations import router as integrations_router
from app.routes.knowledge_base import router as knowledge_base_router
from app.routes.monitoring import router as monitoring_router
from app.routes.nlp import router as nlp_router
from app.routes.security import router as security_router
from app.routes.tickets import router as tickets_router
from app.routes.upload import router as upload_router
from app.routes.video import router as video_router

api_router = APIRouter(prefix="/api/v1")

# Authentication (built separately)
api_router.include_router(auth_router)

# Core communication
api_router.include_router(conversations_router)
api_router.include_router(tickets_router)
api_router.include_router(calls_router)
api_router.include_router(video_router)

# AI & NLP
api_router.include_router(copilot_router)
api_router.include_router(nlp_router)

# Knowledge base
api_router.include_router(knowledge_base_router)

# Analytics & reporting
api_router.include_router(analytics_router)

# Customer management
api_router.include_router(customers_router)

# Agent & team management
api_router.include_router(agents_router)

# Automation
api_router.include_router(automation_router)

# Integrations
api_router.include_router(integrations_router)

# Admin
api_router.include_router(admin_router)

# Monitoring
api_router.include_router(monitoring_router)

# Security
api_router.include_router(security_router)

# File upload
api_router.include_router(upload_router)

# Developer tools
api_router.include_router(developers_router)
