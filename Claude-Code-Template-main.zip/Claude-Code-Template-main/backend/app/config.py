"""Application configuration loaded from environment variables."""

from functools import lru_cache

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Typed application settings with defaults for local development."""

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    # ── App ──────────────────────────────────────────────────
    app_env: str = "development"
    app_debug: bool = True
    app_port: int = 8000
    frontend_url: str = "http://localhost:3000"

    # ── Database ─────────────────────────────────────────────
    postgres_host: str = "localhost"
    postgres_port: int = 5432
    postgres_db: str = "support_copilot"
    postgres_user: str = "postgres"
    postgres_password: str = ""
    database_url: str = ""

    @property
    def async_database_url(self) -> str:
        if self.database_url:
            return self.database_url
        return (
            f"postgresql+asyncpg://{self.postgres_user}:{self.postgres_password}"
            f"@{self.postgres_host}:{self.postgres_port}/{self.postgres_db}"
        )

    # ── Redis ────────────────────────────────────────────────
    redis_host: str = "localhost"
    redis_port: int = 6379
    redis_password: str = ""
    redis_url: str = ""

    @property
    def resolved_redis_url(self) -> str:
        if self.redis_url:
            return self.redis_url
        if self.redis_password:
            return f"redis://:{self.redis_password}@{self.redis_host}:{self.redis_port}/0"
        return f"redis://{self.redis_host}:{self.redis_port}/0"

    # ── JWT ──────────────────────────────────────────────────
    jwt_secret_key: str = "CHANGE_ME_IN_PRODUCTION_32_chars!"
    jwt_algorithm: str = "HS256"
    jwt_access_token_expire_minutes: int = 30
    jwt_refresh_token_expire_days: int = 7

    # ── AI / LLM ─────────────────────────────────────────────
    openai_api_key: str = ""
    openai_model: str = "gpt-4o"
    openai_embedding_model: str = "text-embedding-3-small"
    anthropic_api_key: str = ""
    anthropic_model: str = "claude-sonnet-4-6"
    default_llm_provider: str = "openai"

    # ── Vector Store ─────────────────────────────────────────
    vector_store_provider: str = "pgvector"
    pinecone_api_key: str = ""
    pinecone_environment: str = ""
    pinecone_index_name: str = "support-copilot"

    # ── RAG ──────────────────────────────────────────────────
    rag_chunk_size: int = 512
    rag_chunk_overlap: int = 50
    rag_top_k: int = 5

    # ── AWS ──────────────────────────────────────────────────
    aws_access_key_id: str = ""
    aws_secret_access_key: str = ""
    aws_region: str = "us-east-1"
    aws_s3_bucket: str = "support-copilot-uploads"
    aws_ses_sender_email: str = ""

    # ── Email (SMTP) ─────────────────────────────────────────
    smtp_host: str = ""
    smtp_port: int = 587
    smtp_user: str = ""
    smtp_password: str = ""

    # ── Twilio ───────────────────────────────────────────────
    twilio_account_sid: str = ""
    twilio_auth_token: str = ""
    twilio_phone_number: str = ""

    # ── WhatsApp ─────────────────────────────────────────────
    whatsapp_api_token: str = ""
    whatsapp_phone_number_id: str = ""
    whatsapp_verify_token: str = ""

    # ── Slack ────────────────────────────────────────────────
    slack_bot_token: str = ""
    slack_signing_secret: str = ""

    # ── CRM Integrations ────────────────────────────────────
    salesforce_client_id: str = ""
    salesforce_client_secret: str = ""
    salesforce_instance_url: str = ""
    hubspot_api_key: str = ""
    zendesk_subdomain: str = ""
    zendesk_api_token: str = ""
    zendesk_email: str = ""
    jira_base_url: str = ""
    jira_api_token: str = ""
    jira_email: str = ""

    # ── WebRTC ───────────────────────────────────────────────
    turn_server_url: str = ""
    turn_server_username: str = ""
    turn_server_password: str = ""
    webrtc_provider: str = "twilio"

    # ── Observability ────────────────────────────────────────
    sentry_dsn: str = ""
    log_level: str = "INFO"
    log_format: str = "json"

    # ── Kafka ────────────────────────────────────────────────
    kafka_bootstrap_servers: str = "localhost:9092"
    message_queue_provider: str = "redis"

    # ── Celery ───────────────────────────────────────────────
    celery_broker_url: str = ""
    celery_result_backend: str = ""

    # ── Security ─────────────────────────────────────────────
    cors_origins: str = "http://localhost:3000,http://localhost:3001"
    allowed_upload_types: str = "image/png,image/jpeg,image/webp,application/pdf"
    rate_limit_per_minute: int = 60
    encryption_key: str = ""

    @property
    def cors_origin_list(self) -> list[str]:
        return [o.strip() for o in self.cors_origins.split(",") if o.strip()]

    @property
    def allowed_upload_type_list(self) -> list[str]:
        return [t.strip() for t in self.allowed_upload_types.split(",") if t.strip()]


@lru_cache
def get_settings() -> Settings:
    """Cached singleton settings instance."""
    return Settings()
