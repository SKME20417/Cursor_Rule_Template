"""WebSocket endpoint and message routing."""

import json

import structlog
from fastapi import APIRouter, Query, WebSocket, WebSocketDisconnect

from app.websockets.auth import authenticate_ws_token
from app.websockets.events import WSEventType
from app.websockets.manager import ws_manager

logger = structlog.get_logger()

ws_router = APIRouter()


@ws_router.websocket("/ws")
async def websocket_endpoint(
    websocket: WebSocket,
    token: str = Query(default=""),
) -> None:
    """Main WebSocket endpoint with JWT authentication."""
    # Authenticate
    user = authenticate_ws_token(token)
    if not user:
        await websocket.close(code=4001, reason="Unauthorized")
        return

    user_id = user["user_id"]
    await ws_manager.connect(websocket, user_id)

    try:
        # Send connection confirmation
        await ws_manager.send_to_user(user_id, {
            "type": WSEventType.CONNECT,
            "payload": {"userId": str(user_id), "role": user["role"]},
        })

        while True:
            raw = await websocket.receive_text()

            try:
                data = json.loads(raw)
            except json.JSONDecodeError:
                continue

            event_type = data.get("type", "")
            payload = data.get("payload", {})

            # Handle ping/pong heartbeat
            if event_type == WSEventType.PING:
                await ws_manager.send_to_user(user_id, {"type": WSEventType.PONG})
                continue

            # Handle subscribe
            if event_type == WSEventType.SUBSCRIBE:
                channel = payload.get("channel", "")
                if channel:
                    ws_manager.subscribe(user_id, channel)
                    logger.debug("ws_subscribed", user_id=str(user_id), channel=channel)
                continue

            # Handle unsubscribe
            if event_type == WSEventType.UNSUBSCRIBE:
                channel = payload.get("channel", "")
                if channel:
                    ws_manager.unsubscribe(user_id, channel)
                continue

            # Handle typing indicators
            if event_type in (WSEventType.TYPING_START, WSEventType.TYPING_STOP):
                conversation_id = payload.get("conversationId")
                if conversation_id:
                    await ws_manager.broadcast_to_channel(
                        f"conversation:{conversation_id}",
                        {
                            "type": event_type,
                            "payload": {
                                "conversationId": conversation_id,
                                "userId": str(user_id),
                                "isTyping": event_type == WSEventType.TYPING_START,
                            },
                        },
                    )
                continue

            # Log unknown events
            logger.debug("ws_unknown_event", event_type=event_type, user_id=str(user_id))

    except WebSocketDisconnect:
        pass
    except Exception as exc:
        logger.warning("ws_error", error=str(exc), user_id=str(user_id))
    finally:
        await ws_manager.disconnect(websocket, user_id)
