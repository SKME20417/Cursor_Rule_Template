"""WebSocket connection manager with room/channel support."""

import json
from uuid import UUID

import structlog
from fastapi import WebSocket

logger = structlog.get_logger()


class ConnectionManager:
    """Manages active WebSocket connections and room subscriptions."""

    def __init__(self) -> None:
        # user_id -> set of WebSocket connections
        self._connections: dict[UUID, set[WebSocket]] = {}
        # channel_key -> set of user_ids subscribed
        self._subscriptions: dict[str, set[UUID]] = {}

    async def connect(self, websocket: WebSocket, user_id: UUID) -> None:
        """Accept connection and register user."""
        await websocket.accept()
        self._connections.setdefault(user_id, set()).add(websocket)
        logger.info("ws_connected", user_id=str(user_id))

    async def disconnect(self, websocket: WebSocket, user_id: UUID) -> None:
        """Remove connection and clean up subscriptions."""
        conns = self._connections.get(user_id)
        if conns:
            conns.discard(websocket)
            if not conns:
                del self._connections[user_id]
                # Remove from all subscriptions
                for channel, subscribers in list(self._subscriptions.items()):
                    subscribers.discard(user_id)
                    if not subscribers:
                        del self._subscriptions[channel]
        logger.info("ws_disconnected", user_id=str(user_id))

    def subscribe(self, user_id: UUID, channel: str) -> None:
        """Subscribe a user to a channel."""
        self._subscriptions.setdefault(channel, set()).add(user_id)

    def unsubscribe(self, user_id: UUID, channel: str) -> None:
        """Unsubscribe a user from a channel."""
        subs = self._subscriptions.get(channel)
        if subs:
            subs.discard(user_id)
            if not subs:
                del self._subscriptions[channel]

    async def send_to_user(self, user_id: UUID, message: dict) -> None:
        """Send a message to all connections of a specific user."""
        conns = self._connections.get(user_id, set())
        payload = json.dumps(message, default=str)
        dead: list[WebSocket] = []
        for ws in conns:
            try:
                await ws.send_text(payload)
            except Exception:
                dead.append(ws)
        for ws in dead:
            conns.discard(ws)

    async def broadcast_to_channel(self, channel: str, message: dict) -> None:
        """Broadcast a message to all users subscribed to a channel."""
        subscribers = self._subscriptions.get(channel, set())
        for user_id in subscribers:
            await self.send_to_user(user_id, message)

    async def broadcast_all(self, message: dict) -> None:
        """Broadcast to all connected users."""
        for user_id in list(self._connections.keys()):
            await self.send_to_user(user_id, message)

    @property
    def active_connections_count(self) -> int:
        return sum(len(conns) for conns in self._connections.values())


# Singleton instance
ws_manager = ConnectionManager()
