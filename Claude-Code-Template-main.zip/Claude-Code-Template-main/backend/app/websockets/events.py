"""WebSocket event types and message envelope."""

from datetime import datetime
from enum import StrEnum
from typing import Any
from uuid import UUID, uuid4

from pydantic import BaseModel, Field


class WSEventType(StrEnum):
    CONNECT = "connect"
    DISCONNECT = "disconnect"
    HEARTBEAT = "heartbeat"
    PING = "ping"
    PONG = "pong"
    MESSAGE_CREATED = "message.created"
    MESSAGE_UPDATED = "message.updated"
    TYPING_START = "typing.start"
    TYPING_STOP = "typing.stop"
    CONVERSATION_UPDATED = "conversation.updated"
    AGENT_STATUS_CHANGED = "agent.status_changed"
    AGENT_ASSIGNED = "agent.assigned"
    NOTIFICATION = "notification"
    TICKET_UPDATED = "ticket.updated"
    SLA_WARNING = "sla.warning"
    SUBSCRIBE = "subscribe"
    UNSUBSCRIBE = "unsubscribe"


class WSMessage(BaseModel):
    """WebSocket message envelope."""

    id: UUID = Field(default_factory=uuid4)
    event: str
    payload: Any = None
    timestamp: datetime = Field(default_factory=datetime.utcnow)


class WSSubscription(BaseModel):
    """Subscribe/unsubscribe to a channel."""

    channel: str
    resource_id: UUID | None = None
