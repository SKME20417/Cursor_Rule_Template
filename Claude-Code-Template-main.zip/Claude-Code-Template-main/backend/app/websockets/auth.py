"""WebSocket authentication via JWT query parameter."""

from uuid import UUID

from jose import JWTError

from app.core.security import decode_access_token


def authenticate_ws_token(token: str) -> dict | None:
    """Validate a JWT token from WS query param.

    Returns {"user_id": UUID, "role": str} or None.
    """
    if not token:
        return None
    try:
        payload = decode_access_token(token)
        user_id_str = payload.get("sub")
        role = payload.get("role")
        if not user_id_str or not role:
            return None
        return {"user_id": UUID(user_id_str), "role": role}
    except (JWTError, ValueError):
        return None
