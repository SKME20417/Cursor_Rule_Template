"""Customer repository with domain-specific queries."""

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.customer import Customer
from app.repositories.base import GenericRepository


class CustomerRepository(GenericRepository[Customer]):
    """Repository for Customer entities."""

    def __init__(self, session: AsyncSession) -> None:
        super().__init__(Customer, session)

    async def search_by_email(
        self, email: str, offset: int = 0, limit: int = 20
    ) -> tuple[list[Customer], int]:
        """Search customers by email (case-insensitive partial match)."""
        pattern = f"%{email}%"
        query = select(self.model).where(self.model.email.ilike(pattern))
        count_query = select(func.count()).select_from(self.model).where(
            self.model.email.ilike(pattern)
        )

        total_result = await self.session.execute(count_query)
        total = total_result.scalar() or 0

        query = query.order_by(self.model.created_at.desc()).offset(offset).limit(limit)
        result = await self.session.execute(query)
        return list(result.scalars().all()), total

    async def search_by_name(
        self, name: str, offset: int = 0, limit: int = 20
    ) -> tuple[list[Customer], int]:
        """Search customers by first or last name (case-insensitive partial match)."""
        pattern = f"%{name}%"
        condition = self.model.first_name.ilike(pattern) | self.model.last_name.ilike(
            pattern
        )
        query = select(self.model).where(condition)
        count_query = select(func.count()).select_from(self.model).where(condition)

        total_result = await self.session.execute(count_query)
        total = total_result.scalar() or 0

        query = query.order_by(self.model.created_at.desc()).offset(offset).limit(limit)
        result = await self.session.execute(query)
        return list(result.scalars().all()), total
