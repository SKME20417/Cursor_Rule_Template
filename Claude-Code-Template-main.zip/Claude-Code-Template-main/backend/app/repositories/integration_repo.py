"""Integration repository."""

from sqlalchemy.ext.asyncio import AsyncSession

from app.models.integration import Integration
from app.repositories.base import GenericRepository


class IntegrationRepository(GenericRepository[Integration]):
    """Repository for Integration entities."""

    def __init__(self, session: AsyncSession) -> None:
        super().__init__(Integration, session)
