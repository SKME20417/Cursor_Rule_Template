"""Agent repository with domain-specific queries."""

from uuid import UUID

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.agent import Agent
from app.repositories.base import GenericRepository


class AgentRepository(GenericRepository[Agent]):
    """Repository for Agent entities."""

    def __init__(self, session: AsyncSession) -> None:
        super().__init__(Agent, session)

    async def get_by_user_id(self, user_id: UUID) -> Agent | None:
        """Get an agent by linked user ID."""
        query = select(self.model).where(self.model.user_id == user_id)
        result = await self.session.execute(query)
        return result.scalars().first()

    async def get_online_agents(
        self, offset: int = 0, limit: int = 20
    ) -> tuple[list[Agent], int]:
        """Get agents with online or busy status."""
        condition = self.model.status.in_(["online", "busy"])
        query = select(self.model).where(condition)
        count_query = select(func.count()).select_from(self.model).where(condition)

        total_result = await self.session.execute(count_query)
        total = total_result.scalar() or 0

        query = query.order_by(self.model.last_active_at.desc()).offset(offset).limit(limit)
        result = await self.session.execute(query)
        return list(result.scalars().all()), total
