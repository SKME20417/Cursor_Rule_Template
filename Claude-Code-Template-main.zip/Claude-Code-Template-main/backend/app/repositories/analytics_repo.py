"""Analytics repository with aggregated metric queries."""

from datetime import datetime
from typing import Any

from sqlalchemy import case, func, select, text
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.agent import Agent
from app.models.conversation import Conversation
from app.models.ticket import Ticket


class AnalyticsRepository:
    """Repository for aggregated analytics queries across multiple tables."""

    def __init__(self, session: AsyncSession) -> None:
        self.session = session

    async def get_metric_cards(self) -> list[dict[str, Any]]:
        """Get high-level dashboard metric cards."""
        # Total open conversations
        open_convos_q = select(func.count()).select_from(Conversation).where(
            Conversation.status == "open"
        )
        open_convos_result = await self.session.execute(open_convos_q)
        open_convos = open_convos_result.scalar() or 0

        # Total open tickets
        open_tickets_q = select(func.count()).select_from(Ticket).where(
            Ticket.status.in_(["created", "in_progress", "waiting"])
        )
        open_tickets_result = await self.session.execute(open_tickets_q)
        open_tickets = open_tickets_result.scalar() or 0

        # Online agents
        online_agents_q = select(func.count()).select_from(Agent).where(
            Agent.status.in_(["online", "busy"])
        )
        online_agents_result = await self.session.execute(online_agents_q)
        online_agents = online_agents_result.scalar() or 0

        # Total conversations today
        today_convos_q = select(func.count()).select_from(Conversation).where(
            func.date(Conversation.created_at) == func.current_date()
        )
        today_convos_result = await self.session.execute(today_convos_q)
        today_convos = today_convos_result.scalar() or 0

        return [
            {
                "label": "Open Conversations",
                "value": float(open_convos),
                "previousValue": None,
                "changePercent": None,
                "unit": None,
                "trend": "flat",
            },
            {
                "label": "Open Tickets",
                "value": float(open_tickets),
                "previousValue": None,
                "changePercent": None,
                "unit": None,
                "trend": "flat",
            },
            {
                "label": "Online Agents",
                "value": float(online_agents),
                "previousValue": None,
                "changePercent": None,
                "unit": None,
                "trend": "flat",
            },
            {
                "label": "Conversations Today",
                "value": float(today_convos),
                "previousValue": None,
                "changePercent": None,
                "unit": None,
                "trend": "flat",
            },
        ]

    async def get_agent_metrics(self) -> list[dict[str, Any]]:
        """Get per-agent performance metrics."""
        query = (
            select(
                Agent.id,
                Agent.display_name,
                Agent.active_conversation_count,
                func.count(Conversation.id).label("conversations_handled"),
            )
            .outerjoin(
                Conversation,
                Conversation.assigned_agent_id == Agent.id,
            )
            .group_by(Agent.id, Agent.display_name, Agent.active_conversation_count)
        )
        result = await self.session.execute(query)
        rows = result.all()

        return [
            {
                "agentId": str(row[0]),
                "agentName": row[1],
                "conversationsHandled": row[3],
                "averageResponseTimeSeconds": 0.0,
                "averageResolutionTimeSeconds": 0.0,
                "csatScore": None,
                "firstContactResolutionRate": 0.0,
                "activeConversations": row[2],
            }
            for row in rows
        ]

    async def get_channel_metrics(self) -> list[dict[str, Any]]:
        """Get metrics broken down by communication channel."""
        query = (
            select(
                Conversation.channel,
                func.count(Conversation.id).label("conversation_count"),
            )
            .group_by(Conversation.channel)
        )
        result = await self.session.execute(query)
        rows = result.all()

        return [
            {
                "channel": row[0],
                "conversationCount": row[1],
                "averageWaitTimeSeconds": 0.0,
                "averageHandleTimeSeconds": 0.0,
                "abandonmentRate": 0.0,
                "csatScore": None,
            }
            for row in rows
        ]

    async def get_sla_metrics(self) -> dict[str, Any]:
        """Get SLA compliance metrics."""
        total_q = select(func.count()).select_from(Ticket)
        total_result = await self.session.execute(total_q)
        total = total_result.scalar() or 0

        breached_q = select(func.count()).select_from(Ticket).where(
            Ticket.sla_breach_at.isnot(None)
        )
        breached_result = await self.session.execute(breached_q)
        breached = breached_result.scalar() or 0

        within_sla = total - breached
        compliance_rate = (within_sla / total * 100.0) if total > 0 else 100.0

        return {
            "totalTickets": total,
            "withinSLA": within_sla,
            "breached": breached,
            "complianceRate": round(compliance_rate, 2),
            "averageFirstResponseMinutes": 0.0,
            "averageResolutionMinutes": 0.0,
        }
