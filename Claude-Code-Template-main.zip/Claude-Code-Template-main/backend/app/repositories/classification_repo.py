"""Classification repository."""

from sqlalchemy.ext.asyncio import AsyncSession

from app.models.classification import Classification
from app.repositories.base import GenericRepository


class ClassificationRepository(GenericRepository[Classification]):
    """Repository for Classification entities."""

    def __init__(self, session: AsyncSession) -> None:
        super().__init__(Classification, session)
