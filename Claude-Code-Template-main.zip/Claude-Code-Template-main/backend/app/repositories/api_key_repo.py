"""ApiKey repository with domain-specific queries."""

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.api_key import ApiKey
from app.repositories.base import GenericRepository


class ApiKeyRepository(GenericRepository[ApiKey]):
    """Repository for ApiKey entities."""

    def __init__(self, session: AsyncSession) -> None:
        super().__init__(ApiKey, session)

    async def get_by_prefix(self, key_prefix: str) -> ApiKey | None:
        """Look up an API key by its visible prefix."""
        query = select(self.model).where(self.model.key_prefix == key_prefix)
        result = await self.session.execute(query)
        return result.scalars().first()
