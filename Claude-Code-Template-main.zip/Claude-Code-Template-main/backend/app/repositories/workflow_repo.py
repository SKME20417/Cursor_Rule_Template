"""Workflow repository."""

from sqlalchemy.ext.asyncio import AsyncSession

from app.models.workflow import Workflow
from app.repositories.base import GenericRepository


class WorkflowRepository(GenericRepository[Workflow]):
    """Repository for Workflow entities."""

    def __init__(self, session: AsyncSession) -> None:
        super().__init__(Workflow, session)
