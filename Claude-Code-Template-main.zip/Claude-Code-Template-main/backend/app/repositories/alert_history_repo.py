"""AlertHistory repository."""

from sqlalchemy.ext.asyncio import AsyncSession

from app.models.alert_history import AlertHistory
from app.repositories.base import GenericRepository


class AlertHistoryRepository(GenericRepository[AlertHistory]):
    """Repository for AlertHistory entities."""

    def __init__(self, session: AsyncSession) -> None:
        super().__init__(AlertHistory, session)
