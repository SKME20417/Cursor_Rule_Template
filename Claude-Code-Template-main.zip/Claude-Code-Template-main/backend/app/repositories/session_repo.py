"""Repository for RefreshToken data access."""

import uuid

from sqlalchemy import delete, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.session import RefreshToken
from app.repositories.base import GenericRepository


class SessionRepository(GenericRepository[RefreshToken]):
    """Data-access layer for the refresh_tokens table."""

    def __init__(self, session: AsyncSession) -> None:
        super().__init__(RefreshToken, session)

    async def get_by_token(self, token: str) -> RefreshToken | None:
        """Look up a refresh token row by its token string."""
        stmt = select(RefreshToken).where(RefreshToken.refresh_token == token)
        result = await self.session.execute(stmt)
        return result.scalars().first()

    async def delete_user_sessions(self, user_id: uuid.UUID) -> None:
        """Remove all refresh tokens for a given user (full logout)."""
        stmt = delete(RefreshToken).where(RefreshToken.user_id == user_id)
        await self.session.execute(stmt)
        await self.session.flush()
