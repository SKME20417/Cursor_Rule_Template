"""VideoSession repository."""

from sqlalchemy.ext.asyncio import AsyncSession

from app.models.video_session import VideoSession
from app.repositories.base import GenericRepository


class VideoSessionRepository(GenericRepository[VideoSession]):
    """Repository for VideoSession entities."""

    def __init__(self, session: AsyncSession) -> None:
        super().__init__(VideoSession, session)
