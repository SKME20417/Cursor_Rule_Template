"""TicketComment repository with domain-specific queries."""

from uuid import UUID

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.ticket_comment import TicketComment
from app.repositories.base import GenericRepository


class TicketCommentRepository(GenericRepository[TicketComment]):
    """Repository for TicketComment entities."""

    def __init__(self, session: AsyncSession) -> None:
        super().__init__(TicketComment, session)

    async def get_by_ticket(
        self, ticket_id: UUID, offset: int = 0, limit: int = 20
    ) -> tuple[list[TicketComment], int]:
        """Get comments for a specific ticket ordered by creation time."""
        condition = self.model.ticket_id == ticket_id
        query = select(self.model).where(condition)
        count_query = select(func.count()).select_from(self.model).where(condition)

        total_result = await self.session.execute(count_query)
        total = total_result.scalar() or 0

        query = query.order_by(self.model.created_at.asc()).offset(offset).limit(limit)
        result = await self.session.execute(query)
        return list(result.scalars().all()), total
