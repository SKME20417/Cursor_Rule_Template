"""AlertRule repository."""

from sqlalchemy.ext.asyncio import AsyncSession

from app.models.alert_rule import AlertRule
from app.repositories.base import GenericRepository


class AlertRuleRepository(GenericRepository[AlertRule]):
    """Repository for AlertRule entities."""

    def __init__(self, session: AsyncSession) -> None:
        super().__init__(AlertRule, session)
