"""Conversation repository with domain-specific queries."""

from uuid import UUID

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.conversation import Conversation
from app.repositories.base import GenericRepository


class ConversationRepository(GenericRepository[Conversation]):
    """Repository for Conversation entities."""

    def __init__(self, session: AsyncSession) -> None:
        super().__init__(Conversation, session)

    async def get_by_customer(
        self, customer_id: UUID, offset: int = 0, limit: int = 20
    ) -> tuple[list[Conversation], int]:
        """Get conversations for a specific customer."""
        condition = self.model.customer_id == customer_id
        query = select(self.model).where(condition)
        count_query = select(func.count()).select_from(self.model).where(condition)

        total_result = await self.session.execute(count_query)
        total = total_result.scalar() or 0

        query = query.order_by(self.model.last_message_at.desc()).offset(offset).limit(limit)
        result = await self.session.execute(query)
        return list(result.scalars().all()), total

    async def get_by_agent(
        self, agent_id: UUID, offset: int = 0, limit: int = 20
    ) -> tuple[list[Conversation], int]:
        """Get conversations assigned to a specific agent."""
        condition = self.model.assigned_agent_id == agent_id
        query = select(self.model).where(condition)
        count_query = select(func.count()).select_from(self.model).where(condition)

        total_result = await self.session.execute(count_query)
        total = total_result.scalar() or 0

        query = query.order_by(self.model.last_message_at.desc()).offset(offset).limit(limit)
        result = await self.session.execute(query)
        return list(result.scalars().all()), total
