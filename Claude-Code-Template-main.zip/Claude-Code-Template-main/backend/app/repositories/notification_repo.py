"""Notification repository with domain-specific queries."""

from uuid import UUID

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.notification import Notification
from app.repositories.base import GenericRepository


class NotificationRepository(GenericRepository[Notification]):
    """Repository for Notification entities."""

    def __init__(self, session: AsyncSession) -> None:
        super().__init__(Notification, session)

    async def get_unread_by_user(
        self, user_id: UUID, offset: int = 0, limit: int = 20
    ) -> tuple[list[Notification], int]:
        """Get unread notifications for a specific user."""
        condition = (self.model.user_id == user_id) & (self.model.is_read == False)  # noqa: E712
        query = select(self.model).where(condition)
        count_query = select(func.count()).select_from(self.model).where(condition)

        total_result = await self.session.execute(count_query)
        total = total_result.scalar() or 0

        query = query.order_by(self.model.created_at.desc()).offset(offset).limit(limit)
        result = await self.session.execute(query)
        return list(result.scalars().all()), total
