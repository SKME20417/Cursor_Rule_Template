"""Draft repository."""

from sqlalchemy.ext.asyncio import AsyncSession

from app.models.draft import Draft
from app.repositories.base import GenericRepository


class DraftRepository(GenericRepository[Draft]):
    """Repository for Draft entities."""

    def __init__(self, session: AsyncSession) -> None:
        super().__init__(Draft, session)
