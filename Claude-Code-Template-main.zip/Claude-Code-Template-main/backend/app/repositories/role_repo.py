"""Role repository with domain-specific queries."""

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.role import RoleModel
from app.repositories.base import GenericRepository


class RoleRepository(GenericRepository[RoleModel]):
    """Repository for RoleModel entities."""

    def __init__(self, session: AsyncSession) -> None:
        super().__init__(RoleModel, session)

    async def get_by_name(self, name: str) -> RoleModel | None:
        """Get a role by its unique name."""
        query = select(self.model).where(self.model.name == name)
        result = await self.session.execute(query)
        return result.scalars().first()
