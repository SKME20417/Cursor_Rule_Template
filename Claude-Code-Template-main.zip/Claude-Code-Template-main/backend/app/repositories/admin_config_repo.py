"""AdminConfig repository with singleton access pattern."""

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.admin_config import AdminConfig
from app.repositories.base import GenericRepository


class AdminConfigRepository(GenericRepository[AdminConfig]):
    """Repository for AdminConfig entities."""

    def __init__(self, session: AsyncSession) -> None:
        super().__init__(AdminConfig, session)

    async def get_singleton(self) -> AdminConfig:
        """Get the first config row, or create a default if none exists."""
        query = select(self.model).limit(1)
        result = await self.session.execute(query)
        config = result.scalars().first()

        if config is None:
            config = await self.create({})

        return config
