"""Audit entry repository."""

from sqlalchemy.ext.asyncio import AsyncSession

from app.models.audit_entry import AuditEntry
from app.repositories.base import GenericRepository


class AuditRepository(GenericRepository[AuditEntry]):
    """Repository for AuditEntry entities."""

    def __init__(self, session: AsyncSession) -> None:
        super().__init__(AuditEntry, session)
