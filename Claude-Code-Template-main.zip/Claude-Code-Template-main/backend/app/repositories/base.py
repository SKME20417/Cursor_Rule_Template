"""Generic repository with CRUD operations."""

from typing import Any, Generic, TypeVar
from uuid import UUID

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.exceptions import NotFoundException
from app.models.base import Base

ModelType = TypeVar("ModelType", bound=Base)


class GenericRepository(Generic[ModelType]):
    """Base repository providing standard CRUD operations."""

    def __init__(self, model: type[ModelType], session: AsyncSession):
        self.model = model
        self.session = session

    async def get_by_id(self, id: UUID) -> ModelType:
        """Get a record by ID or raise NotFoundException."""
        result = await self.session.get(self.model, id)
        if result is None:
            raise NotFoundException(self.model.__name__, str(id))
        return result

    async def get_by_id_optional(self, id: UUID) -> ModelType | None:
        """Get a record by ID, returning None if not found."""
        return await self.session.get(self.model, id)

    async def get_all(
        self,
        offset: int = 0,
        limit: int = 20,
        filters: dict[str, Any] | None = None,
        order_by: Any | None = None,
    ) -> tuple[list[ModelType], int]:
        """Get paginated records with optional filtering.

        Returns (items, total_count).
        """
        query = select(self.model)
        count_query = select(func.count()).select_from(self.model)

        if filters:
            for key, value in filters.items():
                if hasattr(self.model, key) and value is not None:
                    col = getattr(self.model, key)
                    if isinstance(value, list):
                        query = query.where(col.in_(value))
                        count_query = count_query.where(col.in_(value))
                    else:
                        query = query.where(col == value)
                        count_query = count_query.where(col == value)

        if order_by is not None:
            query = query.order_by(order_by)
        elif hasattr(self.model, "created_at"):
            query = query.order_by(self.model.created_at.desc())

        total_result = await self.session.execute(count_query)
        total = total_result.scalar() or 0

        query = query.offset(offset).limit(limit)
        result = await self.session.execute(query)
        items = list(result.scalars().all())

        return items, total

    async def create(self, data: dict[str, Any]) -> ModelType:
        """Create a new record."""
        instance = self.model(**data)
        self.session.add(instance)
        await self.session.flush()
        await self.session.refresh(instance)
        return instance

    async def update(self, id: UUID, data: dict[str, Any]) -> ModelType:
        """Update a record by ID."""
        instance = await self.get_by_id(id)
        for key, value in data.items():
            if hasattr(instance, key):
                setattr(instance, key, value)
        await self.session.flush()
        await self.session.refresh(instance)
        return instance

    async def delete(self, id: UUID) -> None:
        """Delete a record by ID."""
        instance = await self.get_by_id(id)
        await self.session.delete(instance)
        await self.session.flush()
