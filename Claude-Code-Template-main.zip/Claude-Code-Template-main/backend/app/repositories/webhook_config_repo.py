"""WebhookConfig repository with domain-specific queries."""

from uuid import UUID

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.webhook_config import WebhookConfig
from app.repositories.base import GenericRepository


class WebhookConfigRepository(GenericRepository[WebhookConfig]):
    """Repository for WebhookConfig entities."""

    def __init__(self, session: AsyncSession) -> None:
        super().__init__(WebhookConfig, session)

    async def get_by_integration(
        self, integration_id: UUID, offset: int = 0, limit: int = 20
    ) -> tuple[list[WebhookConfig], int]:
        """Get webhook configs for a specific integration."""
        condition = self.model.integration_id == integration_id
        query = select(self.model).where(condition)
        count_query = select(func.count()).select_from(self.model).where(condition)

        total_result = await self.session.execute(count_query)
        total = total_result.scalar() or 0

        query = query.order_by(self.model.created_at.desc()).offset(offset).limit(limit)
        result = await self.session.execute(query)
        return list(result.scalars().all()), total
