"""Category repository for knowledge base categories."""

from sqlalchemy.ext.asyncio import AsyncSession

from app.models.category import Category
from app.repositories.base import GenericRepository


class CategoryRepository(GenericRepository[Category]):
    """Repository for Category entities."""

    def __init__(self, session: AsyncSession) -> None:
        super().__init__(Category, session)
