"""Suggestion repository with domain-specific queries."""

from uuid import UUID

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.suggestion import Suggestion
from app.repositories.base import GenericRepository


class SuggestionRepository(GenericRepository[Suggestion]):
    """Repository for Suggestion entities."""

    def __init__(self, session: AsyncSession) -> None:
        super().__init__(Suggestion, session)

    async def get_by_conversation(
        self, conversation_id: UUID, offset: int = 0, limit: int = 20
    ) -> tuple[list[Suggestion], int]:
        """Get suggestions for a specific conversation."""
        condition = self.model.conversation_id == conversation_id
        query = select(self.model).where(condition)
        count_query = select(func.count()).select_from(self.model).where(condition)

        total_result = await self.session.execute(count_query)
        total = total_result.scalar() or 0

        query = query.order_by(self.model.created_at.desc()).offset(offset).limit(limit)
        result = await self.session.execute(query)
        return list(result.scalars().all()), total
