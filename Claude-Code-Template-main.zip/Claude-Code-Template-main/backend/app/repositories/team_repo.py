"""Team repository."""

from sqlalchemy.ext.asyncio import AsyncSession

from app.models.team import Team
from app.repositories.base import GenericRepository


class TeamRepository(GenericRepository[Team]):
    """Repository for Team entities."""

    def __init__(self, session: AsyncSession) -> None:
        super().__init__(Team, session)
