"""Ticket repository with domain-specific queries."""

from uuid import UUID

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.ticket import Ticket
from app.repositories.base import GenericRepository


class TicketRepository(GenericRepository[Ticket]):
    """Repository for Ticket entities."""

    def __init__(self, session: AsyncSession) -> None:
        super().__init__(Ticket, session)

    async def get_by_customer(
        self, customer_id: UUID, offset: int = 0, limit: int = 20
    ) -> tuple[list[Ticket], int]:
        """Get tickets for a specific customer."""
        condition = self.model.customer_id == customer_id
        query = select(self.model).where(condition)
        count_query = select(func.count()).select_from(self.model).where(condition)

        total_result = await self.session.execute(count_query)
        total = total_result.scalar() or 0

        query = query.order_by(self.model.created_at.desc()).offset(offset).limit(limit)
        result = await self.session.execute(query)
        return list(result.scalars().all()), total

    async def get_by_agent(
        self, agent_id: UUID, offset: int = 0, limit: int = 20
    ) -> tuple[list[Ticket], int]:
        """Get tickets assigned to a specific agent."""
        condition = self.model.assigned_agent_id == agent_id
        query = select(self.model).where(condition)
        count_query = select(func.count()).select_from(self.model).where(condition)

        total_result = await self.session.execute(count_query)
        total = total_result.scalar() or 0

        query = query.order_by(self.model.created_at.desc()).offset(offset).limit(limit)
        result = await self.session.execute(query)
        return list(result.scalars().all()), total

    async def get_by_status(
        self, status: str, offset: int = 0, limit: int = 20
    ) -> tuple[list[Ticket], int]:
        """Get tickets filtered by status."""
        condition = self.model.status == status
        query = select(self.model).where(condition)
        count_query = select(func.count()).select_from(self.model).where(condition)

        total_result = await self.session.execute(count_query)
        total = total_result.scalar() or 0

        query = query.order_by(self.model.created_at.desc()).offset(offset).limit(limit)
        result = await self.session.execute(query)
        return list(result.scalars().all()), total
