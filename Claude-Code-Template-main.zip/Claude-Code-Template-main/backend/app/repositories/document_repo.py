"""Document repository."""

from sqlalchemy.ext.asyncio import AsyncSession

from app.models.document import Document
from app.repositories.base import GenericRepository


class DocumentRepository(GenericRepository[Document]):
    """Repository for Document entities."""

    def __init__(self, session: AsyncSession) -> None:
        super().__init__(Document, session)
