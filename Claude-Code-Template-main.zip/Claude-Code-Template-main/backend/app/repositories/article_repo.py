"""Article repository with domain-specific queries."""

from uuid import UUID

from sqlalchemy import func, or_, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.article import Article
from app.repositories.base import GenericRepository


class ArticleRepository(GenericRepository[Article]):
    """Repository for Article entities."""

    def __init__(self, session: AsyncSession) -> None:
        super().__init__(Article, session)

    async def search_by_query(
        self, query_str: str, offset: int = 0, limit: int = 20
    ) -> tuple[list[Article], int]:
        """Search articles by title or content using ILIKE."""
        pattern = f"%{query_str}%"
        condition = or_(
            self.model.title.ilike(pattern),
            self.model.content.ilike(pattern),
        )
        query = select(self.model).where(condition)
        count_query = select(func.count()).select_from(self.model).where(condition)

        total_result = await self.session.execute(count_query)
        total = total_result.scalar() or 0

        query = query.order_by(self.model.created_at.desc()).offset(offset).limit(limit)
        result = await self.session.execute(query)
        return list(result.scalars().all()), total

    async def get_by_category(
        self, category_id: UUID, offset: int = 0, limit: int = 20
    ) -> tuple[list[Article], int]:
        """Get articles in a specific category."""
        condition = self.model.category_id == category_id
        query = select(self.model).where(condition)
        count_query = select(func.count()).select_from(self.model).where(condition)

        total_result = await self.session.execute(count_query)
        total = total_result.scalar() or 0

        query = query.order_by(self.model.created_at.desc()).offset(offset).limit(limit)
        result = await self.session.execute(query)
        return list(result.scalars().all()), total
