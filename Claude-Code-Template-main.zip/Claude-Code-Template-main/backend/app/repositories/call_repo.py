"""Call repository with domain-specific queries."""

from uuid import UUID

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.call import Call
from app.repositories.base import GenericRepository


class CallRepository(GenericRepository[Call]):
    """Repository for Call entities."""

    def __init__(self, session: AsyncSession) -> None:
        super().__init__(Call, session)

    async def get_by_customer(
        self, customer_id: UUID, offset: int = 0, limit: int = 20
    ) -> tuple[list[Call], int]:
        """Get calls for a specific customer."""
        condition = self.model.customer_id == customer_id
        query = select(self.model).where(condition)
        count_query = select(func.count()).select_from(self.model).where(condition)

        total_result = await self.session.execute(count_query)
        total = total_result.scalar() or 0

        query = query.order_by(self.model.started_at.desc()).offset(offset).limit(limit)
        result = await self.session.execute(query)
        return list(result.scalars().all()), total
