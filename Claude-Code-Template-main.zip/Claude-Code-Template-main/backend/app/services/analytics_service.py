"""Analytics and reporting service."""

from typing import Any

import structlog
from sqlalchemy.ext.asyncio import AsyncSession

from app.repositories.analytics_repo import AnalyticsRepository
from app.schemas.analytics import TimeSeriesRequest

logger = structlog.get_logger()


class AnalyticsService:
    """Provides aggregated analytics and metrics."""

    def __init__(self, session: AsyncSession) -> None:
        self._db = session
        self._analytics = AnalyticsRepository(session)

    async def get_metrics(self) -> list[dict[str, Any]]:
        """Get dashboard metric cards."""
        return await self._analytics.get_metric_cards()

    async def get_time_series(self, body: TimeSeriesRequest) -> list[dict[str, Any]]:
        """Get time-series data for a given metric.

        Returns an empty list until the time-series aggregation pipeline is implemented.
        """
        logger.info(
            "analytics.time_series.requested",
            metric=body.metric,
            interval=body.interval,
        )
        return []

    async def get_agent_metrics(self) -> list[dict[str, Any]]:
        """Get per-agent performance metrics."""
        return await self._analytics.get_agent_metrics()

    async def get_channel_metrics(self) -> list[dict[str, Any]]:
        """Get metrics broken down by channel."""
        return await self._analytics.get_channel_metrics()

    async def get_sla_metrics(self) -> dict[str, Any]:
        """Get SLA compliance metrics."""
        return await self._analytics.get_sla_metrics()
