"""Knowledge base service for articles and categories."""

import re
from uuid import UUID

import structlog
from sqlalchemy.ext.asyncio import AsyncSession

from app.repositories.article_repo import ArticleRepository
from app.repositories.category_repo import CategoryRepository
from app.schemas.knowledge_base import (
    ArticleResponse,
    CategoryResponse,
    CreateArticleRequest,
    UpdateArticleRequest,
)

logger = structlog.get_logger()


def _slugify(text: str) -> str:
    """Convert text to a URL-friendly slug."""
    slug = text.lower().strip()
    slug = re.sub(r"[^\w\s-]", "", slug)
    slug = re.sub(r"[\s_]+", "-", slug)
    return re.sub(r"-+", "-", slug).strip("-")


class KnowledgeBaseService:
    """Manages knowledge base articles and categories."""

    def __init__(self, session: AsyncSession) -> None:
        self._db = session
        self._articles = ArticleRepository(session)
        self._categories = CategoryRepository(session)

    async def list_articles(
        self, offset: int = 0, limit: int = 20, filters: dict | None = None
    ) -> tuple[list[dict], int]:
        """List articles with pagination."""
        items, total = await self._articles.get_all(
            offset=offset, limit=limit, filters=filters
        )
        data = [
            ArticleResponse.model_validate(a).model_dump(by_alias=True) for a in items
        ]
        return data, total

    async def get_article(self, article_id: UUID) -> dict:
        """Get a single article by ID."""
        article = await self._articles.get_by_id(article_id)
        return ArticleResponse.model_validate(article).model_dump(by_alias=True)

    async def create_article(
        self, body: CreateArticleRequest, author_id: UUID
    ) -> dict:
        """Create a new article."""
        slug = _slugify(body.title)
        article = await self._articles.create(
            {
                "title": body.title,
                "slug": slug,
                "content": body.content,
                "category_id": body.category_id,
                "author_id": author_id,
                "tags": body.tags or [],
                "status": "draft",
            }
        )
        logger.info(
            "kb.article.created",
            article_id=str(article.id),
            author_id=str(author_id),
        )
        return ArticleResponse.model_validate(article).model_dump(by_alias=True)

    async def update_article(
        self, article_id: UUID, body: UpdateArticleRequest
    ) -> dict:
        """Update an existing article."""
        update_data = body.model_dump(exclude_unset=True)
        if "title" in update_data and update_data["title"]:
            update_data["slug"] = _slugify(update_data["title"])
        article = await self._articles.update(article_id, update_data)
        logger.info("kb.article.updated", article_id=str(article_id))
        return ArticleResponse.model_validate(article).model_dump(by_alias=True)

    async def search_articles(
        self, query: str, offset: int = 0, limit: int = 20
    ) -> tuple[list[dict], int]:
        """Search articles by title or content."""
        items, total = await self._articles.search_by_query(
            query, offset=offset, limit=limit
        )
        data = [
            ArticleResponse.model_validate(a).model_dump(by_alias=True) for a in items
        ]
        return data, total

    async def list_categories(self) -> list[dict]:
        """List all knowledge base categories."""
        items, _ = await self._categories.get_all(
            offset=0, limit=500, order_by=None
        )
        return [
            CategoryResponse.model_validate(c).model_dump(by_alias=True)
            for c in items
        ]
