"""System monitoring and alerting service."""

from typing import Any
from uuid import uuid4

import structlog
from sqlalchemy.ext.asyncio import AsyncSession

from app.repositories.alert_history_repo import AlertHistoryRepository
from app.repositories.alert_rule_repo import AlertRuleRepository
from app.schemas.monitoring import AlertHistoryResponse, AlertRuleResponse

logger = structlog.get_logger()


class MonitoringService:
    """Provides system health, queue metrics, and alert management."""

    def __init__(self, session: AsyncSession) -> None:
        self._db = session
        self._alert_rules = AlertRuleRepository(session)
        self._alert_history = AlertHistoryRepository(session)

    async def get_health(self) -> list[dict[str, Any]]:
        """Get health status of system services.

        Returns synthetic health data; real health probes to be wired later.
        """
        return [
            {
                "id": str(uuid4()),
                "serviceName": "database",
                "status": "healthy",
                "latencyMs": 2.1,
                "uptimePercent": 99.99,
                "lastCheckedAt": "2026-03-09T00:00:00Z",
                "details": None,
            },
            {
                "id": str(uuid4()),
                "serviceName": "redis",
                "status": "healthy",
                "latencyMs": 0.5,
                "uptimePercent": 99.99,
                "lastCheckedAt": "2026-03-09T00:00:00Z",
                "details": None,
            },
            {
                "id": str(uuid4()),
                "serviceName": "ai-service",
                "status": "healthy",
                "latencyMs": 150.0,
                "uptimePercent": 99.95,
                "lastCheckedAt": "2026-03-09T00:00:00Z",
                "details": None,
            },
        ]

    async def get_queues(self) -> list[dict[str, Any]]:
        """Get queue depth and throughput metrics.

        Returns synthetic queue data; real queue probes to be wired later.
        """
        return [
            {
                "queueName": "message-processing",
                "depth": 0,
                "enqueueRate": 12.5,
                "dequeueRate": 12.5,
                "oldestMessageAge": None,
                "timestamp": "2026-03-09T00:00:00Z",
            },
            {
                "queueName": "webhook-delivery",
                "depth": 3,
                "enqueueRate": 5.2,
                "dequeueRate": 5.0,
                "oldestMessageAge": 1.2,
                "timestamp": "2026-03-09T00:00:00Z",
            },
        ]

    async def get_alerts(self) -> list[dict]:
        """Get recent alert history."""
        items, _ = await self._alert_history.get_all(offset=0, limit=50)
        return [
            AlertHistoryResponse.model_validate(a).model_dump(by_alias=True)
            for a in items
        ]

    async def get_alert_rules(self) -> list[dict]:
        """Get all alert rules."""
        items, _ = await self._alert_rules.get_all(offset=0, limit=200)
        return [
            AlertRuleResponse.model_validate(r).model_dump(by_alias=True)
            for r in items
        ]
