"""Chat and messaging service."""

from datetime import UTC, datetime
from uuid import UUID

import structlog
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.exceptions import NotFoundException
from app.repositories.conversation_repo import ConversationRepository
from app.repositories.message_repo import MessageRepository
from app.schemas.chat import (
    ConversationResponse,
    CreateConversationRequest,
    MessageResponse,
    SendMessageRequest,
    UpdateConversationRequest,
)

logger = structlog.get_logger()


class ChatService:
    """Manages conversations and messages."""

    def __init__(self, session: AsyncSession) -> None:
        self._db = session
        self._conversations = ConversationRepository(session)
        self._messages = MessageRepository(session)

    async def list_conversations(
        self, offset: int = 0, limit: int = 20, filters: dict | None = None
    ) -> tuple[list[dict], int]:
        """List conversations with pagination and optional filters."""
        items, total = await self._conversations.get_all(
            offset=offset, limit=limit, filters=filters
        )
        data = [
            ConversationResponse.model_validate(c).model_dump(by_alias=True)
            for c in items
        ]
        return data, total

    async def get_conversation(self, conversation_id: UUID) -> dict:
        """Get a single conversation by ID."""
        conversation = await self._conversations.get_by_id(conversation_id)
        return ConversationResponse.model_validate(conversation).model_dump(by_alias=True)

    async def create_conversation(
        self, body: CreateConversationRequest, user_id: UUID
    ) -> dict:
        """Create a new conversation."""
        conversation = await self._conversations.create(
            {
                "customer_id": body.customer_id,
                "channel": body.channel,
                "subject": body.subject,
                "status": "open",
            }
        )
        logger.info(
            "chat.conversation.created",
            conversation_id=str(conversation.id),
            user_id=str(user_id),
        )
        return ConversationResponse.model_validate(conversation).model_dump(by_alias=True)

    async def update_conversation(
        self, conversation_id: UUID, body: UpdateConversationRequest
    ) -> dict:
        """Update an existing conversation."""
        update_data = body.model_dump(exclude_unset=True)
        conversation = await self._conversations.update(conversation_id, update_data)
        logger.info(
            "chat.conversation.updated",
            conversation_id=str(conversation_id),
        )
        return ConversationResponse.model_validate(conversation).model_dump(by_alias=True)

    async def list_messages(
        self, conversation_id: UUID, offset: int = 0, limit: int = 20
    ) -> tuple[list[dict], int]:
        """List messages in a conversation."""
        # Verify conversation exists
        await self._conversations.get_by_id(conversation_id)
        items, total = await self._messages.get_by_conversation(
            conversation_id, offset=offset, limit=limit
        )
        data = [
            MessageResponse.model_validate(m).model_dump(by_alias=True) for m in items
        ]
        return data, total

    async def send_message(
        self, conversation_id: UUID, body: SendMessageRequest, user_id: UUID, role: str
    ) -> dict:
        """Send a message in a conversation."""
        # Verify conversation exists
        conversation = await self._conversations.get_by_id(conversation_id)

        message = await self._messages.create(
            {
                "conversation_id": conversation_id,
                "sender_id": user_id,
                "sender_role": role,
                "type": body.type,
                "content": body.content,
            }
        )

        # Update conversation metadata
        conversation.last_message_at = datetime.now(UTC)
        conversation.last_message_preview = body.content[:500]
        conversation.message_count = (conversation.message_count or 0) + 1
        await self._db.flush()

        logger.info(
            "chat.message.sent",
            conversation_id=str(conversation_id),
            message_id=str(message.id),
        )
        return MessageResponse.model_validate(message).model_dump(by_alias=True)
