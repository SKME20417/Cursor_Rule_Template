"""Video session management service."""

from datetime import UTC, datetime
from uuid import UUID, uuid4

import structlog
from sqlalchemy.ext.asyncio import AsyncSession

from app.repositories.video_session_repo import VideoSessionRepository
from app.schemas.video import CreateVideoSessionRequest, VideoSessionResponse

logger = structlog.get_logger()


class VideoService:
    """Manages video sessions and participants."""

    def __init__(self, session: AsyncSession) -> None:
        self._db = session
        self._sessions = VideoSessionRepository(session)

    async def create_session(
        self, body: CreateVideoSessionRequest, user_id: UUID
    ) -> dict:
        """Create a new video session."""
        room_id = uuid4().hex[:12]
        video_session = await self._sessions.create(
            {
                "conversation_id": body.conversation_id,
                "host_id": user_id,
                "status": "waiting",
                "room_url": f"/video/room/{room_id}",
                "started_at": datetime.now(UTC),
            }
        )
        logger.info(
            "video.session.created",
            session_id=str(video_session.id),
            host_id=str(user_id),
        )
        return VideoSessionResponse.model_validate(video_session).model_dump(by_alias=True)

    async def join_session(self, session_id: UUID, user_id: UUID) -> dict:
        """Mark a video session as active when a participant joins."""
        video_session = await self._sessions.get_by_id(session_id)
        if video_session.status == "waiting":
            video_session = await self._sessions.update(
                session_id, {"status": "active"}
            )
        logger.info(
            "video.session.joined",
            session_id=str(session_id),
            user_id=str(user_id),
        )
        return VideoSessionResponse.model_validate(video_session).model_dump(by_alias=True)

    async def end_session(self, session_id: UUID, user_id: UUID) -> dict:
        """End a video session."""
        video_session = await self._sessions.get_by_id(session_id)
        now = datetime.now(UTC)
        duration = int((now - video_session.started_at).total_seconds())

        video_session = await self._sessions.update(
            session_id,
            {
                "status": "ended",
                "ended_at": now,
                "duration_seconds": duration,
            },
        )
        logger.info("video.session.ended", session_id=str(session_id))
        return VideoSessionResponse.model_validate(video_session).model_dump(by_alias=True)
