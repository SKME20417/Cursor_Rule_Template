"""File upload service with validation."""

import os
import uuid
from pathlib import Path

import structlog
from fastapi import UploadFile
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import get_settings
from app.core.exceptions import ValidationException

logger = structlog.get_logger()
settings = get_settings()

# Maximum file size: 10 MB
MAX_FILE_SIZE = 10 * 1024 * 1024


class UploadService:
    """Handles file uploads with type and size validation."""

    def __init__(self, session: AsyncSession) -> None:
        self._db = session

    async def upload_file(self, file: UploadFile, user_id: uuid.UUID) -> dict:
        """Validate and store an uploaded file.

        Currently stores files locally. S3 integration to be added later.
        """
        # Validate MIME type
        if file.content_type not in settings.allowed_upload_type_list:
            raise ValidationException(
                f"File type '{file.content_type}' is not allowed. "
                f"Allowed types: {', '.join(settings.allowed_upload_type_list)}"
            )

        # Read file content and validate size
        content = await file.read()
        if len(content) > MAX_FILE_SIZE:
            raise ValidationException(
                f"File size exceeds maximum of {MAX_FILE_SIZE // (1024 * 1024)} MB"
            )

        # Generate unique file key
        ext = Path(file.filename or "file").suffix
        file_key = f"uploads/{user_id}/{uuid.uuid4().hex}{ext}"

        # Store locally (in production this would go to S3)
        upload_dir = Path("storage") / "uploads" / str(user_id)
        upload_dir.mkdir(parents=True, exist_ok=True)
        file_path = upload_dir / f"{uuid.uuid4().hex}{ext}"
        file_path.write_bytes(content)

        file_url = f"/static/{file_key}"

        logger.info(
            "upload.file.stored",
            user_id=str(user_id),
            file_name=file.filename,
            size=len(content),
            mime_type=file.content_type,
        )

        return {
            "url": file_url,
            "key": file_key,
            "size": len(content),
        }
