"""Notification management service."""

from datetime import UTC, datetime
from uuid import UUID

import structlog
from sqlalchemy.ext.asyncio import AsyncSession

from app.repositories.notification_repo import NotificationRepository
from app.schemas.notification import NotificationResponse

logger = structlog.get_logger()


class NotificationService:
    """Manages user notifications."""

    def __init__(self, session: AsyncSession) -> None:
        self._db = session
        self._notifications = NotificationRepository(session)

    async def list_notifications(
        self, user_id: UUID, offset: int = 0, limit: int = 20
    ) -> tuple[list[dict], int]:
        """List notifications for a user, most recent first."""
        items, total = await self._notifications.get_all(
            offset=offset,
            limit=limit,
            filters={"user_id": user_id},
        )
        data = [
            NotificationResponse.model_validate(n).model_dump(by_alias=True)
            for n in items
        ]
        return data, total

    async def mark_read(self, notification_id: UUID, user_id: UUID) -> dict:
        """Mark a notification as read."""
        notification = await self._notifications.get_by_id(notification_id)
        notification = await self._notifications.update(
            notification_id,
            {"is_read": True, "read_at": datetime.now(UTC)},
        )
        logger.info(
            "notification.marked_read",
            notification_id=str(notification_id),
            user_id=str(user_id),
        )
        return NotificationResponse.model_validate(notification).model_dump(by_alias=True)
