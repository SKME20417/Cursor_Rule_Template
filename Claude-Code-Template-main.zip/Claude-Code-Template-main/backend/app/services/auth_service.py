"""Authentication and session management service."""

from datetime import UTC, datetime, timedelta
from uuid import UUID

import structlog
from jose import JWTError
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import get_settings
from app.core.exceptions import (
    ConflictException,
    NotFoundException,
    UnauthorizedException,
    ValidationException,
)
from app.core.security import (
    create_access_token,
    create_refresh_token,
    decode_refresh_token,
    hash_password,
    verify_password,
)
from app.models.user import UserRole
from app.repositories.session_repo import SessionRepository
from app.repositories.user_repo import UserRepository
from app.schemas.auth import RegisterRequest

logger = structlog.get_logger()
settings = get_settings()

# Roles that any user may self-assign during registration.
_SELF_ASSIGNABLE_ROLES = {UserRole.CUSTOMER.value, UserRole.AGENT.value}


class AuthService:
    """Handles authentication workflows: login, register, token refresh, logout."""

    def __init__(self, session: AsyncSession) -> None:
        self._db = session
        self._users = UserRepository(session)
        self._sessions = SessionRepository(session)

    # ── Login ───────────────────────────────────────────────────

    async def login(self, email: str, password: str) -> dict:
        """Authenticate a user and return session data.

        Returns a dict suitable for serialisation into SessionResponse.
        """
        log = logger.bind(email=email)

        user = await self._users.get_by_email(email)
        if user is None:
            log.warning("auth.login.user_not_found")
            raise UnauthorizedException("Invalid email or password")

        if not user.is_active:
            log.warning("auth.login.inactive_user", user_id=str(user.id))
            raise UnauthorizedException("Account is deactivated")

        if not verify_password(password, user.password_hash):
            log.warning("auth.login.bad_password", user_id=str(user.id))
            raise UnauthorizedException("Invalid email or password")

        # Update last login timestamp
        user.last_login_at = datetime.now(UTC)
        await self._db.flush()

        # Issue tokens
        access_token = create_access_token(user.id, user.role)
        refresh_token_str = create_refresh_token(user.id)

        expires_at = datetime.now(UTC) + timedelta(days=settings.jwt_refresh_token_expire_days)

        session_record = await self._sessions.create(
            {
                "user_id": user.id,
                "refresh_token": refresh_token_str,
                "expires_at": expires_at,
            }
        )

        log.info("auth.login.success", user_id=str(user.id))

        return {
            "user": {
                "id": user.id,
                "email": user.email,
                "firstName": user.first_name,
                "lastName": user.last_name,
                "role": user.role,
                "avatarUrl": user.avatar_url,
                "isActive": user.is_active,
            },
            "accessToken": access_token,
            "refreshToken": refresh_token_str,
            "expiresAt": expires_at,
        }

    # ── Register ────────────────────────────────────────────────

    async def register(self, data: RegisterRequest) -> dict:
        """Create a new user account.

        Returns a dict suitable for serialisation into UserResponse.
        """
        log = logger.bind(email=data.email)

        existing = await self._users.get_by_email(data.email)
        if existing is not None:
            log.warning("auth.register.email_taken")
            raise ConflictException("A user with this email already exists")

        # Determine role – only safe roles can be self-assigned.
        role = data.role or UserRole.CUSTOMER.value
        if role not in {r.value for r in UserRole}:
            raise ValidationException(f"Invalid role: {role}")
        if role not in _SELF_ASSIGNABLE_ROLES:
            raise ValidationException(
                f"Role '{role}' cannot be self-assigned during registration"
            )

        hashed = hash_password(data.password)

        user = await self._users.create(
            {
                "email": data.email,
                "password_hash": hashed,
                "first_name": data.first_name,
                "last_name": data.last_name,
                "role": role,
            }
        )

        # Auto-login: issue tokens so the frontend can redirect immediately
        access_token = create_access_token(user.id, user.role)
        refresh_token_str = create_refresh_token(user.id)

        expires_at = datetime.now(UTC) + timedelta(days=settings.jwt_refresh_token_expire_days)

        await self._sessions.create(
            {
                "user_id": user.id,
                "refresh_token": refresh_token_str,
                "expires_at": expires_at,
            }
        )

        log.info("auth.register.success", user_id=str(user.id), role=role)

        return {
            "user": {
                "id": user.id,
                "email": user.email,
                "firstName": user.first_name,
                "lastName": user.last_name,
                "role": user.role,
                "avatarUrl": user.avatar_url,
                "isActive": user.is_active,
            },
            "accessToken": access_token,
            "refreshToken": refresh_token_str,
            "expiresAt": expires_at,
        }

    # ── Token Refresh ───────────────────────────────────────────

    async def refresh_token(self, refresh_token_str: str) -> dict:
        """Validate a refresh token and issue a new access token.

        Returns a dict with the new accessToken.
        """
        # Decode JWT
        try:
            payload = decode_refresh_token(refresh_token_str)
        except JWTError:
            raise UnauthorizedException("Invalid or expired refresh token")

        user_id_str = payload.get("sub")
        if not user_id_str:
            raise UnauthorizedException("Invalid refresh token payload")

        user_id = UUID(user_id_str)

        # Verify the token exists in DB and has not been revoked
        session_record = await self._sessions.get_by_token(refresh_token_str)
        if session_record is None:
            logger.warning("auth.refresh.token_not_found", user_id=user_id_str)
            raise UnauthorizedException("Refresh token has been revoked")

        if session_record.expires_at < datetime.now(UTC):
            logger.warning("auth.refresh.token_expired", user_id=user_id_str)
            # Clean up the expired row
            await self._sessions.delete(session_record.id)
            raise UnauthorizedException("Refresh token has expired")

        # Fetch user to get current role (may have changed since token issuance)
        user = await self._users.get_by_id(user_id)
        if not user.is_active:
            raise UnauthorizedException("Account is deactivated")

        access_token = create_access_token(user.id, user.role)

        logger.info("auth.refresh.success", user_id=user_id_str)

        return {"accessToken": access_token}

    # ── Logout ──────────────────────────────────────────────────

    async def logout(self, refresh_token_str: str) -> None:
        """Revoke a single refresh token (logout from one device)."""
        session_record = await self._sessions.get_by_token(refresh_token_str)
        if session_record is not None:
            await self._sessions.delete(session_record.id)
            logger.info("auth.logout.success", user_id=str(session_record.user_id))

    # ── Get Session ─────────────────────────────────────────────

    async def get_session(self, user_id: UUID) -> dict:
        """Return the current user profile as session data.

        This is used by the frontend to hydrate the current user on page load.
        """
        user = await self._users.get_by_id(user_id)
        if not user.is_active:
            raise UnauthorizedException("Account is deactivated")

        return {
            "id": user.id,
            "email": user.email,
            "firstName": user.first_name,
            "lastName": user.last_name,
            "role": user.role,
            "avatarUrl": user.avatar_url,
            "isActive": user.is_active,
            "lastLoginAt": user.last_login_at,
            "createdAt": user.created_at,
            "updatedAt": user.updated_at,
        }
