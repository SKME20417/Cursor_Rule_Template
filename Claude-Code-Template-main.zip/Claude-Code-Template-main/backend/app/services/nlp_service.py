"""NLP service (stubs with mock responses until AI layer is connected)."""

from uuid import uuid4

import structlog
from sqlalchemy.ext.asyncio import AsyncSession

from app.schemas.nlp import ClassifyRequest, DetectLanguageRequest, SentimentRequest

logger = structlog.get_logger()


class NLPService:
    """Provides NLP capabilities: classification, sentiment analysis, and language detection.

    Methods return mock data until the AI/ML pipeline is connected.
    """

    def __init__(self, session: AsyncSession) -> None:
        self._db = session

    async def classify(self, body: ClassifyRequest) -> dict:
        """Classify text for intents, sentiment, and urgency."""
        logger.info(
            "nlp.classify.mock",
            text_length=len(body.text),
            conversation_id=str(body.conversation_id) if body.conversation_id else None,
        )
        return {
            "id": str(uuid4()),
            "conversationId": str(body.conversation_id) if body.conversation_id else None,
            "intents": [
                {
                    "id": str(uuid4()),
                    "name": "general_inquiry",
                    "confidence": 0.78,
                    "parameters": {},
                }
            ],
            "sentiment": {
                "label": "neutral",
                "score": 0.05,
                "magnitude": 0.3,
            },
            "urgency": "medium",
            "topics": ["general"],
            "createdAt": "2026-03-09T00:00:00Z",
        }

    async def analyze_sentiment(self, body: SentimentRequest) -> dict:
        """Analyze the sentiment of text."""
        logger.info("nlp.sentiment.mock", text_length=len(body.text))
        return {
            "label": "neutral",
            "score": 0.05,
            "magnitude": 0.3,
        }

    async def detect_language(self, body: DetectLanguageRequest) -> dict:
        """Detect the language of text."""
        logger.info("nlp.detect_language.mock", text_length=len(body.text))
        return {
            "languageCode": "en",
            "languageName": "English",
            "confidence": 0.98,
        }
