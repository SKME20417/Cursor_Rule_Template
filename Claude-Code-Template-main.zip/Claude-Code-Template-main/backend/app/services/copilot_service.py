"""AI Copilot service (stubs until AI layer is connected)."""

from uuid import UUID, uuid4

import structlog
from sqlalchemy.ext.asyncio import AsyncSession

from app.repositories.draft_repo import DraftRepository
from app.repositories.suggestion_repo import SuggestionRepository
from app.schemas.copilot import (
    CopilotFeedbackResponse,
    CreateDraftRequest,
    CreateFeedbackRequest,
    DraftResponse,
    SuggestionResponse,
)

logger = structlog.get_logger()


class CopilotService:
    """AI copilot suggestion, draft, and feedback management.

    Methods currently return mock data; the real AI layer will be wired in later.
    """

    def __init__(self, session: AsyncSession) -> None:
        self._db = session
        self._suggestions = SuggestionRepository(session)
        self._drafts = DraftRepository(session)

    async def get_suggestions(self, conversation_id: UUID) -> list[dict]:
        """Get AI-generated suggestions for a conversation.

        Returns stored suggestions if present, otherwise returns mock data.
        """
        items, total = await self._suggestions.get_by_conversation(
            conversation_id, offset=0, limit=10
        )
        if items:
            return [
                SuggestionResponse.model_validate(s).model_dump(by_alias=True)
                for s in items
            ]

        # Mock response until AI pipeline is connected
        logger.info(
            "copilot.suggestions.mock",
            conversation_id=str(conversation_id),
        )
        return [
            {
                "id": str(uuid4()),
                "conversationId": str(conversation_id),
                "type": "reply",
                "content": "Thank you for reaching out. Let me look into this for you.",
                "confidence": 0.85,
                "sourceArticleIds": [],
                "createdAt": "2026-03-09T00:00:00Z",
            }
        ]

    async def create_draft(
        self, body: CreateDraftRequest, agent_id: UUID
    ) -> dict:
        """Create a draft reply, optionally based on a suggestion.

        Returns mock draft content until AI layer is connected.
        """
        draft_content = "Thank you for your patience. I've reviewed your case and here is what I recommend..."

        draft = await self._drafts.create(
            {
                "conversation_id": body.conversation_id,
                "agent_id": agent_id,
                "content": draft_content,
                "based_on_suggestion_id": body.suggestion_id,
                "is_edited": False,
            }
        )
        logger.info(
            "copilot.draft.created",
            draft_id=str(draft.id),
            agent_id=str(agent_id),
        )
        return DraftResponse.model_validate(draft).model_dump(by_alias=True)

    async def submit_feedback(
        self, body: CreateFeedbackRequest, agent_id: UUID
    ) -> dict:
        """Submit feedback on a copilot suggestion.

        Returns mock feedback response.
        """
        logger.info(
            "copilot.feedback.submitted",
            suggestion_id=str(body.suggestion_id),
            rating=body.rating,
            agent_id=str(agent_id),
        )
        return {
            "id": str(uuid4()),
            "suggestionId": str(body.suggestion_id),
            "agentId": str(agent_id),
            "rating": body.rating,
            "comment": body.comment,
            "createdAt": "2026-03-09T00:00:00Z",
        }

    async def get_summary(self, conversation_id: UUID) -> dict:
        """Get an AI-generated summary of a conversation.

        Returns mock summary until AI layer is connected.
        """
        logger.info(
            "copilot.summary.mock",
            conversation_id=str(conversation_id),
        )
        return {
            "conversationId": str(conversation_id),
            "summary": "Customer inquired about account access. Agent verified identity and resolved the issue.",
            "keyTopics": ["account access", "identity verification"],
            "sentiment": "neutral",
            "actionItems": ["Follow up in 24 hours if issue recurs"],
        }
