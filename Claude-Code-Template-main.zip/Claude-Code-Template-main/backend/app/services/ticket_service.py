"""Ticket management service."""

from uuid import UUID

import structlog
from sqlalchemy.ext.asyncio import AsyncSession

from app.repositories.ticket_comment_repo import TicketCommentRepository
from app.repositories.ticket_repo import TicketRepository
from app.schemas.ticket import (
    CreateTicketCommentRequest,
    CreateTicketRequest,
    TicketCommentResponse,
    TicketResponse,
    UpdateTicketRequest,
)

logger = structlog.get_logger()


class TicketService:
    """Manages support tickets and comments."""

    def __init__(self, session: AsyncSession) -> None:
        self._db = session
        self._tickets = TicketRepository(session)
        self._comments = TicketCommentRepository(session)

    async def list_tickets(
        self, offset: int = 0, limit: int = 20, filters: dict | None = None
    ) -> tuple[list[dict], int]:
        """List tickets with pagination and optional filters."""
        items, total = await self._tickets.get_all(
            offset=offset, limit=limit, filters=filters
        )
        data = [
            TicketResponse.model_validate(t).model_dump(by_alias=True) for t in items
        ]
        return data, total

    async def get_ticket(self, ticket_id: UUID) -> dict:
        """Get a single ticket by ID."""
        ticket = await self._tickets.get_by_id(ticket_id)
        return TicketResponse.model_validate(ticket).model_dump(by_alias=True)

    async def create_ticket(
        self, body: CreateTicketRequest, user_id: UUID
    ) -> dict:
        """Create a new ticket."""
        ticket = await self._tickets.create(
            {
                "customer_id": body.customer_id,
                "subject": body.subject,
                "description": body.description,
                "priority": body.priority,
                "channel": body.channel,
                "category_id": body.category_id,
                "tags": body.tags or [],
                "status": "created",
            }
        )
        logger.info(
            "ticket.created",
            ticket_id=str(ticket.id),
            user_id=str(user_id),
        )
        return TicketResponse.model_validate(ticket).model_dump(by_alias=True)

    async def update_ticket(
        self, ticket_id: UUID, body: UpdateTicketRequest
    ) -> dict:
        """Update an existing ticket."""
        update_data = body.model_dump(exclude_unset=True)
        ticket = await self._tickets.update(ticket_id, update_data)
        logger.info("ticket.updated", ticket_id=str(ticket_id))
        return TicketResponse.model_validate(ticket).model_dump(by_alias=True)

    async def add_comment(
        self,
        ticket_id: UUID,
        body: CreateTicketCommentRequest,
        user_id: UUID,
    ) -> dict:
        """Add a comment to a ticket."""
        # Verify ticket exists
        await self._tickets.get_by_id(ticket_id)

        comment = await self._comments.create(
            {
                "ticket_id": ticket_id,
                "author_id": user_id,
                "content": body.content,
                "is_internal": body.is_internal,
            }
        )
        logger.info(
            "ticket.comment.added",
            ticket_id=str(ticket_id),
            comment_id=str(comment.id),
        )
        return TicketCommentResponse.model_validate(comment).model_dump(by_alias=True)

    async def get_timeline(self, ticket_id: UUID) -> list[dict]:
        """Get the timeline of comments for a ticket."""
        # Verify ticket exists
        await self._tickets.get_by_id(ticket_id)

        comments, _ = await self._comments.get_by_ticket(ticket_id, offset=0, limit=200)
        return [
            TicketCommentResponse.model_validate(c).model_dump(by_alias=True)
            for c in comments
        ]
