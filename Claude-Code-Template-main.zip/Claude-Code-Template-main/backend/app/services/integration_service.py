"""Integration management service."""

from uuid import UUID

import structlog
from sqlalchemy.ext.asyncio import AsyncSession

from app.repositories.integration_repo import IntegrationRepository
from app.repositories.webhook_config_repo import WebhookConfigRepository
from app.schemas.integration import (
    IntegrationResponse,
    UpdateIntegrationRequest,
    WebhookConfigResponse,
)

logger = structlog.get_logger()


class IntegrationService:
    """Manages third-party integrations and webhook configurations."""

    def __init__(self, session: AsyncSession) -> None:
        self._db = session
        self._integrations = IntegrationRepository(session)
        self._webhooks = WebhookConfigRepository(session)

    async def list_integrations(self) -> list[dict]:
        """List all integrations."""
        items, _ = await self._integrations.get_all(offset=0, limit=500)
        return [
            IntegrationResponse.model_validate(i).model_dump(by_alias=True)
            for i in items
        ]

    async def update_integration(
        self, integration_id: UUID, body: UpdateIntegrationRequest
    ) -> dict:
        """Update an existing integration."""
        update_data = body.model_dump(exclude_unset=True)
        if "config" in update_data and update_data["config"] is not None:
            update_data["config"] = (
                update_data["config"].model_dump(by_alias=True)
                if hasattr(update_data["config"], "model_dump")
                else update_data["config"]
            )
        integration = await self._integrations.update(integration_id, update_data)
        logger.info(
            "integration.updated", integration_id=str(integration_id)
        )
        return IntegrationResponse.model_validate(integration).model_dump(by_alias=True)

    async def test_integration(self, integration_id: UUID) -> dict:
        """Test connectivity for an integration.

        Performs a basic health check. Full provider-specific testing is not yet implemented.
        """
        integration = await self._integrations.get_by_id(integration_id)
        logger.info(
            "integration.test.requested",
            integration_id=str(integration_id),
            provider=integration.provider,
        )
        return {
            "integrationId": str(integration_id),
            "provider": integration.provider,
            "status": "ok",
            "message": "Connection test passed",
        }

    async def list_webhooks(self, integration_id: UUID) -> list[dict]:
        """List webhooks for a specific integration."""
        items, _ = await self._webhooks.get_by_integration(
            integration_id, offset=0, limit=100
        )
        return [
            WebhookConfigResponse.model_validate(w).model_dump(by_alias=True)
            for w in items
        ]
