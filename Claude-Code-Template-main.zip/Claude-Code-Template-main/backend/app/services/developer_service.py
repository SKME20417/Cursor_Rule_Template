"""Developer tools service: webhooks and sandbox execution."""

from uuid import UUID

import structlog
from sqlalchemy.ext.asyncio import AsyncSession

from app.repositories.webhook_config_repo import WebhookConfigRepository
from app.schemas.integration import WebhookConfigResponse

logger = structlog.get_logger()


class DeveloperService:
    """Manages developer-facing webhook configurations and sandbox execution."""

    def __init__(self, session: AsyncSession) -> None:
        self._db = session
        self._webhooks = WebhookConfigRepository(session)

    async def list_webhooks(self) -> list[dict]:
        """List all webhook configurations."""
        items, _ = await self._webhooks.get_all(offset=0, limit=200)
        return [
            WebhookConfigResponse.model_validate(w).model_dump(by_alias=True)
            for w in items
        ]

    async def create_webhook(self, data: dict) -> dict:
        """Create a new webhook configuration."""
        webhook = await self._webhooks.create(data)
        logger.info("developer.webhook.created", webhook_id=str(webhook.id))
        return WebhookConfigResponse.model_validate(webhook).model_dump(by_alias=True)

    async def update_webhook(self, webhook_id: UUID, data: dict) -> dict:
        """Update a webhook configuration."""
        webhook = await self._webhooks.update(webhook_id, data)
        logger.info("developer.webhook.updated", webhook_id=str(webhook_id))
        return WebhookConfigResponse.model_validate(webhook).model_dump(by_alias=True)

    async def delete_webhook(self, webhook_id: UUID) -> None:
        """Delete a webhook configuration."""
        await self._webhooks.delete(webhook_id)
        logger.info("developer.webhook.deleted", webhook_id=str(webhook_id))

    async def test_webhook(self, webhook_id: UUID) -> dict:
        """Send a test event to a webhook endpoint.

        Returns a synthetic result; real HTTP delivery to be implemented.
        """
        webhook = await self._webhooks.get_by_id(webhook_id)
        logger.info(
            "developer.webhook.test",
            webhook_id=str(webhook_id),
            url=webhook.url,
        )
        return {
            "webhookId": str(webhook_id),
            "url": webhook.url,
            "status": "delivered",
            "statusCode": 200,
            "responseTimeMs": 120,
        }

    async def execute_sandbox(self, code: str) -> dict:
        """Execute code in a sandboxed environment.

        Returns a stub response; real sandbox execution to be implemented.
        """
        logger.info(
            "developer.sandbox.execute",
            code_length=len(code),
        )
        return {
            "output": "Sandbox execution is not yet available.",
            "exitCode": 0,
            "executionTimeMs": 0,
        }
