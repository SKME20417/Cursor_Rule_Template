"""Admin configuration and branding service."""

import structlog
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.brand_config import BrandConfig
from app.repositories.admin_config_repo import AdminConfigRepository
from app.schemas.admin import (
    AdminConfigResponse,
    BrandConfigResponse,
    UpdateAdminConfigRequest,
    UpdateBrandConfigRequest,
)

logger = structlog.get_logger()


class AdminService:
    """Manages platform-wide admin configuration and branding."""

    def __init__(self, session: AsyncSession) -> None:
        self._db = session
        self._admin_config = AdminConfigRepository(session)

    async def get_config(self) -> dict:
        """Get the platform configuration."""
        config = await self._admin_config.get_singleton()
        return {
            "id": str(config.id),
            "maxConcurrentConversationsPerAgent": config.max_concurrent_per_agent,
            "autoAssignEnabled": config.auto_assign_enabled,
            "businessHoursEnabled": config.business_hours_enabled,
            "businessHours": config.business_hours or [],
            "defaultLanguage": config.default_language,
            "supportedLanguages": config.supported_languages or [],
            "updatedAt": config.updated_at.isoformat() if config.updated_at else None,
        }

    async def update_config(self, body: UpdateAdminConfigRequest) -> dict:
        """Update the platform configuration."""
        config = await self._admin_config.get_singleton()
        update_data: dict = {}

        if body.max_concurrent_conversations_per_agent is not None:
            update_data["max_concurrent_per_agent"] = body.max_concurrent_conversations_per_agent
        if body.auto_assign_enabled is not None:
            update_data["auto_assign_enabled"] = body.auto_assign_enabled
        if body.business_hours_enabled is not None:
            update_data["business_hours_enabled"] = body.business_hours_enabled
        if body.business_hours is not None:
            update_data["business_hours"] = [
                bh.model_dump(by_alias=True) for bh in body.business_hours
            ]
        if body.default_language is not None:
            update_data["default_language"] = body.default_language
        if body.supported_languages is not None:
            update_data["supported_languages"] = body.supported_languages

        if update_data:
            config = await self._admin_config.update(config.id, update_data)
            logger.info("admin.config.updated")

        return await self.get_config()

    async def get_branding(self) -> dict:
        """Get the branding configuration."""
        query = select(BrandConfig).limit(1)
        result = await self._db.execute(query)
        brand = result.scalars().first()

        if brand is None:
            # Create default branding
            brand = BrandConfig(
                company_name="Support Copilot",
                primary_color="#0a66c2",
                accent_color="#004182",
                widget_position="bottom-right",
                widget_greeting="Hi! How can we help you today?",
                email_from_name="Support Team",
                email_from_address="support@example.com",
            )
            self._db.add(brand)
            await self._db.flush()
            await self._db.refresh(brand)

        return BrandConfigResponse.model_validate(brand).model_dump(by_alias=True)

    async def update_branding(self, body: UpdateBrandConfigRequest) -> dict:
        """Update the branding configuration."""
        query = select(BrandConfig).limit(1)
        result = await self._db.execute(query)
        brand = result.scalars().first()

        if brand is None:
            brand = await self.get_branding()
            query = select(BrandConfig).limit(1)
            result = await self._db.execute(query)
            brand = result.scalars().first()

        update_data = body.model_dump(exclude_unset=True)
        for key, value in update_data.items():
            if hasattr(brand, key):
                setattr(brand, key, value)
        await self._db.flush()
        await self._db.refresh(brand)

        logger.info("admin.branding.updated")
        return BrandConfigResponse.model_validate(brand).model_dump(by_alias=True)
