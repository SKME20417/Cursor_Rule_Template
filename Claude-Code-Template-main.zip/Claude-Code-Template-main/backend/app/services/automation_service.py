"""Automation workflow service."""

from uuid import UUID

import structlog
from sqlalchemy.ext.asyncio import AsyncSession

from app.repositories.workflow_repo import WorkflowRepository
from app.schemas.automation import (
    AutoReplyTemplateResponse,
    CreateWorkflowRequest,
    EscalationRuleResponse,
    UpdateWorkflowRequest,
    WorkflowResponse,
)

logger = structlog.get_logger()


class AutomationService:
    """Manages automation workflows, auto-reply templates, and escalation rules."""

    def __init__(self, session: AsyncSession) -> None:
        self._db = session
        self._workflows = WorkflowRepository(session)

    async def list_workflows(
        self, offset: int = 0, limit: int = 20, filters: dict | None = None
    ) -> tuple[list[dict], int]:
        """List workflows with pagination."""
        items, total = await self._workflows.get_all(
            offset=offset, limit=limit, filters=filters
        )
        data = [
            WorkflowResponse.model_validate(w).model_dump(by_alias=True) for w in items
        ]
        return data, total

    async def create_workflow(
        self, body: CreateWorkflowRequest, user_id: UUID
    ) -> dict:
        """Create a new automation workflow."""
        workflow = await self._workflows.create(
            {
                "name": body.name,
                "description": body.description,
                "status": "draft",
                "trigger": body.trigger.model_dump(by_alias=True) if body.trigger else None,
                "nodes": [n.model_dump(by_alias=True) for n in body.nodes] if body.nodes else None,
                "edges": [e.model_dump(by_alias=True) for e in body.edges] if body.edges else None,
                "created_by_id": user_id,
            }
        )
        logger.info(
            "automation.workflow.created",
            workflow_id=str(workflow.id),
            user_id=str(user_id),
        )
        return WorkflowResponse.model_validate(workflow).model_dump(by_alias=True)

    async def update_workflow(
        self, workflow_id: UUID, body: UpdateWorkflowRequest
    ) -> dict:
        """Update an existing workflow."""
        update_data = body.model_dump(exclude_unset=True)
        # Serialise nested pydantic objects for JSONB storage
        if "trigger" in update_data and update_data["trigger"] is not None:
            update_data["trigger"] = update_data["trigger"].model_dump(by_alias=True) if hasattr(update_data["trigger"], "model_dump") else update_data["trigger"]
        if "nodes" in update_data and update_data["nodes"] is not None:
            update_data["nodes"] = [
                n.model_dump(by_alias=True) if hasattr(n, "model_dump") else n
                for n in update_data["nodes"]
            ]
        if "edges" in update_data and update_data["edges"] is not None:
            update_data["edges"] = [
                e.model_dump(by_alias=True) if hasattr(e, "model_dump") else e
                for e in update_data["edges"]
            ]

        workflow = await self._workflows.update(workflow_id, update_data)
        logger.info("automation.workflow.updated", workflow_id=str(workflow_id))
        return WorkflowResponse.model_validate(workflow).model_dump(by_alias=True)

    async def list_auto_replies(self) -> list[dict]:
        """List all auto-reply templates.

        Uses a direct query since AutoReplyTemplate has its own table.
        """
        from sqlalchemy import select

        from app.models.auto_reply_template import AutoReplyTemplate

        query = select(AutoReplyTemplate).order_by(AutoReplyTemplate.created_at.desc())
        result = await self._db.execute(query)
        items = list(result.scalars().all())
        return [
            AutoReplyTemplateResponse.model_validate(t).model_dump(by_alias=True)
            for t in items
        ]

    async def list_escalation_rules(self) -> list[dict]:
        """List all escalation rules."""
        from sqlalchemy import select

        from app.models.escalation_rule import EscalationRule

        query = select(EscalationRule).order_by(EscalationRule.created_at.desc())
        result = await self._db.execute(query)
        items = list(result.scalars().all())
        return [
            EscalationRuleResponse.model_validate(r).model_dump(by_alias=True)
            for r in items
        ]
