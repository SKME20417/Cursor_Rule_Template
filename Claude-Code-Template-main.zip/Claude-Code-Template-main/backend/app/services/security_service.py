"""Security, RBAC, audit, and API key management service."""

import hashlib
import secrets
from uuid import UUID

import structlog
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.exceptions import NotFoundException
from app.models.permission import Permission
from app.repositories.api_key_repo import ApiKeyRepository
from app.repositories.audit_repo import AuditRepository
from app.repositories.role_repo import RoleRepository
from app.schemas.security import (
    ApiKeyResponse,
    AuditEntryResponse,
    CreateApiKeyRequest,
    PermissionResponse,
    RoleResponse,
)

logger = structlog.get_logger()


class SecurityService:
    """Manages roles, permissions, audit logging, and API keys."""

    def __init__(self, session: AsyncSession) -> None:
        self._db = session
        self._roles = RoleRepository(session)
        self._audit = AuditRepository(session)
        self._api_keys = ApiKeyRepository(session)

    # ── Roles ────────────────────────────────────────────────

    async def list_roles(self) -> list[dict]:
        """List all roles with their permissions."""
        items, _ = await self._roles.get_all(offset=0, limit=100)
        return [
            RoleResponse.model_validate(r).model_dump(by_alias=True) for r in items
        ]

    async def get_role_permissions(self, role_id: UUID) -> list[dict]:
        """Get permissions for a specific role."""
        role = await self._roles.get_by_id(role_id)
        return [
            PermissionResponse.model_validate(p).model_dump(by_alias=True)
            for p in role.permissions
        ]

    async def update_role_permissions(
        self, role_id: UUID, permissions: list[dict]
    ) -> list[dict]:
        """Replace all permissions for a role.

        Expects a list of dicts with 'resource' and 'action' keys.
        """
        role = await self._roles.get_by_id(role_id)

        # Remove existing permissions
        query = select(Permission).where(Permission.role_id == role_id)
        result = await self._db.execute(query)
        for p in result.scalars().all():
            await self._db.delete(p)

        # Add new permissions
        new_perms: list[Permission] = []
        for perm_data in permissions:
            perm = Permission(
                role_id=role_id,
                resource=perm_data["resource"],
                action=perm_data["action"],
            )
            self._db.add(perm)
            new_perms.append(perm)
        await self._db.flush()

        for p in new_perms:
            await self._db.refresh(p)

        logger.info(
            "security.role.permissions.updated",
            role_id=str(role_id),
            count=len(new_perms),
        )
        return [
            PermissionResponse.model_validate(p).model_dump(by_alias=True)
            for p in new_perms
        ]

    # ── Audit ────────────────────────────────────────────────

    async def get_audit_log(
        self, offset: int = 0, limit: int = 20
    ) -> tuple[list[dict], int]:
        """Get paginated audit log entries."""
        items, total = await self._audit.get_all(offset=offset, limit=limit)
        data = [
            AuditEntryResponse.model_validate(e).model_dump(by_alias=True)
            for e in items
        ]
        return data, total

    # ── API Keys ─────────────────────────────────────────────

    async def list_api_keys(self) -> list[dict]:
        """List all API keys (without revealing the full key)."""
        items, _ = await self._api_keys.get_all(offset=0, limit=200)
        return [
            ApiKeyResponse.model_validate(k).model_dump(by_alias=True) for k in items
        ]

    async def create_api_key(
        self, body: CreateApiKeyRequest, user_id: UUID
    ) -> dict:
        """Generate a new API key.

        Returns the full key only once; after creation only the prefix is stored.
        """
        raw_key = secrets.token_urlsafe(32)
        prefix = raw_key[:8]
        key_hash = hashlib.sha256(raw_key.encode()).hexdigest()

        api_key = await self._api_keys.create(
            {
                "name": body.name,
                "key_hash": key_hash,
                "key_prefix": prefix,
                "permissions": {"scopes": body.permissions},
                "is_active": True,
                "created_by_id": user_id,
            }
        )
        logger.info(
            "security.api_key.created",
            api_key_id=str(api_key.id),
            user_id=str(user_id),
        )
        result = ApiKeyResponse.model_validate(api_key).model_dump(by_alias=True)
        result["key"] = raw_key  # Only returned on creation
        return result

    async def revoke_api_key(self, api_key_id: UUID) -> None:
        """Revoke (delete) an API key."""
        await self._api_keys.delete(api_key_id)
        logger.info("security.api_key.revoked", api_key_id=str(api_key_id))
