"""Customer management service."""

from uuid import UUID

import structlog
from sqlalchemy.ext.asyncio import AsyncSession

from app.repositories.conversation_repo import ConversationRepository
from app.repositories.customer_repo import CustomerRepository
from app.repositories.ticket_repo import TicketRepository
from app.schemas.customer import CustomerProfileResponse, CustomerResponse

logger = structlog.get_logger()


class CustomerService:
    """Manages customer profiles and interaction history."""

    def __init__(self, session: AsyncSession) -> None:
        self._db = session
        self._customers = CustomerRepository(session)
        self._conversations = ConversationRepository(session)
        self._tickets = TicketRepository(session)

    async def list_customers(
        self, offset: int = 0, limit: int = 20, search: str | None = None
    ) -> tuple[list[dict], int]:
        """List customers with optional email/name search."""
        if search:
            items, total = await self._customers.search_by_email(
                search, offset=offset, limit=limit
            )
            if not items:
                items, total = await self._customers.search_by_name(
                    search, offset=offset, limit=limit
                )
        else:
            items, total = await self._customers.get_all(
                offset=offset, limit=limit
            )
        data = [
            CustomerResponse.model_validate(c).model_dump(by_alias=True) for c in items
        ]
        return data, total

    async def get_profile(self, customer_id: UUID) -> dict:
        """Get an enriched customer profile with aggregate data."""
        customer = await self._customers.get_by_id(customer_id)
        customer_data = CustomerResponse.model_validate(customer)

        # Aggregate counts
        _, total_conversations = await self._conversations.get_by_customer(
            customer_id, offset=0, limit=1
        )
        all_tickets, total_tickets = await self._tickets.get_by_customer(
            customer_id, offset=0, limit=1
        )
        open_tickets_items, open_tickets = await self._tickets.get_by_status(
            "created", offset=0, limit=1
        )
        # Simplified: count tickets by customer that are still open
        open_count = sum(
            1
            for t in (await self._tickets.get_by_customer(customer_id, 0, 500))[0]
            if t.status in ("created", "in_progress", "waiting")
        )

        profile = CustomerProfileResponse(
            customer=customer_data,
            total_conversations=total_conversations,
            total_tickets=total_tickets,
            open_tickets=open_count,
            average_satisfaction_score=None,
            last_contact_at=customer.conversations[0].last_message_at
            if customer.conversations
            else None,
            preferred_channel=customer.conversations[0].channel
            if customer.conversations
            else None,
            metadata={},
        )
        return profile.model_dump(by_alias=True)

    async def get_history(
        self, customer_id: UUID, offset: int = 0, limit: int = 20
    ) -> tuple[list[dict], int]:
        """Get conversation history for a customer."""
        # Verify customer exists
        await self._customers.get_by_id(customer_id)
        items, total = await self._conversations.get_by_customer(
            customer_id, offset=offset, limit=limit
        )
        from app.schemas.chat import ConversationResponse

        data = [
            ConversationResponse.model_validate(c).model_dump(by_alias=True)
            for c in items
        ]
        return data, total
