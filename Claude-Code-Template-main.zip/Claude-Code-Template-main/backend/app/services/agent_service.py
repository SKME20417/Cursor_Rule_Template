"""Agent and team management service."""

from uuid import UUID

import structlog
from sqlalchemy.ext.asyncio import AsyncSession

from app.repositories.agent_repo import AgentRepository
from app.repositories.team_repo import TeamRepository
from app.schemas.agent import (
    AgentResponse,
    CreateAgentRequest,
    TeamResponse,
    UpdateAgentRequest,
)

logger = structlog.get_logger()


class AgentService:
    """Manages support agents and teams."""

    def __init__(self, session: AsyncSession) -> None:
        self._db = session
        self._agents = AgentRepository(session)
        self._teams = TeamRepository(session)

    async def list_agents(
        self, offset: int = 0, limit: int = 20, filters: dict | None = None
    ) -> tuple[list[dict], int]:
        """List agents with pagination."""
        items, total = await self._agents.get_all(
            offset=offset, limit=limit, filters=filters
        )
        data = [
            AgentResponse.model_validate(a).model_dump(by_alias=True) for a in items
        ]
        return data, total

    async def get_agent(self, agent_id: UUID) -> dict:
        """Get a single agent by ID."""
        agent = await self._agents.get_by_id(agent_id)
        return AgentResponse.model_validate(agent).model_dump(by_alias=True)

    async def create_agent(self, body: CreateAgentRequest) -> dict:
        """Register a new support agent."""
        agent = await self._agents.create(
            {
                "user_id": body.user_id,
                "display_name": body.display_name,
                "email": body.email,
                "team_id": body.team_id,
                "supported_channels": body.supported_channels or [],
                "max_concurrent_conversations": body.max_concurrent_conversations or 5,
                "status": "offline",
            }
        )
        logger.info(
            "agent.created",
            agent_id=str(agent.id),
            user_id=str(body.user_id),
        )
        return AgentResponse.model_validate(agent).model_dump(by_alias=True)

    async def update_agent(
        self, agent_id: UUID, body: UpdateAgentRequest
    ) -> dict:
        """Update an existing agent."""
        update_data = body.model_dump(exclude_unset=True)
        agent = await self._agents.update(agent_id, update_data)
        logger.info("agent.updated", agent_id=str(agent_id))
        return AgentResponse.model_validate(agent).model_dump(by_alias=True)

    async def list_teams(self) -> list[dict]:
        """List all agent teams."""
        items, _ = await self._teams.get_all(offset=0, limit=500)
        return [
            TeamResponse.model_validate(t).model_dump(by_alias=True) for t in items
        ]
