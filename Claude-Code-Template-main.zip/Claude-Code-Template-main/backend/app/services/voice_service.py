"""Voice call management service."""

from datetime import UTC, datetime
from uuid import UUID

import structlog
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.exceptions import NotFoundException
from app.repositories.call_repo import CallRepository
from app.schemas.voice import CallResponse, CreateCallRequest, RecordingResponse, TranscriptResponse

logger = structlog.get_logger()


class VoiceService:
    """Manages voice calls, recordings, and transcripts."""

    def __init__(self, session: AsyncSession) -> None:
        self._db = session
        self._calls = CallRepository(session)

    async def list_calls(
        self, offset: int = 0, limit: int = 20, filters: dict | None = None
    ) -> tuple[list[dict], int]:
        """List calls with pagination."""
        items, total = await self._calls.get_all(
            offset=offset, limit=limit, filters=filters
        )
        data = [
            CallResponse.model_validate(c).model_dump(by_alias=True) for c in items
        ]
        return data, total

    async def get_call(self, call_id: UUID) -> dict:
        """Get a single call by ID."""
        call = await self._calls.get_by_id(call_id)
        return CallResponse.model_validate(call).model_dump(by_alias=True)

    async def create_call(
        self, body: CreateCallRequest, agent_id: UUID
    ) -> dict:
        """Initiate a new outbound call."""
        call = await self._calls.create(
            {
                "customer_id": body.customer_id,
                "agent_id": agent_id,
                "phone_number": body.phone_number,
                "direction": "outbound",
                "status": "ringing",
                "started_at": datetime.now(UTC),
            }
        )
        logger.info(
            "voice.call.created",
            call_id=str(call.id),
            agent_id=str(agent_id),
        )
        return CallResponse.model_validate(call).model_dump(by_alias=True)

    async def end_call(self, call_id: UUID) -> dict:
        """End an active call."""
        call = await self._calls.get_by_id(call_id)
        now = datetime.now(UTC)
        duration = None
        if call.connected_at:
            duration = int((now - call.connected_at).total_seconds())

        call = await self._calls.update(
            call_id,
            {
                "status": "completed",
                "ended_at": now,
                "duration_seconds": duration,
            },
        )
        logger.info("voice.call.ended", call_id=str(call_id))
        return CallResponse.model_validate(call).model_dump(by_alias=True)

    async def get_recording(self, call_id: UUID) -> dict:
        """Get the recording for a call."""
        call = await self._calls.get_by_id(call_id)
        if call.recording is None:
            raise NotFoundException("Recording", str(call_id))
        return RecordingResponse.model_validate(call.recording).model_dump(by_alias=True)

    async def get_transcript(self, call_id: UUID) -> dict:
        """Get the transcript for a call."""
        call = await self._calls.get_by_id(call_id)
        if call.transcript is None:
            raise NotFoundException("Transcript", str(call_id))
        return TranscriptResponse.model_validate(call.transcript).model_dump(by_alias=True)
