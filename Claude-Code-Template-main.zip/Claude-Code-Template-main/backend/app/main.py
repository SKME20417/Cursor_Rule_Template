"""FastAPI application factory with lifespan events."""

from contextlib import asynccontextmanager
from collections.abc import AsyncIterator

import structlog
from fastapi import FastAPI
from fastapi.responses import ORJSONResponse

from app.config import get_settings
from app.core.error_handlers import register_error_handlers
from app.core.logging import setup_logging
from app.core.middleware import CorrelationIdMiddleware, setup_cors
from app.core.redis import redis_client

logger = structlog.get_logger()
settings = get_settings()


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncIterator[None]:
    """Startup and shutdown lifecycle."""
    setup_logging()
    logger.info("starting_app", env=settings.app_env, port=settings.app_port)

    # Verify Redis connectivity
    try:
        await redis_client.ping()
        logger.info("redis_connected")
    except Exception as exc:
        logger.warning("redis_unavailable", error=str(exc))

    yield

    # Shutdown
    await redis_client.aclose()
    logger.info("app_shutdown_complete")


def create_app() -> FastAPI:
    """Build and configure the FastAPI application."""
    app = FastAPI(
        title="AI Support Copilot API",
        description="AI-powered customer support platform backend",
        version="0.1.0",
        default_response_class=ORJSONResponse,
        lifespan=lifespan,
        docs_url="/api/docs" if settings.app_debug else None,
        redoc_url="/api/redoc" if settings.app_debug else None,
    )

    # Middleware (order matters — outermost first)
    setup_cors(app)
    app.add_middleware(CorrelationIdMiddleware)

    # Error handlers
    register_error_handlers(app)

    # Routes
    from app.routes.router import api_router

    app.include_router(api_router)

    # WebSocket
    from app.websockets.handlers import ws_router

    app.include_router(ws_router)

    # Health check (outside /api/v1)
    @app.get("/health", tags=["Health"])
    async def health_check():
        return {"status": "ok", "service": "ai-support-copilot"}

    return app


app = create_app()
