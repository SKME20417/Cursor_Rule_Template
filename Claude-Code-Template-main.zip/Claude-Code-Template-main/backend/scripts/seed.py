"""Seed script to populate the database with realistic demo data.

Usage:
    python scripts/seed.py

Requires a running PostgreSQL instance at localhost:5433 with the
support_copilot database already migrated.
"""

import asyncio
import sys
from datetime import UTC, datetime, timedelta
from pathlib import Path
from uuid import uuid4

# Ensure the project root is on sys.path so `app` is importable.
PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine

from app.models.base import Base
from app.models.user import User
from app.models.customer import Customer
from app.models.agent import Agent
from app.models.team import Team
from app.models.ticket import Ticket
from app.models.ticket_category import TicketCategory
from app.models.sla_policy import SLAPolicy
from app.models.conversation import Conversation
from app.models.message import Message
from app.models.article import Article
from app.models.category import Category
from app.models.notification import Notification
from app.models.role import RoleModel
from app.models.admin_config import AdminConfig
from app.models.integration import Integration

# Use passlib directly to avoid importing app.config (which needs env vars).
from passlib.context import CryptContext

_pwd_ctx = CryptContext(schemes=["bcrypt"], deprecated="auto")


def hash_password(password: str) -> str:
    return _pwd_ctx.hash(password)


DATABASE_URL = "postgresql+asyncpg://postgres:postgres@localhost:5433/support_copilot"

engine = create_async_engine(DATABASE_URL, echo=False)
async_session = async_sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _now() -> datetime:
    return datetime.now(UTC)


def _ago(**kwargs) -> datetime:
    return datetime.now(UTC) - timedelta(**kwargs)


# ---------------------------------------------------------------------------
# Seed data factories
# ---------------------------------------------------------------------------

def _build_users(password_hash: str) -> list[User]:
    """Return the five demo users."""
    return [
        User(
            id=uuid4(),
            email="admin@copilot.ai",
            password_hash=password_hash,
            first_name="Sarah",
            last_name="Chen",
            role="admin",
            is_active=True,
            last_login_at=_ago(hours=1),
        ),
        User(
            id=uuid4(),
            email="supervisor@copilot.ai",
            password_hash=password_hash,
            first_name="Mike",
            last_name="Johnson",
            role="supervisor",
            is_active=True,
            last_login_at=_ago(hours=3),
        ),
        User(
            id=uuid4(),
            email="agent1@copilot.ai",
            password_hash=password_hash,
            first_name="Emily",
            last_name="Parker",
            role="agent",
            is_active=True,
            last_login_at=_ago(minutes=30),
        ),
        User(
            id=uuid4(),
            email="agent2@copilot.ai",
            password_hash=password_hash,
            first_name="David",
            last_name="Kim",
            role="agent",
            is_active=True,
            last_login_at=_ago(hours=2),
        ),
        User(
            id=uuid4(),
            email="customer@copilot.ai",
            password_hash=password_hash,
            first_name="Alex",
            last_name="Rivera",
            role="customer",
            is_active=True,
            last_login_at=_ago(days=1),
        ),
    ]


def _build_customers(customer_user: User) -> list[Customer]:
    return [
        Customer(
            id=uuid4(),
            external_id=str(customer_user.id),
            email="alex.rivera@example.com",
            first_name="Alex",
            last_name="Rivera",
            phone="+1-415-555-0101",
            segment="premium",
            tags=["early-adopter", "enterprise"],
            is_verified=True,
        ),
        Customer(
            id=uuid4(),
            email="jordan.lee@acmecorp.com",
            first_name="Jordan",
            last_name="Lee",
            phone="+1-415-555-0102",
            segment="enterprise",
            tags=["enterprise", "api-user"],
            is_verified=True,
        ),
        Customer(
            id=uuid4(),
            email="sam.patel@startupinc.io",
            first_name="Sam",
            last_name="Patel",
            phone="+44-20-7946-0958",
            segment="growth",
            tags=["startup", "trial"],
            is_verified=True,
        ),
        Customer(
            id=uuid4(),
            email="morgan.wu@bigretail.com",
            first_name="Morgan",
            last_name="Wu",
            phone="+1-212-555-0199",
            segment="enterprise",
            tags=["retail", "high-volume"],
            is_verified=True,
        ),
        Customer(
            id=uuid4(),
            email="casey.jones@freelance.dev",
            first_name="Casey",
            last_name="Jones",
            segment="new",
            tags=["freelancer"],
            is_verified=False,
        ),
    ]


def _build_teams() -> list[Team]:
    return [
        Team(
            id=uuid4(),
            name="Support Tier 1",
            description="Front-line support handling general inquiries, password resets, and basic troubleshooting.",
            member_count=2,
        ),
        Team(
            id=uuid4(),
            name="Support Tier 2",
            description="Escalation team for complex technical issues, billing disputes, and enterprise accounts.",
            member_count=1,
        ),
    ]


def _build_agents(
    supervisor_user: User,
    agent1_user: User,
    agent2_user: User,
    tier1_team: Team,
    tier2_team: Team,
) -> list[Agent]:
    return [
        Agent(
            id=uuid4(),
            user_id=agent1_user.id,
            display_name="Emily Parker",
            email=agent1_user.email,
            status="online",
            team_id=tier1_team.id,
            supported_channels=["web_chat", "email", "whatsapp"],
            max_concurrent_conversations=5,
            active_conversation_count=2,
            last_active_at=_ago(minutes=5),
        ),
        Agent(
            id=uuid4(),
            user_id=agent2_user.id,
            display_name="David Kim",
            email=agent2_user.email,
            status="online",
            team_id=tier1_team.id,
            supported_channels=["web_chat", "email"],
            max_concurrent_conversations=5,
            active_conversation_count=1,
            last_active_at=_ago(minutes=15),
        ),
        Agent(
            id=uuid4(),
            user_id=supervisor_user.id,
            display_name="Mike Johnson",
            email=supervisor_user.email,
            status="offline",
            team_id=tier2_team.id,
            supported_channels=["web_chat", "email", "whatsapp", "voice"],
            max_concurrent_conversations=3,
            active_conversation_count=0,
            last_active_at=_ago(hours=3),
        ),
    ]


def _build_ticket_categories() -> list[TicketCategory]:
    return [
        TicketCategory(id=uuid4(), name="Billing", description="Invoices, refunds, payment methods, and subscription changes."),
        TicketCategory(id=uuid4(), name="Technical", description="Bugs, outages, API errors, and integration issues."),
        TicketCategory(id=uuid4(), name="Account", description="Password resets, profile updates, and access issues."),
        TicketCategory(id=uuid4(), name="Feature Request", description="Suggestions for new features, improvements, and integrations."),
        TicketCategory(id=uuid4(), name="General", description="Questions, feedback, and other inquiries that do not fit a specific category."),
    ]


def _build_sla_policies() -> list[SLAPolicy]:
    return [
        SLAPolicy(
            id=uuid4(),
            name="Standard",
            description="Default SLA for all non-premium customers. 24-hour first response, 48-hour resolution.",
            first_response_minutes=1440,  # 24 hours
            resolution_minutes=2880,      # 48 hours
            priority="medium",
            is_active=True,
        ),
        SLAPolicy(
            id=uuid4(),
            name="Premium",
            description="Priority SLA for premium and enterprise customers. 4-hour first response, 24-hour resolution.",
            first_response_minutes=240,   # 4 hours
            resolution_minutes=1440,      # 24 hours
            priority="high",
            is_active=True,
        ),
    ]


def _build_tickets(
    customers: list[Customer],
    agents: list[Agent],
    categories: list[TicketCategory],
    sla_policies: list[SLAPolicy],
    teams: list[Team],
    conversations: list[Conversation],
) -> list[Ticket]:
    standard_sla, premium_sla = sla_policies
    billing, technical, account, feature_req, general = categories
    c0, c1, c2, c3, c4 = customers
    a0, a1, a2 = agents  # Emily, David, Mike
    t1, t2 = teams

    return [
        Ticket(
            id=uuid4(),
            customer_id=c0.id,
            assigned_agent_id=a0.id,
            team_id=t1.id,
            subject="Cannot update credit card on file",
            description="I am trying to update my payment method in the billing section but I keep getting a 'Payment method declined' error even though the card works everywhere else.",
            status="in_progress",
            priority="high",
            category_id=billing.id,
            channel="web_chat",
            tags=["billing", "payment"],
            sla_policy_id=premium_sla.id,
            sla_breach_at=_now() + timedelta(hours=20),
            first_response_at=_ago(hours=1),
            conversation_id=conversations[0].id,
        ),
        Ticket(
            id=uuid4(),
            customer_id=c1.id,
            assigned_agent_id=a0.id,
            team_id=t1.id,
            subject="API rate limit errors in production",
            description="Our production integration is returning 429 errors on the /v2/messages endpoint since this morning. We are well below our plan limits.",
            status="in_progress",
            priority="critical",
            category_id=technical.id,
            channel="email",
            tags=["api", "rate-limit", "production"],
            sla_policy_id=premium_sla.id,
            sla_breach_at=_now() + timedelta(hours=2),
            first_response_at=_ago(hours=2),
            conversation_id=conversations[1].id,
        ),
        Ticket(
            id=uuid4(),
            customer_id=c2.id,
            assigned_agent_id=a1.id,
            team_id=t1.id,
            subject="Cannot log in after password reset",
            description="I reset my password using the forgot-password flow but the new password is not being accepted. I have tried three times.",
            status="open",
            priority="medium",
            category_id=account.id,
            channel="web_chat",
            tags=["login", "password"],
            sla_policy_id=standard_sla.id,
            sla_breach_at=_now() + timedelta(hours=22),
            conversation_id=conversations[2].id,
        ),
        Ticket(
            id=uuid4(),
            customer_id=c3.id,
            assigned_agent_id=a1.id,
            team_id=t1.id,
            subject="Request: Bulk import via CSV",
            description="We process thousands of orders daily and need a CSV bulk-import feature for customer records. Currently we are calling the API one by one.",
            status="open",
            priority="low",
            category_id=feature_req.id,
            channel="email",
            tags=["feature-request", "csv", "bulk"],
            sla_policy_id=standard_sla.id,
            sla_breach_at=_now() + timedelta(hours=46),
        ),
        Ticket(
            id=uuid4(),
            customer_id=c4.id,
            subject="Webhook events arriving out of order",
            description="We are receiving webhook events for conversations in a different order than they occurred. The created_at timestamps are correct but delivery order is wrong.",
            status="open",
            priority="medium",
            category_id=technical.id,
            channel="web_chat",
            tags=["webhooks", "ordering"],
            sla_policy_id=standard_sla.id,
            sla_breach_at=_now() + timedelta(hours=23),
        ),
        Ticket(
            id=uuid4(),
            customer_id=c0.id,
            assigned_agent_id=a2.id,
            team_id=t2.id,
            subject="Enterprise SSO setup assistance",
            description="We are migrating to Okta SSO and need help configuring SAML integration with our support portal. Documentation seems outdated.",
            status="in_progress",
            priority="high",
            category_id=account.id,
            channel="email",
            tags=["sso", "enterprise", "okta"],
            sla_policy_id=premium_sla.id,
            sla_breach_at=_now() + timedelta(hours=18),
            first_response_at=_ago(hours=4),
            conversation_id=conversations[3].id,
        ),
        Ticket(
            id=uuid4(),
            customer_id=c1.id,
            assigned_agent_id=a0.id,
            team_id=t1.id,
            subject="Invoice discrepancy for March",
            description="Our March invoice shows charges for 150 agent seats but we only have 120 active agents. Please review and issue a corrected invoice.",
            status="resolved",
            priority="medium",
            category_id=billing.id,
            channel="email",
            tags=["billing", "invoice"],
            sla_policy_id=premium_sla.id,
            first_response_at=_ago(days=3),
            resolved_at=_ago(days=2),
        ),
        Ticket(
            id=uuid4(),
            customer_id=c2.id,
            assigned_agent_id=a1.id,
            team_id=t1.id,
            subject="How to set up email forwarding?",
            description="I want to forward all support emails from help@startupinc.io to the platform. Where do I configure this?",
            status="resolved",
            priority="low",
            category_id=general.id,
            channel="web_chat",
            tags=["email", "setup"],
            sla_policy_id=standard_sla.id,
            first_response_at=_ago(days=5),
            resolved_at=_ago(days=4),
        ),
        Ticket(
            id=uuid4(),
            customer_id=c3.id,
            assigned_agent_id=a2.id,
            team_id=t2.id,
            subject="Data export for compliance audit",
            description="We need a full export of all conversation transcripts and ticket data for the last 12 months. This is required for our SOC 2 audit.",
            status="closed",
            priority="high",
            category_id=general.id,
            channel="email",
            tags=["compliance", "data-export", "soc2"],
            sla_policy_id=premium_sla.id,
            first_response_at=_ago(days=10),
            resolved_at=_ago(days=7),
            closed_at=_ago(days=5),
        ),
        Ticket(
            id=uuid4(),
            customer_id=c4.id,
            assigned_agent_id=a0.id,
            team_id=t1.id,
            subject="Mobile SDK crash on Android 14",
            description="Our Android app crashes when initializing the support chat widget on Android 14 devices. Stack trace attached. Affects approximately 15% of our user base.",
            status="closed",
            priority="critical",
            category_id=technical.id,
            channel="web_chat",
            tags=["mobile", "android", "crash"],
            sla_policy_id=standard_sla.id,
            first_response_at=_ago(days=14),
            resolved_at=_ago(days=12),
            closed_at=_ago(days=10),
        ),
    ]


def _build_conversations(
    customers: list[Customer],
    agents: list[Agent],
) -> list[Conversation]:
    c0, c1, c2, c3, c4 = customers
    a0, a1, a2 = agents  # Emily, David, Mike

    return [
        Conversation(
            id=uuid4(),
            customer_id=c0.id,
            assigned_agent_id=a0.id,
            channel="web_chat",
            status="active",
            subject="Payment method issue",
            tags=["billing"],
            last_message_at=_ago(minutes=10),
            last_message_preview="Let me check your account settings now.",
            message_count=4,
        ),
        Conversation(
            id=uuid4(),
            customer_id=c1.id,
            assigned_agent_id=a0.id,
            channel="email",
            status="active",
            subject="API rate limit investigation",
            tags=["api", "urgent"],
            last_message_at=_ago(minutes=45),
            last_message_preview="We have identified the issue and are deploying a fix.",
            message_count=5,
        ),
        Conversation(
            id=uuid4(),
            customer_id=c2.id,
            assigned_agent_id=a1.id,
            channel="web_chat",
            status="waiting",
            subject="Login trouble after password reset",
            tags=["account"],
            last_message_at=_ago(hours=1),
            last_message_preview="Could you try clearing your browser cache and attempting again?",
            message_count=3,
        ),
        Conversation(
            id=uuid4(),
            customer_id=c0.id,
            assigned_agent_id=a2.id,
            channel="email",
            status="active",
            subject="SSO configuration help",
            tags=["sso", "enterprise"],
            last_message_at=_ago(hours=2),
            last_message_preview="I have attached the updated SAML configuration guide.",
            message_count=4,
        ),
        Conversation(
            id=uuid4(),
            customer_id=c3.id,
            channel="whatsapp",
            status="closed",
            subject="Quick question about pricing tiers",
            tags=["pricing"],
            last_message_at=_ago(days=2),
            last_message_preview="Thank you for the clarification!",
            message_count=3,
        ),
    ]


def _build_messages(
    conversations: list[Conversation],
    customers: list[Customer],
    agents: list[Agent],
) -> list[Message]:
    c0, c1, c2, c3, c4 = customers
    a0, a1, a2 = agents
    conv0, conv1, conv2, conv3, conv4 = conversations

    messages: list[Message] = []

    def _msg(conv_id, sender_id, role, content, minutes_ago, is_read=True):
        messages.append(Message(
            id=uuid4(),
            conversation_id=conv_id,
            sender_id=sender_id,
            sender_role=role,
            type="text",
            content=content,
            is_read=is_read,
        ))

    # Conversation 0: Payment method issue (web_chat)
    _msg(conv0.id, c0.id, "customer", "Hi, I am trying to update my credit card but I keep getting a 'Payment method declined' error.", 60)
    _msg(conv0.id, a0.id, "agent", "Hello Alex! I am sorry to hear you are having trouble. Let me pull up your account to take a look.", 55)
    _msg(conv0.id, c0.id, "customer", "Thank you. The card works fine everywhere else so I am not sure what is going on.", 50)
    _msg(conv0.id, a0.id, "agent", "Let me check your account settings now. I can see there may be a region restriction on the payment gateway. Give me just a moment.", 10)

    # Conversation 1: API rate limits (email)
    _msg(conv1.id, c1.id, "customer", "We are seeing 429 errors on /v2/messages since 08:00 UTC. Our request volume has not changed. Is there a platform issue?", 180)
    _msg(conv1.id, a0.id, "agent", "Hi Jordan, thank you for reporting this. I am escalating to our engineering team immediately given the production impact.", 170)
    _msg(conv1.id, c1.id, "customer", "We are seeing about a 30% failure rate. This is blocking outbound notifications for our customers.", 160)
    _msg(conv1.id, a0.id, "agent", "I understand the urgency. Our engineering team has confirmed a misconfigured rate-limit rule was deployed at 07:45 UTC. A rollback is in progress.", 90)
    _msg(conv1.id, a0.id, "agent", "We have identified the issue and are deploying a fix. You should see normal behavior within the next 15 minutes. I will follow up to confirm.", 45)

    # Conversation 2: Login trouble (web_chat)
    _msg(conv2.id, c2.id, "customer", "I just reset my password but the new one is not working. I have tried three times now.", 120)
    _msg(conv2.id, a1.id, "agent", "Hi Sam, I am sorry about the trouble. Let me check your account status. Can you confirm which email you used for the reset?", 110)
    _msg(conv2.id, a1.id, "agent", "Could you try clearing your browser cache and attempting again? Sometimes cached session tokens can interfere with the new password.", 60, is_read=False)

    # Conversation 3: SSO setup (email)
    _msg(conv3.id, c0.id, "customer", "We need help setting up SAML SSO with Okta. The documentation references an older admin panel version.", 300)
    _msg(conv3.id, a2.id, "agent", "Hi Alex, I would be happy to help with your SSO configuration. Let me pull up the latest setup guide.", 280)
    _msg(conv3.id, c0.id, "customer", "That would be great. We need the Entity ID, ACS URL, and certificate details for our Okta configuration.", 260)
    _msg(conv3.id, a2.id, "agent", "I have attached the updated SAML configuration guide. The Entity ID and ACS URL are on page 3. Let me know if you need the signing certificate exported.", 120)

    # Conversation 4: Pricing question (whatsapp, closed)
    _msg(conv4.id, c3.id, "customer", "Quick question: does the Growth plan include the analytics dashboard or is that only on Enterprise?", 3000)
    _msg(conv4.id, a1.id, "agent", "Hi Morgan! The Growth plan includes basic analytics (response times, volume). The full analytics suite with AI insights, CSAT trends, and custom reports is available on Enterprise.", 2900)
    _msg(conv4.id, c3.id, "customer", "Thank you for the clarification!", 2880)

    return messages


def _build_kb_categories() -> list[Category]:
    return [
        Category(
            id=uuid4(),
            name="Getting Started",
            slug="getting-started",
            description="Guides for new users covering setup, configuration, and first steps.",
            sort_order=1,
        ),
        Category(
            id=uuid4(),
            name="Billing & Payments",
            slug="billing-payments",
            description="Information about invoicing, payment methods, subscriptions, and refunds.",
            sort_order=2,
        ),
        Category(
            id=uuid4(),
            name="Troubleshooting",
            slug="troubleshooting",
            description="Solutions for common technical issues, errors, and performance problems.",
            sort_order=3,
        ),
    ]


def _build_articles(categories: list[Category], author: User) -> list[Article]:
    cat_gs, cat_billing, cat_trouble = categories
    now = _now()

    return [
        Article(
            id=uuid4(),
            title="Setting Up Your Support Portal",
            slug="setting-up-your-support-portal",
            content=(
                "Welcome to the AI Support Copilot platform. This guide walks you through the initial setup process.\n\n"
                "## Step 1: Configure Your Organization\n"
                "Navigate to Admin > Settings > Organization and fill in your company name, support email, and timezone.\n\n"
                "## Step 2: Invite Your Team\n"
                "Go to Admin > Team Members and invite agents by email. Each agent will receive an activation link.\n\n"
                "## Step 3: Set Up Channels\n"
                "Enable the channels your team will use (web chat, email, WhatsApp) under Admin > Channels.\n\n"
                "## Step 4: Import Your Knowledge Base\n"
                "Upload existing help articles or FAQs under Knowledge Base > Import. The system will automatically "
                "chunk and index the content for AI-powered retrieval."
            ),
            category_id=cat_gs.id,
            status="published",
            author_id=author.id,
            tags=["setup", "getting-started", "onboarding"],
            view_count=342,
            helpful_count=89,
            not_helpful_count=4,
            published_at=_ago(days=60),
        ),
        Article(
            id=uuid4(),
            title="Configuring AI Copilot for Agents",
            slug="configuring-ai-copilot-for-agents",
            content=(
                "The AI Copilot assists your agents by suggesting replies, surfacing relevant articles, and drafting responses.\n\n"
                "## Enabling Copilot\n"
                "Go to Admin > AI Settings > Copilot and toggle the feature on. You can enable it for specific teams or all agents.\n\n"
                "## Confidence Thresholds\n"
                "Set the minimum confidence score for suggestions to appear. We recommend starting at 0.7 and adjusting based on agent feedback.\n\n"
                "## Knowledge Base Integration\n"
                "Copilot uses your knowledge base for retrieval-augmented generation. Ensure your articles are up to date "
                "for the best suggestion quality.\n\n"
                "## Monitoring Performance\n"
                "Track acceptance rates, edit rates, and dismissal rates in Analytics > Copilot Performance."
            ),
            category_id=cat_gs.id,
            status="published",
            author_id=author.id,
            tags=["ai", "copilot", "configuration"],
            view_count=218,
            helpful_count=67,
            not_helpful_count=2,
            published_at=_ago(days=45),
        ),
        Article(
            id=uuid4(),
            title="Managing Your Subscription and Billing",
            slug="managing-subscription-billing",
            content=(
                "This article covers everything related to your subscription plan and billing settings.\n\n"
                "## Viewing Your Plan\n"
                "Navigate to Admin > Billing to see your current plan, usage, and next billing date.\n\n"
                "## Updating Payment Method\n"
                "Click 'Payment Methods' to add, remove, or update your credit card or bank account. "
                "Changes take effect on the next billing cycle.\n\n"
                "## Upgrading or Downgrading\n"
                "Plan changes can be made at any time. Upgrades are prorated, and downgrades take effect at the end "
                "of the current billing period.\n\n"
                "## Requesting a Refund\n"
                "Contact our billing team through the support portal or email billing@copilot.ai within 30 days of the charge."
            ),
            category_id=cat_billing.id,
            status="published",
            author_id=author.id,
            tags=["billing", "subscription", "payment"],
            view_count=456,
            helpful_count=112,
            not_helpful_count=8,
            published_at=_ago(days=90),
        ),
        Article(
            id=uuid4(),
            title="Understanding Your Invoice",
            slug="understanding-your-invoice",
            content=(
                "Each month you receive a detailed invoice breaking down your platform usage.\n\n"
                "## Line Items\n"
                "- **Agent Seats**: Charged per active agent per month.\n"
                "- **AI Credits**: Usage-based charges for AI copilot suggestions, auto-replies, and classifications.\n"
                "- **Channel Add-ons**: Additional charges for premium channels (WhatsApp, SMS).\n"
                "- **Storage**: Charges for call recordings and file attachments beyond the included quota.\n\n"
                "## Discrepancies\n"
                "If your invoice does not match expected usage, check Admin > Billing > Usage Report for a daily breakdown. "
                "Contact support if you believe there is an error.\n\n"
                "## Tax Information\n"
                "Tax is calculated based on your billing address. Update your tax ID under Admin > Billing > Tax Settings."
            ),
            category_id=cat_billing.id,
            status="published",
            author_id=author.id,
            tags=["billing", "invoice", "charges"],
            view_count=189,
            helpful_count=45,
            not_helpful_count=3,
            published_at=_ago(days=75),
        ),
        Article(
            id=uuid4(),
            title="Resolving API Connection Errors",
            slug="resolving-api-connection-errors",
            content=(
                "This guide helps you diagnose and fix common API connectivity issues.\n\n"
                "## Common Error Codes\n"
                "- **401 Unauthorized**: Your API key is invalid or expired. Regenerate it in Admin > API Keys.\n"
                "- **429 Too Many Requests**: You have exceeded your rate limit. Implement exponential backoff.\n"
                "- **502 Bad Gateway**: Temporary server issue. Retry after a few seconds.\n"
                "- **504 Gateway Timeout**: Request took too long. Reduce payload size or use pagination.\n\n"
                "## Debugging Steps\n"
                "1. Verify your API key is active and has the required scopes.\n"
                "2. Check the status page at status.copilot.ai for ongoing incidents.\n"
                "3. Test with a minimal request to isolate the issue.\n"
                "4. Review request headers — ensure Content-Type is set to application/json.\n\n"
                "## Rate Limits\n"
                "Default rate limits vary by plan. Check Admin > API Keys > Rate Limits for your current configuration."
            ),
            category_id=cat_trouble.id,
            status="published",
            author_id=author.id,
            tags=["api", "errors", "troubleshooting"],
            view_count=523,
            helpful_count=134,
            not_helpful_count=11,
            published_at=_ago(days=30),
        ),
        Article(
            id=uuid4(),
            title="Fixing WebSocket Disconnection Issues",
            slug="fixing-websocket-disconnection-issues",
            content=(
                "If your agents or customers are experiencing frequent disconnections in the chat widget, follow these steps.\n\n"
                "## Check Network Stability\n"
                "WebSocket connections are sensitive to network changes. Ensure the client network supports persistent connections "
                "and is not behind an aggressive proxy that terminates idle TCP connections.\n\n"
                "## Verify Heartbeat Configuration\n"
                "The platform sends ping frames every 30 seconds. If your load balancer has an idle timeout shorter than this, "
                "connections will drop. Set the idle timeout to at least 60 seconds.\n\n"
                "## Client-Side Reconnection\n"
                "Our SDK includes automatic reconnection with exponential backoff. Ensure you are using SDK version 2.3 or later "
                "which includes improved reconnection logic.\n\n"
                "## Server-Side Logs\n"
                "Check Admin > Monitoring > WebSocket Health for connection metrics. Look for patterns in disconnection times "
                "that might indicate scheduled maintenance or resource constraints."
            ),
            category_id=cat_trouble.id,
            status="published",
            author_id=author.id,
            tags=["websocket", "chat", "disconnection", "troubleshooting"],
            view_count=287,
            helpful_count=76,
            not_helpful_count=5,
            published_at=_ago(days=20),
        ),
    ]


def _build_notifications(agent1_user: User, agent2_user: User) -> list[Notification]:
    return [
        Notification(
            id=uuid4(),
            user_id=agent1_user.id,
            type="ticket_assigned",
            priority="high",
            title="Critical ticket assigned to you",
            body="Ticket 'API rate limit errors in production' from Jordan Lee has been assigned to you. Priority: Critical.",
            link_url="/tickets",
            is_read=True,
            read_at=_ago(hours=2),
        ),
        Notification(
            id=uuid4(),
            user_id=agent1_user.id,
            type="sla_warning",
            priority="high",
            title="SLA breach warning",
            body="Ticket 'Cannot update credit card on file' is approaching its SLA deadline. 4 hours remaining.",
            link_url="/tickets",
            is_read=False,
        ),
        Notification(
            id=uuid4(),
            user_id=agent1_user.id,
            type="new_message",
            priority="normal",
            title="New message from Alex Rivera",
            body="Alex Rivera sent a new message in the 'Payment method issue' conversation.",
            link_url="/conversations",
            is_read=False,
        ),
        Notification(
            id=uuid4(),
            user_id=agent2_user.id,
            type="ticket_assigned",
            priority="normal",
            title="New ticket assigned to you",
            body="Ticket 'Cannot log in after password reset' from Sam Patel has been assigned to you.",
            link_url="/tickets",
            is_read=True,
            read_at=_ago(hours=1),
        ),
        Notification(
            id=uuid4(),
            user_id=agent2_user.id,
            type="system",
            priority="low",
            title="Weekly performance summary",
            body="Your weekly summary is ready. You resolved 12 tickets with an average CSAT of 4.6/5.",
            link_url="/analytics",
            is_read=False,
        ),
    ]


def _build_roles() -> list[RoleModel]:
    return [
        RoleModel(id=uuid4(), name="admin", description="Full platform access. Can manage users, configuration, billing, and all system settings.", is_system=True),
        RoleModel(id=uuid4(), name="supervisor", description="Team management, analytics, ticket reassignment, and escalation handling.", is_system=True),
        RoleModel(id=uuid4(), name="agent", description="Handle conversations, manage assigned tickets, and use AI copilot features.", is_system=True),
        RoleModel(id=uuid4(), name="customer", description="Submit tickets, participate in conversations, and view own ticket history.", is_system=True),
    ]


def _build_admin_config() -> AdminConfig:
    return AdminConfig(
        id=uuid4(),
        max_concurrent_per_agent=5,
        auto_assign_enabled=True,
        business_hours_enabled=True,
        business_hours={
            "timezone": "America/New_York",
            "schedule": {
                "monday": {"start": "09:00", "end": "18:00"},
                "tuesday": {"start": "09:00", "end": "18:00"},
                "wednesday": {"start": "09:00", "end": "18:00"},
                "thursday": {"start": "09:00", "end": "18:00"},
                "friday": {"start": "09:00", "end": "17:00"},
                "saturday": None,
                "sunday": None,
            },
        },
        default_language="en",
        supported_languages=["en", "es", "fr", "de", "pt"],
    )


def _build_integrations() -> list[Integration]:
    return [
        Integration(
            id=uuid4(),
            provider="slack",
            name="Slack Workspace",
            status="connected",
            config={
                "workspace_name": "Copilot Support",
                "bot_channel": "#support-alerts",
                "escalation_channel": "#escalations",
                "notification_types": ["sla_breach", "escalation", "new_ticket"],
            },
            last_sync_at=_ago(minutes=5),
        ),
        Integration(
            id=uuid4(),
            provider="salesforce",
            name="Salesforce CRM",
            status="disconnected",
            config={
                "instance_url": "https://acme.my.salesforce.com",
                "sync_contacts": True,
                "sync_cases": True,
            },
            error_message="OAuth refresh token expired. Please re-authenticate in Admin > Integrations.",
        ),
        Integration(
            id=uuid4(),
            provider="zendesk",
            name="Zendesk Help Desk",
            status="connected",
            config={
                "subdomain": "copilot-support",
                "sync_tickets": True,
                "sync_direction": "bidirectional",
                "field_mapping": {
                    "status": {"open": "new", "in_progress": "open", "resolved": "solved", "closed": "closed"},
                },
            },
            last_sync_at=_ago(hours=1),
        ),
    ]


# ---------------------------------------------------------------------------
# Main seed logic
# ---------------------------------------------------------------------------

async def main() -> None:
    print("Connecting to database...")
    async with async_session() as session:
        # Check if data already exists
        result = await session.execute(select(User).limit(1))
        if result.scalars().first() is not None:
            print("Database already contains data. Skipping seed.")
            print("To re-seed, truncate the tables first.")
            return

        password_hash = hash_password("password123")

        # 1. Users
        print("Seeding users...")
        users = _build_users(password_hash)
        session.add_all(users)
        await session.flush()
        admin_user, supervisor_user, agent1_user, agent2_user, customer_user = users

        # 2. Teams (before agents, since agents reference teams)
        print("Seeding teams...")
        teams = _build_teams()
        session.add_all(teams)
        await session.flush()

        # 3. Agents
        print("Seeding agents...")
        agents = _build_agents(supervisor_user, agent1_user, agent2_user, teams[0], teams[1])
        session.add_all(agents)
        await session.flush()

        # 4. Customers
        print("Seeding customers...")
        customers = _build_customers(customer_user)
        session.add_all(customers)
        await session.flush()

        # 5. Ticket categories
        print("Seeding ticket categories...")
        ticket_categories = _build_ticket_categories()
        session.add_all(ticket_categories)
        await session.flush()

        # 6. SLA policies
        print("Seeding SLA policies...")
        sla_policies = _build_sla_policies()
        session.add_all(sla_policies)
        await session.flush()

        # 7. Conversations
        print("Seeding conversations...")
        conversations = _build_conversations(customers, agents)
        session.add_all(conversations)
        await session.flush()

        # 8. Tickets
        print("Seeding tickets...")
        tickets = _build_tickets(customers, agents, ticket_categories, sla_policies, teams, conversations)
        session.add_all(tickets)
        await session.flush()

        # 9. Messages
        print("Seeding messages...")
        messages = _build_messages(conversations, customers, agents)
        session.add_all(messages)
        await session.flush()

        # 10. Knowledge base categories
        print("Seeding knowledge base categories...")
        kb_categories = _build_kb_categories()
        session.add_all(kb_categories)
        await session.flush()

        # 11. Articles
        print("Seeding articles...")
        articles = _build_articles(kb_categories, admin_user)
        session.add_all(articles)
        await session.flush()

        # 12. Notifications
        print("Seeding notifications...")
        notifications = _build_notifications(agent1_user, agent2_user)
        session.add_all(notifications)
        await session.flush()

        # 13. Roles
        print("Seeding roles...")
        roles = _build_roles()
        session.add_all(roles)
        await session.flush()

        # 14. Admin config
        print("Seeding admin configuration...")
        admin_config = _build_admin_config()
        session.add(admin_config)
        await session.flush()

        # 15. Integrations
        print("Seeding integrations...")
        integrations = _build_integrations()
        session.add_all(integrations)
        await session.flush()

        # Commit everything
        await session.commit()

    await engine.dispose()

    print()
    print("Seed complete. Summary:")
    print("  Users .............. 5")
    print("  Customers .......... 5")
    print("  Teams .............. 2")
    print("  Agents ............. 3")
    print("  Ticket Categories .. 5")
    print("  SLA Policies ....... 2")
    print("  Conversations ...... 5")
    print("  Tickets ............ 10")
    print("  Messages ........... 19")
    print("  KB Categories ...... 3")
    print("  Articles ........... 6")
    print("  Notifications ...... 5")
    print("  Roles .............. 4")
    print("  Admin Config ....... 1")
    print("  Integrations ....... 3")
    print()
    print("Default credentials: any email above with password 'password123'")


if __name__ == "__main__":
    asyncio.run(main())
