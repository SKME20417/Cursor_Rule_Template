import { NextRequest, NextResponse } from "next/server";

export async function POST(request: NextRequest) {
  const formData = await request.formData();
  const file = formData.get("file") as File | null;

  if (!file) {
    return NextResponse.json({ error: "No file provided" }, { status: 400 });
  }

  const maxSize = 10 * 1024 * 1024; // 10MB
  if (file.size > maxSize) {
    return NextResponse.json({ error: "File too large" }, { status: 413 });
  }

  // Mock - in production, upload to S3
  const key = `uploads/${Date.now()}-${file.name}`;
  return NextResponse.json({
    url: `https://cdn.example.com/${key}`,
    key,
    size: file.size,
    name: file.name,
    type: file.type,
  });
}
