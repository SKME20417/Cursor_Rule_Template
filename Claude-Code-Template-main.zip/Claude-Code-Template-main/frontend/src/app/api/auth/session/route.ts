import { NextRequest, NextResponse } from "next/server";

export async function GET(request: NextRequest) {
  const token = request.cookies.get("auth-token")?.value;

  if (!token) {
    return NextResponse.json({ authenticated: false }, { status: 401 });
  }

  try {
    const payload = JSON.parse(Buffer.from(token, "base64").toString());
    if (payload.exp < Date.now()) {
      return NextResponse.json({ authenticated: false, error: "Token expired" }, { status: 401 });
    }
    return NextResponse.json({
      authenticated: true,
      user: { id: "usr_1", email: payload.email, name: "Demo User", role: payload.role, avatar: null },
    });
  } catch {
    return NextResponse.json({ authenticated: false }, { status: 401 });
  }
}
