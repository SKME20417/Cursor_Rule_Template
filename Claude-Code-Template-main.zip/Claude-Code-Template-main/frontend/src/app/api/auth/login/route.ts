import { NextRequest, NextResponse } from "next/server";

export async function POST(request: NextRequest) {
  const body = await request.json();
  const { email, password } = body;

  // Mock auth - in production, proxy to backend
  if (!email || !password) {
    return NextResponse.json({ error: "Email and password required" }, { status: 400 });
  }

  // Mock token generation
  const mockToken = Buffer.from(JSON.stringify({ email, role: "admin", exp: Date.now() + 86400000 })).toString("base64");

  const response = NextResponse.json({
    token: mockToken,
    user: { id: "usr_1", email, name: "Demo User", role: "admin", avatar: null },
  });

  response.cookies.set("auth-token", mockToken, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    maxAge: 86400,
    path: "/",
  });

  return response;
}
