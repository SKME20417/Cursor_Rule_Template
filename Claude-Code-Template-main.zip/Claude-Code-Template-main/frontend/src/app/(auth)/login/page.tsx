"use client";

import React, { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useAuth } from "@/providers/auth-provider";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Mail, Lock } from "lucide-react";

export default function LoginPage() {
  const router = useRouter();
  const { login, isLoading } = useAuth();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);

  const isValid = email.trim().length > 0 && password.length >= 8;

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);

    if (!isValid) {
      setError("Please enter a valid email and password (min 8 characters).");
      return;
    }

    try {
      await login({ email, password });
      // Read the user from localStorage (just set by login)
      const stored = localStorage.getItem("auth_session");
      const role = stored ? (JSON.parse(stored) as { role?: string }).role : null;
      const home =
        role === "admin" ? "/admin" : role === "agent" ? "/agent" : "/customer";
      router.push(home);
    } catch {
      setError("Invalid email or password. Please try again.");
    }
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-linkedin-gray-05 px-4">
      <div className="w-full max-w-[400px]">
        {/* Logo */}
        <div className="mb-8 text-center">
          <h1 className="text-3xl font-bold text-linkedin-blue">AI Support Copilot</h1>
          <p className="mt-2 text-sm text-linkedin-gray-60">
            Sign in to manage your customer support
          </p>
        </div>

        <Card padding="lg">
          <form onSubmit={handleSubmit} className="flex flex-col gap-5">
            {error && (
              <div className="rounded-lg bg-red-50 px-4 py-3 text-sm text-linkedin-red" role="alert">
                {error}
              </div>
            )}

            <Input
              label="Email"
              type="email"
              placeholder="you@company.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              iconLeft={<Mail className="h-4 w-4" />}
              autoComplete="email"
              required
            />

            <Input
              label="Password"
              type="password"
              placeholder="Enter your password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              iconLeft={<Lock className="h-4 w-4" />}
              autoComplete="current-password"
              required
            />

            <div className="flex justify-end">
              <Link
                href="/forgot-password"
                className="text-sm font-medium text-linkedin-blue hover:underline"
              >
                Forgot password?
              </Link>
            </div>

            <Button
              type="submit"
              loading={isLoading}
              disabled={!isValid}
              className="w-full rounded-full"
              size="lg"
            >
              Sign in
            </Button>
          </form>

          {/* Divider */}
          <div className="my-6 flex items-center gap-3">
            <div className="h-px flex-1 bg-linkedin-gray-20" />
            <span className="text-xs text-linkedin-gray-50">or</span>
            <div className="h-px flex-1 bg-linkedin-gray-20" />
          </div>

          {/* Social login */}
          <div className="flex flex-col gap-3">
            <button
              type="button"
              className="flex w-full items-center justify-center gap-2 rounded-full border border-linkedin-gray-30 bg-linkedin-white px-4 py-2.5 text-sm font-medium text-linkedin-gray-90 transition-colors hover:bg-linkedin-gray-05"
              onClick={() => {
                /* Mock Google SSO */
              }}
            >
              <svg className="h-5 w-5" viewBox="0 0 24 24" aria-hidden="true">
                <path
                  d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92a5.06 5.06 0 01-2.2 3.32v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.1z"
                  fill="#4285F4"
                />
                <path
                  d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                  fill="#34A853"
                />
                <path
                  d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"
                  fill="#FBBC05"
                />
                <path
                  d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
                  fill="#EA4335"
                />
              </svg>
              Sign in with Google
            </button>

            <button
              type="button"
              className="flex w-full items-center justify-center gap-2 rounded-full border border-linkedin-gray-30 bg-linkedin-white px-4 py-2.5 text-sm font-medium text-linkedin-gray-90 transition-colors hover:bg-linkedin-gray-05"
              onClick={() => {
                /* Mock Microsoft SSO */
              }}
            >
              <svg className="h-5 w-5" viewBox="0 0 24 24" aria-hidden="true">
                <path d="M11.4 2H2v9.4h9.4V2z" fill="#F25022" />
                <path d="M22 2h-9.4v9.4H22V2z" fill="#7FBA00" />
                <path d="M11.4 12.6H2V22h9.4v-9.4z" fill="#00A4EF" />
                <path d="M22 12.6h-9.4V22H22v-9.4z" fill="#FFB900" />
              </svg>
              Sign in with Microsoft
            </button>
          </div>
        </Card>

        <p className="mt-6 text-center text-sm text-linkedin-gray-60">
          Don&apos;t have an account?{" "}
          <Link href="/register" className="font-semibold text-linkedin-blue hover:underline">
            Register
          </Link>
        </p>
      </div>
    </div>
  );
}
