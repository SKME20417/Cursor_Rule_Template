import { cn } from "@/lib/utils/cn";

export default function AuthLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-linkedin-blue via-linkedin-blue-hover to-linkedin-blue px-4 py-12">
      <div className="w-full max-w-md">
        {/* Logo */}
        <div className="mb-8 flex flex-col items-center">
          <div className="h-12 w-12 rounded-lg bg-linkedin-white flex items-center justify-center shadow-card">
            <span className="text-lg font-bold text-linkedin-blue">AI</span>
          </div>
          <h1 className="mt-3 text-xl font-semibold text-white">
            AI Support Copilot
          </h1>
        </div>

        {/* Card */}
        <div className="rounded-card bg-linkedin-white shadow-modal p-8">
          {children}
        </div>
      </div>
    </div>
  );
}
