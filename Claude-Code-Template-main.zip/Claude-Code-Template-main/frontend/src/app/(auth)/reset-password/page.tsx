"use client";

import React, { useMemo, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Lock, ArrowLeft } from "lucide-react";
import { cn } from "@/lib/utils/cn";

type PasswordStrength = "weak" | "fair" | "good" | "strong";

function evaluateStrength(password: string): PasswordStrength {
  let score = 0;
  if (password.length >= 8) score++;
  if (password.length >= 12) score++;
  if (/[A-Z]/.test(password) && /[a-z]/.test(password)) score++;
  if (/\d/.test(password)) score++;
  if (/[^A-Za-z0-9]/.test(password)) score++;

  if (score <= 1) return "weak";
  if (score <= 2) return "fair";
  if (score <= 3) return "good";
  return "strong";
}

const strengthConfig: Record<PasswordStrength, { color: string; width: string; label: string }> = {
  weak: { color: "bg-linkedin-red", width: "w-1/4", label: "Weak" },
  fair: { color: "bg-yellow-500", width: "w-2/4", label: "Fair" },
  good: { color: "bg-blue-500", width: "w-3/4", label: "Good" },
  strong: { color: "bg-green-500", width: "w-full", label: "Strong" },
};

export default function ResetPasswordPage() {
  const router = useRouter();

  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const strength = useMemo(() => evaluateStrength(password), [password]);
  const passwordsMatch = password === confirmPassword;
  const isValid = password.length >= 8 && passwordsMatch;
  const config = strengthConfig[strength];

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);

    if (!passwordsMatch) {
      setError("Passwords do not match.");
      return;
    }
    if (password.length < 8) {
      setError("Password must be at least 8 characters.");
      return;
    }

    setIsSubmitting(true);
    try {
      // Mock API call
      await new Promise((resolve) => setTimeout(resolve, 800));
      router.push("/login");
    } catch {
      setError("Failed to reset password. Please try again.");
    } finally {
      setIsSubmitting(false);
    }
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-linkedin-gray-05 px-4">
      <div className="w-full max-w-[400px]">
        {/* Logo */}
        <div className="mb-8 text-center">
          <h1 className="text-3xl font-bold text-linkedin-blue">AI Support Copilot</h1>
          <p className="mt-2 text-sm text-linkedin-gray-60">Create a new password</p>
        </div>

        <Card padding="lg">
          <form onSubmit={handleSubmit} className="flex flex-col gap-5">
            {error && (
              <div className="rounded-lg bg-red-50 px-4 py-3 text-sm text-linkedin-red" role="alert">
                {error}
              </div>
            )}

            <div className="flex flex-col gap-2">
              <Input
                label="New password"
                type="password"
                placeholder="Min 8 characters"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                iconLeft={<Lock className="h-4 w-4" />}
                autoComplete="new-password"
                required
              />

              {/* Password strength indicator */}
              {password.length > 0 && (
                <div className="flex flex-col gap-1">
                  <div className="h-1.5 w-full rounded-full bg-linkedin-gray-20">
                    <div
                      className={cn("h-1.5 rounded-full transition-all", config.color, config.width)}
                    />
                  </div>
                  <span className="text-xs text-linkedin-gray-50">
                    Password strength: {config.label}
                  </span>
                </div>
              )}
            </div>

            <Input
              label="Confirm password"
              type="password"
              placeholder="Re-enter password"
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              iconLeft={<Lock className="h-4 w-4" />}
              autoComplete="new-password"
              error={
                confirmPassword.length > 0 && !passwordsMatch
                  ? "Passwords do not match"
                  : undefined
              }
              required
            />

            <Button
              type="submit"
              loading={isSubmitting}
              disabled={!isValid}
              className="w-full rounded-full"
              size="lg"
            >
              Reset password
            </Button>

            <Link
              href="/login"
              className="inline-flex items-center justify-center gap-1 text-sm font-medium text-linkedin-blue hover:underline"
            >
              <ArrowLeft className="h-4 w-4" />
              Back to login
            </Link>
          </form>
        </Card>
      </div>
    </div>
  );
}
