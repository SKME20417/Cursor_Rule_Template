"use client";

import React, { useState } from "react";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Mail, ArrowLeft, CheckCircle } from "lucide-react";

export default function ForgotPasswordPage() {
  const [email, setEmail] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const isValid = email.trim().length > 0 && email.includes("@");

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);

    if (!isValid) {
      setError("Please enter a valid email address.");
      return;
    }

    setIsSubmitting(true);
    try {
      // Mock API call
      await new Promise((resolve) => setTimeout(resolve, 800));
      setIsSuccess(true);
    } catch {
      setError("Something went wrong. Please try again.");
    } finally {
      setIsSubmitting(false);
    }
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-linkedin-gray-05 px-4">
      <div className="w-full max-w-[400px]">
        {/* Logo */}
        <div className="mb-8 text-center">
          <h1 className="text-3xl font-bold text-linkedin-blue">AI Support Copilot</h1>
          <p className="mt-2 text-sm text-linkedin-gray-60">Reset your password</p>
        </div>

        <Card padding="lg">
          {isSuccess ? (
            <div className="flex flex-col items-center gap-4 py-4 text-center">
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-green-100">
                <CheckCircle className="h-6 w-6 text-green-600" />
              </div>
              <h2 className="text-lg font-semibold text-linkedin-gray-90">Check your email</h2>
              <p className="text-sm text-linkedin-gray-60">
                We&apos;ve sent a password reset link to{" "}
                <span className="font-medium text-linkedin-gray-90">{email}</span>.
                Please check your inbox and follow the instructions.
              </p>
              <Link
                href="/login"
                className="mt-2 inline-flex items-center gap-1 text-sm font-medium text-linkedin-blue hover:underline"
              >
                <ArrowLeft className="h-4 w-4" />
                Back to login
              </Link>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="flex flex-col gap-5">
              <p className="text-sm text-linkedin-gray-60">
                Enter the email address associated with your account and we&apos;ll send you a link to
                reset your password.
              </p>

              {error && (
                <div className="rounded-lg bg-red-50 px-4 py-3 text-sm text-linkedin-red" role="alert">
                  {error}
                </div>
              )}

              <Input
                label="Email"
                type="email"
                placeholder="you@company.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                iconLeft={<Mail className="h-4 w-4" />}
                autoComplete="email"
                required
              />

              <Button
                type="submit"
                loading={isSubmitting}
                disabled={!isValid}
                className="w-full rounded-full"
                size="lg"
              >
                Send reset link
              </Button>

              <Link
                href="/login"
                className="inline-flex items-center justify-center gap-1 text-sm font-medium text-linkedin-blue hover:underline"
              >
                <ArrowLeft className="h-4 w-4" />
                Back to login
              </Link>
            </form>
          )}
        </Card>
      </div>
    </div>
  );
}
