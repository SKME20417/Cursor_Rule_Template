"use client";

import React, { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useAuth } from "@/providers/auth-provider";
import { Role } from "@/types/auth.types";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Card } from "@/components/ui/card";
import { User, Mail, Lock, Building2 } from "lucide-react";

const ROLE_OPTIONS = [
  { value: Role.CUSTOMER, label: "Customer" },
  { value: Role.AGENT, label: "Agent" },
];

export default function RegisterPage() {
  const router = useRouter();
  const { register, isLoading } = useAuth();

  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [companyName, setCompanyName] = useState("");
  const [role, setRole] = useState<Role>(Role.CUSTOMER);
  const [termsAccepted, setTermsAccepted] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const passwordsMatch = password === confirmPassword;
  const isValid =
    firstName.trim().length > 0 &&
    lastName.trim().length > 0 &&
    email.trim().length > 0 &&
    password.length >= 8 &&
    passwordsMatch &&
    termsAccepted;

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);

    if (!passwordsMatch) {
      setError("Passwords do not match.");
      return;
    }
    if (password.length < 8) {
      setError("Password must be at least 8 characters.");
      return;
    }
    if (!termsAccepted) {
      setError("You must accept the terms and conditions.");
      return;
    }

    try {
      await register({ firstName, lastName, email, password, role });
      // Read role from stored user (just set by register)
      const stored = localStorage.getItem("auth_session");
      const userRole = stored ? (JSON.parse(stored) as { role?: string }).role : null;
      const home =
        userRole === "admin" ? "/admin" : userRole === "agent" ? "/agent" : "/customer";
      router.push(home);
    } catch {
      setError("Registration failed. Please try again.");
    }
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-linkedin-gray-05 px-4 py-8">
      <div className="w-full max-w-[440px]">
        {/* Logo */}
        <div className="mb-8 text-center">
          <h1 className="text-3xl font-bold text-linkedin-blue">AI Support Copilot</h1>
          <p className="mt-2 text-sm text-linkedin-gray-60">
            Create your account to get started
          </p>
        </div>

        <Card padding="lg">
          <form onSubmit={handleSubmit} className="flex flex-col gap-4">
            {error && (
              <div className="rounded-lg bg-red-50 px-4 py-3 text-sm text-linkedin-red" role="alert">
                {error}
              </div>
            )}

            <div className="grid grid-cols-2 gap-3">
              <Input
                label="First name"
                placeholder="Jane"
                value={firstName}
                onChange={(e) => setFirstName(e.target.value)}
                iconLeft={<User className="h-4 w-4" />}
                required
              />
              <Input
                label="Last name"
                placeholder="Doe"
                value={lastName}
                onChange={(e) => setLastName(e.target.value)}
                required
              />
            </div>

            <Input
              label="Email"
              type="email"
              placeholder="you@company.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              iconLeft={<Mail className="h-4 w-4" />}
              autoComplete="email"
              required
            />

            <Input
              label="Password"
              type="password"
              placeholder="Min 8 characters"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              iconLeft={<Lock className="h-4 w-4" />}
              autoComplete="new-password"
              required
            />

            <Input
              label="Confirm password"
              type="password"
              placeholder="Re-enter password"
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              iconLeft={<Lock className="h-4 w-4" />}
              autoComplete="new-password"
              error={confirmPassword.length > 0 && !passwordsMatch ? "Passwords do not match" : undefined}
              required
            />

            <Input
              label="Company name (optional)"
              placeholder="Acme Inc."
              value={companyName}
              onChange={(e) => setCompanyName(e.target.value)}
              iconLeft={<Building2 className="h-4 w-4" />}
            />

            <Select
              label="Role"
              options={ROLE_OPTIONS}
              value={role}
              onChange={(e) => setRole(e.target.value as Role)}
            />

            <Checkbox
              label="I agree to the Terms of Service and Privacy Policy"
              checked={termsAccepted}
              onChange={(e) => setTermsAccepted(e.target.checked)}
            />

            <Button
              type="submit"
              loading={isLoading}
              disabled={!isValid}
              className="w-full rounded-full"
              size="lg"
            >
              Create account
            </Button>
          </form>
        </Card>

        <p className="mt-6 text-center text-sm text-linkedin-gray-60">
          Already have an account?{" "}
          <Link href="/login" className="font-semibold text-linkedin-blue hover:underline">
            Sign in
          </Link>
        </p>
      </div>
    </div>
  );
}
