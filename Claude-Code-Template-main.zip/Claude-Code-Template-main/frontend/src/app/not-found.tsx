import Link from "next/link";

export default function NotFound() {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-linkedin-gray-05 px-4 text-center">
      <div className="rounded-lg border border-linkedin-gray-20 bg-linkedin-white p-10 shadow-card max-w-md">
        <p className="text-7xl font-bold text-linkedin-gray-30">404</p>

        <h1 className="mt-4 text-xl font-bold text-linkedin-gray-90">
          Page not found
        </h1>
        <p className="mt-2 text-sm text-linkedin-gray-50">
          The page you&apos;re looking for doesn&apos;t exist or has been moved.
        </p>

        <Link
          href="/"
          className="mt-6 inline-flex items-center justify-center rounded-full bg-linkedin-blue px-6 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-linkedin-blue-hover"
        >
          Go back home
        </Link>
      </div>
    </div>
  );
}
