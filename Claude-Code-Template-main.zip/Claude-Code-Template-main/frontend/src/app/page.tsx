"use client";

import React from "react";
import Link from "next/link";
import { cn } from "@/lib/utils/cn";
import {
  MessageSquare,
  Bot,
  Phone,
  Video,
  Brain,
  Ticket,
  Sparkles,
  Headphones,
  BarChart3,
  GraduationCap,
  BookOpen,
  Zap,
  Users,
  Shield,
  Plug,
  Settings2,
  Globe,
  LayoutDashboard,
  Activity,
  Code2,
  ArrowRight,
  CheckCircle2,
  Star,
  ChevronRight,
  Play,
} from "lucide-react";

/* ------------------------------------------------------------------ */
/* Data                                                                */
/* ------------------------------------------------------------------ */

const FEATURES = [
  {
    icon: MessageSquare,
    title: "Omni-Channel Support",
    description:
      "Unified inbox across live chat, email, WhatsApp, SMS, Slack, and social media. Never miss a customer message.",
    color: "bg-blue-50 text-blue-600",
  },
  {
    icon: Bot,
    title: "AI Chatbot & RAG",
    description:
      "Intelligent chatbot powered by retrieval-augmented generation. Answers from your knowledge base instantly.",
    color: "bg-purple-50 text-purple-600",
  },
  {
    icon: Phone,
    title: "Voice AI Agent",
    description:
      "AI-powered voice support with real-time transcription, sentiment analysis, and smart call routing.",
    color: "bg-green-50 text-green-600",
  },
  {
    icon: Video,
    title: "Video Support",
    description:
      "Face-to-face video calls with screen sharing, co-browsing, and session recording for complex issues.",
    color: "bg-pink-50 text-pink-600",
  },
  {
    icon: Brain,
    title: "NLP Intelligence",
    description:
      "Intent detection, sentiment analysis, urgency scoring, and automatic language detection on every message.",
    color: "bg-indigo-50 text-indigo-600",
  },
  {
    icon: Ticket,
    title: "Smart Ticketing",
    description:
      "AI-powered ticket routing, SLA tracking, priority scoring, and automated escalation workflows.",
    color: "bg-orange-50 text-orange-600",
  },
  {
    icon: Sparkles,
    title: "Agent Copilot",
    description:
      "Real-time AI suggestions, response drafts, knowledge lookups, and next-best-action recommendations.",
    color: "bg-yellow-50 text-yellow-600",
  },
  {
    icon: Headphones,
    title: "Call Monitoring",
    description:
      "Live call monitoring, whisper coaching, barge-in capabilities, and quality assurance scoring.",
    color: "bg-teal-50 text-teal-600",
  },
  {
    icon: BarChart3,
    title: "Analytics & Reporting",
    description:
      "Real-time dashboards, CSAT tracking, agent performance metrics, and custom report builder.",
    color: "bg-cyan-50 text-cyan-600",
  },
  {
    icon: GraduationCap,
    title: "Learning System",
    description:
      "AI-driven training recommendations, knowledge gap analysis, and continuous agent improvement.",
    color: "bg-amber-50 text-amber-600",
  },
  {
    icon: BookOpen,
    title: "Knowledge Base",
    description:
      "Self-service knowledge base with AI-powered search, article suggestions, and content analytics.",
    color: "bg-emerald-50 text-emerald-600",
  },
  {
    icon: Zap,
    title: "Real-Time Infrastructure",
    description:
      "WebSocket-powered live updates, presence tracking, typing indicators, and instant notifications.",
    color: "bg-red-50 text-red-600",
  },
  {
    icon: Users,
    title: "Customer 360",
    description:
      "Complete customer context with interaction history, preferences, and predictive insights.",
    color: "bg-violet-50 text-violet-600",
  },
  {
    icon: Shield,
    title: "Security & RBAC",
    description:
      "Role-based access control, audit logging, data encryption, GDPR compliance, and API key management.",
    color: "bg-slate-50 text-slate-600",
  },
  {
    icon: Plug,
    title: "Integrations",
    description:
      "Connect with Salesforce, HubSpot, Zendesk, Jira, Slack, and 50+ other tools out of the box.",
    color: "bg-sky-50 text-sky-600",
  },
  {
    icon: Settings2,
    title: "Automation Engine",
    description:
      "Visual workflow builder for auto-replies, escalation rules, ticket routing, and custom triggers.",
    color: "bg-rose-50 text-rose-600",
  },
  {
    icon: Globe,
    title: "Multi-Language",
    description:
      "Support customers in 50+ languages with real-time translation and localized knowledge bases.",
    color: "bg-lime-50 text-lime-600",
  },
  {
    icon: LayoutDashboard,
    title: "Admin Panel",
    description:
      "Full-featured admin dashboard for team management, configuration, branding, and system settings.",
    color: "bg-fuchsia-50 text-fuchsia-600",
  },
  {
    icon: Activity,
    title: "Observability",
    description:
      "Service health monitoring, queue depths, alert management, and infrastructure observability.",
    color: "bg-stone-50 text-stone-600",
  },
  {
    icon: Code2,
    title: "Developer APIs",
    description:
      "RESTful APIs, webhook handlers, sandbox environment, and comprehensive API documentation.",
    color: "bg-neutral-100 text-neutral-600",
  },
];

const STATS = [
  { value: "95%", label: "Customer Satisfaction" },
  { value: "60%", label: "Faster Resolution" },
  { value: "3x", label: "Agent Productivity" },
  { value: "24/7", label: "AI Availability" },
];

const TESTIMONIALS = [
  {
    name: "Sarah Chen",
    role: "VP of Support, TechScale",
    text: "AI Support Copilot reduced our average response time from 4 hours to under 2 minutes. The AI suggestions are incredibly accurate.",
    rating: 5,
  },
  {
    name: "Marcus Johnson",
    role: "Head of CX, RetailFlow",
    text: "The omni-channel inbox and smart routing transformed how our team works. We handle 3x the volume with the same team size.",
    rating: 5,
  },
  {
    name: "Priya Patel",
    role: "CTO, FinServe Pro",
    text: "Security and compliance features gave us confidence to deploy at scale. The RBAC and audit logging are enterprise-grade.",
    rating: 5,
  },
];

/* ------------------------------------------------------------------ */
/* Component                                                           */
/* ------------------------------------------------------------------ */

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-linkedin-white">
      {/* ── Navbar ─────────────────────────────────────────────── */}
      <nav className="sticky top-0 z-50 border-b border-linkedin-gray-20 bg-linkedin-white/95 backdrop-blur-sm">
        <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
          <div className="flex items-center gap-2">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-linkedin-blue">
              <Sparkles className="h-5 w-5 text-white" />
            </div>
            <span className="text-xl font-bold text-linkedin-gray-90">
              AI Support Copilot
            </span>
          </div>

          <div className="hidden items-center gap-8 md:flex">
            <a href="#features" className="text-sm font-medium text-linkedin-gray-70 transition-colors hover:text-linkedin-blue">
              Features
            </a>
            <a href="#how-it-works" className="text-sm font-medium text-linkedin-gray-70 transition-colors hover:text-linkedin-blue">
              How It Works
            </a>
            <a href="#testimonials" className="text-sm font-medium text-linkedin-gray-70 transition-colors hover:text-linkedin-blue">
              Testimonials
            </a>
          </div>

          <div className="flex items-center gap-3">
            <Link
              href="/login"
              className="rounded-full px-5 py-2 text-sm font-semibold text-linkedin-blue transition-colors hover:bg-linkedin-blue-bg"
            >
              Sign in
            </Link>
            <Link
              href="/register"
              className="rounded-full bg-linkedin-blue px-5 py-2 text-sm font-semibold text-white transition-colors hover:bg-linkedin-blue-hover"
            >
              Get Started
            </Link>
          </div>
        </div>
      </nav>

      {/* ── Hero ───────────────────────────────────────────────── */}
      <section className="relative overflow-hidden bg-gradient-to-br from-linkedin-blue via-[#084e96] to-[#063970] py-20 sm:py-28 lg:py-36">
        {/* Background pattern */}
        <div className="absolute inset-0 opacity-10">
          <div className="absolute left-1/4 top-1/4 h-96 w-96 rounded-full bg-white blur-3xl" />
          <div className="absolute bottom-1/4 right-1/4 h-64 w-64 rounded-full bg-white blur-3xl" />
        </div>

        <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="mx-auto max-w-3xl text-center">
            <div className="mb-6 inline-flex items-center gap-2 rounded-full bg-white/15 px-4 py-1.5 text-sm font-medium text-white/90 backdrop-blur-sm">
              <Zap className="h-4 w-4" />
              Powered by Advanced AI
            </div>

            <h1 className="text-4xl font-bold tracking-tight text-white sm:text-5xl lg:text-6xl">
              Customer Support,{" "}
              <span className="text-linkedin-blue-light">Supercharged</span> by
              AI
            </h1>

            <p className="mx-auto mt-6 max-w-2xl text-lg text-white/80 sm:text-xl">
              The all-in-one AI platform that empowers your support team with
              intelligent routing, real-time copilot assistance, and omni-channel
              engagement. Resolve issues faster, delight customers more.
            </p>

            <div className="mt-10 flex flex-col items-center justify-center gap-4 sm:flex-row">
              <Link
                href="/register"
                className="group inline-flex items-center gap-2 rounded-full bg-white px-8 py-3.5 text-base font-semibold text-linkedin-blue shadow-lg transition-all hover:shadow-xl hover:scale-[1.02]"
              >
                Start Free Trial
                <ArrowRight className="h-5 w-5 transition-transform group-hover:translate-x-0.5" />
              </Link>
              <button
                type="button"
                className="inline-flex items-center gap-2 rounded-full border border-white/30 px-8 py-3.5 text-base font-semibold text-white transition-colors hover:bg-white/10"
              >
                <Play className="h-5 w-5" />
                Watch Demo
              </button>
            </div>
          </div>

          {/* Stats row */}
          <div className="mx-auto mt-16 grid max-w-3xl grid-cols-2 gap-6 sm:grid-cols-4">
            {STATS.map((stat) => (
              <div key={stat.label} className="text-center">
                <div className="text-3xl font-bold text-white sm:text-4xl">
                  {stat.value}
                </div>
                <div className="mt-1 text-sm text-white/70">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Trusted By ─────────────────────────────────────────── */}
      <section className="border-b border-linkedin-gray-20 bg-linkedin-gray-05 py-10">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <p className="text-center text-sm font-medium uppercase tracking-wider text-linkedin-gray-50">
            Trusted by innovative teams worldwide
          </p>
          <div className="mt-6 flex flex-wrap items-center justify-center gap-x-12 gap-y-4">
            {["TechScale", "RetailFlow", "FinServe Pro", "HealthBridge", "EduPlatform", "CloudServe"].map(
              (name) => (
                <span
                  key={name}
                  className="text-lg font-bold text-linkedin-gray-30"
                >
                  {name}
                </span>
              ),
            )}
          </div>
        </div>
      </section>

      {/* ── Features Grid ──────────────────────────────────────── */}
      <section id="features" className="py-20 sm:py-28">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="mx-auto max-w-2xl text-center">
            <h2 className="text-3xl font-bold text-linkedin-gray-90 sm:text-4xl">
              20 Powerful Features, One Platform
            </h2>
            <p className="mt-4 text-lg text-linkedin-gray-60">
              Everything you need to deliver exceptional customer support at
              scale, powered by cutting-edge AI.
            </p>
          </div>

          <div className="mt-16 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {FEATURES.map((feature) => {
              const Icon = feature.icon;
              return (
                <div
                  key={feature.title}
                  className="group rounded-xl border border-linkedin-gray-20 bg-linkedin-white p-5 shadow-card transition-all hover:shadow-card-hover hover:-translate-y-0.5"
                >
                  <div
                    className={cn(
                      "mb-4 inline-flex h-11 w-11 items-center justify-center rounded-lg",
                      feature.color,
                    )}
                  >
                    <Icon className="h-5 w-5" />
                  </div>
                  <h3 className="text-sm font-semibold text-linkedin-gray-90">
                    {feature.title}
                  </h3>
                  <p className="mt-1.5 text-xs leading-relaxed text-linkedin-gray-60">
                    {feature.description}
                  </p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* ── How It Works ───────────────────────────────────────── */}
      <section
        id="how-it-works"
        className="border-y border-linkedin-gray-20 bg-linkedin-gray-05 py-20 sm:py-28"
      >
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="mx-auto max-w-2xl text-center">
            <h2 className="text-3xl font-bold text-linkedin-gray-90 sm:text-4xl">
              How It Works
            </h2>
            <p className="mt-4 text-lg text-linkedin-gray-60">
              Get up and running in minutes, not months.
            </p>
          </div>

          <div className="mx-auto mt-16 grid max-w-5xl gap-8 md:grid-cols-3">
            {[
              {
                step: "01",
                title: "Connect Your Channels",
                description:
                  "Integrate your existing channels — live chat, email, WhatsApp, Slack, and more — in a single unified inbox.",
                icon: Plug,
              },
              {
                step: "02",
                title: "Train Your AI",
                description:
                  "Upload your knowledge base, FAQs, and documentation. The AI learns your products and processes instantly.",
                icon: Brain,
              },
              {
                step: "03",
                title: "Delight Customers",
                description:
                  "Let AI handle routine queries while your team focuses on complex issues with copilot assistance.",
                icon: Sparkles,
              },
            ].map((item) => {
              const Icon = item.icon;
              return (
                <div
                  key={item.step}
                  className="relative rounded-xl border border-linkedin-gray-20 bg-linkedin-white p-8 shadow-card"
                >
                  <div className="absolute -top-4 left-6 flex h-8 w-8 items-center justify-center rounded-full bg-linkedin-blue text-sm font-bold text-white">
                    {item.step}
                  </div>
                  <div className="mt-2 mb-4 flex h-12 w-12 items-center justify-center rounded-lg bg-linkedin-blue-bg">
                    <Icon className="h-6 w-6 text-linkedin-blue" />
                  </div>
                  <h3 className="text-lg font-semibold text-linkedin-gray-90">
                    {item.title}
                  </h3>
                  <p className="mt-2 text-sm text-linkedin-gray-60">
                    {item.description}
                  </p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* ── Dashboard Preview ──────────────────────────────────── */}
      <section className="py-20 sm:py-28">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col items-center gap-12 lg:flex-row">
            <div className="flex-1 space-y-6">
              <h2 className="text-3xl font-bold text-linkedin-gray-90 sm:text-4xl">
                Three Powerful Interfaces, One Platform
              </h2>
              <p className="text-lg text-linkedin-gray-60">
                Purpose-built dashboards for every role in your support
                organization.
              </p>

              <div className="space-y-4">
                {[
                  {
                    title: "Admin Dashboard",
                    href: "/admin",
                    description:
                      "Full control over team, channels, automation, security, analytics, and integrations.",
                    icon: LayoutDashboard,
                    color: "text-linkedin-blue",
                  },
                  {
                    title: "Agent Workspace",
                    href: "/agent",
                    description:
                      "Unified inbox with AI copilot, customer context, knowledge base, and call tools.",
                    icon: Headphones,
                    color: "text-linkedin-green",
                  },
                  {
                    title: "Customer Portal",
                    href: "/customer",
                    description:
                      "Self-service knowledge base, AI chat, ticket tracking, and video support.",
                    icon: Users,
                    color: "text-linkedin-orange",
                  },
                ].map((item) => {
                  const Icon = item.icon;
                  return (
                    <Link
                      key={item.title}
                      href={item.href}
                      className="group flex items-start gap-4 rounded-xl border border-linkedin-gray-20 bg-linkedin-white p-5 shadow-card transition-all hover:shadow-card-hover hover:border-linkedin-blue/30"
                    >
                      <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-linkedin-gray-05">
                        <Icon className={cn("h-5 w-5", item.color)} />
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center gap-2">
                          <h3 className="text-sm font-semibold text-linkedin-gray-90">
                            {item.title}
                          </h3>
                          <ChevronRight className="h-4 w-4 text-linkedin-gray-30 transition-transform group-hover:translate-x-0.5 group-hover:text-linkedin-blue" />
                        </div>
                        <p className="mt-1 text-xs text-linkedin-gray-60">
                          {item.description}
                        </p>
                      </div>
                    </Link>
                  );
                })}
              </div>
            </div>

            {/* Mock dashboard preview */}
            <div className="flex-1">
              <div className="overflow-hidden rounded-2xl border border-linkedin-gray-20 bg-linkedin-gray-05 shadow-xl">
                {/* Title bar */}
                <div className="flex items-center gap-2 border-b border-linkedin-gray-20 bg-linkedin-white px-4 py-3">
                  <div className="flex gap-1.5">
                    <div className="h-3 w-3 rounded-full bg-red-400" />
                    <div className="h-3 w-3 rounded-full bg-yellow-400" />
                    <div className="h-3 w-3 rounded-full bg-green-400" />
                  </div>
                  <div className="ml-4 flex-1 rounded-md bg-linkedin-gray-10 px-3 py-1 text-xs text-linkedin-gray-50">
                    app.aisupportcopilot.com/admin
                  </div>
                </div>
                {/* Mock dashboard content */}
                <div className="p-6">
                  <div className="grid grid-cols-3 gap-3">
                    {[
                      { label: "Open Tickets", value: "247", trend: "-12%" },
                      { label: "Avg Response", value: "1.8m", trend: "-34%" },
                      { label: "CSAT Score", value: "4.8", trend: "+8%" },
                    ].map((stat) => (
                      <div
                        key={stat.label}
                        className="rounded-lg border border-linkedin-gray-20 bg-linkedin-white p-3"
                      >
                        <div className="text-[10px] text-linkedin-gray-50">
                          {stat.label}
                        </div>
                        <div className="mt-1 text-lg font-bold text-linkedin-gray-90">
                          {stat.value}
                        </div>
                        <div className="text-[10px] text-linkedin-green">
                          {stat.trend}
                        </div>
                      </div>
                    ))}
                  </div>
                  {/* Mock chart area */}
                  <div className="mt-4 rounded-lg border border-linkedin-gray-20 bg-linkedin-white p-4">
                    <div className="text-xs font-semibold text-linkedin-gray-70">
                      Ticket Volume — Last 7 Days
                    </div>
                    <div className="mt-3 flex items-end gap-1.5">
                      {[40, 65, 45, 80, 55, 70, 90].map((h, i) => (
                        <div
                          key={i}
                          className="flex-1 rounded-t bg-linkedin-blue/70"
                          style={{ height: `${h}px` }}
                        />
                      ))}
                    </div>
                    <div className="mt-2 flex justify-between text-[9px] text-linkedin-gray-50">
                      <span>Mon</span>
                      <span>Tue</span>
                      <span>Wed</span>
                      <span>Thu</span>
                      <span>Fri</span>
                      <span>Sat</span>
                      <span>Sun</span>
                    </div>
                  </div>
                  {/* Mock recent tickets */}
                  <div className="mt-4 space-y-2">
                    {[
                      { id: "#4521", subject: "Login issue — MFA not working", status: "Open", priority: "High" },
                      { id: "#4520", subject: "Billing discrepancy on invoice", status: "In Progress", priority: "Medium" },
                      { id: "#4519", subject: "API rate limit exceeded", status: "Resolved", priority: "Low" },
                    ].map((ticket) => (
                      <div
                        key={ticket.id}
                        className="flex items-center gap-3 rounded-lg border border-linkedin-gray-20 bg-linkedin-white px-3 py-2"
                      >
                        <span className="text-[10px] font-mono text-linkedin-gray-50">
                          {ticket.id}
                        </span>
                        <span className="flex-1 truncate text-xs text-linkedin-gray-70">
                          {ticket.subject}
                        </span>
                        <span
                          className={cn(
                            "rounded-full px-2 py-0.5 text-[9px] font-medium",
                            ticket.status === "Open" && "bg-blue-50 text-blue-600",
                            ticket.status === "In Progress" && "bg-yellow-50 text-yellow-700",
                            ticket.status === "Resolved" && "bg-green-50 text-green-600",
                          )}
                        >
                          {ticket.status}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ── Testimonials ───────────────────────────────────────── */}
      <section
        id="testimonials"
        className="border-y border-linkedin-gray-20 bg-linkedin-gray-05 py-20 sm:py-28"
      >
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="mx-auto max-w-2xl text-center">
            <h2 className="text-3xl font-bold text-linkedin-gray-90 sm:text-4xl">
              Loved by Support Teams
            </h2>
            <p className="mt-4 text-lg text-linkedin-gray-60">
              See why leading companies trust AI Support Copilot.
            </p>
          </div>

          <div className="mx-auto mt-16 grid max-w-5xl gap-6 md:grid-cols-3">
            {TESTIMONIALS.map((t) => (
              <div
                key={t.name}
                className="rounded-xl border border-linkedin-gray-20 bg-linkedin-white p-6 shadow-card"
              >
                <div className="flex gap-0.5">
                  {Array.from({ length: t.rating }).map((_, i) => (
                    <Star
                      key={i}
                      className="h-4 w-4 fill-yellow-400 text-yellow-400"
                    />
                  ))}
                </div>
                <p className="mt-4 text-sm leading-relaxed text-linkedin-gray-70">
                  &ldquo;{t.text}&rdquo;
                </p>
                <div className="mt-5 flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-full bg-linkedin-blue text-sm font-bold text-white">
                    {t.name.charAt(0)}
                  </div>
                  <div>
                    <div className="text-sm font-semibold text-linkedin-gray-90">
                      {t.name}
                    </div>
                    <div className="text-xs text-linkedin-gray-50">
                      {t.role}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── CTA ────────────────────────────────────────────────── */}
      <section className="bg-gradient-to-br from-linkedin-blue via-[#084e96] to-[#063970] py-20 sm:py-28">
        <div className="mx-auto max-w-3xl px-4 text-center sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-white sm:text-4xl">
            Ready to Transform Your Support?
          </h2>
          <p className="mx-auto mt-4 max-w-xl text-lg text-white/80">
            Join thousands of teams already using AI Support Copilot to deliver
            faster, smarter, and more personalized customer experiences.
          </p>

          <div className="mt-10 flex flex-col items-center justify-center gap-4 sm:flex-row">
            <Link
              href="/register"
              className="group inline-flex items-center gap-2 rounded-full bg-white px-8 py-3.5 text-base font-semibold text-linkedin-blue shadow-lg transition-all hover:shadow-xl hover:scale-[1.02]"
            >
              Start Free Trial
              <ArrowRight className="h-5 w-5 transition-transform group-hover:translate-x-0.5" />
            </Link>
            <Link
              href="/login"
              className="inline-flex items-center gap-2 rounded-full border border-white/30 px-8 py-3.5 text-base font-semibold text-white transition-colors hover:bg-white/10"
            >
              Sign In
            </Link>
          </div>

          <div className="mt-8 flex flex-wrap items-center justify-center gap-6 text-sm text-white/70">
            <span className="inline-flex items-center gap-1.5">
              <CheckCircle2 className="h-4 w-4" />
              No credit card required
            </span>
            <span className="inline-flex items-center gap-1.5">
              <CheckCircle2 className="h-4 w-4" />
              14-day free trial
            </span>
            <span className="inline-flex items-center gap-1.5">
              <CheckCircle2 className="h-4 w-4" />
              Cancel anytime
            </span>
          </div>
        </div>
      </section>

      {/* ── Footer ─────────────────────────────────────────────── */}
      <footer className="border-t border-linkedin-gray-20 bg-linkedin-white py-12">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
            {/* Brand */}
            <div>
              <div className="flex items-center gap-2">
                <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-linkedin-blue">
                  <Sparkles className="h-4 w-4 text-white" />
                </div>
                <span className="text-base font-bold text-linkedin-gray-90">
                  AI Support Copilot
                </span>
              </div>
              <p className="mt-3 text-xs text-linkedin-gray-50">
                AI-powered customer support platform with intelligent routing,
                real-time chat, and agent copilot assistance.
              </p>
            </div>

            {/* Product */}
            <div>
              <h4 className="text-sm font-semibold text-linkedin-gray-90">
                Product
              </h4>
              <ul className="mt-3 space-y-2">
                {["Features", "Pricing", "Integrations", "API Docs", "Changelog"].map(
                  (item) => (
                    <li key={item}>
                      <a
                        href="#"
                        className="text-xs text-linkedin-gray-50 transition-colors hover:text-linkedin-blue"
                      >
                        {item}
                      </a>
                    </li>
                  ),
                )}
              </ul>
            </div>

            {/* Company */}
            <div>
              <h4 className="text-sm font-semibold text-linkedin-gray-90">
                Company
              </h4>
              <ul className="mt-3 space-y-2">
                {["About", "Blog", "Careers", "Press", "Contact"].map(
                  (item) => (
                    <li key={item}>
                      <a
                        href="#"
                        className="text-xs text-linkedin-gray-50 transition-colors hover:text-linkedin-blue"
                      >
                        {item}
                      </a>
                    </li>
                  ),
                )}
              </ul>
            </div>

            {/* Legal */}
            <div>
              <h4 className="text-sm font-semibold text-linkedin-gray-90">
                Legal
              </h4>
              <ul className="mt-3 space-y-2">
                {["Privacy Policy", "Terms of Service", "Security", "GDPR", "SOC 2"].map(
                  (item) => (
                    <li key={item}>
                      <a
                        href="#"
                        className="text-xs text-linkedin-gray-50 transition-colors hover:text-linkedin-blue"
                      >
                        {item}
                      </a>
                    </li>
                  ),
                )}
              </ul>
            </div>
          </div>

          <div className="mt-10 flex flex-col items-center justify-between gap-4 border-t border-linkedin-gray-20 pt-6 sm:flex-row">
            <p className="text-xs text-linkedin-gray-50">
              &copy; 2026 AI Support Copilot. All rights reserved.
            </p>
            <div className="flex items-center gap-4">
              {["Twitter", "LinkedIn", "GitHub"].map((social) => (
                <a
                  key={social}
                  href="#"
                  className="text-xs text-linkedin-gray-50 transition-colors hover:text-linkedin-blue"
                >
                  {social}
                </a>
              ))}
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
