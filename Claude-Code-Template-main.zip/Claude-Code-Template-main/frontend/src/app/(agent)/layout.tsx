"use client";

import {
  LayoutDashboard,
  Inbox,
  Ticket,
  Phone,
  Video,
  BookOpen,
  Users,
  BarChart3,
  Settings,
} from "lucide-react";
import { ResponsiveShell } from "@/components/layout/responsive-shell";
import type { SidebarItem } from "@/components/layout/sidebar";

const agentSidebarItems: SidebarItem[] = [
  { label: "Dashboard", href: "/agent/dashboard", icon: LayoutDashboard },
  { label: "Inbox", href: "/agent/inbox", icon: Inbox, badge: 5 },
  { label: "Tickets", href: "/agent/tickets", icon: Ticket },
  { label: "Calls", href: "/agent/calls", icon: Phone },
  { label: "Video", href: "/agent/video", icon: Video },
  { label: "Knowledge Base", href: "/agent/knowledge-base", icon: BookOpen },
  { label: "Customers", href: "/agent/customers", icon: Users },
  { label: "Analytics", href: "/agent/analytics", icon: BarChart3 },
  { label: "Settings", href: "/agent/settings", icon: Settings },
];

export default function AgentLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <ResponsiveShell sidebarItems={agentSidebarItems}>
      {children}
    </ResponsiveShell>
  );
}
