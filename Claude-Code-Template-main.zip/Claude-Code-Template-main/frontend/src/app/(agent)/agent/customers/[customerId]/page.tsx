"use client";

import React, { useState } from "react";
import { cn } from "@/lib/utils/cn";
import {
  ChevronLeft,
  Mail,
  Phone,
  Building,
  CreditCard,
  Calendar,
  Ticket,
  MessageSquare,
  PhoneCall,
  Star,
  DollarSign,
  Tag,
  StickyNote,
  Send,
} from "lucide-react";

// ----- Inline types -----
interface TimelineEvent {
  id: string;
  type: "ticket" | "chat" | "call" | "email" | "note";
  summary: string;
  date: string;
  icon: React.ElementType;
  iconColor: string;
  iconBg: string;
}

// ----- Mock data -----
const CUSTOMER = {
  name: "Sarah Chen",
  initials: "SC",
  email: "sarah.chen@techcorp.com",
  phone: "+1 (555) 123-4567",
  company: "TechCorp Inc.",
  plan: "Pro",
  memberSince: "January 2024",
};

const STATS = [
  { label: "Total Tickets", value: "23", icon: Ticket, color: "text-linkedin-blue" },
  { label: "Open Tickets", value: "2", icon: Ticket, color: "text-linkedin-orange" },
  { label: "Avg CSAT", value: "4.5", icon: Star, color: "text-yellow-600" },
  { label: "Lifetime Value", value: "$12,400", icon: DollarSign, color: "text-linkedin-green" },
];

const TAGS = ["VIP", "Enterprise", "Early Adopter", "Beta Tester"];

const TIMELINE: TimelineEvent[] = [
  {
    id: "ev1",
    type: "ticket",
    summary: "Created ticket: Cannot access billing dashboard",
    date: "2026-03-08 10:00 AM",
    icon: Ticket,
    iconColor: "text-linkedin-blue",
    iconBg: "bg-linkedin-blue-bg",
  },
  {
    id: "ev2",
    type: "chat",
    summary: "Chat session about upgrading to Enterprise plan",
    date: "2026-03-06 2:00 PM",
    icon: MessageSquare,
    iconColor: "text-linkedin-green",
    iconBg: "bg-green-50",
  },
  {
    id: "ev3",
    type: "call",
    summary: "Quarterly business review call - discussed expansion plans",
    date: "2026-03-03 11:00 AM",
    icon: PhoneCall,
    iconColor: "text-purple-600",
    iconBg: "bg-purple-50",
  },
  {
    id: "ev4",
    type: "email",
    summary: "Inquired about team seat pricing and annual billing",
    date: "2026-02-28 9:00 AM",
    icon: Mail,
    iconColor: "text-linkedin-orange",
    iconBg: "bg-orange-50",
  },
  {
    id: "ev5",
    type: "ticket",
    summary: "Resolved: Invoice not showing correct amount",
    date: "2026-02-20 3:00 PM",
    icon: Ticket,
    iconColor: "text-linkedin-blue",
    iconBg: "bg-linkedin-blue-bg",
  },
];

const NOTES = [
  { id: "n1", text: "Interested in annual enterprise plan renewal.", date: "2026-03-06" },
  { id: "n2", text: "Prefers email communication over phone.", date: "2026-02-15" },
];

// ----- Page -----
export default function AgentCustomerDetailPage() {
  const [noteInput, setNoteInput] = useState("");

  return (
    <div className="page-container space-y-6">
      {/* Back */}
      <a
        href="/customers"
        className="inline-flex items-center gap-1 text-sm text-linkedin-blue hover:underline"
      >
        <ChevronLeft className="h-4 w-4" />
        Back to Customers
      </a>

      <div className="flex flex-col gap-6 lg:flex-row">
        {/* Left column (2/3) */}
        <div className="flex-1 min-w-0 space-y-6 lg:w-2/3">
          {/* Profile card */}
          <div className="rounded-lg border border-linkedin-gray-20 bg-linkedin-white p-6 shadow-card">
            <div className="flex items-start gap-4">
              <div className="flex h-16 w-16 shrink-0 items-center justify-center rounded-full bg-linkedin-blue-bg text-xl font-bold text-linkedin-blue">
                {CUSTOMER.initials}
              </div>
              <div>
                <h1 className="text-xl font-semibold text-linkedin-gray-90">
                  {CUSTOMER.name}
                </h1>
                <div className="mt-2 space-y-1 text-sm text-linkedin-gray-50">
                  <p className="flex items-center gap-2">
                    <Mail className="h-3.5 w-3.5" />
                    {CUSTOMER.email}
                  </p>
                  <p className="flex items-center gap-2">
                    <Phone className="h-3.5 w-3.5" />
                    {CUSTOMER.phone}
                  </p>
                  <p className="flex items-center gap-2">
                    <Building className="h-3.5 w-3.5" />
                    {CUSTOMER.company}
                  </p>
                  <p className="flex items-center gap-2">
                    <CreditCard className="h-3.5 w-3.5" />
                    {CUSTOMER.plan} Plan
                  </p>
                  <p className="flex items-center gap-2">
                    <Calendar className="h-3.5 w-3.5" />
                    Member since {CUSTOMER.memberSince}
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Interaction History */}
          <div className="rounded-lg border border-linkedin-gray-20 bg-linkedin-white shadow-card">
            <div className="border-b border-linkedin-gray-20 px-4 py-3">
              <h2 className="text-sm font-semibold text-linkedin-gray-90">
                Interaction History
              </h2>
            </div>
            <div className="p-4">
              <div className="relative space-y-6 pl-8">
                {/* Timeline line */}
                <div className="absolute left-3 top-2 bottom-2 w-px bg-linkedin-gray-20" />

                {TIMELINE.map((event) => {
                  const Icon = event.icon;
                  return (
                    <div key={event.id} className="relative">
                      <div
                        className={cn(
                          "absolute -left-8 flex h-6 w-6 items-center justify-center rounded-full",
                          event.iconBg,
                        )}
                      >
                        <Icon className={cn("h-3 w-3", event.iconColor)} />
                      </div>
                      <div>
                        <p className="text-sm text-linkedin-gray-90">
                          {event.summary}
                        </p>
                        <p className="mt-0.5 text-xs text-linkedin-gray-50">
                          {event.date}
                        </p>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>

        {/* Right column (1/3) */}
        <div className="space-y-4 lg:w-1/3">
          {/* Stats cards */}
          <div className="grid grid-cols-2 gap-3">
            {STATS.map((stat) => {
              const Icon = stat.icon;
              return (
                <div
                  key={stat.label}
                  className="rounded-lg border border-linkedin-gray-20 bg-linkedin-white p-4 shadow-card text-center"
                >
                  <Icon className={cn("mx-auto h-5 w-5", stat.color)} />
                  <p className="mt-1 text-xl font-bold text-linkedin-gray-90">
                    {stat.value}
                  </p>
                  <p className="text-xs text-linkedin-gray-50">{stat.label}</p>
                </div>
              );
            })}
          </div>

          {/* Tags */}
          <div className="rounded-lg border border-linkedin-gray-20 bg-linkedin-white p-4 shadow-card">
            <h3 className="flex items-center gap-2 text-sm font-semibold text-linkedin-gray-90 mb-3">
              <Tag className="h-4 w-4 text-linkedin-gray-50" />
              Tags
            </h3>
            <div className="flex flex-wrap gap-2">
              {TAGS.map((tag) => (
                <span
                  key={tag}
                  className="rounded-full bg-linkedin-blue-bg px-2.5 py-0.5 text-xs font-medium text-linkedin-blue"
                >
                  {tag}
                </span>
              ))}
            </div>
          </div>

          {/* Notes */}
          <div className="rounded-lg border border-linkedin-gray-20 bg-linkedin-white p-4 shadow-card">
            <h3 className="flex items-center gap-2 text-sm font-semibold text-linkedin-gray-90 mb-3">
              <StickyNote className="h-4 w-4 text-linkedin-gray-50" />
              Notes
            </h3>
            <div className="space-y-3">
              {NOTES.map((note) => (
                <div key={note.id} className="rounded-lg bg-linkedin-gray-10 p-3">
                  <p className="text-sm text-linkedin-gray-70">{note.text}</p>
                  <p className="mt-1 text-xs text-linkedin-gray-50">{note.date}</p>
                </div>
              ))}
            </div>
            <div className="mt-3 flex gap-2">
              <input
                type="text"
                value={noteInput}
                onChange={(e) => setNoteInput(e.target.value)}
                placeholder="Add a note..."
                className="flex-1 rounded-lg border border-linkedin-gray-30 bg-linkedin-white px-3 py-2 text-sm text-linkedin-gray-90 placeholder:text-linkedin-gray-50 focus:border-linkedin-blue focus:outline-none"
              />
              <button
                className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-linkedin-blue text-white transition-colors hover:bg-linkedin-blue-hover disabled:opacity-50"
                disabled={!noteInput.trim()}
              >
                <Send className="h-4 w-4" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
