"use client";

import React, { useState } from "react";
import { cn } from "@/lib/utils/cn";
import { Search, Users, Clock, Ticket, ArrowRight } from "lucide-react";

// ----- Inline types -----
interface Customer {
  id: string;
  name: string;
  initials: string;
  email: string;
  company: string;
  totalTickets: number;
  lastInteraction: string;
}

// ----- Mock data -----
const ALL_CUSTOMERS: Customer[] = [
  {
    id: "c1",
    name: "Sarah Chen",
    initials: "SC",
    email: "sarah.chen@techcorp.com",
    company: "TechCorp Inc.",
    totalTickets: 12,
    lastInteraction: "2026-03-09",
  },
  {
    id: "c2",
    name: "James Park",
    initials: "JP",
    email: "james.park@acmeco.com",
    company: "Acme Co.",
    totalTickets: 8,
    lastInteraction: "2026-03-08",
  },
  {
    id: "c3",
    name: "Maria Garcia",
    initials: "MG",
    email: "maria.garcia@startuplab.io",
    company: "StartupLab",
    totalTickets: 5,
    lastInteraction: "2026-03-07",
  },
  {
    id: "c4",
    name: "David Kim",
    initials: "DK",
    email: "david.kim@enterprise.com",
    company: "Enterprise Solutions",
    totalTickets: 23,
    lastInteraction: "2026-03-06",
  },
  {
    id: "c5",
    name: "Emily Watson",
    initials: "EW",
    email: "emily.watson@designstudio.co",
    company: "Design Studio",
    totalTickets: 3,
    lastInteraction: "2026-03-05",
  },
  {
    id: "c6",
    name: "Alex Johnson",
    initials: "AJ",
    email: "alex.j@devtools.io",
    company: "DevTools Inc.",
    totalTickets: 15,
    lastInteraction: "2026-03-04",
  },
];

const RECENTLY_VIEWED: Customer[] = ALL_CUSTOMERS.slice(0, 4);

// ----- Page -----
export default function AgentCustomersPage() {
  const [query, setQuery] = useState("");

  const results = query.trim()
    ? ALL_CUSTOMERS.filter(
        (c) =>
          c.name.toLowerCase().includes(query.toLowerCase()) ||
          c.email.toLowerCase().includes(query.toLowerCase()) ||
          c.company.toLowerCase().includes(query.toLowerCase()),
      )
    : [];

  return (
    <div className="page-container space-y-6">
      <div className="flex items-center gap-3">
        <Users className="h-6 w-6 text-linkedin-blue" />
        <h1 className="text-xl font-semibold text-linkedin-gray-90">
          Customers
        </h1>
      </div>

      {/* Search bar */}
      <div className="relative">
        <Search className="pointer-events-none absolute left-4 top-1/2 h-5 w-5 -translate-y-1/2 text-linkedin-gray-50" />
        <input
          type="text"
          placeholder="Search for customers by name, email, or company..."
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          className="w-full rounded-lg border border-linkedin-gray-30 bg-linkedin-white py-3 pl-12 pr-4 text-sm text-linkedin-gray-90 shadow-card placeholder:text-linkedin-gray-50 focus:border-linkedin-blue focus:outline-none focus:ring-1 focus:ring-linkedin-blue"
        />
      </div>

      {/* Recently Viewed (shown when not searching) */}
      {!query.trim() && (
        <section>
          <h2 className="mb-3 text-sm font-semibold text-linkedin-gray-90">
            Recently Viewed
          </h2>
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
            {RECENTLY_VIEWED.map((customer) => (
              <a
                key={customer.id}
                href={`/customers/${customer.id}`}
                className="flex items-center gap-3 rounded-lg border border-linkedin-gray-20 bg-linkedin-white p-4 shadow-card transition-shadow hover:shadow-md"
              >
                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-linkedin-blue-bg text-sm font-semibold text-linkedin-blue">
                  {customer.initials}
                </div>
                <div className="min-w-0">
                  <p className="truncate text-sm font-medium text-linkedin-gray-90">
                    {customer.name}
                  </p>
                  <p className="truncate text-xs text-linkedin-gray-50">
                    {customer.company}
                  </p>
                  <p className="text-xs text-linkedin-gray-50">
                    Last: {customer.lastInteraction}
                  </p>
                </div>
              </a>
            ))}
          </div>
        </section>
      )}

      {/* Search results */}
      {query.trim() && results.length === 0 && (
        <div className="rounded-lg border border-linkedin-gray-20 bg-linkedin-white p-8 text-center shadow-card">
          <Search className="mx-auto h-10 w-10 text-linkedin-gray-30" />
          <p className="mt-3 text-sm text-linkedin-gray-50">
            No customers found for &quot;{query}&quot;
          </p>
        </div>
      )}

      {query.trim() && results.length > 0 && (
        <section>
          <h2 className="mb-3 text-sm font-semibold text-linkedin-gray-90">
            Results ({results.length})
          </h2>
          <div className="space-y-3">
            {results.map((customer) => (
              <a
                key={customer.id}
                href={`/customers/${customer.id}`}
                className="flex items-center gap-4 rounded-lg border border-linkedin-gray-20 bg-linkedin-white p-4 shadow-card transition-shadow hover:shadow-md"
              >
                <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-linkedin-blue-bg text-sm font-semibold text-linkedin-blue">
                  {customer.initials}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold text-linkedin-gray-90">
                    {customer.name}
                  </p>
                  <p className="text-xs text-linkedin-gray-50">
                    {customer.email}
                  </p>
                  <p className="text-xs text-linkedin-gray-50">
                    {customer.company}
                  </p>
                </div>
                <div className="flex shrink-0 items-center gap-4 text-xs text-linkedin-gray-50">
                  <span className="inline-flex items-center gap-1">
                    <Ticket className="h-3 w-3" />
                    {customer.totalTickets} tickets
                  </span>
                  <span className="inline-flex items-center gap-1">
                    <Clock className="h-3 w-3" />
                    {customer.lastInteraction}
                  </span>
                  <ArrowRight className="h-4 w-4 text-linkedin-gray-30" />
                </div>
              </a>
            ))}
          </div>
        </section>
      )}

      {/* Default state */}
      {!query.trim() && (
        <div className="rounded-lg border border-linkedin-gray-20 bg-linkedin-white p-8 text-center shadow-card">
          <Search className="mx-auto h-10 w-10 text-linkedin-gray-30" />
          <p className="mt-3 text-sm text-linkedin-gray-50">
            Search for customers by name, email, or company
          </p>
        </div>
      )}
    </div>
  );
}
