"use client";

import React, { useState } from "react";
import { cn } from "@/lib/utils/cn";
import {
  Settings,
  Bell,
  Globe,
  MessageSquare,
  Keyboard,
  Save,
  Check,
} from "lucide-react";

// ----- Mock data -----
interface NotificationSetting {
  id: string;
  label: string;
  description: string;
  defaultEnabled: boolean;
}

const NOTIFICATION_SETTINGS: NotificationSetting[] = [
  {
    id: "n1",
    label: "New conversation assigned",
    description: "Get notified when a conversation is assigned to you",
    defaultEnabled: true,
  },
  {
    id: "n2",
    label: "Customer reply",
    description: "Alert when a customer replies to your conversation",
    defaultEnabled: true,
  },
  {
    id: "n3",
    label: "SLA warning",
    description: "Warning when a ticket is approaching SLA breach",
    defaultEnabled: true,
  },
  {
    id: "n4",
    label: "Mention",
    description: "When another agent mentions you in a note",
    defaultEnabled: false,
  },
  {
    id: "n5",
    label: "Call incoming",
    description: "Audio alert for incoming calls",
    defaultEnabled: true,
  },
];

const LANGUAGE_OPTIONS = [
  { value: "en", label: "English" },
  { value: "es", label: "Spanish" },
  { value: "fr", label: "French" },
  { value: "de", label: "German" },
  { value: "pt", label: "Portuguese" },
  { value: "ja", label: "Japanese" },
];

const KEYBOARD_SHORTCUTS = [
  { action: "Reply to conversation", keys: "Ctrl + Enter" },
  { action: "Add internal note", keys: "Ctrl + Shift + N" },
  { action: "Resolve ticket", keys: "Ctrl + Shift + R" },
  { action: "Next conversation", keys: "Alt + Down" },
  { action: "Previous conversation", keys: "Alt + Up" },
  { action: "Search", keys: "Ctrl + K" },
  { action: "Toggle sidebar", keys: "Ctrl + B" },
];

// ----- Page -----
export default function AgentSettingsPage() {
  const [notifications, setNotifications] = useState<Record<string, boolean>>(
    Object.fromEntries(
      NOTIFICATION_SETTINGS.map((n) => [n.id, n.defaultEnabled]),
    ),
  );
  const [language, setLanguage] = useState("en");
  const [autoAccept, setAutoAccept] = useState(false);
  const [maxConcurrent, setMaxConcurrent] = useState(5);
  const [saved, setSaved] = useState(false);

  function handleSave() {
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  }

  return (
    <div className="mx-auto max-w-2xl px-4 py-8">
      <div className="flex items-center gap-3">
        <Settings className="h-6 w-6 text-linkedin-blue" />
        <h1 className="text-xl font-semibold text-linkedin-gray-90">
          Preferences
        </h1>
      </div>
      <p className="mt-1 text-sm text-linkedin-gray-50">
        Customize your agent workspace settings.
      </p>

      <div className="mt-6 space-y-6">
        {/* Notifications */}
        <section className="rounded-lg border border-linkedin-gray-20 bg-linkedin-white shadow-card">
          <div className="flex items-center gap-2 border-b border-linkedin-gray-20 px-4 py-3">
            <Bell className="h-4 w-4 text-linkedin-blue" />
            <h2 className="text-sm font-semibold text-linkedin-gray-90">
              Notifications
            </h2>
          </div>
          <div className="divide-y divide-linkedin-gray-20">
            {NOTIFICATION_SETTINGS.map((setting) => (
              <div
                key={setting.id}
                className="flex items-center justify-between px-4 py-3"
              >
                <div className="flex-1 min-w-0 mr-4">
                  <p className="text-sm font-medium text-linkedin-gray-90">
                    {setting.label}
                  </p>
                  <p className="text-xs text-linkedin-gray-50">
                    {setting.description}
                  </p>
                </div>
                <button
                  role="switch"
                  aria-checked={notifications[setting.id]}
                  onClick={() =>
                    setNotifications((prev) => ({
                      ...prev,
                      [setting.id]: !prev[setting.id],
                    }))
                  }
                  className={cn(
                    "relative inline-flex h-6 w-11 shrink-0 items-center rounded-full transition-colors",
                    notifications[setting.id]
                      ? "bg-linkedin-blue"
                      : "bg-linkedin-gray-30",
                  )}
                >
                  <span
                    className={cn(
                      "pointer-events-none block h-4 w-4 rounded-full bg-white shadow-sm transition-transform",
                      notifications[setting.id]
                        ? "translate-x-6"
                        : "translate-x-1",
                    )}
                  />
                </button>
              </div>
            ))}
          </div>
        </section>

        {/* Language */}
        <section className="rounded-lg border border-linkedin-gray-20 bg-linkedin-white shadow-card">
          <div className="flex items-center gap-2 border-b border-linkedin-gray-20 px-4 py-3">
            <Globe className="h-4 w-4 text-linkedin-blue" />
            <h2 className="text-sm font-semibold text-linkedin-gray-90">
              Language
            </h2>
          </div>
          <div className="px-4 py-3">
            <select
              value={language}
              onChange={(e) => setLanguage(e.target.value)}
              className="w-full max-w-xs appearance-none rounded-lg border border-linkedin-gray-30 bg-linkedin-white px-3 py-2 text-sm text-linkedin-gray-90 focus:border-linkedin-blue focus:outline-none focus:ring-1 focus:ring-linkedin-blue"
            >
              {LANGUAGE_OPTIONS.map((opt) => (
                <option key={opt.value} value={opt.value}>
                  {opt.label}
                </option>
              ))}
            </select>
          </div>
        </section>

        {/* Conversation handling */}
        <section className="rounded-lg border border-linkedin-gray-20 bg-linkedin-white shadow-card">
          <div className="flex items-center gap-2 border-b border-linkedin-gray-20 px-4 py-3">
            <MessageSquare className="h-4 w-4 text-linkedin-blue" />
            <h2 className="text-sm font-semibold text-linkedin-gray-90">
              Conversation Handling
            </h2>
          </div>
          <div className="divide-y divide-linkedin-gray-20">
            <div className="flex items-center justify-between px-4 py-3">
              <div className="flex-1 min-w-0 mr-4">
                <p className="text-sm font-medium text-linkedin-gray-90">
                  Auto-accept conversations
                </p>
                <p className="text-xs text-linkedin-gray-50">
                  Automatically accept new assigned conversations without manual
                  confirmation
                </p>
              </div>
              <button
                role="switch"
                aria-checked={autoAccept}
                onClick={() => setAutoAccept(!autoAccept)}
                className={cn(
                  "relative inline-flex h-6 w-11 shrink-0 items-center rounded-full transition-colors",
                  autoAccept ? "bg-linkedin-blue" : "bg-linkedin-gray-30",
                )}
              >
                <span
                  className={cn(
                    "pointer-events-none block h-4 w-4 rounded-full bg-white shadow-sm transition-transform",
                    autoAccept ? "translate-x-6" : "translate-x-1",
                  )}
                />
              </button>
            </div>
            <div className="flex items-center justify-between px-4 py-3">
              <div className="flex-1 min-w-0 mr-4">
                <p className="text-sm font-medium text-linkedin-gray-90">
                  Max concurrent chats
                </p>
                <p className="text-xs text-linkedin-gray-50">
                  Maximum number of chats you can handle simultaneously
                </p>
              </div>
              <input
                type="number"
                min={1}
                max={20}
                value={maxConcurrent}
                onChange={(e) =>
                  setMaxConcurrent(parseInt(e.target.value, 10) || 1)
                }
                className="w-20 rounded-lg border border-linkedin-gray-30 bg-linkedin-white px-3 py-1.5 text-sm text-center text-linkedin-gray-90 focus:border-linkedin-blue focus:outline-none focus:ring-1 focus:ring-linkedin-blue"
              />
            </div>
          </div>
        </section>

        {/* Keyboard shortcuts */}
        <section className="rounded-lg border border-linkedin-gray-20 bg-linkedin-white shadow-card">
          <div className="flex items-center gap-2 border-b border-linkedin-gray-20 px-4 py-3">
            <Keyboard className="h-4 w-4 text-linkedin-blue" />
            <h2 className="text-sm font-semibold text-linkedin-gray-90">
              Keyboard Shortcuts
            </h2>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-linkedin-gray-20 bg-linkedin-gray-10">
                  <th className="px-4 py-2 text-left text-xs font-semibold text-linkedin-gray-50">
                    Action
                  </th>
                  <th className="px-4 py-2 text-right text-xs font-semibold text-linkedin-gray-50">
                    Shortcut
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-linkedin-gray-20">
                {KEYBOARD_SHORTCUTS.map((shortcut) => (
                  <tr key={shortcut.action}>
                    <td className="px-4 py-2.5 text-linkedin-gray-70">
                      {shortcut.action}
                    </td>
                    <td className="px-4 py-2.5 text-right">
                      <kbd className="rounded border border-linkedin-gray-20 bg-linkedin-gray-10 px-2 py-0.5 font-mono text-xs text-linkedin-gray-70">
                        {shortcut.keys}
                      </kbd>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>

        {/* Save */}
        <div className="flex justify-end">
          <button
            onClick={handleSave}
            className="inline-flex items-center gap-1.5 rounded-full bg-linkedin-blue px-6 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-linkedin-blue-hover"
          >
            {saved ? (
              <>
                <Check className="h-4 w-4" />
                Saved
              </>
            ) : (
              <>
                <Save className="h-4 w-4" />
                Save Changes
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
}
