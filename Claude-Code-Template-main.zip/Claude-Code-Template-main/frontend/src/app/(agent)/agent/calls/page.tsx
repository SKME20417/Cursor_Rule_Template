"use client";

import React from "react";
import { cn } from "@/lib/utils/cn";
import {
  Phone,
  PhoneIncoming,
  PhoneOutgoing,
  Clock,
  Star,
  Users,
} from "lucide-react";

// ----- Inline types -----
interface CallStat {
  label: string;
  value: string;
  icon: React.ElementType;
  color: string;
  bg: string;
}

interface ActiveCall {
  id: string;
  customerName: string;
  agentName: string;
  duration: string;
  sentiment: "positive" | "neutral" | "negative";
}

interface RecentCall {
  id: string;
  date: string;
  customer: string;
  duration: string;
  type: "inbound" | "outbound";
  quality: number;
  outcome: "resolved" | "transferred" | "follow-up";
}

// ----- Mock data -----
const CALL_STATS: CallStat[] = [
  {
    label: "Calls Today",
    value: "12",
    icon: Phone,
    color: "text-linkedin-blue",
    bg: "bg-linkedin-blue-bg",
  },
  {
    label: "Avg Duration",
    value: "4:32",
    icon: Clock,
    color: "text-linkedin-orange",
    bg: "bg-orange-50",
  },
  {
    label: "Avg Quality",
    value: "4.2/5",
    icon: Star,
    color: "text-yellow-600",
    bg: "bg-yellow-50",
  },
  {
    label: "Active Now",
    value: "3",
    icon: Users,
    color: "text-linkedin-green",
    bg: "bg-green-50",
  },
];

const ACTIVE_CALLS: ActiveCall[] = [
  {
    id: "ac-1",
    customerName: "Sarah Johnson",
    agentName: "Mike Chen",
    duration: "12:34",
    sentiment: "positive",
  },
  {
    id: "ac-2",
    customerName: "James Wilson",
    agentName: "Lisa Park",
    duration: "5:21",
    sentiment: "neutral",
  },
  {
    id: "ac-3",
    customerName: "Maria Garcia",
    agentName: "Alex Kim",
    duration: "2:08",
    sentiment: "negative",
  },
];

const RECENT_CALLS: RecentCall[] = [
  {
    id: "rc-1",
    date: "2026-03-09 14:30",
    customer: "David Lee",
    duration: "6:45",
    type: "inbound",
    quality: 5,
    outcome: "resolved",
  },
  {
    id: "rc-2",
    date: "2026-03-09 13:15",
    customer: "Emily Watson",
    duration: "3:20",
    type: "outbound",
    quality: 4,
    outcome: "follow-up",
  },
  {
    id: "rc-3",
    date: "2026-03-09 11:45",
    customer: "Robert Taylor",
    duration: "8:12",
    type: "inbound",
    quality: 3,
    outcome: "transferred",
  },
  {
    id: "rc-4",
    date: "2026-03-09 10:00",
    customer: "Jennifer Brown",
    duration: "4:56",
    type: "inbound",
    quality: 5,
    outcome: "resolved",
  },
  {
    id: "rc-5",
    date: "2026-03-09 09:30",
    customer: "Michael Adams",
    duration: "2:33",
    type: "outbound",
    quality: 4,
    outcome: "resolved",
  },
];

const SENTIMENT_COLORS: Record<string, string> = {
  positive: "bg-linkedin-green",
  neutral: "bg-yellow-400",
  negative: "bg-linkedin-red",
};

const OUTCOME_STYLES: Record<string, { label: string; className: string }> = {
  resolved: { label: "Resolved", className: "bg-green-50 text-linkedin-green" },
  transferred: { label: "Transferred", className: "bg-orange-50 text-linkedin-orange" },
  "follow-up": { label: "Follow-up", className: "bg-linkedin-blue-bg text-linkedin-blue" },
};

// ----- Page -----
export default function AgentCallsPage() {
  return (
    <div className="page-container space-y-6">
      <h1 className="text-xl font-semibold text-linkedin-gray-90">Calls</h1>

      {/* Stats row */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {CALL_STATS.map((stat) => {
          const Icon = stat.icon;
          return (
            <div
              key={stat.label}
              className="rounded-lg border border-linkedin-gray-20 bg-linkedin-white p-4 shadow-card"
            >
              <div className="flex items-center gap-3">
                <div
                  className={cn(
                    "flex h-10 w-10 items-center justify-center rounded-full",
                    stat.bg,
                  )}
                >
                  <Icon className={cn("h-5 w-5", stat.color)} />
                </div>
                <div>
                  <p className="text-2xl font-bold text-linkedin-gray-90">
                    {stat.value}
                  </p>
                  <p className="text-xs text-linkedin-gray-50">{stat.label}</p>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Active Calls */}
      <div className="rounded-lg border border-linkedin-gray-20 bg-linkedin-white shadow-card">
        <div className="flex items-center justify-between border-b border-linkedin-gray-20 px-4 py-3">
          <h2 className="text-sm font-semibold text-linkedin-gray-90">
            Active Calls
          </h2>
          <span className="rounded-full bg-green-50 px-2 py-0.5 text-xs font-medium text-linkedin-green">
            {ACTIVE_CALLS.length} live
          </span>
        </div>
        <div className="divide-y divide-linkedin-gray-20">
          {ACTIVE_CALLS.map((call) => (
            <div
              key={call.id}
              className="flex items-center gap-4 px-4 py-3"
            >
              <span
                className={cn(
                  "h-2.5 w-2.5 shrink-0 rounded-full",
                  SENTIMENT_COLORS[call.sentiment],
                )}
              />
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-linkedin-gray-90">
                  {call.customerName}
                </p>
                <p className="text-xs text-linkedin-gray-50">
                  Agent: {call.agentName}
                </p>
              </div>
              <span className="text-sm font-mono text-linkedin-gray-70">
                {call.duration}
              </span>
              <a
                href={`/calls/${call.id}`}
                className="rounded-full bg-linkedin-blue px-4 py-1.5 text-xs font-semibold text-white transition-colors hover:bg-linkedin-blue-hover"
              >
                Join
              </a>
            </div>
          ))}
        </div>
      </div>

      {/* Recent Calls */}
      <div className="rounded-lg border border-linkedin-gray-20 bg-linkedin-white shadow-card">
        <div className="border-b border-linkedin-gray-20 px-4 py-3">
          <h2 className="text-sm font-semibold text-linkedin-gray-90">
            Recent Calls
          </h2>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-linkedin-gray-20 bg-linkedin-gray-10">
                <th className="px-4 py-2.5 text-left text-xs font-semibold text-linkedin-gray-50">
                  Date
                </th>
                <th className="px-4 py-2.5 text-left text-xs font-semibold text-linkedin-gray-50">
                  Customer
                </th>
                <th className="px-4 py-2.5 text-left text-xs font-semibold text-linkedin-gray-50">
                  Duration
                </th>
                <th className="px-4 py-2.5 text-left text-xs font-semibold text-linkedin-gray-50">
                  Type
                </th>
                <th className="px-4 py-2.5 text-left text-xs font-semibold text-linkedin-gray-50">
                  Quality
                </th>
                <th className="px-4 py-2.5 text-left text-xs font-semibold text-linkedin-gray-50">
                  Outcome
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-linkedin-gray-20">
              {RECENT_CALLS.map((call) => {
                const outcome = OUTCOME_STYLES[call.outcome];
                return (
                  <tr
                    key={call.id}
                    className="cursor-pointer transition-colors hover:bg-linkedin-gray-10"
                  >
                    <td className="px-4 py-3 text-linkedin-gray-70">
                      {call.date}
                    </td>
                    <td className="px-4 py-3 font-medium text-linkedin-gray-90">
                      {call.customer}
                    </td>
                    <td className="px-4 py-3 font-mono text-linkedin-gray-70">
                      {call.duration}
                    </td>
                    <td className="px-4 py-3">
                      <span
                        className={cn(
                          "inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-xs font-medium",
                          call.type === "inbound"
                            ? "bg-green-50 text-linkedin-green"
                            : "bg-linkedin-blue-bg text-linkedin-blue",
                        )}
                      >
                        {call.type === "inbound" ? (
                          <PhoneIncoming className="h-3 w-3" />
                        ) : (
                          <PhoneOutgoing className="h-3 w-3" />
                        )}
                        {call.type}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-0.5">
                        {Array.from({ length: 5 }).map((_, i) => (
                          <Star
                            key={i}
                            className={cn(
                              "h-3 w-3",
                              i < call.quality
                                ? "fill-yellow-400 text-yellow-400"
                                : "text-linkedin-gray-20",
                            )}
                          />
                        ))}
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <span
                        className={cn(
                          "rounded-full px-2 py-0.5 text-xs font-medium",
                          outcome.className,
                        )}
                      >
                        {outcome.label}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
