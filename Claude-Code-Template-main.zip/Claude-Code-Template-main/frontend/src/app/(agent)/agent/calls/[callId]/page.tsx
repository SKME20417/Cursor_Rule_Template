"use client";

import React, { useState } from "react";
import { cn } from "@/lib/utils/cn";
import {
  Play,
  Pause,
  ChevronLeft,
  Star,
  Clock,
  User,
  Sparkles,
} from "lucide-react";

// ----- Inline types -----
interface TranscriptSegment {
  id: string;
  speaker: "agent" | "customer";
  name: string;
  timestamp: string;
  text: string;
}

interface SentimentPoint {
  label: string;
  value: "positive" | "neutral" | "negative";
  width: string;
}

// ----- Mock data -----
const CALL_DETAILS = {
  id: "rc-1",
  customerName: "David Lee",
  date: "March 9, 2026 at 2:30 PM",
  duration: "6:45",
  quality: 5,
};

const AI_SUMMARY = [
  "Customer called about a billing discrepancy on their February invoice.",
  "Agent identified the issue as a prorated charge from the mid-cycle plan upgrade.",
  "Agent issued a credit of $15.00 for the confusion and sent a detailed breakdown via email.",
  "Customer confirmed satisfaction and the issue was resolved.",
];

const TRANSCRIPT: TranscriptSegment[] = [
  {
    id: "t1",
    speaker: "agent",
    name: "Mike Chen",
    timestamp: "0:00",
    text: "Thank you for calling support. My name is Mike. How can I help you today?",
  },
  {
    id: "t2",
    speaker: "customer",
    name: "David Lee",
    timestamp: "0:08",
    text: "Hi Mike, I'm looking at my February invoice and the amount doesn't match what I expected. I was charged $89 but my plan is $74 per month.",
  },
  {
    id: "t3",
    speaker: "agent",
    name: "Mike Chen",
    timestamp: "0:25",
    text: "I understand the concern, David. Let me pull up your account and take a look at that invoice for you.",
  },
  {
    id: "t4",
    speaker: "agent",
    name: "Mike Chen",
    timestamp: "0:45",
    text: "I can see here that you upgraded from the Starter plan to the Pro plan on February 15th. The $89 charge includes a prorated amount of $15 for the upgrade mid-billing cycle.",
  },
  {
    id: "t5",
    speaker: "customer",
    name: "David Lee",
    timestamp: "1:10",
    text: "Oh I see. I wasn't aware there would be a prorated charge. Is there any way to get that adjusted?",
  },
  {
    id: "t6",
    speaker: "agent",
    name: "Mike Chen",
    timestamp: "1:22",
    text: "Absolutely. I understand that wasn't clear during the upgrade process. Let me apply a $15 credit to your account right now. You'll see it reflected on your next invoice.",
  },
  {
    id: "t7",
    speaker: "customer",
    name: "David Lee",
    timestamp: "1:45",
    text: "That would be great, thank you so much Mike!",
  },
  {
    id: "t8",
    speaker: "agent",
    name: "Mike Chen",
    timestamp: "1:50",
    text: "You're welcome! The credit has been applied. I'll also send you a detailed breakdown via email so you have it for your records. Is there anything else I can help with?",
  },
];

const SENTIMENT_TIMELINE: SentimentPoint[] = [
  { label: "Opening", value: "neutral", width: "w-[15%]" },
  { label: "Issue raised", value: "negative", width: "w-[25%]" },
  { label: "Investigation", value: "neutral", width: "w-[20%]" },
  { label: "Resolution", value: "positive", width: "w-[25%]" },
  { label: "Closing", value: "positive", width: "w-[15%]" },
];

const SENTIMENT_COLORS: Record<string, string> = {
  positive: "bg-linkedin-green",
  neutral: "bg-yellow-400",
  negative: "bg-linkedin-red",
};

// ----- Page -----
export default function AgentCallDetailPage() {
  const [playing, setPlaying] = useState(false);
  const [speed, setSpeed] = useState("1x");

  return (
    <div className="page-container space-y-6">
      {/* Back */}
      <a
        href="/calls"
        className="inline-flex items-center gap-1 text-sm text-linkedin-blue hover:underline"
      >
        <ChevronLeft className="h-4 w-4" />
        Back to Calls
      </a>

      {/* Call header */}
      <div className="rounded-lg border border-linkedin-gray-20 bg-linkedin-white p-6 shadow-card">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <h1 className="text-xl font-semibold text-linkedin-gray-90">
              Call with {CALL_DETAILS.customerName}
            </h1>
            <div className="mt-2 flex flex-wrap items-center gap-4 text-xs text-linkedin-gray-50">
              <span className="inline-flex items-center gap-1">
                <Clock className="h-3 w-3" />
                {CALL_DETAILS.date}
              </span>
              <span className="inline-flex items-center gap-1">
                <User className="h-3 w-3" />
                Duration: {CALL_DETAILS.duration}
              </span>
            </div>
          </div>
          <div className="flex items-center gap-1">
            {Array.from({ length: 5 }).map((_, i) => (
              <Star
                key={i}
                className={cn(
                  "h-5 w-5",
                  i < CALL_DETAILS.quality
                    ? "fill-yellow-400 text-yellow-400"
                    : "text-linkedin-gray-20",
                )}
              />
            ))}
          </div>
        </div>
      </div>

      {/* Audio player */}
      <div className="rounded-lg border border-linkedin-gray-20 bg-linkedin-white p-4 shadow-card">
        <div className="flex items-center gap-4">
          <button
            onClick={() => setPlaying(!playing)}
            className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-linkedin-blue text-white transition-colors hover:bg-linkedin-blue-hover"
          >
            {playing ? (
              <Pause className="h-4 w-4" />
            ) : (
              <Play className="h-4 w-4 ml-0.5" />
            )}
          </button>

          {/* Waveform placeholder */}
          <div className="flex-1">
            <div className="flex h-8 items-end gap-0.5">
              {Array.from({ length: 60 }).map((_, i) => (
                <div
                  key={i}
                  className="flex-1 rounded-full bg-linkedin-blue/20"
                  style={{
                    height: `${20 + Math.sin(i * 0.5) * 40 + Math.random() * 30}%`,
                    minHeight: "4px",
                  }}
                />
              ))}
            </div>
          </div>

          <span className="shrink-0 text-sm font-mono text-linkedin-gray-70">
            0:00 / {CALL_DETAILS.duration}
          </span>

          <select
            value={speed}
            onChange={(e) => setSpeed(e.target.value)}
            className="rounded-lg border border-linkedin-gray-30 bg-linkedin-white px-2 py-1 text-xs text-linkedin-gray-70 focus:border-linkedin-blue focus:outline-none"
          >
            <option value="0.5x">0.5x</option>
            <option value="1x">1x</option>
            <option value="1.5x">1.5x</option>
            <option value="2x">2x</option>
          </select>
        </div>
      </div>

      {/* AI Summary */}
      <div className="rounded-lg border border-linkedin-gray-20 bg-linkedin-white p-6 shadow-card">
        <h2 className="flex items-center gap-2 text-sm font-semibold text-linkedin-gray-90">
          <Sparkles className="h-4 w-4 text-linkedin-blue" />
          AI Summary
        </h2>
        <ul className="mt-3 space-y-2">
          {AI_SUMMARY.map((point, i) => (
            <li key={i} className="flex items-start gap-2 text-sm text-linkedin-gray-70">
              <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-linkedin-blue" />
              {point}
            </li>
          ))}
        </ul>
      </div>

      {/* Transcript */}
      <div className="rounded-lg border border-linkedin-gray-20 bg-linkedin-white shadow-card">
        <div className="border-b border-linkedin-gray-20 px-4 py-3">
          <h2 className="text-sm font-semibold text-linkedin-gray-90">
            Full Transcript
          </h2>
        </div>
        <div className="divide-y divide-linkedin-gray-20">
          {TRANSCRIPT.map((segment) => (
            <div key={segment.id} className="px-4 py-3">
              <div className="flex items-center gap-2 mb-1">
                <span
                  className={cn(
                    "flex h-6 w-6 items-center justify-center rounded-full text-xs font-semibold text-white",
                    segment.speaker === "agent"
                      ? "bg-linkedin-blue"
                      : "bg-linkedin-gray-50",
                  )}
                >
                  {segment.name[0]}
                </span>
                <span className="text-sm font-medium text-linkedin-gray-90">
                  {segment.name}
                </span>
                <span className="text-xs text-linkedin-gray-50 font-mono">
                  {segment.timestamp}
                </span>
              </div>
              <p className="ml-8 text-sm text-linkedin-gray-70">
                {segment.text}
              </p>
            </div>
          ))}
        </div>
      </div>

      {/* Sentiment Timeline */}
      <div className="rounded-lg border border-linkedin-gray-20 bg-linkedin-white p-6 shadow-card">
        <h2 className="text-sm font-semibold text-linkedin-gray-90 mb-4">
          Sentiment Timeline
        </h2>
        <div className="flex h-6 overflow-hidden rounded-full">
          {SENTIMENT_TIMELINE.map((point, i) => (
            <div
              key={i}
              className={cn(
                "h-full",
                point.width,
                SENTIMENT_COLORS[point.value],
              )}
            />
          ))}
        </div>
        <div className="mt-2 flex justify-between">
          {SENTIMENT_TIMELINE.map((point, i) => (
            <span key={i} className="text-xs text-linkedin-gray-50">
              {point.label}
            </span>
          ))}
        </div>
        <div className="mt-3 flex items-center gap-4 text-xs text-linkedin-gray-50">
          <span className="inline-flex items-center gap-1">
            <span className="h-2 w-2 rounded-full bg-linkedin-green" /> Positive
          </span>
          <span className="inline-flex items-center gap-1">
            <span className="h-2 w-2 rounded-full bg-yellow-400" /> Neutral
          </span>
          <span className="inline-flex items-center gap-1">
            <span className="h-2 w-2 rounded-full bg-linkedin-red" /> Negative
          </span>
        </div>
      </div>
    </div>
  );
}
