"use client";

import React from "react";
import { cn } from "@/lib/utils/cn";
import {
  Headphones,
  MessageSquare,
  Phone,
  PhoneOff,
  Radio,
} from "lucide-react";

// ----- Inline types -----
interface LiveCall {
  id: string;
  agentName: string;
  agentInitials: string;
  customerName: string;
  duration: string;
  sentiment: "positive" | "neutral" | "negative";
  qualityBars: number;
}

// ----- Mock data -----
const LIVE_CALLS: LiveCall[] = [
  {
    id: "lc-1",
    agentName: "Mike Chen",
    agentInitials: "MC",
    customerName: "Sarah Johnson",
    duration: "12:34",
    sentiment: "positive",
    qualityBars: 4,
  },
  {
    id: "lc-2",
    agentName: "Lisa Park",
    agentInitials: "LP",
    customerName: "James Wilson",
    duration: "5:21",
    sentiment: "neutral",
    qualityBars: 3,
  },
  {
    id: "lc-3",
    agentName: "Alex Kim",
    agentInitials: "AK",
    customerName: "Maria Garcia",
    duration: "2:08",
    sentiment: "negative",
    qualityBars: 2,
  },
  {
    id: "lc-4",
    agentName: "Jordan Lee",
    agentInitials: "JL",
    customerName: "Robert Taylor",
    duration: "8:45",
    sentiment: "positive",
    qualityBars: 5,
  },
];

const SENTIMENT_EMOJI: Record<string, string> = {
  positive: "😊",
  neutral: "😐",
  negative: "😟",
};

// ----- Page -----
export default function CallMonitorPage() {
  const hasActiveCalls = LIVE_CALLS.length > 0;

  return (
    <div className="page-container space-y-6">
      <div className="flex items-center gap-3">
        <Radio className="h-6 w-6 text-linkedin-blue" />
        <h1 className="text-xl font-semibold text-linkedin-gray-90">
          Live Calls
        </h1>
        <span className="rounded-full bg-green-50 px-2.5 py-0.5 text-xs font-semibold text-linkedin-green">
          {LIVE_CALLS.length} active
        </span>
      </div>

      {!hasActiveCalls ? (
        <div className="rounded-lg border border-linkedin-gray-20 bg-linkedin-white px-6 py-16 text-center shadow-card">
          <PhoneOff className="mx-auto h-12 w-12 text-linkedin-gray-30" />
          <h2 className="mt-4 text-lg font-semibold text-linkedin-gray-90">
            No active calls
          </h2>
          <p className="mt-1 text-sm text-linkedin-gray-50">
            There are no live calls to monitor at this time. Check back later.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {LIVE_CALLS.map((call) => (
            <div
              key={call.id}
              className="rounded-lg border border-linkedin-gray-20 bg-linkedin-white p-5 shadow-card"
            >
              {/* Agent info */}
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-full bg-linkedin-blue-bg text-sm font-semibold text-linkedin-blue">
                  {call.agentInitials}
                </div>
                <div>
                  <p className="text-sm font-semibold text-linkedin-gray-90">
                    {call.agentName}
                  </p>
                  <p className="text-xs text-linkedin-gray-50">
                    with {call.customerName}
                  </p>
                </div>
              </div>

              {/* Metrics */}
              <div className="mt-4 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="text-sm font-mono text-linkedin-gray-70">
                    {call.duration}
                  </span>
                  <span className="text-lg" title={call.sentiment}>
                    {SENTIMENT_EMOJI[call.sentiment]}
                  </span>
                </div>
                <div className="flex items-end gap-0.5">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <div
                      key={i}
                      className={cn(
                        "w-1.5 rounded-full",
                        i < call.qualityBars
                          ? "bg-linkedin-green"
                          : "bg-linkedin-gray-20",
                      )}
                      style={{ height: `${8 + i * 3}px` }}
                    />
                  ))}
                </div>
              </div>

              {/* Actions */}
              <div className="mt-4 flex items-center gap-2">
                <button className="inline-flex flex-1 items-center justify-center gap-1.5 rounded-full border border-linkedin-gray-30 px-3 py-1.5 text-xs font-medium text-linkedin-gray-70 transition-colors hover:bg-linkedin-gray-10">
                  <Headphones className="h-3.5 w-3.5" />
                  Listen
                </button>
                <button className="inline-flex flex-1 items-center justify-center gap-1.5 rounded-full border border-linkedin-gray-30 px-3 py-1.5 text-xs font-medium text-linkedin-gray-70 transition-colors hover:bg-linkedin-gray-10">
                  <MessageSquare className="h-3.5 w-3.5" />
                  Whisper
                </button>
                <button className="inline-flex flex-1 items-center justify-center gap-1.5 rounded-full border border-linkedin-orange px-3 py-1.5 text-xs font-medium text-linkedin-orange transition-colors hover:bg-orange-50">
                  <Phone className="h-3.5 w-3.5" />
                  Barge
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
