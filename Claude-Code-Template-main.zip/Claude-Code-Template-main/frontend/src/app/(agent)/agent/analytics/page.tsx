"use client";

import React from "react";
import { cn } from "@/lib/utils/cn";
import {
  BarChart3,
  CheckCircle2,
  Star,
  Clock,
  Target,
  TrendingUp,
} from "lucide-react";

// ----- Inline types -----
interface PerfStat {
  label: string;
  value: string;
  icon: React.ElementType;
  color: string;
  bg: string;
}

interface ComparisonItem {
  label: string;
  you: number;
  team: number;
  max: number;
  unit: string;
}

interface Goal {
  label: string;
  current: number;
  target: number;
  met: boolean;
}

// ----- Mock data -----
const PERF_STATS: PerfStat[] = [
  {
    label: "Tickets Resolved",
    value: "47",
    icon: CheckCircle2,
    color: "text-linkedin-green",
    bg: "bg-green-50",
  },
  {
    label: "Avg CSAT",
    value: "4.6",
    icon: Star,
    color: "text-yellow-600",
    bg: "bg-yellow-50",
  },
  {
    label: "Avg Response Time",
    value: "2m 15s",
    icon: Clock,
    color: "text-linkedin-blue",
    bg: "bg-linkedin-blue-bg",
  },
  {
    label: "Resolution Rate",
    value: "94%",
    icon: Target,
    color: "text-purple-600",
    bg: "bg-purple-50",
  },
];

const COMPARISONS: ComparisonItem[] = [
  { label: "CSAT", you: 4.6, team: 4.2, max: 5, unit: "/5" },
  { label: "Response Time", you: 2.25, team: 3.5, max: 5, unit: " min" },
  { label: "Resolution Rate", you: 94, team: 87, max: 100, unit: "%" },
];

const GOALS: Goal[] = [
  { label: "Daily ticket target", current: 8, target: 10, met: false },
  { label: "CSAT target", current: 4.6, target: 4.5, met: true },
  { label: "First response under 3 min", current: 92, target: 90, met: true },
];

// ----- Page -----
export default function AgentAnalyticsPage() {
  return (
    <div className="page-container space-y-6">
      <div className="flex items-center gap-3">
        <BarChart3 className="h-6 w-6 text-linkedin-blue" />
        <h1 className="text-xl font-semibold text-linkedin-gray-90">
          My Performance
        </h1>
      </div>

      {/* Stats row */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {PERF_STATS.map((stat) => {
          const Icon = stat.icon;
          return (
            <div
              key={stat.label}
              className="rounded-lg border border-linkedin-gray-20 bg-linkedin-white p-4 shadow-card"
            >
              <div className="flex items-center gap-3">
                <div
                  className={cn(
                    "flex h-10 w-10 items-center justify-center rounded-full",
                    stat.bg,
                  )}
                >
                  <Icon className={cn("h-5 w-5", stat.color)} />
                </div>
                <div>
                  <p className="text-2xl font-bold text-linkedin-gray-90">
                    {stat.value}
                  </p>
                  <p className="text-xs text-linkedin-gray-50">{stat.label}</p>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Chart placeholder */}
      <div className="rounded-lg border border-linkedin-gray-20 bg-linkedin-white p-6 shadow-card">
        <h2 className="text-sm font-semibold text-linkedin-gray-90 mb-4">
          Performance Over Time
        </h2>
        <div className="flex h-48 items-center justify-center rounded-lg border-2 border-dashed border-linkedin-gray-20 bg-linkedin-gray-10">
          <div className="text-center">
            <TrendingUp className="mx-auto h-8 w-8 text-linkedin-gray-30" />
            <p className="mt-2 text-sm text-linkedin-gray-50">
              Chart: Resolution rate over past 30 days
            </p>
          </div>
        </div>
      </div>

      {/* Compared to Team */}
      <div className="rounded-lg border border-linkedin-gray-20 bg-linkedin-white p-6 shadow-card">
        <h2 className="text-sm font-semibold text-linkedin-gray-90 mb-4">
          Compared to Team
        </h2>
        <div className="space-y-5">
          {COMPARISONS.map((item) => {
            const youPercent = (item.you / item.max) * 100;
            const teamPercent = (item.team / item.max) * 100;
            return (
              <div key={item.label}>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium text-linkedin-gray-90">
                    {item.label}
                  </span>
                  <div className="flex items-center gap-4 text-xs text-linkedin-gray-50">
                    <span>
                      You:{" "}
                      <span className="font-semibold text-linkedin-blue">
                        {item.you}{item.unit}
                      </span>
                    </span>
                    <span>
                      Team:{" "}
                      <span className="font-semibold text-linkedin-gray-70">
                        {item.team}{item.unit}
                      </span>
                    </span>
                  </div>
                </div>
                <div className="space-y-1.5">
                  <div className="flex items-center gap-2">
                    <span className="w-8 text-xs text-linkedin-gray-50">You</span>
                    <div className="flex-1 h-3 rounded-full bg-linkedin-gray-10 overflow-hidden">
                      <div
                        className="h-full rounded-full bg-linkedin-blue transition-all"
                        style={{ width: `${youPercent}%` }}
                      />
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="w-8 text-xs text-linkedin-gray-50">Avg</span>
                    <div className="flex-1 h-3 rounded-full bg-linkedin-gray-10 overflow-hidden">
                      <div
                        className="h-full rounded-full bg-linkedin-gray-30 transition-all"
                        style={{ width: `${teamPercent}%` }}
                      />
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Goals */}
      <div className="rounded-lg border border-linkedin-gray-20 bg-linkedin-white p-6 shadow-card">
        <h2 className="text-sm font-semibold text-linkedin-gray-90 mb-4">
          Goals
        </h2>
        <div className="space-y-4">
          {GOALS.map((goal) => {
            const percent = Math.min(
              (goal.current / goal.target) * 100,
              100,
            );
            return (
              <div key={goal.label}>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-sm text-linkedin-gray-90">
                    {goal.label}
                  </span>
                  <span className="text-sm text-linkedin-gray-70">
                    {goal.current}/{goal.target}
                    {goal.met && (
                      <CheckCircle2 className="ml-1 inline h-4 w-4 text-linkedin-green" />
                    )}
                  </span>
                </div>
                <div className="h-2.5 rounded-full bg-linkedin-gray-10 overflow-hidden">
                  <div
                    className={cn(
                      "h-full rounded-full transition-all",
                      goal.met ? "bg-linkedin-green" : "bg-linkedin-blue",
                    )}
                    style={{ width: `${percent}%` }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
