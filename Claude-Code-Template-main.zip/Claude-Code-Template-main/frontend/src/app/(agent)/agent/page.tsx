"use client";

import React from "react";
import { cn } from "@/lib/utils/cn";
import {
  MessageSquare,
  Ticket,
  Clock,
  Star,
  TrendingUp,
  TrendingDown,
  ArrowRight,
  AlertTriangle,
  Inbox,
} from "lucide-react";

// ----- Inline types -----
interface StatCard {
  label: string;
  value: string;
  change: string;
  trend: "up" | "down" | "neutral";
  icon: React.ElementType;
  color: string;
  bg: string;
}

interface ActiveConversation {
  id: string;
  customerName: string;
  lastMessage: string;
  channel: string;
  waitTime: string;
  priority: "low" | "medium" | "high" | "urgent";
}

interface SlaBreach {
  id: string;
  ticketId: string;
  subject: string;
  breachIn: string;
  severity: "warning" | "critical";
}

// ----- Mock data -----
const STATS: StatCard[] = [
  {
    label: "Open Conversations",
    value: "12",
    change: "+3 from yesterday",
    trend: "up",
    icon: MessageSquare,
    color: "text-linkedin-blue",
    bg: "bg-linkedin-blue-bg",
  },
  {
    label: "Pending Tickets",
    value: "8",
    change: "-2 from yesterday",
    trend: "down",
    icon: Ticket,
    color: "text-linkedin-orange",
    bg: "bg-orange-50",
  },
  {
    label: "Avg Response Time",
    value: "2m 34s",
    change: "15% faster",
    trend: "down",
    icon: Clock,
    color: "text-linkedin-green",
    bg: "bg-green-50",
  },
  {
    label: "CSAT Score",
    value: "4.7",
    change: "+0.2 this week",
    trend: "up",
    icon: Star,
    color: "text-yellow-600",
    bg: "bg-yellow-50",
  },
];

const ACTIVE_CONVERSATIONS: ActiveConversation[] = [
  {
    id: "ac-1",
    customerName: "Sarah Johnson",
    lastMessage: "Thank you! How long will the refund take?",
    channel: "web",
    waitTime: "2m",
    priority: "high",
  },
  {
    id: "ac-2",
    customerName: "James Wilson",
    lastMessage: "I can't access the API dashboard since this morning.",
    channel: "email",
    waitTime: "5m",
    priority: "urgent",
  },
  {
    id: "ac-3",
    customerName: "Maria Garcia",
    lastMessage: "Can you help me set up the webhook?",
    channel: "whatsapp",
    waitTime: "1m",
    priority: "medium",
  },
  {
    id: "ac-4",
    customerName: "David Lee",
    lastMessage: "I need to update my billing information.",
    channel: "chat",
    waitTime: "8m",
    priority: "low",
  },
  {
    id: "ac-5",
    customerName: "Emma Brown",
    lastMessage: "The integration keeps failing with error 500.",
    channel: "email",
    waitTime: "12m",
    priority: "urgent",
  },
];

const SLA_BREACHES: SlaBreach[] = [
  {
    id: "sla-1",
    ticketId: "TKT-1045",
    subject: "API downtime report",
    breachIn: "15 min",
    severity: "critical",
  },
  {
    id: "sla-2",
    ticketId: "TKT-1043",
    subject: "Data export not working",
    breachIn: "45 min",
    severity: "warning",
  },
  {
    id: "sla-3",
    ticketId: "TKT-1040",
    subject: "Account access issue",
    breachIn: "1h 20m",
    severity: "warning",
  },
];

const PRIORITY_COLORS: Record<string, string> = {
  low: "bg-linkedin-gray-50",
  medium: "bg-linkedin-blue",
  high: "bg-linkedin-orange",
  urgent: "bg-linkedin-red",
};

export default function AgentDashboardPage() {
  return (
    <div className="page-container space-y-6">
      {/* Welcome */}
      <div className="rounded-lg border border-linkedin-gray-20 bg-linkedin-white p-6 shadow-card">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-xl font-semibold text-linkedin-gray-90">
              Welcome back, Mike
            </h1>
            <p className="mt-1 text-sm text-linkedin-gray-50">
              You have <span className="font-semibold text-linkedin-blue">12 active conversations</span> and{" "}
              <span className="font-semibold text-linkedin-orange">3 SLA alerts</span> today.
            </p>
          </div>
          <span className="inline-flex items-center gap-1.5 rounded-full bg-green-50 px-3 py-1 text-xs font-medium text-linkedin-green">
            <span className="h-2 w-2 rounded-full bg-linkedin-green" />
            Online
          </span>
        </div>
      </div>

      {/* Stats grid */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {STATS.map((stat) => {
          const Icon = stat.icon;
          return (
            <div
              key={stat.label}
              className="rounded-lg border border-linkedin-gray-20 bg-linkedin-white p-4 shadow-card"
            >
              <div className="flex items-center justify-between">
                <div className={cn("flex h-10 w-10 items-center justify-center rounded-full", stat.bg)}>
                  <Icon className={cn("h-5 w-5", stat.color)} />
                </div>
                <div className="flex items-center gap-1 text-xs">
                  {stat.trend === "up" ? (
                    <TrendingUp className="h-3 w-3 text-linkedin-green" />
                  ) : stat.trend === "down" ? (
                    <TrendingDown className="h-3 w-3 text-linkedin-green" />
                  ) : null}
                  <span className="text-linkedin-gray-50">{stat.change}</span>
                </div>
              </div>
              <p className="mt-3 text-2xl font-bold text-linkedin-gray-90">
                {stat.value}
              </p>
              <p className="mt-0.5 text-xs text-linkedin-gray-50">
                {stat.label}
              </p>
            </div>
          );
        })}
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        {/* Active conversations */}
        <div className="lg:col-span-2 rounded-lg border border-linkedin-gray-20 bg-linkedin-white shadow-card">
          <div className="flex items-center justify-between border-b border-linkedin-gray-20 px-4 py-3">
            <h2 className="text-sm font-semibold text-linkedin-gray-90">
              Active Conversations
            </h2>
            <a
              href="/inbox"
              className="inline-flex items-center gap-1 text-xs font-medium text-linkedin-blue hover:text-linkedin-blue-hover"
            >
              Go to Inbox
              <ArrowRight className="h-3 w-3" />
            </a>
          </div>
          <div className="divide-y divide-linkedin-gray-20">
            {ACTIVE_CONVERSATIONS.map((conv) => (
              <a
                key={conv.id}
                href={`/inbox/${conv.id}`}
                className="flex items-center gap-3 px-4 py-3 transition-colors hover:bg-linkedin-gray-10"
              >
                <div className="relative">
                  <span className="flex h-9 w-9 items-center justify-center rounded-full bg-linkedin-blue-bg text-xs font-semibold text-linkedin-blue">
                    {conv.customerName.split(" ").map((w) => w[0]).join("").slice(0, 2)}
                  </span>
                  <span
                    className={cn(
                      "absolute -right-0.5 -top-0.5 h-2.5 w-2.5 rounded-full border-2 border-linkedin-white",
                      PRIORITY_COLORS[conv.priority],
                    )}
                  />
                </div>
                <div className="flex min-w-0 flex-1 flex-col">
                  <span className="text-sm font-medium text-linkedin-gray-90">
                    {conv.customerName}
                  </span>
                  <span className="truncate text-xs text-linkedin-gray-50">
                    {conv.lastMessage}
                  </span>
                </div>
                <div className="flex shrink-0 flex-col items-end gap-0.5">
                  <span className="text-xs text-linkedin-gray-50">
                    {conv.waitTime} ago
                  </span>
                  <span className="rounded-full bg-linkedin-gray-10 px-1.5 py-0.5 text-[10px] text-linkedin-gray-50">
                    {conv.channel}
                  </span>
                </div>
              </a>
            ))}
          </div>
        </div>

        {/* SLA breaches */}
        <div className="rounded-lg border border-linkedin-gray-20 bg-linkedin-white shadow-card">
          <div className="flex items-center justify-between border-b border-linkedin-gray-20 px-4 py-3">
            <h2 className="text-sm font-semibold text-linkedin-gray-90">
              Upcoming SLA Breaches
            </h2>
            <a
              href="/tickets"
              className="inline-flex items-center gap-1 text-xs font-medium text-linkedin-blue hover:text-linkedin-blue-hover"
            >
              View Tickets
              <ArrowRight className="h-3 w-3" />
            </a>
          </div>
          <div className="divide-y divide-linkedin-gray-20">
            {SLA_BREACHES.map((sla) => (
              <div
                key={sla.id}
                className="flex items-start gap-3 px-4 py-3"
              >
                <AlertTriangle
                  className={cn(
                    "mt-0.5 h-4 w-4 shrink-0",
                    sla.severity === "critical"
                      ? "text-linkedin-red"
                      : "text-linkedin-orange",
                  )}
                />
                <div className="flex-1">
                  <p className="text-sm font-medium text-linkedin-gray-90">
                    {sla.ticketId}
                  </p>
                  <p className="text-xs text-linkedin-gray-50">
                    {sla.subject}
                  </p>
                </div>
                <span
                  className={cn(
                    "shrink-0 rounded-full px-2 py-0.5 text-xs font-semibold",
                    sla.severity === "critical"
                      ? "bg-red-50 text-linkedin-red"
                      : "bg-orange-50 text-linkedin-orange",
                  )}
                >
                  {sla.breachIn}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Quick actions */}
      <div className="flex flex-wrap gap-3">
        <a
          href="/inbox"
          className="inline-flex items-center gap-2 rounded-full bg-linkedin-blue px-5 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-linkedin-blue-hover"
        >
          <Inbox className="h-4 w-4" />
          Go to Inbox
        </a>
        <a
          href="/tickets"
          className="inline-flex items-center gap-2 rounded-full border border-linkedin-blue px-5 py-2.5 text-sm font-semibold text-linkedin-blue transition-colors hover:bg-linkedin-blue-bg"
        >
          <Ticket className="h-4 w-4" />
          View Tickets
        </a>
      </div>
    </div>
  );
}
