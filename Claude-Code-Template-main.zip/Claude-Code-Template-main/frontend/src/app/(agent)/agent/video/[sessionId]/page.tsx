"use client";

import React, { useState } from "react";
import { cn } from "@/lib/utils/cn";
import {
  Video,
  VideoOff,
  Mic,
  MicOff,
  Monitor,
  MessageSquare,
  PhoneOff,
  User,
  ChevronRight,
} from "lucide-react";

// ----- Mock data -----
const CUSTOMER_CONTEXT = {
  name: "Sarah Johnson",
  email: "sarah.johnson@techcorp.com",
  company: "TechCorp Inc.",
  plan: "Pro",
  openTickets: 2,
  lifetimeValue: "$12,400",
  lastInteraction: "2026-03-08",
};

// ----- Page -----
export default function AgentVideoRoomPage() {
  const [cameraOn, setCameraOn] = useState(true);
  const [micOn, setMicOn] = useState(true);
  const [screenSharing, setScreenSharing] = useState(false);
  const [chatOpen, setChatOpen] = useState(false);
  const [contextOpen, setContextOpen] = useState(false);

  return (
    <div className="flex h-screen flex-col bg-linkedin-gray-90">
      {/* Main area */}
      <div className="relative flex flex-1 overflow-hidden">
        {/* Video area */}
        <div className="flex flex-1 items-center justify-center">
          <div className="rounded-xl border border-white/10 bg-white/5 px-20 py-28 text-center">
            <Video className="mx-auto h-16 w-16 text-white/30" />
            <p className="mt-4 text-lg font-medium text-white/50">
              Customer Video Feed
            </p>
            <p className="mt-1 text-sm text-white/30">
              {CUSTOMER_CONTEXT.name}
            </p>
          </div>

          {/* Self-view */}
          <div className="absolute bottom-20 right-4 h-36 w-48 rounded-lg border border-white/10 bg-white/5 flex items-center justify-center">
            <div className="text-center">
              <User className="mx-auto h-8 w-8 text-white/30" />
              <p className="mt-1 text-xs text-white/40">Your Camera</p>
            </div>
          </div>
        </div>

        {/* Chat side panel */}
        {chatOpen && (
          <div className="w-80 flex flex-col border-l border-white/10 bg-linkedin-gray-90/95 backdrop-blur-sm">
            <div className="border-b border-white/10 px-4 py-3">
              <h3 className="text-sm font-semibold text-white">Chat</h3>
            </div>
            <div className="flex-1 overflow-y-auto p-4">
              <p className="text-center text-xs text-white/40">
                No messages yet
              </p>
            </div>
            <div className="border-t border-white/10 p-3">
              <input
                type="text"
                placeholder="Type a message..."
                className="w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm text-white placeholder:text-white/30 focus:border-linkedin-blue focus:outline-none"
              />
            </div>
          </div>
        )}

        {/* Customer context sidebar */}
        {contextOpen && (
          <div className="w-80 flex flex-col border-l border-white/10 bg-linkedin-gray-90/95 backdrop-blur-sm overflow-y-auto">
            <div className="border-b border-white/10 px-4 py-3">
              <h3 className="text-sm font-semibold text-white">
                Customer Context
              </h3>
            </div>
            <div className="p-4 space-y-4">
              <div>
                <p className="text-xs text-white/40">Name</p>
                <p className="text-sm text-white">{CUSTOMER_CONTEXT.name}</p>
              </div>
              <div>
                <p className="text-xs text-white/40">Email</p>
                <p className="text-sm text-white">{CUSTOMER_CONTEXT.email}</p>
              </div>
              <div>
                <p className="text-xs text-white/40">Company</p>
                <p className="text-sm text-white">{CUSTOMER_CONTEXT.company}</p>
              </div>
              <div>
                <p className="text-xs text-white/40">Plan</p>
                <p className="text-sm text-white">{CUSTOMER_CONTEXT.plan}</p>
              </div>
              <div className="border-t border-white/10 pt-4">
                <p className="text-xs text-white/40">Open Tickets</p>
                <p className="text-sm text-white">{CUSTOMER_CONTEXT.openTickets}</p>
              </div>
              <div>
                <p className="text-xs text-white/40">Lifetime Value</p>
                <p className="text-sm text-white">{CUSTOMER_CONTEXT.lifetimeValue}</p>
              </div>
              <div>
                <p className="text-xs text-white/40">Last Interaction</p>
                <p className="text-sm text-white">{CUSTOMER_CONTEXT.lastInteraction}</p>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Controls bar */}
      <div className="flex items-center justify-center gap-4 border-t border-white/10 bg-linkedin-gray-90 px-6 py-4">
        <button
          onClick={() => setCameraOn(!cameraOn)}
          className={cn(
            "flex h-12 w-12 items-center justify-center rounded-full transition-colors",
            cameraOn
              ? "bg-white/10 text-white hover:bg-white/20"
              : "bg-white/20 text-red-400 hover:bg-white/30",
          )}
          aria-label={cameraOn ? "Turn off camera" : "Turn on camera"}
        >
          {cameraOn ? <Video className="h-5 w-5" /> : <VideoOff className="h-5 w-5" />}
        </button>

        <button
          onClick={() => setMicOn(!micOn)}
          className={cn(
            "flex h-12 w-12 items-center justify-center rounded-full transition-colors",
            micOn
              ? "bg-white/10 text-white hover:bg-white/20"
              : "bg-white/20 text-red-400 hover:bg-white/30",
          )}
          aria-label={micOn ? "Mute microphone" : "Unmute microphone"}
        >
          {micOn ? <Mic className="h-5 w-5" /> : <MicOff className="h-5 w-5" />}
        </button>

        <button
          onClick={() => setScreenSharing(!screenSharing)}
          className={cn(
            "flex h-12 w-12 items-center justify-center rounded-full transition-colors",
            screenSharing
              ? "bg-linkedin-blue text-white"
              : "bg-white/10 text-white hover:bg-white/20",
          )}
          aria-label={screenSharing ? "Stop sharing screen" : "Share screen"}
        >
          <Monitor className="h-5 w-5" />
        </button>

        <button
          onClick={() => {
            setChatOpen(!chatOpen);
            if (contextOpen) setContextOpen(false);
          }}
          className={cn(
            "flex h-12 w-12 items-center justify-center rounded-full transition-colors",
            chatOpen
              ? "bg-linkedin-blue text-white"
              : "bg-white/10 text-white hover:bg-white/20",
          )}
          aria-label={chatOpen ? "Close chat" : "Open chat"}
        >
          <MessageSquare className="h-5 w-5" />
        </button>

        <button
          className="flex h-12 w-16 items-center justify-center rounded-full bg-red-600 text-white transition-colors hover:bg-red-700"
          aria-label="End call"
        >
          <PhoneOff className="h-5 w-5" />
        </button>

        <button
          onClick={() => {
            setContextOpen(!contextOpen);
            if (chatOpen) setChatOpen(false);
          }}
          className={cn(
            "flex h-12 w-12 items-center justify-center rounded-full transition-colors",
            contextOpen
              ? "bg-linkedin-blue text-white"
              : "bg-white/10 text-white hover:bg-white/20",
          )}
          aria-label={contextOpen ? "Close context" : "Show customer context"}
        >
          <ChevronRight className={cn("h-5 w-5 transition-transform", contextOpen && "rotate-180")} />
        </button>
      </div>
    </div>
  );
}
