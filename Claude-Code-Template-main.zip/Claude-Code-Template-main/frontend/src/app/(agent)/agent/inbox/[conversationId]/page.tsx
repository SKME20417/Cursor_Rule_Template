"use client";

import React, { useState } from "react";
import { cn } from "@/lib/utils/cn";
import { ChatWindow } from "@/components/chat/chat-window";
import { CopilotPanel } from "@/components/copilot/copilot-panel";
import {
  User,
  Mail,
  Phone,
  MapPin,
  Calendar,
  Tag,
  ExternalLink,
  UserPlus,
  ArrowRightLeft,
  CheckCircle2,
  AlertTriangle,
  ChevronDown,
  ChevronUp,
} from "lucide-react";

interface AgentConversationDetailProps {
  params: { conversationId: string };
}

// ----- Mock customer context -----
const CUSTOMER_CONTEXT = {
  name: "Sarah Johnson",
  email: "sarah.johnson@example.com",
  phone: "+1 (555) 123-4567",
  location: "San Francisco, CA",
  customerSince: "2024-06-15",
  plan: "Professional",
  totalTickets: 8,
  lifetime: "$1,247.00",
  tags: ["VIP", "Enterprise Trial"],
};

export default function AgentConversationDetailPage({
  params,
}: AgentConversationDetailProps) {
  const { conversationId } = params;
  const [showContext, setShowContext] = useState(true);

  return (
    <div className="flex h-[calc(100vh-64px)]">
      {/* Center: Chat window */}
      <div className="flex flex-1 flex-col">
        {/* Action bar */}
        <div className="flex items-center justify-between border-b border-linkedin-gray-20 bg-linkedin-white px-4 py-2">
          <div className="flex items-center gap-2">
            <button
              type="button"
              className="inline-flex items-center gap-1.5 rounded-full border border-linkedin-gray-20 px-3 py-1.5 text-xs font-medium text-linkedin-gray-70 transition-colors hover:bg-linkedin-gray-10"
            >
              <UserPlus className="h-3.5 w-3.5" />
              Assign
            </button>
            <button
              type="button"
              className="inline-flex items-center gap-1.5 rounded-full border border-linkedin-gray-20 px-3 py-1.5 text-xs font-medium text-linkedin-gray-70 transition-colors hover:bg-linkedin-gray-10"
            >
              <ArrowRightLeft className="h-3.5 w-3.5" />
              Transfer
            </button>
            <button
              type="button"
              className="inline-flex items-center gap-1.5 rounded-full border border-linkedin-green px-3 py-1.5 text-xs font-medium text-linkedin-green transition-colors hover:bg-green-50"
            >
              <CheckCircle2 className="h-3.5 w-3.5" />
              Resolve
            </button>
            <button
              type="button"
              className="inline-flex items-center gap-1.5 rounded-full border border-linkedin-orange px-3 py-1.5 text-xs font-medium text-linkedin-orange transition-colors hover:bg-orange-50"
            >
              <AlertTriangle className="h-3.5 w-3.5" />
              Escalate
            </button>
          </div>
        </div>

        <ChatWindow
          conversationId={conversationId}
          className="flex-1"
        />
      </div>

      {/* Right: Copilot + Customer context */}
      <div className="flex w-80 flex-col border-l border-linkedin-gray-20 bg-linkedin-white max-xl:hidden">
        {/* Customer context panel */}
        <div className="border-b border-linkedin-gray-20">
          <button
            type="button"
            onClick={() => setShowContext((s) => !s)}
            className="flex w-full items-center justify-between px-4 py-3"
          >
            <h3 className="text-xs font-semibold uppercase tracking-wider text-linkedin-gray-50">
              Customer Context
            </h3>
            {showContext ? (
              <ChevronUp className="h-4 w-4 text-linkedin-gray-50" />
            ) : (
              <ChevronDown className="h-4 w-4 text-linkedin-gray-50" />
            )}
          </button>

          {showContext && (
            <div className="space-y-3 px-4 pb-4">
              {/* Name + plan */}
              <div className="flex items-center gap-3">
                <span className="flex h-10 w-10 items-center justify-center rounded-full bg-linkedin-blue-bg text-sm font-semibold text-linkedin-blue">
                  SJ
                </span>
                <div>
                  <p className="text-sm font-semibold text-linkedin-gray-90">
                    {CUSTOMER_CONTEXT.name}
                  </p>
                  <span className="rounded-full bg-linkedin-blue-bg px-2 py-0.5 text-[10px] font-medium text-linkedin-blue">
                    {CUSTOMER_CONTEXT.plan}
                  </span>
                </div>
              </div>

              {/* Details */}
              <div className="space-y-2 text-xs text-linkedin-gray-70">
                <div className="flex items-center gap-2">
                  <Mail className="h-3.5 w-3.5 text-linkedin-gray-50" />
                  {CUSTOMER_CONTEXT.email}
                </div>
                <div className="flex items-center gap-2">
                  <Phone className="h-3.5 w-3.5 text-linkedin-gray-50" />
                  {CUSTOMER_CONTEXT.phone}
                </div>
                <div className="flex items-center gap-2">
                  <MapPin className="h-3.5 w-3.5 text-linkedin-gray-50" />
                  {CUSTOMER_CONTEXT.location}
                </div>
                <div className="flex items-center gap-2">
                  <Calendar className="h-3.5 w-3.5 text-linkedin-gray-50" />
                  Customer since{" "}
                  {new Date(CUSTOMER_CONTEXT.customerSince).toLocaleDateString(
                    undefined,
                    { month: "short", year: "numeric" },
                  )}
                </div>
              </div>

              {/* Stats */}
              <div className="flex gap-4">
                <div>
                  <p className="text-lg font-bold text-linkedin-gray-90">
                    {CUSTOMER_CONTEXT.totalTickets}
                  </p>
                  <p className="text-[10px] text-linkedin-gray-50">
                    Total Tickets
                  </p>
                </div>
                <div>
                  <p className="text-lg font-bold text-linkedin-gray-90">
                    {CUSTOMER_CONTEXT.lifetime}
                  </p>
                  <p className="text-[10px] text-linkedin-gray-50">
                    Lifetime Value
                  </p>
                </div>
              </div>

              {/* Tags */}
              <div className="flex flex-wrap gap-1">
                {CUSTOMER_CONTEXT.tags.map((tag) => (
                  <span
                    key={tag}
                    className="inline-flex items-center gap-1 rounded-full border border-linkedin-gray-20 px-2 py-0.5 text-[10px] font-medium text-linkedin-gray-70"
                  >
                    <Tag className="h-2.5 w-2.5" />
                    {tag}
                  </span>
                ))}
              </div>

              <a
                href={`/customers/${conversationId}`}
                className="inline-flex items-center gap-1 text-xs font-medium text-linkedin-blue hover:text-linkedin-blue-hover"
              >
                <ExternalLink className="h-3 w-3" />
                Full profile
              </a>
            </div>
          )}
        </div>

        {/* Copilot panel content (tabs inlined) */}
        <CopilotPanel className="flex-1 border-l-0" />
      </div>
    </div>
  );
}
