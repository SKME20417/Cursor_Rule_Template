"use client";

import React, { useState } from "react";
import { cn } from "@/lib/utils/cn";
import { ConversationList } from "@/components/chat/conversation-list";
import { ChatWindow } from "@/components/chat/chat-window";
import { CopilotPanel } from "@/components/copilot/copilot-panel";
import {
  SlidersHorizontal,
  ArrowUpDown,
  Bell,
} from "lucide-react";

// ----- Inline types -----
interface Conversation {
  id: string;
  customerName: string;
  customerAvatar?: string;
  lastMessage: string;
  timestamp: string;
  channel: string;
  unreadCount: number;
  priority: "low" | "medium" | "high" | "urgent";
  sentiment: "positive" | "neutral" | "negative";
  assignedTo?: string;
  isAiHandled?: boolean;
}

// ----- Mock data -----
const MOCK_CONVERSATIONS: Conversation[] = [
  {
    id: "conv-1",
    customerName: "Sarah Johnson",
    lastMessage: "Thank you! How long will the refund take?",
    timestamp: new Date(Date.now() - 1800000).toISOString(),
    channel: "web",
    unreadCount: 2,
    priority: "high",
    sentiment: "neutral",
    assignedTo: "current-agent",
  },
  {
    id: "conv-2",
    customerName: "James Wilson",
    lastMessage: "I can't access the API dashboard since this morning.",
    timestamp: new Date(Date.now() - 300000).toISOString(),
    channel: "email",
    unreadCount: 1,
    priority: "urgent",
    sentiment: "negative",
    assignedTo: "current-agent",
  },
  {
    id: "conv-3",
    customerName: "Maria Garcia",
    lastMessage: "Can you help me set up the webhook integration?",
    timestamp: new Date(Date.now() - 3600000).toISOString(),
    channel: "whatsapp",
    unreadCount: 0,
    priority: "medium",
    sentiment: "positive",
    assignedTo: "current-agent",
  },
  {
    id: "conv-4",
    customerName: "David Lee",
    lastMessage: "I need to update my billing information.",
    timestamp: new Date(Date.now() - 7200000).toISOString(),
    channel: "chat",
    unreadCount: 3,
    priority: "low",
    sentiment: "neutral",
  },
  {
    id: "conv-5",
    customerName: "Emma Brown",
    lastMessage: "The integration keeps failing with error 500.",
    timestamp: new Date(Date.now() - 600000).toISOString(),
    channel: "email",
    unreadCount: 0,
    priority: "urgent",
    sentiment: "negative",
    isAiHandled: true,
  },
  {
    id: "conv-6",
    customerName: "Alex Thompson",
    lastMessage: "Thanks for the help! Everything is working now.",
    timestamp: new Date(Date.now() - 14400000).toISOString(),
    channel: "web",
    unreadCount: 0,
    priority: "low",
    sentiment: "positive",
    assignedTo: "current-agent",
  },
  {
    id: "conv-7",
    customerName: "Nina Patel",
    lastMessage: "I'd like to upgrade my plan. What are the options?",
    timestamp: new Date(Date.now() - 900000).toISOString(),
    channel: "chat",
    unreadCount: 1,
    priority: "medium",
    sentiment: "positive",
    isAiHandled: true,
  },
];

export default function AgentInboxPage() {
  const [selectedId, setSelectedId] = useState<string>(MOCK_CONVERSATIONS[0].id);

  return (
    <div className="flex h-[calc(100vh-64px)]">
      {/* Conversation list sidebar */}
      <ConversationList
        conversations={MOCK_CONVERSATIONS}
        activeId={selectedId}
        onSelect={setSelectedId}
        className="w-80 shrink-0 max-lg:hidden"
      />

      {/* Chat window */}
      <div className="flex flex-1 flex-col">
        {/* Toolbar */}
        <div className="flex items-center justify-between border-b border-linkedin-gray-20 bg-linkedin-white px-4 py-2">
          <div className="flex items-center gap-2">
            <button
              type="button"
              className="inline-flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-medium text-linkedin-gray-50 transition-colors hover:bg-linkedin-gray-10 hover:text-linkedin-gray-70"
            >
              <SlidersHorizontal className="h-3.5 w-3.5" />
              Filter
            </button>
            <button
              type="button"
              className="inline-flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-medium text-linkedin-gray-50 transition-colors hover:bg-linkedin-gray-10 hover:text-linkedin-gray-70"
            >
              <ArrowUpDown className="h-3.5 w-3.5" />
              Sort
            </button>
          </div>
          <button
            type="button"
            className="relative flex h-8 w-8 items-center justify-center rounded-full text-linkedin-gray-50 transition-colors hover:bg-linkedin-gray-10 hover:text-linkedin-blue"
            aria-label="Notifications"
          >
            <Bell className="h-4 w-4" />
            <span className="absolute -right-0.5 -top-0.5 flex h-4 w-4 items-center justify-center rounded-full bg-linkedin-red text-[9px] font-bold text-white">
              3
            </span>
          </button>
        </div>

        <ChatWindow
          conversationId={selectedId}
          className="flex-1"
        />
      </div>

      {/* Copilot panel */}
      <CopilotPanel className="max-xl:hidden" />
    </div>
  );
}
