"use client";

import React, { useState } from "react";
import { cn } from "@/lib/utils/cn";
import {
  Send,
  StickyNote,
  Sparkles,
  ChevronLeft,
} from "lucide-react";
import { Avatar } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Card } from "@/components/ui/card";
import { TicketDetail } from "@/components/tickets/ticket-detail";
import { CustomerContextPanel } from "@/components/customers/customer-context-panel";
import { IntentBadge } from "@/components/nlp/intent-badge";
import { SentimentMeter } from "@/components/nlp/sentiment-meter";
import { UrgencyIndicator } from "@/components/nlp/urgency-indicator";
import { ClassificationDebug } from "@/components/nlp/classification-debug";

/* ------------------------------------------------------------------ */
/* Mock data                                                           */
/* ------------------------------------------------------------------ */

const MOCK_TICKET = {
  id: "t1",
  shortId: "T-1001",
  subject: "Cannot access billing dashboard",
  status: "in_progress" as const,
  priority: "high" as const,
  assignee: "Agent Mike",
  category: "Billing",
  tags: ["access-issue", "billing", "pro-plan"],
  slaDeadline: "2026-03-09T18:00:00Z",
  createdAt: "2026-03-08T10:00:00Z",
  updatedAt: "2026-03-09T08:30:00Z",
  timeline: [
    {
      id: "e1",
      type: "created" as const,
      description: "Ticket created via email",
      actor: "Sarah Chen",
      timestamp: "2026-03-08T10:00:00Z",
    },
    {
      id: "e2",
      type: "assigned" as const,
      description: "Auto-assigned to Agent Mike based on category",
      actor: "System",
      timestamp: "2026-03-08T10:02:00Z",
    },
    {
      id: "e3",
      type: "status_changed" as const,
      description: "Status changed to In Progress",
      actor: "Agent Mike",
      timestamp: "2026-03-08T11:30:00Z",
    },
    {
      id: "e4",
      type: "message_sent" as const,
      description: "Agent Mike replied to the customer",
      actor: "Agent Mike",
      timestamp: "2026-03-08T11:30:00Z",
    },
  ],
};

const MOCK_CUSTOMER = {
  name: "Sarah Chen",
  email: "sarah.chen@example.com",
  company: "TechCorp Inc.",
  plan: "Pro",
};

const MOCK_RECENT_TICKETS = [
  {
    id: "t3",
    shortId: "T-0998",
    subject: "Invoice not showing correct amount",
    status: "resolved" as const,
    date: "2026-03-01T10:00:00Z",
  },
  {
    id: "t4",
    shortId: "T-0950",
    subject: "Need to update payment method",
    status: "closed" as const,
    date: "2026-02-15T10:00:00Z",
  },
];

const MOCK_RECENT_CONVERSATIONS = [
  {
    id: "c1",
    summary: "Asked about upgrading to Enterprise plan",
    channel: "Chat",
    date: "2026-03-06T14:00:00Z",
  },
  {
    id: "c2",
    summary: "Inquired about team seat pricing",
    channel: "Email",
    date: "2026-02-28T09:00:00Z",
  },
];

const MOCK_ACCOUNT_INFO = [
  { label: "Plan", value: "Pro" },
  { label: "Seats", value: "15" },
  { label: "MRR", value: "$450" },
  { label: "Member since", value: "Jan 2025" },
];

const MOCK_COPILOT_SUGGESTIONS = [
  "I can see you're on the Pro plan. The billing dashboard access issue has been reported by a few customers recently due to a permission cache issue. I recommend clearing the permission cache for this user.",
  "The customer has had 2 previous billing-related tickets, both resolved successfully. Consider proactively offering a walkthrough of the billing dashboard.",
];

const MOCK_CLASSIFICATIONS = [
  { classifier: "Intent", value: "access_issue", confidence: 0.92 },
  { classifier: "Sentiment", value: "frustrated", confidence: 0.78 },
  { classifier: "Urgency", value: "high", confidence: 0.85 },
  { classifier: "Language", value: "en", confidence: 0.99 },
  { classifier: "Escalation Risk", value: "medium", confidence: 0.62 },
];

/* ------------------------------------------------------------------ */
/* Page                                                                */
/* ------------------------------------------------------------------ */

export default function AgentTicketDetailPage() {
  const [replyText, setReplyText] = useState("");
  const [isInternalNote, setIsInternalNote] = useState(false);

  return (
    <div className="mx-auto max-w-7xl px-4 py-8">
      {/* Back link */}
      <a
        href="/tickets"
        className="mb-4 inline-flex items-center gap-1 text-sm text-linkedin-blue hover:underline"
      >
        <ChevronLeft className="h-4 w-4" />
        Back to Queue
      </a>

      <div className="flex flex-col gap-6 xl:flex-row">
        {/* Left: Ticket detail + reply */}
        <div className="flex-1 min-w-0">
          <TicketDetail ticket={MOCK_TICKET} />

          {/* NLP indicators */}
          <Card padding="md" className="mt-6">
            <h3 className="mb-3 text-sm font-semibold text-linkedin-gray-90">
              AI Analysis
            </h3>
            <div className="flex flex-wrap items-center gap-3">
              <IntentBadge
                intent="access_issue"
                confidence={0.92}
                details={{
                  topIntents: [
                    { name: "access_issue", score: 0.92 },
                    { name: "billing_inquiry", score: 0.06 },
                    { name: "general_question", score: 0.02 },
                  ],
                  modelVersion: "v2.1.0",
                }}
              />
              <SentimentMeter value={-0.35} />
              <UrgencyIndicator level="high" />
            </div>

            <ClassificationDebug
              classifications={MOCK_CLASSIFICATIONS}
              modelVersion="nlp-v2.1.0"
              messageId="msg-a1b2c3"
              className="mt-4"
            />
          </Card>

          {/* Copilot suggestions */}
          <Card padding="md" className="mt-6">
            <h3 className="mb-3 flex items-center gap-2 text-sm font-semibold text-linkedin-gray-90">
              <Sparkles className="h-4 w-4 text-linkedin-orange" />
              Copilot Suggestions
            </h3>
            <ul className="space-y-2">
              {MOCK_COPILOT_SUGGESTIONS.map((suggestion, i) => (
                <li
                  key={i}
                  className="rounded-lg bg-orange-50 p-3 text-sm text-linkedin-gray-70"
                >
                  {suggestion}
                </li>
              ))}
            </ul>
          </Card>

          {/* Reply box */}
          <Card padding="md" className="mt-6">
            <div className="mb-3 flex gap-2">
              <button
                type="button"
                onClick={() => setIsInternalNote(false)}
                className={cn(
                  "flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-medium transition-colors",
                  !isInternalNote
                    ? "bg-linkedin-blue text-linkedin-white"
                    : "bg-linkedin-gray-20 text-linkedin-gray-70",
                )}
              >
                <Send className="h-3 w-3" />
                Reply
              </button>
              <button
                type="button"
                onClick={() => setIsInternalNote(true)}
                className={cn(
                  "flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-medium transition-colors",
                  isInternalNote
                    ? "bg-yellow-500 text-linkedin-white"
                    : "bg-linkedin-gray-20 text-linkedin-gray-70",
                )}
              >
                <StickyNote className="h-3 w-3" />
                Internal Note
              </button>
            </div>

            <Textarea
              placeholder={
                isInternalNote
                  ? "Add internal note (agents only)..."
                  : "Type your reply to the customer..."
              }
              value={replyText}
              onChange={(e) => setReplyText(e.target.value)}
              rows={4}
              autoResize
            />

            <div className="mt-3 flex justify-end">
              <Button
                disabled={!replyText.trim()}
                iconLeft={
                  isInternalNote ? (
                    <StickyNote className="h-4 w-4" />
                  ) : (
                    <Send className="h-4 w-4" />
                  )
                }
              >
                {isInternalNote ? "Add Note" : "Send Reply"}
              </Button>
            </div>
          </Card>
        </div>

        {/* Right: Customer context panel */}
        <aside className="w-full shrink-0 xl:w-80">
          <div className="sticky top-8">
            <CustomerContextPanel
              customer={MOCK_CUSTOMER}
              recentTickets={MOCK_RECENT_TICKETS}
              recentConversations={MOCK_RECENT_CONVERSATIONS}
              accountInfo={MOCK_ACCOUNT_INFO}
            />
          </div>
        </aside>
      </div>
    </div>
  );
}
