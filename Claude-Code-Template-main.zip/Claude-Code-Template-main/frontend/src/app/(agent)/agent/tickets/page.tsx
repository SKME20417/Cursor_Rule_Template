"use client";

import React, { useState } from "react";
import { UserCheck, Users, Inbox, RefreshCw } from "lucide-react";
import { Tabs } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Pagination } from "@/components/ui/pagination";
import { TicketList } from "@/components/tickets/ticket-list";
import { TicketFilters } from "@/components/tickets/ticket-filters";

/* ------------------------------------------------------------------ */
/* Mock data                                                           */
/* ------------------------------------------------------------------ */

const MOCK_TICKETS = [
  {
    id: "t1",
    shortId: "T-1001",
    subject: "Cannot access billing dashboard",
    customerName: "Sarah Chen",
    status: "in_progress" as const,
    priority: "high" as const,
    assignee: "Agent Mike",
    createdAt: "2026-03-09T08:30:00Z",
    slaDeadline: "2026-03-09T18:00:00Z",
    lastActivity: "2026-03-09T08:30:00Z",
    channel: "email",
  },
  {
    id: "t2",
    shortId: "T-1002",
    subject: "Feature request: dark mode support",
    customerName: "James Park",
    status: "created" as const,
    priority: "low" as const,
    createdAt: "2026-03-08T14:00:00Z",
    lastActivity: "2026-03-08T14:00:00Z",
    channel: "web",
  },
  {
    id: "t3",
    shortId: "T-1003",
    subject: "API rate limiting returning 429 errors",
    customerName: "Maria Garcia",
    status: "assigned" as const,
    priority: "critical" as const,
    assignee: "Agent Mike",
    createdAt: "2026-03-07T09:15:00Z",
    slaDeadline: "2026-03-09T09:15:00Z",
    lastActivity: "2026-03-09T07:00:00Z",
    channel: "chat",
  },
  {
    id: "t4",
    shortId: "T-1004",
    subject: "SSO integration not working with Okta",
    customerName: "David Kim",
    status: "in_progress" as const,
    priority: "high" as const,
    assignee: "Agent Lisa",
    createdAt: "2026-03-07T11:00:00Z",
    slaDeadline: "2026-03-10T11:00:00Z",
    lastActivity: "2026-03-09T06:30:00Z",
    channel: "email",
  },
  {
    id: "t5",
    shortId: "T-1005",
    subject: "How to export data in CSV format?",
    customerName: "Emily Watson",
    status: "resolved" as const,
    priority: "medium" as const,
    assignee: "Agent Mike",
    createdAt: "2026-03-05T16:45:00Z",
    lastActivity: "2026-03-08T10:00:00Z",
    channel: "phone",
  },
  {
    id: "t6",
    shortId: "T-1006",
    subject: "Webhook events not being delivered",
    customerName: "Alex Johnson",
    status: "created" as const,
    priority: "high" as const,
    createdAt: "2026-03-09T07:00:00Z",
    slaDeadline: "2026-03-09T19:00:00Z",
    lastActivity: "2026-03-09T07:00:00Z",
    channel: "email",
  },
];

const ASSIGNEE_OPTIONS = [
  { value: "agent-mike", label: "Agent Mike" },
  { value: "agent-lisa", label: "Agent Lisa" },
  { value: "agent-john", label: "Agent John" },
];

const TAB_ITEMS = [
  { key: "mine", label: "Assigned to Me", icon: <UserCheck className="h-4 w-4" /> },
  { key: "unassigned", label: "Unassigned", icon: <Inbox className="h-4 w-4" /> },
  { key: "all", label: "All", icon: <Users className="h-4 w-4" /> },
];

/* ------------------------------------------------------------------ */
/* Page                                                                */
/* ------------------------------------------------------------------ */

export default function AgentTicketQueuePage() {
  const [activeTab, setActiveTab] = useState("mine");
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [filters, setFilters] = useState({
    statuses: [] as string[],
    priorities: [] as string[],
    assignee: "",
    channel: "",
    dateFrom: "",
    dateTo: "",
  });

  const perPage = 20;

  // Filter by tab
  const tabFiltered = MOCK_TICKETS.filter((t) => {
    if (activeTab === "mine") return t.assignee === "Agent Mike";
    if (activeTab === "unassigned") return !t.assignee;
    return true;
  });

  // Apply filters
  const filtered = tabFiltered.filter((t) => {
    if (filters.statuses.length > 0 && !filters.statuses.includes(t.status)) return false;
    if (filters.priorities.length > 0 && !filters.priorities.includes(t.priority)) return false;
    if (filters.channel && t.channel !== filters.channel) return false;
    return true;
  });

  const totalPages = Math.max(1, Math.ceil(filtered.length / perPage));
  const paginated = filtered.slice(
    (currentPage - 1) * perPage,
    currentPage * perPage,
  );

  return (
    <div className="mx-auto max-w-7xl px-4 py-8">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold text-linkedin-gray-90">
          Ticket Queue
        </h1>
        <div className="flex items-center gap-2">
          {selectedIds.length > 0 && (
            <>
              <span className="text-sm text-linkedin-gray-50">
                {selectedIds.length} selected
              </span>
              <Button variant="secondary" size="sm">
                Assign
              </Button>
              <Button variant="secondary" size="sm">
                Change Status
              </Button>
            </>
          )}
          <Button
            variant="ghost"
            size="sm"
            iconLeft={<RefreshCw className="h-4 w-4" />}
          >
            Refresh
          </Button>
        </div>
      </div>

      {/* Tabs */}
      <Tabs
        items={TAB_ITEMS}
        activeKey={activeTab}
        onChange={(key) => {
          setActiveTab(key);
          setSelectedIds([]);
          setCurrentPage(1);
        }}
        className="mb-4"
      />

      {/* Filters */}
      <TicketFilters
        filters={filters}
        onChange={(f) => {
          setFilters(f);
          setCurrentPage(1);
        }}
        assigneeOptions={ASSIGNEE_OPTIONS}
        className="mb-4"
      />

      {/* Ticket table */}
      <TicketList
        tickets={paginated}
        selectedIds={selectedIds}
        onSelectionChange={setSelectedIds}
        onRowClick={(id) => {
          /* navigate to /tickets/[id] */
        }}
      />

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="mt-6 flex justify-center">
          <Pagination
            currentPage={currentPage}
            totalPages={totalPages}
            onPageChange={setCurrentPage}
          />
        </div>
      )}
    </div>
  );
}
