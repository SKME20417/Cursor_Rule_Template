"use client";

import React, { useState } from "react";
import { cn } from "@/lib/utils/cn";
import {
  ChevronRight,
  ThumbsUp,
  ThumbsDown,
  BookOpen,
  Bookmark,
  Copy,
  FileInput,
  Clock,
  User,
} from "lucide-react";

// ----- Mock data -----
const MOCK_ARTICLE = {
  id: "art-1",
  title: "How to reset your password",
  category: "Account & Billing",
  categorySlug: "account-billing",
  author: "Support Team",
  updatedAt: "2026-02-15",
  readTime: "3 min read",
  content: `## Steps to Reset Your Password

If you've forgotten your password or need to change it, follow these steps:

### Method 1: From the Login Page

1. Navigate to the login page at app.example.com/login
2. Click the "Forgot Password?" link below the password field
3. Enter the email address associated with your account
4. Check your email for a password reset link
5. Click the link and enter your new password

### Method 2: From Account Settings

If you're already logged in:

1. Go to Settings > Security
2. Click "Change Password"
3. Enter your current password
4. Enter and confirm your new password
5. Click "Update Password"

### Troubleshooting

- Didn't receive the email? Check your spam/junk folder
- Link expired? Password reset links expire after 1 hour
- Still having issues? Contact our support team

### Security Tips

- Use a unique password not shared with other services
- Consider using a password manager
- Enable two-factor authentication for extra security`,
};

const RELATED_ARTICLES = [
  { id: "art-20", title: "Setting up two-factor authentication" },
  { id: "art-21", title: "Managing account security settings" },
  { id: "art-22", title: "What to do if your account is compromised" },
];

// ----- Helpers -----
function renderMarkdown(content: string): React.ReactNode[] {
  const lines = content.split("\n");
  const elements: React.ReactNode[] = [];

  lines.forEach((line, i) => {
    if (line.startsWith("## ")) {
      elements.push(
        <h2 key={i} className="mt-8 mb-3 text-lg font-semibold text-linkedin-gray-90">
          {line.replace("## ", "")}
        </h2>,
      );
    } else if (line.startsWith("### ")) {
      elements.push(
        <h3 key={i} className="mt-6 mb-2 text-base font-semibold text-linkedin-gray-90">
          {line.replace("### ", "")}
        </h3>,
      );
    } else if (line.match(/^\d+\./)) {
      elements.push(
        <p key={i} className="ml-4 my-1 text-sm text-linkedin-gray-70">
          {line}
        </p>,
      );
    } else if (line.startsWith("- ")) {
      elements.push(
        <li key={i} className="ml-6 my-1 text-sm text-linkedin-gray-70 list-disc">
          {line.replace("- ", "")}
        </li>,
      );
    } else if (line.trim() === "") {
      elements.push(<div key={i} className="h-2" />);
    } else {
      elements.push(
        <p key={i} className="my-1 text-sm text-linkedin-gray-70">
          {line}
        </p>,
      );
    }
  });

  return elements;
}

// ----- Page -----
export default function AgentArticleViewPage() {
  const [feedback, setFeedback] = useState<"up" | "down" | null>(null);
  const [bookmarked, setBookmarked] = useState(false);
  const [copied, setCopied] = useState(false);

  function handleCopyLink() {
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }

  return (
    <div className="mx-auto max-w-3xl px-4 py-8">
      {/* Breadcrumb */}
      <nav className="mb-6 flex items-center gap-1.5 text-sm text-linkedin-gray-50">
        <a href="/knowledge-base" className="hover:text-linkedin-blue transition-colors">
          Knowledge Base
        </a>
        <ChevronRight className="h-3.5 w-3.5" />
        <a
          href={`/knowledge-base/${MOCK_ARTICLE.categorySlug}`}
          className="hover:text-linkedin-blue transition-colors"
        >
          {MOCK_ARTICLE.category}
        </a>
        <ChevronRight className="h-3.5 w-3.5" />
        <span className="font-medium text-linkedin-gray-90">
          {MOCK_ARTICLE.title}
        </span>
      </nav>

      {/* Agent action bar */}
      <div className="mb-4 flex flex-wrap items-center gap-2">
        <button className="inline-flex items-center gap-1.5 rounded-full bg-linkedin-blue px-4 py-2 text-sm font-semibold text-white transition-colors hover:bg-linkedin-blue-hover">
          <FileInput className="h-4 w-4" />
          Insert into Reply
        </button>
        <button
          onClick={handleCopyLink}
          className="inline-flex items-center gap-1.5 rounded-full border border-linkedin-gray-30 px-4 py-2 text-sm font-medium text-linkedin-gray-70 transition-colors hover:bg-linkedin-gray-10"
        >
          <Copy className="h-4 w-4" />
          {copied ? "Copied!" : "Copy Link"}
        </button>
        <button
          onClick={() => setBookmarked(!bookmarked)}
          className={cn(
            "inline-flex items-center gap-1.5 rounded-full border px-4 py-2 text-sm font-medium transition-colors",
            bookmarked
              ? "border-linkedin-orange bg-orange-50 text-linkedin-orange"
              : "border-linkedin-gray-30 text-linkedin-gray-70 hover:bg-linkedin-gray-10",
          )}
        >
          <Bookmark className={cn("h-4 w-4", bookmarked && "fill-linkedin-orange")} />
          {bookmarked ? "Pinned" : "Pin"}
        </button>
      </div>

      {/* Article content */}
      <div className="rounded-lg border border-linkedin-gray-20 bg-linkedin-white p-6 shadow-card">
        <h1 className="text-2xl font-bold text-linkedin-gray-90">
          {MOCK_ARTICLE.title}
        </h1>
        <div className="mt-2 flex flex-wrap items-center gap-4 text-xs text-linkedin-gray-50">
          <span className="inline-flex items-center gap-1">
            <User className="h-3 w-3" />
            {MOCK_ARTICLE.author}
          </span>
          <span>Updated {MOCK_ARTICLE.updatedAt}</span>
          <span className="inline-flex items-center gap-1">
            <Clock className="h-3 w-3" />
            {MOCK_ARTICLE.readTime}
          </span>
        </div>

        <div className="mt-6">{renderMarkdown(MOCK_ARTICLE.content)}</div>
      </div>

      {/* Feedback */}
      <div className="mt-6 rounded-lg border border-linkedin-gray-20 bg-linkedin-white p-6 shadow-card">
        <div className="flex items-center justify-between">
          <span className="text-sm font-medium text-linkedin-gray-90">
            Was this article helpful?
          </span>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setFeedback("up")}
              className={cn(
                "flex h-9 w-9 items-center justify-center rounded-full border transition-colors",
                feedback === "up"
                  ? "border-linkedin-green bg-green-50 text-linkedin-green"
                  : "border-linkedin-gray-30 text-linkedin-gray-50 hover:bg-linkedin-gray-10",
              )}
            >
              <ThumbsUp className="h-4 w-4" />
            </button>
            <button
              onClick={() => setFeedback("down")}
              className={cn(
                "flex h-9 w-9 items-center justify-center rounded-full border transition-colors",
                feedback === "down"
                  ? "border-linkedin-red bg-red-50 text-linkedin-red"
                  : "border-linkedin-gray-30 text-linkedin-gray-50 hover:bg-linkedin-gray-10",
              )}
            >
              <ThumbsDown className="h-4 w-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Related articles */}
      <div className="mt-6 rounded-lg border border-linkedin-gray-20 bg-linkedin-white shadow-card">
        <div className="border-b border-linkedin-gray-20 px-4 py-3">
          <h3 className="flex items-center gap-2 text-sm font-semibold text-linkedin-gray-90">
            <BookOpen className="h-4 w-4 text-linkedin-blue" />
            Related Articles
          </h3>
        </div>
        <div className="divide-y divide-linkedin-gray-20">
          {RELATED_ARTICLES.map((article) => (
            <a
              key={article.id}
              href={`/knowledge-base/${article.id}`}
              className="flex items-center gap-2 px-4 py-3 text-sm text-linkedin-blue transition-colors hover:bg-linkedin-gray-10"
            >
              <BookOpen className="h-3.5 w-3.5 shrink-0 text-linkedin-gray-50" />
              {article.title}
            </a>
          ))}
        </div>
      </div>
    </div>
  );
}
