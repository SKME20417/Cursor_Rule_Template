"use client";

import React, { useState } from "react";
import { cn } from "@/lib/utils/cn";
import {
  Search,
  BookOpen,
  Bookmark,
  CreditCard,
  Wrench,
  Puzzle,
  Code,
  AlertCircle,
  Clock,
} from "lucide-react";

// ----- Inline types -----
interface PinnedArticle {
  id: string;
  title: string;
  category: string;
}

interface KBCategory {
  slug: string;
  label: string;
  icon: React.ElementType;
  articleCount: number;
  color: string;
  bg: string;
}

interface RecentArticle {
  id: string;
  title: string;
  category: string;
  viewedAt: string;
}

// ----- Mock data -----
const PINNED_ARTICLES: PinnedArticle[] = [
  {
    id: "art-1",
    title: "Troubleshooting SSO login failures",
    category: "Technical Support",
  },
  {
    id: "art-2",
    title: "How to process a refund",
    category: "Account & Billing",
  },
  {
    id: "art-3",
    title: "API rate limits and best practices",
    category: "API Docs",
  },
];

const CATEGORIES: KBCategory[] = [
  {
    slug: "getting-started",
    label: "Getting Started",
    icon: BookOpen,
    articleCount: 12,
    color: "text-linkedin-blue",
    bg: "bg-linkedin-blue-bg",
  },
  {
    slug: "account-billing",
    label: "Account & Billing",
    icon: CreditCard,
    articleCount: 8,
    color: "text-linkedin-green",
    bg: "bg-green-50",
  },
  {
    slug: "technical-support",
    label: "Technical Support",
    icon: Wrench,
    articleCount: 15,
    color: "text-linkedin-orange",
    bg: "bg-orange-50",
  },
  {
    slug: "integrations",
    label: "Integrations",
    icon: Puzzle,
    articleCount: 22,
    color: "text-purple-600",
    bg: "bg-purple-50",
  },
  {
    slug: "api-docs",
    label: "API Docs",
    icon: Code,
    articleCount: 18,
    color: "text-cyan-600",
    bg: "bg-cyan-50",
  },
  {
    slug: "troubleshooting",
    label: "Troubleshooting",
    icon: AlertCircle,
    articleCount: 10,
    color: "text-linkedin-red",
    bg: "bg-red-50",
  },
];

const RECENTLY_VIEWED: RecentArticle[] = [
  {
    id: "art-5",
    title: "Setting up webhooks for real-time events",
    category: "Integrations",
    viewedAt: "10 min ago",
  },
  {
    id: "art-6",
    title: "Managing team permissions",
    category: "Getting Started",
    viewedAt: "1 hour ago",
  },
  {
    id: "art-7",
    title: "Debugging failed email deliveries",
    category: "Troubleshooting",
    viewedAt: "3 hours ago",
  },
  {
    id: "art-8",
    title: "Understanding invoice line items",
    category: "Account & Billing",
    viewedAt: "Yesterday",
  },
];

// ----- Page -----
export default function AgentKnowledgeBasePage() {
  const [query, setQuery] = useState("");

  return (
    <div className="page-container space-y-6">
      <div className="flex items-center gap-3">
        <BookOpen className="h-6 w-6 text-linkedin-blue" />
        <h1 className="text-xl font-semibold text-linkedin-gray-90">
          Knowledge Base
        </h1>
      </div>

      {/* Search bar */}
      <div className="relative">
        <Search className="pointer-events-none absolute left-4 top-1/2 h-5 w-5 -translate-y-1/2 text-linkedin-gray-50" />
        <input
          type="text"
          placeholder="Search articles, guides, and documentation..."
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          className="w-full rounded-lg border border-linkedin-gray-30 bg-linkedin-white py-3 pl-12 pr-4 text-sm text-linkedin-gray-90 shadow-card placeholder:text-linkedin-gray-50 focus:border-linkedin-blue focus:outline-none focus:ring-1 focus:ring-linkedin-blue"
        />
      </div>

      {/* Pinned Articles */}
      <section>
        <h2 className="mb-3 flex items-center gap-2 text-sm font-semibold text-linkedin-gray-90">
          <Bookmark className="h-4 w-4 text-linkedin-orange" />
          Pinned Articles
        </h2>
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
          {PINNED_ARTICLES.map((article) => (
            <a
              key={article.id}
              href={`/knowledge-base/${article.id}`}
              className="rounded-lg border border-linkedin-gray-20 bg-linkedin-white p-4 shadow-card transition-shadow hover:shadow-md"
            >
              <div className="flex items-start gap-2">
                <Bookmark className="mt-0.5 h-4 w-4 shrink-0 fill-linkedin-orange text-linkedin-orange" />
                <div>
                  <p className="text-sm font-medium text-linkedin-gray-90">
                    {article.title}
                  </p>
                  <p className="mt-1 text-xs text-linkedin-gray-50">
                    {article.category}
                  </p>
                </div>
              </div>
            </a>
          ))}
        </div>
      </section>

      {/* Browse Categories */}
      <section>
        <h2 className="mb-3 text-sm font-semibold text-linkedin-gray-90">
          Browse Categories
        </h2>
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {CATEGORIES.map((cat) => {
            const Icon = cat.icon;
            return (
              <a
                key={cat.slug}
                href={`/knowledge-base/${cat.slug}`}
                className="flex items-center gap-3 rounded-lg border border-linkedin-gray-20 bg-linkedin-white p-4 shadow-card transition-shadow hover:shadow-md"
              >
                <div
                  className={cn(
                    "flex h-10 w-10 shrink-0 items-center justify-center rounded-full",
                    cat.bg,
                  )}
                >
                  <Icon className={cn("h-5 w-5", cat.color)} />
                </div>
                <div>
                  <p className="text-sm font-semibold text-linkedin-gray-90">
                    {cat.label}
                  </p>
                  <p className="text-xs text-linkedin-gray-50">
                    {cat.articleCount} articles
                  </p>
                </div>
              </a>
            );
          })}
        </div>
      </section>

      {/* Recently Viewed */}
      <section>
        <h2 className="mb-3 flex items-center gap-2 text-sm font-semibold text-linkedin-gray-90">
          <Clock className="h-4 w-4 text-linkedin-gray-50" />
          Recently Viewed
        </h2>
        <div className="rounded-lg border border-linkedin-gray-20 bg-linkedin-white shadow-card divide-y divide-linkedin-gray-20">
          {RECENTLY_VIEWED.map((article) => (
            <a
              key={article.id}
              href={`/knowledge-base/${article.id}`}
              className="flex items-center justify-between px-4 py-3 transition-colors hover:bg-linkedin-gray-10"
            >
              <div className="flex items-center gap-2">
                <BookOpen className="h-4 w-4 shrink-0 text-linkedin-gray-50" />
                <div>
                  <p className="text-sm font-medium text-linkedin-gray-90">
                    {article.title}
                  </p>
                  <p className="text-xs text-linkedin-gray-50">
                    {article.category}
                  </p>
                </div>
              </div>
              <span className="shrink-0 text-xs text-linkedin-gray-50">
                {article.viewedAt}
              </span>
            </a>
          ))}
        </div>
      </section>
    </div>
  );
}
