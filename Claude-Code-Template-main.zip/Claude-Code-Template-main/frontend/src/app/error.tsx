"use client";

import React from "react";
import { AlertTriangle } from "lucide-react";

interface ErrorPageProps {
  error: Error & { digest?: string };
  reset: () => void;
}

export default function ErrorPage({ error, reset }: ErrorPageProps) {
  return (
    <div className="flex min-h-screen items-center justify-center bg-linkedin-gray-05 px-4">
      <div className="max-w-md rounded-lg border border-linkedin-gray-20 bg-linkedin-white p-8 shadow-card text-center">
        <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-red-50">
          <AlertTriangle className="h-7 w-7 text-linkedin-red" />
        </div>

        <h1 className="mt-4 text-xl font-bold text-linkedin-gray-90">
          Something went wrong
        </h1>
        <p className="mt-2 text-sm text-linkedin-gray-50">
          {error.message ||
            "An unexpected error occurred. Please try again or contact support."}
        </p>

        {error.digest && (
          <p className="mt-2 text-xs text-linkedin-gray-30">
            Error reference: {error.digest}
          </p>
        )}

        <button
          onClick={reset}
          className="mt-6 inline-flex items-center justify-center rounded-full bg-linkedin-blue px-6 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-linkedin-blue-hover"
        >
          Try again
        </button>
      </div>
    </div>
  );
}
