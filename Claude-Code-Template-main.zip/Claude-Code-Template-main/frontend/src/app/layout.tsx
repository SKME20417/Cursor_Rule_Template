import type { Metadata, Viewport } from "next";
import { AuthProvider } from "@/providers/auth-provider";
import { QueryProvider } from "@/providers/query-provider";
import { WebSocketProvider } from "@/providers/websocket-provider";
import { NotificationProvider } from "@/providers/notification-provider";
import { ToastProvider } from "@/providers/toast-provider";
import { LocaleProvider } from "@/providers/locale-provider";
import "./globals.css";

export const metadata: Metadata = {
  title: "AI Support Copilot",
  description:
    "AI-powered customer support platform with intelligent routing, real-time chat, and agent copilot assistance.",
  manifest: "/manifest.json",
};

export const viewport: Viewport = {
  themeColor: "#0a66c2",
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body className="font-sans antialiased">
        <QueryProvider>
          <AuthProvider>
            <WebSocketProvider>
              <LocaleProvider>
                <NotificationProvider>
                  <ToastProvider>
                    {children}
                  </ToastProvider>
                </NotificationProvider>
              </LocaleProvider>
            </WebSocketProvider>
          </AuthProvider>
        </QueryProvider>
      </body>
    </html>
  );
}
