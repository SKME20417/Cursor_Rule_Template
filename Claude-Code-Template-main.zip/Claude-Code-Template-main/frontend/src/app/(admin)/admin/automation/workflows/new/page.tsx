"use client";

import React, { useState } from "react";
import {
  Zap,
  GitBranch,
  Mail,
  Bell,
  Users,
  Clock,
  MessageSquare,
  Tag,
  Save,
  Play,
} from "lucide-react";
import { cn } from "@/lib/utils/cn";
import { Card, CardBody, CardHeader } from "@/components/ui/card";
import { PageHeader } from "@/components/layout/page-header";

/* ------------------------------------------------------------------ */
/* Mock Data                                                           */
/* ------------------------------------------------------------------ */

const triggers = [
  { name: "New Ticket", icon: Zap },
  { name: "Sentiment Change", icon: GitBranch },
  { name: "SLA Threshold", icon: Clock },
  { name: "Customer Message", icon: MessageSquare },
  { name: "Tag Applied", icon: Tag },
];

const actions = [
  { name: "Send Email", icon: Mail },
  { name: "Send Notification", icon: Bell },
  { name: "Assign to Team", icon: Users },
  { name: "Auto-Reply", icon: MessageSquare },
  { name: "Add Tag", icon: Tag },
];

/* ------------------------------------------------------------------ */
/* Page                                                                */
/* ------------------------------------------------------------------ */

export default function NewWorkflowPage() {
  const [name, setName] = useState("");

  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="New Workflow"
        subtitle="Create a new automation workflow"
        actions={
          <div className="flex items-center gap-2">
            <button className="inline-flex items-center gap-2 rounded-lg border border-linkedin-gray-30 bg-white px-4 py-2 text-sm font-medium text-linkedin-gray-70 hover:bg-linkedin-gray-10 transition-colors">
              <Save className="h-4 w-4" />
              Save
            </button>
            <button className="inline-flex items-center gap-2 rounded-lg bg-linkedin-green px-4 py-2 text-sm font-medium text-white hover:opacity-90 transition-opacity">
              <Play className="h-4 w-4" />
              Activate
            </button>
          </div>
        }
      />

      <Card>
        <CardBody>
          <div className="flex flex-col gap-1">
            <label className="text-sm font-medium text-linkedin-gray-90">Workflow Name</label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Enter workflow name..."
              className="w-full rounded-lg border border-linkedin-gray-30 bg-white px-3 py-2 text-sm text-linkedin-gray-90 focus:border-linkedin-blue focus:outline-none focus:ring-1 focus:ring-linkedin-blue"
            />
          </div>
        </CardBody>
      </Card>

      <div className="grid gap-6 lg:grid-cols-4">
        {/* Left Sidebar */}
        <div className="flex flex-col gap-4">
          <Card padding="none">
            <CardHeader>Triggers</CardHeader>
            <CardBody className="flex flex-col gap-1">
              {triggers.map((t) => (
                <div
                  key={t.name}
                  className="flex items-center gap-2 rounded-md px-3 py-2 text-sm text-linkedin-gray-70 hover:bg-linkedin-blue-bg hover:text-linkedin-blue cursor-grab transition-colors"
                >
                  <t.icon className="h-4 w-4" />
                  {t.name}
                </div>
              ))}
            </CardBody>
          </Card>

          <Card padding="none">
            <CardHeader>Actions</CardHeader>
            <CardBody className="flex flex-col gap-1">
              {actions.map((a) => (
                <div
                  key={a.name}
                  className="flex items-center gap-2 rounded-md px-3 py-2 text-sm text-linkedin-gray-70 hover:bg-linkedin-blue-bg hover:text-linkedin-blue cursor-grab transition-colors"
                >
                  <a.icon className="h-4 w-4" />
                  {a.name}
                </div>
              ))}
            </CardBody>
          </Card>
        </div>

        {/* Canvas */}
        <div className="lg:col-span-3">
          <Card padding="none">
            <CardHeader>Workflow Canvas</CardHeader>
            <CardBody>
              <div
                className="flex items-center justify-center rounded-lg border-2 border-dashed border-linkedin-gray-20 bg-linkedin-gray-10"
                style={{
                  height: 500,
                  backgroundImage: "radial-gradient(circle, #d1d5db 1px, transparent 1px)",
                  backgroundSize: "20px 20px",
                }}
              >
                <p className="text-sm text-linkedin-gray-50">
                  Drag and drop workflow steps here
                </p>
              </div>
            </CardBody>
          </Card>
        </div>
      </div>
    </div>
  );
}
