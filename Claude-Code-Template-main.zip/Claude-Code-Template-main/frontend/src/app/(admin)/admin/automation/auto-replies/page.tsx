"use client";

import React, { useState } from "react";
import { Plus, ChevronDown, ChevronUp, MessageSquare } from "lucide-react";
import { cn } from "@/lib/utils/cn";
import { Card, CardBody, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { PageHeader } from "@/components/layout/page-header";

/* ------------------------------------------------------------------ */
/* Mock Data                                                           */
/* ------------------------------------------------------------------ */

const templates = [
  {
    name: "Welcome Message",
    trigger: "First customer message",
    active: true,
    preview: "Hello! Welcome to our support. We're here to help you with anything you need. A team member will be with you shortly.",
  },
  {
    name: "Off-Hours Reply",
    trigger: "Message outside business hours",
    active: true,
    preview: "Thank you for reaching out! Our team is currently offline. We'll get back to you first thing in the morning. In the meantime, check our FAQ.",
  },
  {
    name: "Ticket Acknowledgment",
    trigger: "New ticket created",
    active: true,
    preview: "We've received your support request and created ticket #{{ticket_id}}. Our team will review it shortly. Expected response time: 2 hours.",
  },
  {
    name: "FAQ Auto-Response",
    trigger: "FAQ match confidence > 90%",
    active: false,
    preview: "Based on your question, here's what we found in our knowledge base: {{kb_article}}. Did this answer your question?",
  },
];

/* ------------------------------------------------------------------ */
/* Page                                                                */
/* ------------------------------------------------------------------ */

export default function AutoRepliesPage() {
  const [expanded, setExpanded] = useState<string | null>(null);
  const [items, setItems] = useState(templates);

  const toggleExpand = (name: string) => {
    setExpanded(expanded === name ? null : name);
  };

  const toggleActive = (name: string) => {
    setItems((prev) =>
      prev.map((t) => (t.name === name ? { ...t, active: !t.active } : t))
    );
  };

  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="Auto-Replies"
        subtitle="Configure automatic response templates"
        actions={
          <button className="inline-flex items-center gap-2 rounded-lg bg-linkedin-blue px-4 py-2 text-sm font-medium text-white hover:bg-linkedin-blue-dark transition-colors">
            <Plus className="h-4 w-4" />
            Create Template
          </button>
        }
      />

      <div className="flex flex-col gap-4">
        {items.map((tpl) => (
          <Card key={tpl.name} padding="none">
            <div
              className="flex items-center justify-between px-4 py-3 cursor-pointer hover:bg-linkedin-gray-10 transition-colors"
              onClick={() => toggleExpand(tpl.name)}
            >
              <div className="flex items-center gap-3">
                <MessageSquare className="h-4 w-4 text-linkedin-blue" />
                <div>
                  <h3 className="text-sm font-semibold text-linkedin-gray-90">{tpl.name}</h3>
                  <p className="text-xs text-linkedin-gray-50">{tpl.trigger}</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    toggleActive(tpl.name);
                  }}
                  className={cn(
                    "relative inline-flex h-5 w-9 items-center rounded-full transition-colors",
                    tpl.active ? "bg-linkedin-green" : "bg-linkedin-gray-30"
                  )}
                >
                  <span className={cn(
                    "inline-block h-3.5 w-3.5 rounded-full bg-white transition-transform",
                    tpl.active ? "translate-x-4" : "translate-x-0.5"
                  )} />
                </button>
                {expanded === tpl.name ? (
                  <ChevronUp className="h-4 w-4 text-linkedin-gray-50" />
                ) : (
                  <ChevronDown className="h-4 w-4 text-linkedin-gray-50" />
                )}
              </div>
            </div>
            {expanded === tpl.name && (
              <CardBody className="border-t border-linkedin-gray-20">
                <div className="flex flex-col gap-3">
                  <div>
                    <label className="text-xs font-medium text-linkedin-gray-50 uppercase tracking-wider">Response Preview</label>
                    <div className="mt-1 rounded-lg bg-linkedin-gray-10 p-3 text-sm text-linkedin-gray-70">
                      {tpl.preview}
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <button className="inline-flex items-center gap-1 rounded-lg bg-linkedin-blue px-3 py-1.5 text-xs font-medium text-white hover:bg-linkedin-blue-dark transition-colors">
                      Edit Template
                    </button>
                    <button className="inline-flex items-center gap-1 rounded-lg border border-linkedin-gray-30 bg-white px-3 py-1.5 text-xs font-medium text-linkedin-gray-70 hover:bg-linkedin-gray-10 transition-colors">
                      Duplicate
                    </button>
                  </div>
                </div>
              </CardBody>
            )}
          </Card>
        ))}
      </div>
    </div>
  );
}
