"use client";

import React, { useState } from "react";
import { Plus } from "lucide-react";
import { cn } from "@/lib/utils/cn";
import { Card, CardBody, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { PageHeader } from "@/components/layout/page-header";

/* ------------------------------------------------------------------ */
/* Mock Data                                                           */
/* ------------------------------------------------------------------ */

const rules = [
  { name: "Negative Sentiment", trigger: "Sentiment < -0.5", action: "Assign to supervisor", notifications: "Notify via Slack #escalations", active: true },
  { name: "SLA At Risk", trigger: "SLA <30% remaining", action: "Notify team lead", notifications: "Email + Slack", active: true },
  { name: "Repeated Contact", trigger: "3+ contacts in 24h", action: "Flag for review", notifications: "In-app notification", active: true },
  { name: "Customer Request", trigger: "Explicit escalation request", action: "Immediate transfer to supervisor", notifications: "Slack + Email", active: true },
];

/* ------------------------------------------------------------------ */
/* Page                                                                */
/* ------------------------------------------------------------------ */

export default function EscalationRulesPage() {
  const [items, setItems] = useState(rules);

  const toggleActive = (idx: number) => {
    setItems((prev) =>
      prev.map((r, i) => (i === idx ? { ...r, active: !r.active } : r))
    );
  };

  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="Escalation Rules"
        subtitle="Configure automatic escalation triggers and actions"
        actions={
          <button className="inline-flex items-center gap-2 rounded-lg bg-linkedin-blue px-4 py-2 text-sm font-medium text-white hover:bg-linkedin-blue-dark transition-colors">
            <Plus className="h-4 w-4" />
            Add Rule
          </button>
        }
      />

      <Card padding="none">
        <CardBody className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-linkedin-gray-20 bg-linkedin-gray-10">
                  <th className="px-4 py-3 text-left font-medium text-linkedin-gray-70">Name</th>
                  <th className="px-4 py-3 text-left font-medium text-linkedin-gray-70">Trigger</th>
                  <th className="px-4 py-3 text-left font-medium text-linkedin-gray-70">Action</th>
                  <th className="px-4 py-3 text-left font-medium text-linkedin-gray-70">Notifications</th>
                  <th className="px-4 py-3 text-left font-medium text-linkedin-gray-70">Status</th>
                </tr>
              </thead>
              <tbody>
                {items.map((rule, i) => (
                  <tr key={i} className="border-b border-linkedin-gray-20 last:border-0 hover:bg-linkedin-gray-10 transition-colors">
                    <td className="px-4 py-3 font-medium text-linkedin-gray-90">{rule.name}</td>
                    <td className="px-4 py-3 text-linkedin-gray-70">{rule.trigger}</td>
                    <td className="px-4 py-3 text-linkedin-gray-70">{rule.action}</td>
                    <td className="px-4 py-3 text-linkedin-gray-50 text-xs">{rule.notifications}</td>
                    <td className="px-4 py-3">
                      <button
                        onClick={() => toggleActive(i)}
                        className={cn(
                          "relative inline-flex h-5 w-9 items-center rounded-full transition-colors",
                          rule.active ? "bg-linkedin-green" : "bg-linkedin-gray-30"
                        )}
                      >
                        <span className={cn(
                          "inline-block h-3.5 w-3.5 rounded-full bg-white transition-transform",
                          rule.active ? "translate-x-4" : "translate-x-0.5"
                        )} />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardBody>
      </Card>
    </div>
  );
}
