"use client";

import React, { useState } from "react";
import { Plus } from "lucide-react";
import { cn } from "@/lib/utils/cn";
import { Card, CardBody, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { PageHeader } from "@/components/layout/page-header";

/* ------------------------------------------------------------------ */
/* Mock Data                                                           */
/* ------------------------------------------------------------------ */

const workflows = [
  { name: "Auto-Reply on New Ticket", trigger: "New ticket created", active: true, lastRun: "2 min ago", successRate: "98.5%" },
  { name: "Escalate Negative Sentiment", trigger: "Sentiment score < -0.5", active: true, lastRun: "15 min ago", successRate: "94.2%" },
  { name: "SLA Warning Notification", trigger: "SLA at 70% threshold", active: true, lastRun: "1 hour ago", successRate: "100%" },
  { name: "Off-Hours Auto Response", trigger: "Message outside business hours", active: false, lastRun: "12 hours ago", successRate: "99.1%" },
  { name: "VIP Priority Routing", trigger: "VIP customer identified", active: true, lastRun: "30 min ago", successRate: "97.8%" },
];

/* ------------------------------------------------------------------ */
/* Page                                                                */
/* ------------------------------------------------------------------ */

export default function WorkflowsListPage() {
  const [items, setItems] = useState(workflows);

  const toggleActive = (idx: number) => {
    setItems((prev) =>
      prev.map((w, i) => (i === idx ? { ...w, active: !w.active } : w))
    );
  };

  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="Workflows"
        subtitle="Manage automation workflows"
        actions={
          <a
            href="/automation/workflows/new"
            className="inline-flex items-center gap-2 rounded-lg bg-linkedin-blue px-4 py-2 text-sm font-medium text-white hover:bg-linkedin-blue-dark transition-colors"
          >
            <Plus className="h-4 w-4" />
            Create Workflow
          </a>
        }
      />

      <Card padding="none">
        <CardBody className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-linkedin-gray-20 bg-linkedin-gray-10">
                  <th className="px-4 py-3 text-left font-medium text-linkedin-gray-70">Name</th>
                  <th className="px-4 py-3 text-left font-medium text-linkedin-gray-70">Trigger</th>
                  <th className="px-4 py-3 text-left font-medium text-linkedin-gray-70">Status</th>
                  <th className="px-4 py-3 text-left font-medium text-linkedin-gray-70">Last Run</th>
                  <th className="px-4 py-3 text-left font-medium text-linkedin-gray-70">Success Rate</th>
                </tr>
              </thead>
              <tbody>
                {items.map((wf, i) => (
                  <tr key={i} className="border-b border-linkedin-gray-20 last:border-0 hover:bg-linkedin-gray-10 transition-colors">
                    <td className="px-4 py-3 font-medium text-linkedin-blue hover:underline cursor-pointer">{wf.name}</td>
                    <td className="px-4 py-3 text-linkedin-gray-70">{wf.trigger}</td>
                    <td className="px-4 py-3">
                      <button
                        onClick={() => toggleActive(i)}
                        className={cn(
                          "relative inline-flex h-5 w-9 items-center rounded-full transition-colors",
                          wf.active ? "bg-linkedin-green" : "bg-linkedin-gray-30"
                        )}
                      >
                        <span className={cn(
                          "inline-block h-3.5 w-3.5 rounded-full bg-white transition-transform",
                          wf.active ? "translate-x-4" : "translate-x-0.5"
                        )} />
                      </button>
                    </td>
                    <td className="px-4 py-3 text-linkedin-gray-50">{wf.lastRun}</td>
                    <td className="px-4 py-3 text-linkedin-gray-70 tabular-nums">{wf.successRate}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardBody>
      </Card>
    </div>
  );
}
