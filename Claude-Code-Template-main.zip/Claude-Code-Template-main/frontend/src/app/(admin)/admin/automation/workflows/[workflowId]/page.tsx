"use client";

import React, { useState } from "react";
import {
  Zap,
  GitBranch,
  Users,
  Save,
  Play,
  ArrowRight,
} from "lucide-react";
import { cn } from "@/lib/utils/cn";
import { Card, CardBody, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { PageHeader } from "@/components/layout/page-header";

/* ------------------------------------------------------------------ */
/* Mock Data                                                           */
/* ------------------------------------------------------------------ */

const nodes = [
  { type: "Trigger", label: "Sentiment Drop", icon: Zap, color: "bg-linkedin-blue-bg text-linkedin-blue" },
  { type: "Condition", label: "Score < -0.5", icon: GitBranch, color: "bg-orange-50 text-linkedin-orange" },
  { type: "Action", label: "Assign to Supervisor", icon: Users, color: "bg-green-50 text-linkedin-green" },
];

const runHistory = [
  { date: "2026-03-09 14:23", triggeredBy: "Ticket #4521", result: "Success", duration: "1.2s" },
  { date: "2026-03-09 12:15", triggeredBy: "Ticket #4518", result: "Success", duration: "0.9s" },
  { date: "2026-03-09 09:45", triggeredBy: "Ticket #4512", result: "Success", duration: "1.5s" },
  { date: "2026-03-08 16:30", triggeredBy: "Ticket #4498", result: "Failed", duration: "3.2s" },
  { date: "2026-03-08 11:20", triggeredBy: "Ticket #4490", result: "Success", duration: "1.1s" },
];

/* ------------------------------------------------------------------ */
/* Page                                                                */
/* ------------------------------------------------------------------ */

export default function EditWorkflowPage() {
  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="Escalate Negative Sentiment"
        subtitle="Edit workflow configuration"
        actions={
          <div className="flex items-center gap-2">
            <button className="inline-flex items-center gap-2 rounded-lg border border-linkedin-gray-30 bg-white px-4 py-2 text-sm font-medium text-linkedin-gray-70 hover:bg-linkedin-gray-10 transition-colors">
              <Save className="h-4 w-4" />
              Save
            </button>
            <button className="inline-flex items-center gap-2 rounded-lg bg-linkedin-green px-4 py-2 text-sm font-medium text-white hover:opacity-90 transition-opacity">
              <Play className="h-4 w-4" />
              Activate
            </button>
          </div>
        }
      />

      {/* Workflow Canvas */}
      <Card padding="none">
        <CardHeader>Workflow Canvas</CardHeader>
        <CardBody>
          <div
            className="flex items-center justify-center gap-4 rounded-lg border-2 border-dashed border-linkedin-gray-20 bg-linkedin-gray-10 px-8 py-12"
            style={{
              backgroundImage: "radial-gradient(circle, #d1d5db 1px, transparent 1px)",
              backgroundSize: "20px 20px",
            }}
          >
            {nodes.map((node, i) => (
              <React.Fragment key={i}>
                <div className={cn("flex flex-col items-center gap-2 rounded-lg border border-linkedin-gray-20 bg-white p-4 shadow-sm min-w-[160px]")}>
                  <div className={cn("flex h-8 w-8 items-center justify-center rounded-lg", node.color)}>
                    <node.icon className="h-4 w-4" />
                  </div>
                  <span className="text-[10px] font-medium text-linkedin-gray-50 uppercase tracking-wider">{node.type}</span>
                  <span className="text-sm font-medium text-linkedin-gray-90">{node.label}</span>
                </div>
                {i < nodes.length - 1 && (
                  <ArrowRight className="h-5 w-5 text-linkedin-gray-30 shrink-0" />
                )}
              </React.Fragment>
            ))}
          </div>
        </CardBody>
      </Card>

      {/* Run History */}
      <Card padding="none">
        <CardHeader>Run History</CardHeader>
        <CardBody className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-linkedin-gray-20 bg-linkedin-gray-10">
                  <th className="px-4 py-3 text-left font-medium text-linkedin-gray-70">Date</th>
                  <th className="px-4 py-3 text-left font-medium text-linkedin-gray-70">Triggered By</th>
                  <th className="px-4 py-3 text-left font-medium text-linkedin-gray-70">Result</th>
                  <th className="px-4 py-3 text-left font-medium text-linkedin-gray-70">Duration</th>
                </tr>
              </thead>
              <tbody>
                {runHistory.map((run, i) => (
                  <tr key={i} className="border-b border-linkedin-gray-20 last:border-0 hover:bg-linkedin-gray-10 transition-colors">
                    <td className="px-4 py-3 text-linkedin-gray-50 tabular-nums">{run.date}</td>
                    <td className="px-4 py-3 font-medium text-linkedin-gray-90">{run.triggeredBy}</td>
                    <td className="px-4 py-3">
                      <Badge variant={run.result === "Success" ? "success" : "danger"}>{run.result}</Badge>
                    </td>
                    <td className="px-4 py-3 text-linkedin-gray-70 tabular-nums">{run.duration}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardBody>
      </Card>
    </div>
  );
}
