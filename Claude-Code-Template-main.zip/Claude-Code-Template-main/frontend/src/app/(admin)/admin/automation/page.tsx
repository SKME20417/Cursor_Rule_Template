"use client";

import React from "react";
import {
  Workflow,
  MessageSquareReply,
  ArrowUpRight,
  XCircle,
  Zap,
  Bot,
  AlertTriangle,
} from "lucide-react";
import { cn } from "@/lib/utils/cn";
import { Card, CardBody } from "@/components/ui/card";
import { PageHeader } from "@/components/layout/page-header";

/* ------------------------------------------------------------------ */
/* Mock Data                                                           */
/* ------------------------------------------------------------------ */

const stats = [
  { label: "Active Workflows", value: "8", icon: Workflow, color: "text-linkedin-blue" },
  { label: "Auto-Replies Sent Today", value: "234", icon: MessageSquareReply, color: "text-linkedin-green" },
  { label: "Auto-Escalations", value: "12", icon: ArrowUpRight, color: "text-linkedin-orange" },
  { label: "Tickets Auto-Closed", value: "45", icon: XCircle, color: "text-linkedin-gray-50" },
];

const quickLinks = [
  { title: "Workflows", description: "Create and manage automation workflows", icon: Zap, href: "/automation/workflows" },
  { title: "Auto-Replies", description: "Configure automatic response templates", icon: Bot, href: "/automation/auto-replies" },
  { title: "Escalation Rules", description: "Set up escalation triggers and actions", icon: AlertTriangle, href: "/automation/escalation" },
];

/* ------------------------------------------------------------------ */
/* Page                                                                */
/* ------------------------------------------------------------------ */

export default function AutomationOverviewPage() {
  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="Automation"
        subtitle="Automate workflows, replies, and escalations"
      />

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {stats.map((stat) => (
          <Card key={stat.label} hover>
            <CardBody>
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-xs text-linkedin-gray-50">{stat.label}</p>
                  <p className="mt-1 text-2xl font-bold text-linkedin-gray-90">{stat.value}</p>
                </div>
                <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-linkedin-blue-bg">
                  <stat.icon className={cn("h-5 w-5", stat.color)} />
                </div>
              </div>
            </CardBody>
          </Card>
        ))}
      </div>

      <div className="grid gap-4 sm:grid-cols-3">
        {quickLinks.map((link) => (
          <a key={link.title} href={link.href}>
            <Card hover>
              <CardBody>
                <div className="flex flex-col gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-linkedin-blue-bg">
                    <link.icon className="h-5 w-5 text-linkedin-blue" />
                  </div>
                  <div>
                    <h3 className="text-sm font-semibold text-linkedin-gray-90">{link.title}</h3>
                    <p className="text-xs text-linkedin-gray-50 mt-1">{link.description}</p>
                  </div>
                </div>
              </CardBody>
            </Card>
          </a>
        ))}
      </div>
    </div>
  );
}
