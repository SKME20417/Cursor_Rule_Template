"use client";

import React, { useState } from "react";
import { Upload, MessageCircle, Save } from "lucide-react";
import { cn } from "@/lib/utils/cn";
import { Card, CardBody, CardHeader } from "@/components/ui/card";
import { PageHeader } from "@/components/layout/page-header";

/* ------------------------------------------------------------------ */
/* Page                                                                */
/* ------------------------------------------------------------------ */

export default function BrandingPage() {
  const [primaryColor, setPrimaryColor] = useState("#0a66c2");
  const [companyName, setCompanyName] = useState("Acme Corp");

  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="Branding"
        subtitle="Customize your support widget appearance"
        actions={
          <button className="inline-flex items-center gap-2 rounded-lg bg-linkedin-blue px-4 py-2 text-sm font-medium text-white hover:bg-linkedin-blue-dark transition-colors">
            <Save className="h-4 w-4" />
            Save
          </button>
        }
      />

      <div className="grid gap-6 lg:grid-cols-2">
        <div className="flex flex-col gap-6">
          {/* Logo Upload */}
          <Card padding="none">
            <CardHeader>Logo</CardHeader>
            <CardBody>
              <div className="flex flex-col items-center justify-center rounded-lg border-2 border-dashed border-linkedin-gray-30 bg-linkedin-gray-10 px-6 py-8 text-center hover:border-linkedin-blue hover:bg-linkedin-blue-bg transition-colors cursor-pointer">
                <Upload className="h-8 w-8 text-linkedin-gray-50 mb-2" />
                <p className="text-sm font-medium text-linkedin-gray-90">Drop logo here or click to browse</p>
                <p className="mt-1 text-xs text-linkedin-gray-50">PNG, SVG, or JPG (max 2MB)</p>
              </div>
            </CardBody>
          </Card>

          {/* Primary Color */}
          <Card padding="none">
            <CardHeader>Brand Colors</CardHeader>
            <CardBody className="flex flex-col gap-4">
              <div className="flex flex-col gap-1">
                <label className="text-sm font-medium text-linkedin-gray-90">Primary Color</label>
                <div className="flex items-center gap-3">
                  <input type="color" value={primaryColor} onChange={(e) => setPrimaryColor(e.target.value)} className="h-10 w-10 cursor-pointer rounded-lg border border-linkedin-gray-30" />
                  <input type="text" value={primaryColor} onChange={(e) => setPrimaryColor(e.target.value)} className="w-32 rounded-lg border border-linkedin-gray-30 bg-white px-3 py-2 text-sm text-linkedin-gray-90 focus:border-linkedin-blue focus:outline-none focus:ring-1 focus:ring-linkedin-blue font-mono" />
                  <div className="h-10 w-10 rounded-lg" style={{ backgroundColor: primaryColor }} />
                </div>
              </div>
              <div className="flex flex-col gap-1">
                <label className="text-sm font-medium text-linkedin-gray-90">Company Name in Widget</label>
                <input type="text" value={companyName} onChange={(e) => setCompanyName(e.target.value)} className="w-full rounded-lg border border-linkedin-gray-30 bg-white px-3 py-2 text-sm text-linkedin-gray-90 focus:border-linkedin-blue focus:outline-none focus:ring-1 focus:ring-linkedin-blue" />
              </div>
            </CardBody>
          </Card>

          {/* Favicon Upload */}
          <Card padding="none">
            <CardHeader>Favicon</CardHeader>
            <CardBody>
              <div className="flex flex-col items-center justify-center rounded-lg border-2 border-dashed border-linkedin-gray-30 bg-linkedin-gray-10 px-6 py-6 text-center hover:border-linkedin-blue hover:bg-linkedin-blue-bg transition-colors cursor-pointer">
                <Upload className="h-6 w-6 text-linkedin-gray-50 mb-2" />
                <p className="text-sm font-medium text-linkedin-gray-90">Upload favicon</p>
                <p className="mt-1 text-xs text-linkedin-gray-50">ICO, PNG (32x32 or 16x16)</p>
              </div>
            </CardBody>
          </Card>
        </div>

        {/* Preview */}
        <Card padding="none">
          <CardHeader>Widget Preview</CardHeader>
          <CardBody>
            <div className="relative rounded-lg border border-linkedin-gray-20 bg-linkedin-gray-10 p-6" style={{ minHeight: 400 }}>
              <p className="text-center text-xs text-linkedin-gray-50 mt-4">Website preview area</p>
              <div className="absolute bottom-4 right-4">
                <div className="mb-3 w-72 rounded-lg bg-white shadow-lg border border-linkedin-gray-20 overflow-hidden">
                  <div className="px-4 py-3 text-white text-sm font-medium" style={{ backgroundColor: primaryColor }}>
                    {companyName} Support
                  </div>
                  <div className="p-4">
                    <div className="rounded-lg bg-linkedin-gray-10 p-3 text-xs text-linkedin-gray-70">
                      Hi there! How can we help you today?
                    </div>
                  </div>
                  <div className="border-t border-linkedin-gray-20 px-4 py-2">
                    <input type="text" placeholder="Type a message..." disabled className="w-full bg-transparent text-xs text-linkedin-gray-50" />
                  </div>
                </div>
                <div className="flex h-12 w-12 items-center justify-center rounded-full shadow-lg cursor-pointer ml-auto" style={{ backgroundColor: primaryColor }}>
                  <MessageCircle className="h-6 w-6 text-white" />
                </div>
              </div>
            </div>
          </CardBody>
        </Card>
      </div>
    </div>
  );
}
