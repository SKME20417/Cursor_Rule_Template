"use client";

import React, { useState } from "react";
import { Save, Globe } from "lucide-react";
import { cn } from "@/lib/utils/cn";
import { Card, CardBody, CardHeader } from "@/components/ui/card";
import { PageHeader } from "@/components/layout/page-header";

/* ------------------------------------------------------------------ */
/* Mock Data                                                           */
/* ------------------------------------------------------------------ */

const languages = [
  { code: "en", name: "English", enabled: true },
  { code: "es", name: "Spanish", enabled: true },
  { code: "fr", name: "French", enabled: true },
  { code: "de", name: "German", enabled: false },
  { code: "pt", name: "Portuguese", enabled: false },
  { code: "ja", name: "Japanese", enabled: false },
  { code: "zh", name: "Chinese", enabled: false },
  { code: "ar", name: "Arabic", enabled: false },
];

/* ------------------------------------------------------------------ */
/* Page                                                                */
/* ------------------------------------------------------------------ */

export default function LocalizationPage() {
  const [langs, setLangs] = useState(languages);
  const [defaultLang, setDefaultLang] = useState("en");
  const [defaultTimezone, setDefaultTimezone] = useState("America/New_York");
  const [dateFormat, setDateFormat] = useState("MM/DD/YYYY");

  const toggleLang = (code: string) => {
    setLangs((prev) =>
      prev.map((l) => (l.code === code ? { ...l, enabled: !l.enabled } : l))
    );
  };

  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="Localization"
        subtitle="Configure languages, timezone, and date formats"
        actions={
          <button className="inline-flex items-center gap-2 rounded-lg bg-linkedin-blue px-4 py-2 text-sm font-medium text-white hover:bg-linkedin-blue-dark transition-colors">
            <Save className="h-4 w-4" />
            Save
          </button>
        }
      />

      <div className="grid gap-6 lg:grid-cols-2">
        {/* Supported Languages */}
        <Card padding="none">
          <CardHeader>Supported Languages</CardHeader>
          <CardBody className="flex flex-col gap-2">
            {langs.map((lang) => (
              <label
                key={lang.code}
                className="flex items-center justify-between rounded-lg border border-linkedin-gray-20 px-4 py-3 hover:bg-linkedin-gray-10 transition-colors cursor-pointer"
              >
                <div className="flex items-center gap-3">
                  <Globe className="h-4 w-4 text-linkedin-gray-50" />
                  <span className="text-sm font-medium text-linkedin-gray-90">{lang.name}</span>
                  <span className="text-xs text-linkedin-gray-50 uppercase">{lang.code}</span>
                </div>
                <input
                  type="checkbox"
                  checked={lang.enabled}
                  onChange={() => toggleLang(lang.code)}
                  className="h-4 w-4 rounded border-linkedin-gray-30 text-linkedin-blue focus:ring-linkedin-blue"
                />
              </label>
            ))}
          </CardBody>
        </Card>

        {/* Defaults */}
        <div className="flex flex-col gap-6">
          <Card padding="none">
            <CardHeader>Default Settings</CardHeader>
            <CardBody className="flex flex-col gap-4">
              <div className="flex flex-col gap-1">
                <label className="text-sm font-medium text-linkedin-gray-90">Default Language</label>
                <select value={defaultLang} onChange={(e) => setDefaultLang(e.target.value)} className="w-full rounded-lg border border-linkedin-gray-30 bg-white px-3 py-2 text-sm text-linkedin-gray-90 focus:border-linkedin-blue focus:outline-none focus:ring-1 focus:ring-linkedin-blue">
                  {langs.filter((l) => l.enabled).map((l) => (
                    <option key={l.code} value={l.code}>{l.name}</option>
                  ))}
                </select>
              </div>

              <div className="flex flex-col gap-1">
                <label className="text-sm font-medium text-linkedin-gray-90">Default Timezone</label>
                <select value={defaultTimezone} onChange={(e) => setDefaultTimezone(e.target.value)} className="w-full rounded-lg border border-linkedin-gray-30 bg-white px-3 py-2 text-sm text-linkedin-gray-90 focus:border-linkedin-blue focus:outline-none focus:ring-1 focus:ring-linkedin-blue">
                  <option value="America/New_York">Eastern Time (ET)</option>
                  <option value="America/Chicago">Central Time (CT)</option>
                  <option value="America/Denver">Mountain Time (MT)</option>
                  <option value="America/Los_Angeles">Pacific Time (PT)</option>
                  <option value="Europe/London">GMT</option>
                  <option value="Europe/Berlin">Central European Time</option>
                  <option value="Asia/Tokyo">Japan Standard Time</option>
                </select>
              </div>

              <div className="flex flex-col gap-1">
                <label className="text-sm font-medium text-linkedin-gray-90">Date Format</label>
                <select value={dateFormat} onChange={(e) => setDateFormat(e.target.value)} className="w-full rounded-lg border border-linkedin-gray-30 bg-white px-3 py-2 text-sm text-linkedin-gray-90 focus:border-linkedin-blue focus:outline-none focus:ring-1 focus:ring-linkedin-blue">
                  <option value="MM/DD/YYYY">MM/DD/YYYY</option>
                  <option value="DD/MM/YYYY">DD/MM/YYYY</option>
                  <option value="YYYY-MM-DD">YYYY-MM-DD</option>
                </select>
              </div>
            </CardBody>
          </Card>
        </div>
      </div>
    </div>
  );
}
