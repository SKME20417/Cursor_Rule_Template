"use client";

import React, { useState } from "react";
import { Save } from "lucide-react";
import { cn } from "@/lib/utils/cn";
import { Card, CardBody, CardHeader } from "@/components/ui/card";
import { PageHeader } from "@/components/layout/page-header";

/* ------------------------------------------------------------------ */
/* Mock Data                                                           */
/* ------------------------------------------------------------------ */

const daysOfWeek = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
const defaultChecked = ["Mon", "Tue", "Wed", "Thu", "Fri"];

/* ------------------------------------------------------------------ */
/* Page                                                                */
/* ------------------------------------------------------------------ */

export default function GeneralSettingsPage() {
  const [companyName, setCompanyName] = useState("Acme Corp");
  const [supportEmail, setSupportEmail] = useState("support@acme.com");
  const [timezone, setTimezone] = useState("America/New_York");
  const [language, setLanguage] = useState("en");
  const [checkedDays, setCheckedDays] = useState<Set<string>>(new Set(defaultChecked));
  const [startTime, setStartTime] = useState("09:00");
  const [endTime, setEndTime] = useState("17:00");

  const toggleDay = (day: string) => {
    setCheckedDays((prev) => {
      const next = new Set(prev);
      if (next.has(day)) next.delete(day);
      else next.add(day);
      return next;
    });
  };

  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="General Settings"
        subtitle="Configure company information and business hours"
        actions={
          <button className="inline-flex items-center gap-2 rounded-lg bg-linkedin-blue px-4 py-2 text-sm font-medium text-white hover:bg-linkedin-blue-dark transition-colors">
            <Save className="h-4 w-4" />
            Save
          </button>
        }
      />

      <div className="grid gap-6 lg:grid-cols-2">
        <Card padding="none">
          <CardHeader>Company Information</CardHeader>
          <CardBody className="flex flex-col gap-4">
            <div className="flex flex-col gap-1">
              <label className="text-sm font-medium text-linkedin-gray-90">Company Name</label>
              <input type="text" value={companyName} onChange={(e) => setCompanyName(e.target.value)} className="w-full rounded-lg border border-linkedin-gray-30 bg-white px-3 py-2 text-sm text-linkedin-gray-90 focus:border-linkedin-blue focus:outline-none focus:ring-1 focus:ring-linkedin-blue" />
            </div>
            <div className="flex flex-col gap-1">
              <label className="text-sm font-medium text-linkedin-gray-90">Support Email</label>
              <input type="email" value={supportEmail} onChange={(e) => setSupportEmail(e.target.value)} className="w-full rounded-lg border border-linkedin-gray-30 bg-white px-3 py-2 text-sm text-linkedin-gray-90 focus:border-linkedin-blue focus:outline-none focus:ring-1 focus:ring-linkedin-blue" />
            </div>
          </CardBody>
        </Card>

        <Card padding="none">
          <CardHeader>Defaults</CardHeader>
          <CardBody className="flex flex-col gap-4">
            <div className="flex flex-col gap-1">
              <label className="text-sm font-medium text-linkedin-gray-90">Default Timezone</label>
              <select value={timezone} onChange={(e) => setTimezone(e.target.value)} className="w-full rounded-lg border border-linkedin-gray-30 bg-white px-3 py-2 text-sm text-linkedin-gray-90 focus:border-linkedin-blue focus:outline-none focus:ring-1 focus:ring-linkedin-blue">
                <option value="America/New_York">Eastern Time (ET)</option>
                <option value="America/Chicago">Central Time (CT)</option>
                <option value="America/Denver">Mountain Time (MT)</option>
                <option value="America/Los_Angeles">Pacific Time (PT)</option>
                <option value="Europe/London">GMT</option>
                <option value="Europe/Berlin">Central European Time</option>
                <option value="Asia/Tokyo">Japan Standard Time</option>
              </select>
            </div>
            <div className="flex flex-col gap-1">
              <label className="text-sm font-medium text-linkedin-gray-90">Default Language</label>
              <select value={language} onChange={(e) => setLanguage(e.target.value)} className="w-full rounded-lg border border-linkedin-gray-30 bg-white px-3 py-2 text-sm text-linkedin-gray-90 focus:border-linkedin-blue focus:outline-none focus:ring-1 focus:ring-linkedin-blue">
                <option value="en">English</option>
                <option value="es">Spanish</option>
                <option value="fr">French</option>
                <option value="de">German</option>
                <option value="pt">Portuguese</option>
                <option value="ja">Japanese</option>
              </select>
            </div>
          </CardBody>
        </Card>
      </div>

      <Card padding="none">
        <CardHeader>Business Hours</CardHeader>
        <CardBody className="flex flex-col gap-4">
          <div className="flex flex-wrap gap-2">
            {daysOfWeek.map((day) => (
              <button
                key={day}
                onClick={() => toggleDay(day)}
                className={cn(
                  "rounded-lg px-4 py-2 text-sm font-medium transition-colors",
                  checkedDays.has(day)
                    ? "bg-linkedin-blue text-white"
                    : "bg-linkedin-gray-10 text-linkedin-gray-50 hover:bg-linkedin-gray-20"
                )}
              >
                {day}
              </button>
            ))}
          </div>
          <div className="flex items-center gap-3">
            <div className="flex flex-col gap-1">
              <label className="text-xs text-linkedin-gray-50">Start Time</label>
              <input type="time" value={startTime} onChange={(e) => setStartTime(e.target.value)} className="rounded-lg border border-linkedin-gray-30 bg-white px-3 py-2 text-sm text-linkedin-gray-90 focus:border-linkedin-blue focus:outline-none focus:ring-1 focus:ring-linkedin-blue" />
            </div>
            <span className="mt-5 text-linkedin-gray-50">to</span>
            <div className="flex flex-col gap-1">
              <label className="text-xs text-linkedin-gray-50">End Time</label>
              <input type="time" value={endTime} onChange={(e) => setEndTime(e.target.value)} className="rounded-lg border border-linkedin-gray-30 bg-white px-3 py-2 text-sm text-linkedin-gray-90 focus:border-linkedin-blue focus:outline-none focus:ring-1 focus:ring-linkedin-blue" />
            </div>
          </div>
        </CardBody>
      </Card>
    </div>
  );
}
