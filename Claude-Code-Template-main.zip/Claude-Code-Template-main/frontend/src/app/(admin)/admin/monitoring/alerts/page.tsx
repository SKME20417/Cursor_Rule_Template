"use client";

import React, { useState } from "react";
import { Plus, Bell } from "lucide-react";
import { cn } from "@/lib/utils/cn";
import { Card, CardBody, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { PageHeader } from "@/components/layout/page-header";

/* ------------------------------------------------------------------ */
/* Mock Data                                                           */
/* ------------------------------------------------------------------ */

const alertRules = [
  { name: "High Latency", metric: "response_time_ms", condition: ">", threshold: "200ms", channels: "Slack, Email", active: true },
  { name: "Error Rate Spike", metric: "error_rate", condition: ">", threshold: "1%", channels: "Slack", active: true },
  { name: "Queue Depth", metric: "queue_depth", condition: ">", threshold: "100", channels: "Slack", active: true },
  { name: "CPU Usage", metric: "cpu_percent", condition: ">", threshold: "90%", channels: "Email", active: false },
  { name: "Memory Usage", metric: "memory_percent", condition: ">", threshold: "85%", channels: "Slack, Email", active: true },
];

const alertHistory = [
  { time: "2026-03-09 14:23", rule: "High Latency", severity: "warning", message: "RAG Service latency at 234ms", resolved: false },
  { time: "2026-03-09 13:45", rule: "Queue Depth", severity: "warning", message: "Embedding queue depth: 156", resolved: false },
  { time: "2026-03-09 12:30", rule: "Error Rate Spike", severity: "critical", message: "NLP Service error rate: 2.3%", resolved: true },
  { time: "2026-03-09 11:15", rule: "High Latency", severity: "warning", message: "Voice Service latency at 210ms", resolved: true },
  { time: "2026-03-09 10:00", rule: "CPU Usage", severity: "info", message: "Worker-03 CPU at 78%", resolved: true },
  { time: "2026-03-08 22:30", rule: "Memory Usage", severity: "warning", message: "Redis memory at 87%", resolved: true },
  { time: "2026-03-08 18:45", rule: "Error Rate Spike", severity: "critical", message: "Gateway error rate: 1.5%", resolved: true },
  { time: "2026-03-08 15:20", rule: "Queue Depth", severity: "warning", message: "Email queue depth: 120", resolved: true },
  { time: "2026-03-08 12:10", rule: "High Latency", severity: "info", message: "Chat Service latency at 150ms", resolved: true },
  { time: "2026-03-08 09:00", rule: "CPU Usage", severity: "warning", message: "Worker-01 CPU at 92%", resolved: true },
];

const severityVariant: Record<string, "danger" | "warning" | "info"> = {
  critical: "danger",
  warning: "warning",
  info: "info",
};

/* ------------------------------------------------------------------ */
/* Page                                                                */
/* ------------------------------------------------------------------ */

export default function AlertsPage() {
  const [rules, setRules] = useState(alertRules);

  const toggleRule = (idx: number) => {
    setRules((prev) =>
      prev.map((r, i) => (i === idx ? { ...r, active: !r.active } : r))
    );
  };

  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="Alerts"
        subtitle="Configure alert rules and view alert history"
        actions={
          <button className="inline-flex items-center gap-2 rounded-lg bg-linkedin-blue px-4 py-2 text-sm font-medium text-white hover:bg-linkedin-blue-dark transition-colors">
            <Plus className="h-4 w-4" />
            Create Alert Rule
          </button>
        }
      />

      {/* Active Rules */}
      <Card padding="none">
        <CardHeader>Alert Rules</CardHeader>
        <CardBody className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-linkedin-gray-20 bg-linkedin-gray-10">
                  <th className="px-4 py-3 text-left font-medium text-linkedin-gray-70">Name</th>
                  <th className="px-4 py-3 text-left font-medium text-linkedin-gray-70">Metric</th>
                  <th className="px-4 py-3 text-left font-medium text-linkedin-gray-70">Condition</th>
                  <th className="px-4 py-3 text-left font-medium text-linkedin-gray-70">Threshold</th>
                  <th className="px-4 py-3 text-left font-medium text-linkedin-gray-70">Channels</th>
                  <th className="px-4 py-3 text-left font-medium text-linkedin-gray-70">Status</th>
                </tr>
              </thead>
              <tbody>
                {rules.map((rule, i) => (
                  <tr key={i} className="border-b border-linkedin-gray-20 last:border-0 hover:bg-linkedin-gray-10 transition-colors">
                    <td className="px-4 py-3 font-medium text-linkedin-gray-90">{rule.name}</td>
                    <td className="px-4 py-3">
                      <code className="rounded bg-linkedin-gray-10 px-2 py-0.5 text-xs font-mono text-linkedin-gray-70">{rule.metric}</code>
                    </td>
                    <td className="px-4 py-3 text-linkedin-gray-70">{rule.condition}</td>
                    <td className="px-4 py-3 text-linkedin-gray-70 tabular-nums">{rule.threshold}</td>
                    <td className="px-4 py-3 text-linkedin-gray-50">{rule.channels}</td>
                    <td className="px-4 py-3">
                      <button
                        onClick={() => toggleRule(i)}
                        className={cn(
                          "relative inline-flex h-5 w-9 items-center rounded-full transition-colors",
                          rule.active ? "bg-linkedin-green" : "bg-linkedin-gray-30"
                        )}
                      >
                        <span className={cn(
                          "inline-block h-3.5 w-3.5 rounded-full bg-white transition-transform",
                          rule.active ? "translate-x-4" : "translate-x-0.5"
                        )} />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardBody>
      </Card>

      {/* Alert History */}
      <Card padding="none">
        <CardHeader>Alert History</CardHeader>
        <CardBody className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-linkedin-gray-20 bg-linkedin-gray-10">
                  <th className="px-4 py-3 text-left font-medium text-linkedin-gray-70">Time</th>
                  <th className="px-4 py-3 text-left font-medium text-linkedin-gray-70">Rule</th>
                  <th className="px-4 py-3 text-left font-medium text-linkedin-gray-70">Severity</th>
                  <th className="px-4 py-3 text-left font-medium text-linkedin-gray-70">Message</th>
                  <th className="px-4 py-3 text-left font-medium text-linkedin-gray-70">Resolved</th>
                </tr>
              </thead>
              <tbody>
                {alertHistory.map((alert, i) => (
                  <tr key={i} className="border-b border-linkedin-gray-20 last:border-0 hover:bg-linkedin-gray-10 transition-colors">
                    <td className="px-4 py-3 text-linkedin-gray-50 tabular-nums whitespace-nowrap">{alert.time}</td>
                    <td className="px-4 py-3 font-medium text-linkedin-gray-90">{alert.rule}</td>
                    <td className="px-4 py-3">
                      <Badge variant={severityVariant[alert.severity]}>{alert.severity}</Badge>
                    </td>
                    <td className="px-4 py-3 text-linkedin-gray-70">{alert.message}</td>
                    <td className="px-4 py-3">
                      <Badge variant={alert.resolved ? "success" : "warning"}>
                        {alert.resolved ? "Resolved" : "Active"}
                      </Badge>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardBody>
      </Card>
    </div>
  );
}
