"use client";

import React from "react";
import { Activity, CheckCircle, AlertTriangle } from "lucide-react";
import { cn } from "@/lib/utils/cn";
import { Card, CardBody, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { PageHeader } from "@/components/layout/page-header";

/* ------------------------------------------------------------------ */
/* Mock Data                                                           */
/* ------------------------------------------------------------------ */

const queueDepths = [
  { name: "Chat Queue", depth: 12, max: 200 },
  { name: "Ticket Queue", depth: 5, max: 200 },
  { name: "Email Queue", depth: 23, max: 200 },
  { name: "Embedding Queue", depth: 156, max: 200 },
];

const kafkaConsumerLag = [
  { topic: "chat-messages", partition: 0, currentOffset: 145230, latestOffset: 145235, lag: 5 },
  { topic: "chat-messages", partition: 1, currentOffset: 143890, latestOffset: 143895, lag: 5 },
  { topic: "ticket-events", partition: 0, currentOffset: 89450, latestOffset: 89452, lag: 2 },
  { topic: "embedding-jobs", partition: 0, currentOffset: 56780, latestOffset: 56936, lag: 156 },
  { topic: "analytics-events", partition: 0, currentOffset: 234560, latestOffset: 234565, lag: 5 },
];

const celeryWorkers = [
  { name: "worker-01", status: "active", activeTasks: 3, completed: 1245, failed: 2 },
  { name: "worker-02", status: "active", activeTasks: 2, completed: 1189, failed: 1 },
  { name: "worker-03", status: "active", activeTasks: 4, completed: 1312, failed: 3 },
  { name: "worker-04", status: "idle", activeTasks: 0, completed: 1098, failed: 0 },
];

/* ------------------------------------------------------------------ */
/* Page                                                                */
/* ------------------------------------------------------------------ */

export default function QueuesPage() {
  const maxDepth = Math.max(...queueDepths.map((q) => q.depth));

  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="Queues"
        subtitle="Monitor message queues, consumer lag, and worker health"
      />

      {/* Queue Depths Chart */}
      <Card padding="none">
        <CardHeader>Queue Depths</CardHeader>
        <CardBody>
          <div className="flex items-end gap-6 justify-around" style={{ height: 200 }}>
            {queueDepths.map((q) => (
              <div key={q.name} className="flex flex-col items-center gap-2 flex-1 max-w-[120px]">
                <span className="text-sm font-bold text-linkedin-gray-90 tabular-nums">{q.depth}</span>
                <div
                  className={cn(
                    "w-full rounded-t-md transition-all",
                    q.depth > 100 ? "bg-linkedin-orange" : "bg-linkedin-blue"
                  )}
                  style={{ height: `${Math.max((q.depth / maxDepth) * 140, 8)}px` }}
                />
                <span className="text-xs text-linkedin-gray-50 text-center">{q.name}</span>
              </div>
            ))}
          </div>
        </CardBody>
      </Card>

      {/* Kafka Consumer Lag */}
      <Card padding="none">
        <CardHeader>Kafka Consumer Lag</CardHeader>
        <CardBody className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-linkedin-gray-20 bg-linkedin-gray-10">
                  <th className="px-4 py-3 text-left font-medium text-linkedin-gray-70">Topic</th>
                  <th className="px-4 py-3 text-left font-medium text-linkedin-gray-70">Partition</th>
                  <th className="px-4 py-3 text-left font-medium text-linkedin-gray-70">Current Offset</th>
                  <th className="px-4 py-3 text-left font-medium text-linkedin-gray-70">Latest Offset</th>
                  <th className="px-4 py-3 text-left font-medium text-linkedin-gray-70">Lag</th>
                </tr>
              </thead>
              <tbody>
                {kafkaConsumerLag.map((row, i) => (
                  <tr key={i} className="border-b border-linkedin-gray-20 last:border-0 hover:bg-linkedin-gray-10 transition-colors">
                    <td className="px-4 py-3">
                      <code className="rounded bg-linkedin-gray-10 px-2 py-0.5 text-xs font-mono text-linkedin-gray-70">{row.topic}</code>
                    </td>
                    <td className="px-4 py-3 text-linkedin-gray-70 tabular-nums">{row.partition}</td>
                    <td className="px-4 py-3 text-linkedin-gray-70 tabular-nums">{row.currentOffset.toLocaleString()}</td>
                    <td className="px-4 py-3 text-linkedin-gray-70 tabular-nums">{row.latestOffset.toLocaleString()}</td>
                    <td className="px-4 py-3">
                      <Badge variant={row.lag > 100 ? "warning" : row.lag > 10 ? "primary" : "success"}>
                        {row.lag}
                      </Badge>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardBody>
      </Card>

      {/* Celery Workers */}
      <Card padding="none">
        <CardHeader>Worker Health (Celery)</CardHeader>
        <CardBody className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-linkedin-gray-20 bg-linkedin-gray-10">
                  <th className="px-4 py-3 text-left font-medium text-linkedin-gray-70">Worker</th>
                  <th className="px-4 py-3 text-left font-medium text-linkedin-gray-70">Status</th>
                  <th className="px-4 py-3 text-left font-medium text-linkedin-gray-70">Active Tasks</th>
                  <th className="px-4 py-3 text-left font-medium text-linkedin-gray-70">Completed</th>
                  <th className="px-4 py-3 text-left font-medium text-linkedin-gray-70">Failed</th>
                </tr>
              </thead>
              <tbody>
                {celeryWorkers.map((w, i) => (
                  <tr key={i} className="border-b border-linkedin-gray-20 last:border-0 hover:bg-linkedin-gray-10 transition-colors">
                    <td className="px-4 py-3 font-medium text-linkedin-gray-90">{w.name}</td>
                    <td className="px-4 py-3">
                      <Badge variant={w.status === "active" ? "success" : "default"}>{w.status}</Badge>
                    </td>
                    <td className="px-4 py-3 text-linkedin-gray-70 tabular-nums">{w.activeTasks}</td>
                    <td className="px-4 py-3 text-linkedin-gray-70 tabular-nums">{w.completed.toLocaleString()}</td>
                    <td className="px-4 py-3 text-linkedin-gray-70 tabular-nums">{w.failed}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardBody>
      </Card>
    </div>
  );
}
