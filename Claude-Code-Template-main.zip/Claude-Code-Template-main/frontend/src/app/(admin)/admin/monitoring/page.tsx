"use client";

import React from "react";
import {
  CheckCircle,
  AlertTriangle,
  Activity,
} from "lucide-react";
import { cn } from "@/lib/utils/cn";
import { Card, CardBody, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { PageHeader } from "@/components/layout/page-header";

/* ------------------------------------------------------------------ */
/* Mock Data                                                           */
/* ------------------------------------------------------------------ */

const services = [
  { name: "Gateway", status: "healthy", latency: "12ms" },
  { name: "Chat Service", status: "healthy", latency: "8ms" },
  { name: "Voice Service", status: "healthy", latency: "45ms" },
  { name: "Ticket Service", status: "healthy", latency: "15ms" },
  { name: "RAG Service", status: "degraded", latency: "234ms" },
  { name: "NLP Service", status: "healthy", latency: "67ms" },
  { name: "Kafka", status: "healthy", latency: "" },
  { name: "Redis", status: "healthy", latency: "2ms" },
  { name: "PostgreSQL", status: "healthy", latency: "5ms" },
];

const activeAlerts = [
  { message: "RAG Service high latency", severity: "warning" },
  { message: "Queue depth above threshold", severity: "warning" },
];

/* ------------------------------------------------------------------ */
/* Page                                                                */
/* ------------------------------------------------------------------ */

export default function MonitoringOverviewPage() {
  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="System Health"
        subtitle="Monitor services, queues, and system alerts"
      />

      {/* Overall Uptime */}
      <Card>
        <CardBody>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Activity className="h-5 w-5 text-linkedin-green" />
              <div>
                <h3 className="text-sm font-semibold text-linkedin-gray-90">Overall Uptime</h3>
                <p className="text-xs text-linkedin-gray-50">Last 30 days</p>
              </div>
            </div>
            <span className="text-2xl font-bold text-linkedin-green">99.97%</span>
          </div>
        </CardBody>
      </Card>

      {/* Service Grid */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {services.map((svc) => (
          <Card key={svc.name} hover>
            <CardBody>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  {svc.status === "healthy" ? (
                    <CheckCircle className="h-5 w-5 text-linkedin-green" />
                  ) : (
                    <AlertTriangle className="h-5 w-5 text-linkedin-orange" />
                  )}
                  <span className="text-sm font-medium text-linkedin-gray-90">{svc.name}</span>
                </div>
                <div className="flex items-center gap-2">
                  {svc.latency && (
                    <span className="text-xs tabular-nums text-linkedin-gray-50">{svc.latency}</span>
                  )}
                  <Badge variant={svc.status === "healthy" ? "success" : "warning"}>
                    {svc.status}
                  </Badge>
                </div>
              </div>
            </CardBody>
          </Card>
        ))}
      </div>

      {/* Active Alerts */}
      <Card padding="none">
        <CardHeader>
          <div className="flex items-center gap-2">
            Active Alerts
            <Badge variant="warning">{activeAlerts.length}</Badge>
          </div>
        </CardHeader>
        <CardBody className="flex flex-col gap-2">
          {activeAlerts.map((alert, i) => (
            <div key={i} className="flex items-center gap-3 rounded-lg border border-orange-200 bg-orange-50 px-4 py-3">
              <AlertTriangle className="h-4 w-4 text-linkedin-orange shrink-0" />
              <span className="text-sm text-linkedin-gray-90">{alert.message}</span>
              <Badge variant="warning" className="ml-auto">{alert.severity}</Badge>
            </div>
          ))}
        </CardBody>
      </Card>
    </div>
  );
}
