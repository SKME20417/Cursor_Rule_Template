"use client";

import React from "react";
import { CheckCircle, AlertTriangle, BarChart3 } from "lucide-react";
import { cn } from "@/lib/utils/cn";
import { Card, CardBody, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { PageHeader } from "@/components/layout/page-header";

/* ------------------------------------------------------------------ */
/* Mock Data                                                           */
/* ------------------------------------------------------------------ */

const services = [
  { name: "Gateway", status: "healthy", uptime: "99.99", avgLatency: "12ms", errorRate: "0.01%", lastCheck: "30s ago" },
  { name: "Chat Service", status: "healthy", uptime: "99.98", avgLatency: "8ms", errorRate: "0.02%", lastCheck: "30s ago" },
  { name: "Voice Service", status: "healthy", uptime: "99.95", avgLatency: "45ms", errorRate: "0.05%", lastCheck: "30s ago" },
  { name: "Ticket Service", status: "healthy", uptime: "99.99", avgLatency: "15ms", errorRate: "0.01%", lastCheck: "30s ago" },
  { name: "RAG Service", status: "degraded", uptime: "99.82", avgLatency: "234ms", errorRate: "0.8%", lastCheck: "30s ago" },
  { name: "NLP Service", status: "healthy", uptime: "99.96", avgLatency: "67ms", errorRate: "0.04%", lastCheck: "30s ago" },
  { name: "Kafka", status: "healthy", uptime: "99.99", avgLatency: "3ms", errorRate: "0.00%", lastCheck: "30s ago" },
  { name: "Redis", status: "healthy", uptime: "99.99", avgLatency: "2ms", errorRate: "0.00%", lastCheck: "30s ago" },
  { name: "PostgreSQL", status: "healthy", uptime: "99.99", avgLatency: "5ms", errorRate: "0.01%", lastCheck: "30s ago" },
];

/* ------------------------------------------------------------------ */
/* Page                                                                */
/* ------------------------------------------------------------------ */

export default function ServicesHealthPage() {
  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="Service Health"
        subtitle="Detailed status and performance metrics for all services"
      />

      <Card padding="none">
        <CardBody className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-linkedin-gray-20 bg-linkedin-gray-10">
                  <th className="px-4 py-3 text-left font-medium text-linkedin-gray-70">Service</th>
                  <th className="px-4 py-3 text-left font-medium text-linkedin-gray-70">Status</th>
                  <th className="px-4 py-3 text-left font-medium text-linkedin-gray-70">Uptime %</th>
                  <th className="px-4 py-3 text-left font-medium text-linkedin-gray-70">Avg Latency</th>
                  <th className="px-4 py-3 text-left font-medium text-linkedin-gray-70">Error Rate</th>
                  <th className="px-4 py-3 text-left font-medium text-linkedin-gray-70">Last Check</th>
                </tr>
              </thead>
              <tbody>
                {services.map((svc, i) => (
                  <tr key={i} className="border-b border-linkedin-gray-20 last:border-0 hover:bg-linkedin-gray-10 transition-colors">
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2">
                        {svc.status === "healthy" ? (
                          <CheckCircle className="h-4 w-4 text-linkedin-green" />
                        ) : (
                          <AlertTriangle className="h-4 w-4 text-linkedin-orange" />
                        )}
                        <span className="font-medium text-linkedin-gray-90">{svc.name}</span>
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <Badge variant={svc.status === "healthy" ? "success" : "warning"}>{svc.status}</Badge>
                    </td>
                    <td className="px-4 py-3 text-linkedin-gray-70 tabular-nums">{svc.uptime}%</td>
                    <td className="px-4 py-3 text-linkedin-gray-70 tabular-nums">{svc.avgLatency}</td>
                    <td className="px-4 py-3 text-linkedin-gray-70 tabular-nums">{svc.errorRate}</td>
                    <td className="px-4 py-3 text-linkedin-gray-50">{svc.lastCheck}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardBody>
      </Card>

      <div className="grid gap-6 lg:grid-cols-2">
        <Card padding="none">
          <CardHeader>Latency Chart</CardHeader>
          <CardBody>
            <div className="flex items-end gap-2" style={{ height: 200 }}>
              {services.map((svc) => {
                const latencyNum = parseInt(svc.avgLatency);
                const maxLatency = 234;
                return (
                  <div key={svc.name} className="flex flex-1 flex-col items-center gap-1">
                    <span className="text-[10px] text-linkedin-gray-50 tabular-nums">{svc.avgLatency}</span>
                    <div
                      className={cn(
                        "w-full rounded-t-md transition-all",
                        svc.status === "degraded" ? "bg-linkedin-orange" : "bg-linkedin-blue"
                      )}
                      style={{ height: `${Math.max((latencyNum / maxLatency) * 160, 4)}px` }}
                    />
                    <span className="text-[9px] text-linkedin-gray-50 truncate w-full text-center">{svc.name}</span>
                  </div>
                );
              })}
            </div>
          </CardBody>
        </Card>

        <Card padding="none">
          <CardHeader>Error Rate Chart</CardHeader>
          <CardBody>
            <div className="flex items-end gap-2" style={{ height: 200 }}>
              {services.map((svc) => {
                const errorNum = parseFloat(svc.errorRate);
                const maxError = 0.8;
                return (
                  <div key={svc.name} className="flex flex-1 flex-col items-center gap-1">
                    <span className="text-[10px] text-linkedin-gray-50 tabular-nums">{svc.errorRate}</span>
                    <div
                      className={cn(
                        "w-full rounded-t-md transition-all",
                        errorNum > 0.5 ? "bg-linkedin-red" : errorNum > 0.02 ? "bg-linkedin-orange" : "bg-linkedin-green"
                      )}
                      style={{ height: `${Math.max((errorNum / maxError) * 160, 4)}px` }}
                    />
                    <span className="text-[9px] text-linkedin-gray-50 truncate w-full text-center">{svc.name}</span>
                  </div>
                );
              })}
            </div>
          </CardBody>
        </Card>
      </div>
    </div>
  );
}
