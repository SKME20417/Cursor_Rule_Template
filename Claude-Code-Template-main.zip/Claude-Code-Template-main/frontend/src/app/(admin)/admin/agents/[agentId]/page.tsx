"use client";

import React from "react";
import { cn } from "@/lib/utils/cn";
import {
  User,
  Mail,
  Users,
  Calendar,
  CheckCircle,
  Star,
  Clock,
  Activity,
} from "lucide-react";
import { Card, CardBody, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { PageHeader } from "@/components/layout/page-header";

/* ------------------------------------------------------------------ */
/* Mock Data                                                           */
/* ------------------------------------------------------------------ */

const agentProfile = {
  name: "Sarah Chen",
  avatar: "SC",
  email: "sarah.chen@company.com",
  role: "supervisor" as const,
  team: "Support Tier 2",
  status: "online" as const,
  joinedDate: "Jan 15, 2024",
} as const;

const performanceStats = [
  { label: "Tickets Resolved", value: "156", icon: CheckCircle },
  { label: "CSAT", value: "4.7", icon: Star },
  { label: "Avg Response", value: "1m 23s", icon: Clock },
] as const;

const recentActivity = [
  { id: "1", action: "Resolved ticket TKT-4521 (Billing inquiry)", time: "5 min ago" },
  { id: "2", action: "Escalated ticket TKT-4519 to Technical Support", time: "22 min ago" },
  { id: "3", action: "Left internal note on TKT-4515", time: "1 hour ago" },
  { id: "4", action: "Closed ticket TKT-4510 (Password reset)", time: "2 hours ago" },
  { id: "5", action: "Updated knowledge base article: Refund Process", time: "3 hours ago" },
] as const;

const skillOptions = ["Billing", "Technical", "Sales", "Onboarding", "VIP", "Escalation"] as const;
const selectedSkills: readonly string[] = ["Billing", "Technical", "Escalation"];

const statusDot: Record<string, string> = {
  online: "bg-linkedin-green",
  away: "bg-linkedin-orange",
  offline: "bg-linkedin-gray-50",
};

/* ------------------------------------------------------------------ */
/* Page                                                                */
/* ------------------------------------------------------------------ */

export default function AgentDetailPage() {
  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="Agent Detail"
        subtitle="View and edit agent profile"
      />

      <div className="grid gap-6 lg:grid-cols-3">
        {/* Profile Card */}
        <Card padding="none">
          <CardHeader>Profile</CardHeader>
          <CardBody>
            <div className="flex flex-col items-center gap-3">
              <div className="flex h-16 w-16 items-center justify-center rounded-full bg-linkedin-blue-bg text-xl font-bold text-linkedin-blue">
                {agentProfile.avatar}
              </div>
              <div className="text-center">
                <p className="text-lg font-semibold text-linkedin-gray-90">{agentProfile.name}</p>
                <p className="text-sm text-linkedin-gray-50">{agentProfile.email}</p>
              </div>
              <Badge variant="success" size="md">{agentProfile.role}</Badge>
              <div className="mt-2 flex w-full flex-col gap-2 text-sm">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5 text-linkedin-gray-50">
                    <Users className="h-3.5 w-3.5" />
                    <span>Team</span>
                  </div>
                  <span className="text-linkedin-gray-90">{agentProfile.team}</span>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5 text-linkedin-gray-50">
                    <Activity className="h-3.5 w-3.5" />
                    <span>Status</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span className={cn("h-2 w-2 rounded-full", statusDot[agentProfile.status])} />
                    <span className="capitalize text-linkedin-gray-90">{agentProfile.status}</span>
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5 text-linkedin-gray-50">
                    <Calendar className="h-3.5 w-3.5" />
                    <span>Joined</span>
                  </div>
                  <span className="text-linkedin-gray-90">{agentProfile.joinedDate}</span>
                </div>
              </div>
            </div>
          </CardBody>
        </Card>

        {/* Performance Stats + Edit Form */}
        <div className="flex flex-col gap-4 lg:col-span-2">
          <div className="grid gap-4 sm:grid-cols-3">
            {performanceStats.map((stat) => (
              <Card key={stat.label} hover>
                <CardBody>
                  <div className="flex items-start justify-between">
                    <div>
                      <p className="text-xs text-linkedin-gray-50">{stat.label}</p>
                      <p className="mt-1 text-2xl font-bold text-linkedin-gray-90">{stat.value}</p>
                    </div>
                    <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-linkedin-blue-bg">
                      <stat.icon className="h-5 w-5 text-linkedin-blue" />
                    </div>
                  </div>
                </CardBody>
              </Card>
            ))}
          </div>

          <Card padding="none">
            <CardHeader>Edit Agent</CardHeader>
            <CardBody>
              <div className="grid gap-4 sm:grid-cols-2">
                <div>
                  <label className="mb-1 block text-xs font-medium text-linkedin-gray-70">Name</label>
                  <input
                    type="text"
                    defaultValue={agentProfile.name}
                    className="w-full rounded-lg border border-linkedin-gray-20 px-3 py-2 text-sm text-linkedin-gray-90 focus:border-linkedin-blue focus:outline-none focus:ring-1 focus:ring-linkedin-blue"
                  />
                </div>
                <div>
                  <label className="mb-1 block text-xs font-medium text-linkedin-gray-70">Email</label>
                  <input
                    type="email"
                    defaultValue={agentProfile.email}
                    className="w-full rounded-lg border border-linkedin-gray-20 px-3 py-2 text-sm text-linkedin-gray-90 focus:border-linkedin-blue focus:outline-none focus:ring-1 focus:ring-linkedin-blue"
                  />
                </div>
                <div>
                  <label className="mb-1 block text-xs font-medium text-linkedin-gray-70">Role</label>
                  <select
                    defaultValue={agentProfile.role}
                    className="w-full rounded-lg border border-linkedin-gray-20 px-3 py-2 text-sm text-linkedin-gray-70 focus:border-linkedin-blue focus:outline-none"
                  >
                    <option value="agent">Agent</option>
                    <option value="supervisor">Supervisor</option>
                    <option value="admin">Admin</option>
                  </select>
                </div>
                <div>
                  <label className="mb-1 block text-xs font-medium text-linkedin-gray-70">Team</label>
                  <select
                    defaultValue={agentProfile.team}
                    className="w-full rounded-lg border border-linkedin-gray-20 px-3 py-2 text-sm text-linkedin-gray-70 focus:border-linkedin-blue focus:outline-none"
                  >
                    <option>Support Tier 1</option>
                    <option>Support Tier 2</option>
                    <option>Technical Support</option>
                    <option>VIP Support</option>
                  </select>
                </div>
                <div className="sm:col-span-2">
                  <label className="mb-1 block text-xs font-medium text-linkedin-gray-70">Skills</label>
                  <div className="flex flex-wrap gap-2">
                    {skillOptions.map((skill) => (
                      <Badge
                        key={skill}
                        variant={selectedSkills.includes(skill) ? "primary" : "default"}
                        className="cursor-pointer"
                      >
                        {skill}
                      </Badge>
                    ))}
                  </div>
                </div>
                <div>
                  <label className="mb-1 block text-xs font-medium text-linkedin-gray-70">Max Concurrent Tickets</label>
                  <input
                    type="number"
                    defaultValue={10}
                    min={1}
                    max={20}
                    className="w-full rounded-lg border border-linkedin-gray-20 px-3 py-2 text-sm text-linkedin-gray-90 focus:border-linkedin-blue focus:outline-none focus:ring-1 focus:ring-linkedin-blue"
                  />
                </div>
              </div>
              <div className="mt-4 flex justify-end">
                <button className="rounded-lg bg-linkedin-blue px-4 py-2 text-sm font-medium text-white transition-colors hover:bg-linkedin-blue-dark">
                  Save Changes
                </button>
              </div>
            </CardBody>
          </Card>
        </div>
      </div>

      {/* Recent Activity */}
      <Card padding="none">
        <CardHeader>Recent Activity</CardHeader>
        <CardBody>
          <div className="flex flex-col gap-3">
            {recentActivity.map((item) => (
              <div
                key={item.id}
                className="flex items-center justify-between rounded-lg px-2 py-2 transition-colors hover:bg-linkedin-gray-10"
              >
                <div className="flex items-center gap-2">
                  <div className="flex h-6 w-6 items-center justify-center rounded-full bg-linkedin-blue-bg">
                    <Activity className="h-3 w-3 text-linkedin-blue" />
                  </div>
                  <span className="text-sm text-linkedin-gray-90">{item.action}</span>
                </div>
                <span className="shrink-0 text-xs text-linkedin-gray-50">{item.time}</span>
              </div>
            ))}
          </div>
        </CardBody>
      </Card>
    </div>
  );
}
