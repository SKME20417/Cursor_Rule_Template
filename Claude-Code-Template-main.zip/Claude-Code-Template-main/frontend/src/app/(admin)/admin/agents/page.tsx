"use client";

import React, { useState } from "react";
import { cn } from "@/lib/utils/cn";
import {
  Users,
  Wifi,
  BarChart3,
  Plus,
  Search,
  Star,
} from "lucide-react";
import { Card, CardBody, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { PageHeader } from "@/components/layout/page-header";

/* ------------------------------------------------------------------ */
/* Mock Data                                                           */
/* ------------------------------------------------------------------ */

const summaryStats = [
  { label: "Total Agents", value: "24", icon: Users },
  { label: "Online", value: "18", icon: Wifi },
  { label: "Avg Workload", value: "6.2 tickets", icon: BarChart3 },
] as const;

interface Agent {
  id: string;
  name: string;
  avatar: string;
  email: string;
  role: "admin" | "supervisor" | "agent";
  team: string;
  status: "online" | "away" | "offline";
  activeTickets: number;
  csat: number;
}

const mockAgents: Agent[] = [
  { id: "1", name: "Sarah Chen", avatar: "SC", email: "sarah.chen@company.com", role: "supervisor", team: "Support Tier 2", status: "online", activeTickets: 8, csat: 4.9 },
  { id: "2", name: "James Wilson", avatar: "JW", email: "james.wilson@company.com", role: "agent", team: "Support Tier 1", status: "online", activeTickets: 6, csat: 4.8 },
  { id: "3", name: "Maria Garcia", avatar: "MG", email: "maria.garcia@company.com", role: "agent", team: "Technical Support", status: "online", activeTickets: 7, csat: 4.7 },
  { id: "4", name: "Alex Kim", avatar: "AK", email: "alex.kim@company.com", role: "agent", team: "VIP Support", status: "away", activeTickets: 4, csat: 4.7 },
  { id: "5", name: "David Brown", avatar: "DB", email: "david.brown@company.com", role: "agent", team: "Support Tier 1", status: "online", activeTickets: 5, csat: 4.6 },
  { id: "6", name: "Emma Davis", avatar: "ED", email: "emma.davis@company.com", role: "supervisor", team: "Technical Support", status: "online", activeTickets: 9, csat: 4.5 },
  { id: "7", name: "Mike Johnson", avatar: "MJ", email: "mike.johnson@company.com", role: "agent", team: "Support Tier 2", status: "offline", activeTickets: 0, csat: 4.5 },
  { id: "8", name: "Lisa Wang", avatar: "LW", email: "lisa.wang@company.com", role: "agent", team: "VIP Support", status: "online", activeTickets: 3, csat: 4.4 },
];

const statusDot: Record<string, string> = {
  online: "bg-linkedin-green",
  away: "bg-linkedin-orange",
  offline: "bg-linkedin-gray-50",
};

const roleBadge: Record<string, "primary" | "success" | "default"> = {
  admin: "primary",
  supervisor: "success",
  agent: "default",
};

/* ------------------------------------------------------------------ */
/* Page                                                                */
/* ------------------------------------------------------------------ */

export default function AgentsPage() {
  const [searchQuery, setSearchQuery] = useState("");
  const [filterTeam, setFilterTeam] = useState("all");
  const [filterRole, setFilterRole] = useState("all");
  const [filterStatus, setFilterStatus] = useState("all");

  const teams = [...new Set(mockAgents.map((a) => a.team))];
  const roles = [...new Set(mockAgents.map((a) => a.role))];
  const statuses = ["online", "away", "offline"] as const;

  const filtered = mockAgents.filter((agent) => {
    if (searchQuery && !agent.name.toLowerCase().includes(searchQuery.toLowerCase()) && !agent.email.toLowerCase().includes(searchQuery.toLowerCase())) return false;
    if (filterTeam !== "all" && agent.team !== filterTeam) return false;
    if (filterRole !== "all" && agent.role !== filterRole) return false;
    if (filterStatus !== "all" && agent.status !== filterStatus) return false;
    return true;
  });

  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="Agent Management"
        subtitle="Manage your support team"
        actions={
          <button className="flex items-center gap-2 rounded-lg bg-linkedin-blue px-4 py-2 text-sm font-medium text-white transition-colors hover:bg-linkedin-blue-dark">
            <Plus className="h-4 w-4" />
            Invite Agent
          </button>
        }
      />

      {/* Stats */}
      <div className="grid gap-4 sm:grid-cols-3">
        {summaryStats.map((s) => (
          <Card key={s.label} hover>
            <CardBody>
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-xs text-linkedin-gray-50">{s.label}</p>
                  <p className="mt-1 text-2xl font-bold text-linkedin-gray-90">{s.value}</p>
                </div>
                <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-linkedin-blue-bg">
                  <s.icon className="h-5 w-5 text-linkedin-blue" />
                </div>
              </div>
            </CardBody>
          </Card>
        ))}
      </div>

      {/* Filters */}
      <Card padding="none">
        <CardBody>
          <div className="flex flex-wrap items-center gap-3">
            <div className="relative flex-1 min-w-[200px]">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-linkedin-gray-50" />
              <input
                type="text"
                placeholder="Search agents..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full rounded-lg border border-linkedin-gray-20 py-2 pl-10 pr-3 text-sm text-linkedin-gray-90 placeholder:text-linkedin-gray-50 focus:border-linkedin-blue focus:outline-none focus:ring-1 focus:ring-linkedin-blue"
              />
            </div>
            <select
              value={filterTeam}
              onChange={(e) => setFilterTeam(e.target.value)}
              className="rounded-lg border border-linkedin-gray-20 px-3 py-2 text-sm text-linkedin-gray-70 focus:border-linkedin-blue focus:outline-none"
            >
              <option value="all">All Teams</option>
              {teams.map((t) => (
                <option key={t} value={t}>{t}</option>
              ))}
            </select>
            <select
              value={filterRole}
              onChange={(e) => setFilterRole(e.target.value)}
              className="rounded-lg border border-linkedin-gray-20 px-3 py-2 text-sm text-linkedin-gray-70 focus:border-linkedin-blue focus:outline-none"
            >
              <option value="all">All Roles</option>
              {roles.map((r) => (
                <option key={r} value={r}>{r}</option>
              ))}
            </select>
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="rounded-lg border border-linkedin-gray-20 px-3 py-2 text-sm text-linkedin-gray-70 focus:border-linkedin-blue focus:outline-none"
            >
              <option value="all">All Statuses</option>
              {statuses.map((s) => (
                <option key={s} value={s}>{s}</option>
              ))}
            </select>
          </div>
        </CardBody>
      </Card>

      {/* Agent Table */}
      <Card padding="none">
        <CardBody className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-linkedin-gray-20 text-left text-xs text-linkedin-gray-50">
                  <th className="px-4 py-3 font-medium">Agent</th>
                  <th className="px-4 py-3 font-medium">Email</th>
                  <th className="px-4 py-3 font-medium">Role</th>
                  <th className="px-4 py-3 font-medium">Team</th>
                  <th className="px-4 py-3 font-medium">Status</th>
                  <th className="px-4 py-3 font-medium">Active Tickets</th>
                  <th className="px-4 py-3 font-medium">CSAT</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((agent) => (
                  <tr
                    key={agent.id}
                    className="border-b border-linkedin-gray-20 last:border-0 cursor-pointer transition-colors hover:bg-linkedin-gray-10"
                  >
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2">
                        <div className="flex h-8 w-8 items-center justify-center rounded-full bg-linkedin-blue-bg text-xs font-semibold text-linkedin-blue">
                          {agent.avatar}
                        </div>
                        <span className="font-medium text-linkedin-gray-90">{agent.name}</span>
                      </div>
                    </td>
                    <td className="px-4 py-3 text-linkedin-gray-70">{agent.email}</td>
                    <td className="px-4 py-3">
                      <Badge variant={roleBadge[agent.role]} size="sm">{agent.role}</Badge>
                    </td>
                    <td className="px-4 py-3 text-linkedin-gray-70">{agent.team}</td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-1.5">
                        <span className={cn("h-2 w-2 rounded-full", statusDot[agent.status])} />
                        <span className="text-xs capitalize text-linkedin-gray-70">{agent.status}</span>
                      </div>
                    </td>
                    <td className="px-4 py-3 text-linkedin-gray-70">{agent.activeTickets}</td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-1">
                        <Star className="h-3 w-3 text-linkedin-orange" />
                        <span className="text-linkedin-gray-70">{agent.csat}</span>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardBody>
      </Card>
    </div>
  );
}
