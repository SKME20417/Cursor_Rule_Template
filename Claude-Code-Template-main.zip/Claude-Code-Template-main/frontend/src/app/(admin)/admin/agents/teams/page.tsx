"use client";

import React from "react";
import { cn } from "@/lib/utils/cn";
import {
  Users,
  Star,
  Plus,
  User,
} from "lucide-react";
import { Card, CardBody } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { PageHeader } from "@/components/layout/page-header";

/* ------------------------------------------------------------------ */
/* Mock Data                                                           */
/* ------------------------------------------------------------------ */

const teams = [
  { id: "1", name: "Support Tier 1", memberCount: 8, teamLead: "James Wilson", avgCsat: 4.5, color: "bg-linkedin-blue-bg text-linkedin-blue" },
  { id: "2", name: "Support Tier 2", memberCount: 6, teamLead: "Sarah Chen", avgCsat: 4.7, color: "bg-green-50 text-linkedin-green" },
  { id: "3", name: "Technical Support", memberCount: 5, teamLead: "Emma Davis", avgCsat: 4.6, color: "bg-purple-50 text-purple-600" },
  { id: "4", name: "VIP Support", memberCount: 5, teamLead: "Lisa Wang", avgCsat: 4.8, color: "bg-orange-50 text-linkedin-orange" },
] as const;

/* ------------------------------------------------------------------ */
/* Page                                                                */
/* ------------------------------------------------------------------ */

export default function TeamsPage() {
  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="Teams"
        subtitle="Organize agents into support teams"
        actions={
          <button className="flex items-center gap-2 rounded-lg bg-linkedin-blue px-4 py-2 text-sm font-medium text-white transition-colors hover:bg-linkedin-blue-dark">
            <Plus className="h-4 w-4" />
            Create Team
          </button>
        }
      />

      {/* Team Cards */}
      <div className="grid gap-4 sm:grid-cols-2">
        {teams.map((team) => (
          <Card key={team.id} hover>
            <CardBody>
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <div className={cn("flex h-12 w-12 items-center justify-center rounded-xl", team.color)}>
                    <Users className="h-6 w-6" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-linkedin-gray-90">{team.name}</h3>
                    <p className="text-sm text-linkedin-gray-50">{team.memberCount} members</p>
                  </div>
                </div>
              </div>

              <div className="mt-4 flex flex-col gap-2 text-sm">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5 text-linkedin-gray-50">
                    <User className="h-3.5 w-3.5" />
                    <span>Team Lead</span>
                  </div>
                  <span className="font-medium text-linkedin-gray-90">{team.teamLead}</span>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5 text-linkedin-gray-50">
                    <Star className="h-3.5 w-3.5" />
                    <span>Avg CSAT</span>
                  </div>
                  <Badge variant="success" size="sm">{team.avgCsat}</Badge>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5 text-linkedin-gray-50">
                    <Users className="h-3.5 w-3.5" />
                    <span>Members</span>
                  </div>
                  <span className="font-medium text-linkedin-gray-90">{team.memberCount}</span>
                </div>
              </div>

              <div className="mt-4 flex gap-2">
                <button className="flex-1 rounded-lg border border-linkedin-gray-20 px-3 py-1.5 text-xs font-medium text-linkedin-gray-70 transition-colors hover:bg-linkedin-gray-10">
                  View Members
                </button>
                <button className="flex-1 rounded-lg border border-linkedin-blue px-3 py-1.5 text-xs font-medium text-linkedin-blue transition-colors hover:bg-linkedin-blue-bg">
                  Edit Team
                </button>
              </div>
            </CardBody>
          </Card>
        ))}
      </div>
    </div>
  );
}
