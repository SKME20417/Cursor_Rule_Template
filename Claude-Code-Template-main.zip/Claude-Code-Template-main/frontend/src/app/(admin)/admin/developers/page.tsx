"use client";

import React from "react";
import {
  BookOpen,
  Webhook,
  Terminal,
  Zap,
  Clock,
  AlertCircle,
} from "lucide-react";
import { cn } from "@/lib/utils/cn";
import { Card, CardBody } from "@/components/ui/card";
import { PageHeader } from "@/components/layout/page-header";

/* ------------------------------------------------------------------ */
/* Mock Data                                                           */
/* ------------------------------------------------------------------ */

const usageStats = [
  { label: "API Calls Today", value: "12,456", icon: Zap, color: "text-linkedin-blue" },
  { label: "Avg Latency", value: "45ms", icon: Clock, color: "text-linkedin-green" },
  { label: "Error Rate", value: "0.3%", icon: AlertCircle, color: "text-linkedin-orange" },
];

const portalCards = [
  { title: "API Documentation", description: "Explore endpoints, request/response schemas, and examples", icon: BookOpen, href: "/developers/api-docs" },
  { title: "Webhooks", description: "3 active webhooks configured", icon: Webhook, href: "/developers/webhooks" },
  { title: "API Sandbox", description: "Test API endpoints in a live sandbox environment", icon: Terminal, href: "/developers/sandbox" },
];

/* ------------------------------------------------------------------ */
/* Page                                                                */
/* ------------------------------------------------------------------ */

export default function DeveloperPortalPage() {
  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="Developer Portal"
        subtitle="API documentation, webhooks, and sandbox tools"
      />

      {/* Welcome */}
      <Card>
        <CardBody>
          <h2 className="text-lg font-semibold text-linkedin-gray-90">Welcome to the Developer Portal</h2>
          <p className="mt-1 text-sm text-linkedin-gray-50">
            Access API documentation, manage webhooks, and test endpoints in the sandbox. Everything you need to integrate with our platform.
          </p>
        </CardBody>
      </Card>

      {/* Stats */}
      <div className="grid gap-4 sm:grid-cols-3">
        {usageStats.map((stat) => (
          <Card key={stat.label} hover>
            <CardBody>
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-xs text-linkedin-gray-50">{stat.label}</p>
                  <p className="mt-1 text-2xl font-bold text-linkedin-gray-90">{stat.value}</p>
                </div>
                <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-linkedin-blue-bg">
                  <stat.icon className={cn("h-5 w-5", stat.color)} />
                </div>
              </div>
            </CardBody>
          </Card>
        ))}
      </div>

      {/* Portal Cards */}
      <div className="grid gap-4 sm:grid-cols-3">
        {portalCards.map((card) => (
          <a key={card.title} href={card.href}>
            <Card hover>
              <CardBody>
                <div className="flex flex-col gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-linkedin-blue-bg">
                    <card.icon className="h-5 w-5 text-linkedin-blue" />
                  </div>
                  <div>
                    <h3 className="text-sm font-semibold text-linkedin-gray-90">{card.title}</h3>
                    <p className="mt-1 text-xs text-linkedin-gray-50">{card.description}</p>
                  </div>
                </div>
              </CardBody>
            </Card>
          </a>
        ))}
      </div>
    </div>
  );
}
