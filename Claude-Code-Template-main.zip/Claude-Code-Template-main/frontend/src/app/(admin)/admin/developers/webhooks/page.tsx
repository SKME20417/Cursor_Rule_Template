"use client";

import React, { useState } from "react";
import { Plus, Play, Pencil, Trash2, CheckCircle } from "lucide-react";
import { cn } from "@/lib/utils/cn";
import { Card, CardBody, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { PageHeader } from "@/components/layout/page-header";

/* ------------------------------------------------------------------ */
/* Mock Data                                                           */
/* ------------------------------------------------------------------ */

const webhooks = [
  {
    url: "https://hooks.example.com/support/events",
    events: ["ticket.created", "ticket.updated"],
    status: "Active",
    lastTriggered: "5 min ago",
    testResult: null as string | null,
  },
  {
    url: "https://api.internal.com/webhooks/conversations",
    events: ["conversation.created", "conversation.closed"],
    status: "Active",
    lastTriggered: "1 hour ago",
    testResult: null as string | null,
  },
  {
    url: "https://analytics.example.com/ingest",
    events: ["ticket.resolved", "csat.submitted"],
    status: "Active",
    lastTriggered: "3 hours ago",
    testResult: null as string | null,
  },
];

/* ------------------------------------------------------------------ */
/* Page                                                                */
/* ------------------------------------------------------------------ */

export default function WebhooksPage() {
  const [items, setItems] = useState(webhooks);

  const handleTest = (idx: number) => {
    setItems((prev) =>
      prev.map((w, i) => (i === idx ? { ...w, testResult: "200 OK - Success" } : w))
    );
  };

  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="Webhooks"
        subtitle="Manage webhook endpoints and event subscriptions"
        actions={
          <button className="inline-flex items-center gap-2 rounded-lg bg-linkedin-blue px-4 py-2 text-sm font-medium text-white hover:bg-linkedin-blue-dark transition-colors">
            <Plus className="h-4 w-4" />
            Add Webhook
          </button>
        }
      />

      <Card padding="none">
        <CardBody className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-linkedin-gray-20 bg-linkedin-gray-10">
                  <th className="px-4 py-3 text-left font-medium text-linkedin-gray-70">URL</th>
                  <th className="px-4 py-3 text-left font-medium text-linkedin-gray-70">Events</th>
                  <th className="px-4 py-3 text-left font-medium text-linkedin-gray-70">Status</th>
                  <th className="px-4 py-3 text-left font-medium text-linkedin-gray-70">Last Triggered</th>
                  <th className="px-4 py-3 text-left font-medium text-linkedin-gray-70">Actions</th>
                </tr>
              </thead>
              <tbody>
                {items.map((wh, i) => (
                  <tr key={i} className="border-b border-linkedin-gray-20 last:border-0 hover:bg-linkedin-gray-10 transition-colors">
                    <td className="px-4 py-3">
                      <code className="text-xs font-mono text-linkedin-gray-90 break-all">{wh.url}</code>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex flex-wrap gap-1">
                        {wh.events.map((ev) => (
                          <Badge key={ev} variant="primary">{ev}</Badge>
                        ))}
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <Badge variant="success">{wh.status}</Badge>
                    </td>
                    <td className="px-4 py-3 text-linkedin-gray-50">{wh.lastTriggered}</td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-1">
                        <button
                          onClick={() => handleTest(i)}
                          className="rounded-md p-1.5 text-linkedin-blue hover:bg-linkedin-blue-bg transition-colors"
                          title="Test"
                        >
                          <Play className="h-3.5 w-3.5" />
                        </button>
                        <button className="rounded-md p-1.5 text-linkedin-gray-50 hover:bg-linkedin-gray-20 transition-colors" title="Edit">
                          <Pencil className="h-3.5 w-3.5" />
                        </button>
                        <button className="rounded-md p-1.5 text-linkedin-red hover:bg-red-50 transition-colors" title="Delete">
                          <Trash2 className="h-3.5 w-3.5" />
                        </button>
                      </div>
                      {wh.testResult && (
                        <div className="mt-1 flex items-center gap-1 text-xs text-linkedin-green">
                          <CheckCircle className="h-3 w-3" />
                          {wh.testResult}
                        </div>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardBody>
      </Card>
    </div>
  );
}
