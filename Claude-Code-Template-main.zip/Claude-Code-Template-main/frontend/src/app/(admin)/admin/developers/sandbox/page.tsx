"use client";

import React, { useState } from "react";
import { Send, Plus } from "lucide-react";
import { cn } from "@/lib/utils/cn";
import { Card, CardBody, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { PageHeader } from "@/components/layout/page-header";

/* ------------------------------------------------------------------ */
/* Mock Data                                                           */
/* ------------------------------------------------------------------ */

const mockRequestBody = `{
  "customer_id": "cust_abc123",
  "channel": "live_chat",
  "message": "Hello, I need help with my order"
}`;

const mockResponseBody = `{
  "id": "conv_xyz789",
  "customer_id": "cust_abc123",
  "channel": "live_chat",
  "status": "open",
  "created_at": "2026-03-09T14:30:00Z",
  "messages": [
    {
      "id": "msg_001",
      "role": "customer",
      "content": "Hello, I need help with my order",
      "created_at": "2026-03-09T14:30:00Z"
    }
  ]
}`;

/* ------------------------------------------------------------------ */
/* Page                                                                */
/* ------------------------------------------------------------------ */

export default function SandboxPage() {
  const [method, setMethod] = useState("POST");
  const [endpoint, setEndpoint] = useState("/api/v1/conversations");
  const [headers, setHeaders] = useState([
    { key: "Authorization", value: "Bearer sk_live_your_api_key" },
    { key: "Content-Type", value: "application/json" },
  ]);
  const [body, setBody] = useState(mockRequestBody);
  const [showResponse, setShowResponse] = useState(true);

  const addHeader = () => {
    setHeaders([...headers, { key: "", value: "" }]);
  };

  const methodColors: Record<string, string> = {
    GET: "bg-green-100 text-green-700",
    POST: "bg-blue-100 text-blue-700",
    PUT: "bg-orange-100 text-orange-700",
    DELETE: "bg-red-100 text-red-700",
  };

  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="API Sandbox"
        subtitle="Test API endpoints with live requests"
      />

      {/* Request */}
      <Card padding="none">
        <CardHeader>Request</CardHeader>
        <CardBody className="flex flex-col gap-4">
          {/* Method + Endpoint */}
          <div className="flex gap-2">
            <select
              value={method}
              onChange={(e) => setMethod(e.target.value)}
              className={cn(
                "rounded-lg border border-linkedin-gray-30 px-3 py-2 text-sm font-bold focus:border-linkedin-blue focus:outline-none focus:ring-1 focus:ring-linkedin-blue",
                methodColors[method] || "bg-white"
              )}
            >
              <option value="GET">GET</option>
              <option value="POST">POST</option>
              <option value="PUT">PUT</option>
              <option value="DELETE">DELETE</option>
            </select>
            <input
              type="text"
              value={endpoint}
              onChange={(e) => setEndpoint(e.target.value)}
              className="flex-1 rounded-lg border border-linkedin-gray-30 bg-white px-3 py-2 text-sm font-mono text-linkedin-gray-90 focus:border-linkedin-blue focus:outline-none focus:ring-1 focus:ring-linkedin-blue"
            />
            <button
              onClick={() => setShowResponse(true)}
              className="inline-flex items-center gap-2 rounded-lg bg-linkedin-blue px-4 py-2 text-sm font-medium text-white hover:bg-linkedin-blue-dark transition-colors"
            >
              <Send className="h-4 w-4" />
              Send Request
            </button>
          </div>

          {/* Headers */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-sm font-medium text-linkedin-gray-90">Headers</label>
              <button onClick={addHeader} className="inline-flex items-center gap-1 text-xs text-linkedin-blue hover:underline">
                <Plus className="h-3 w-3" />
                Add Header
              </button>
            </div>
            <div className="flex flex-col gap-2">
              {headers.map((h, i) => (
                <div key={i} className="flex gap-2">
                  <input
                    type="text"
                    value={h.key}
                    onChange={(e) => {
                      const updated = [...headers];
                      updated[i] = { ...updated[i], key: e.target.value };
                      setHeaders(updated);
                    }}
                    placeholder="Key"
                    className="w-1/3 rounded-lg border border-linkedin-gray-30 bg-white px-3 py-2 text-sm text-linkedin-gray-90 font-mono focus:border-linkedin-blue focus:outline-none focus:ring-1 focus:ring-linkedin-blue"
                  />
                  <input
                    type="text"
                    value={h.value}
                    onChange={(e) => {
                      const updated = [...headers];
                      updated[i] = { ...updated[i], value: e.target.value };
                      setHeaders(updated);
                    }}
                    placeholder="Value"
                    className="flex-1 rounded-lg border border-linkedin-gray-30 bg-white px-3 py-2 text-sm text-linkedin-gray-90 font-mono focus:border-linkedin-blue focus:outline-none focus:ring-1 focus:ring-linkedin-blue"
                  />
                </div>
              ))}
            </div>
          </div>

          {/* Body */}
          {(method === "POST" || method === "PUT") && (
            <div>
              <label className="text-sm font-medium text-linkedin-gray-90 mb-2 block">Body (JSON)</label>
              <textarea
                value={body}
                onChange={(e) => setBody(e.target.value)}
                rows={8}
                className="w-full rounded-lg border border-linkedin-gray-30 bg-white px-3 py-2 text-sm text-linkedin-gray-90 font-mono focus:border-linkedin-blue focus:outline-none focus:ring-1 focus:ring-linkedin-blue resize-none"
              />
            </div>
          )}
        </CardBody>
      </Card>

      {/* Response */}
      {showResponse && (
        <Card padding="none">
          <CardHeader>
            <div className="flex items-center gap-3">
              Response
              <Badge variant="success">200 OK</Badge>
              <span className="text-xs text-linkedin-gray-50">45ms</span>
            </div>
          </CardHeader>
          <CardBody>
            <pre className="overflow-x-auto rounded-lg bg-linkedin-gray-90 p-4 text-xs text-green-400 font-mono whitespace-pre-wrap">
              {mockResponseBody}
            </pre>
          </CardBody>
        </Card>
      )}
    </div>
  );
}
