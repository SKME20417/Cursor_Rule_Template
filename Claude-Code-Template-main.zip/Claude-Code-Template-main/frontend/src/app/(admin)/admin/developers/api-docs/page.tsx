"use client";

import React, { useState } from "react";
import { cn } from "@/lib/utils/cn";
import { Card, CardBody, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { PageHeader } from "@/components/layout/page-header";

/* ------------------------------------------------------------------ */
/* Mock Data                                                           */
/* ------------------------------------------------------------------ */

const sections = ["Authentication", "Conversations", "Tickets", "Customers", "Knowledge Base", "Webhooks"];

const methodColors: Record<string, string> = {
  GET: "bg-green-100 text-green-700",
  POST: "bg-blue-100 text-blue-700",
  PUT: "bg-orange-100 text-orange-700",
  DELETE: "bg-red-100 text-red-700",
};

interface Endpoint {
  method: string;
  path: string;
  description: string;
}

const endpointsBySection: Record<string, Endpoint[]> = {
  Authentication: [
    { method: "POST", path: "/api/v1/auth/token", description: "Generate an access token" },
    { method: "POST", path: "/api/v1/auth/refresh", description: "Refresh an expired token" },
  ],
  Conversations: [
    { method: "GET", path: "/api/v1/conversations", description: "List all conversations" },
    { method: "POST", path: "/api/v1/conversations", description: "Create a new conversation" },
    { method: "GET", path: "/api/v1/conversations/:id", description: "Get conversation details" },
    { method: "POST", path: "/api/v1/conversations/:id/messages", description: "Send a message" },
  ],
  Tickets: [
    { method: "GET", path: "/api/v1/tickets", description: "List all tickets" },
    { method: "POST", path: "/api/v1/tickets", description: "Create a new ticket" },
    { method: "PUT", path: "/api/v1/tickets/:id", description: "Update a ticket" },
    { method: "DELETE", path: "/api/v1/tickets/:id", description: "Delete a ticket" },
  ],
  Customers: [
    { method: "GET", path: "/api/v1/customers", description: "List all customers" },
    { method: "GET", path: "/api/v1/customers/:id", description: "Get customer details" },
  ],
  "Knowledge Base": [
    { method: "GET", path: "/api/v1/kb/articles", description: "List all articles" },
    { method: "POST", path: "/api/v1/kb/search", description: "Search the knowledge base" },
  ],
  Webhooks: [
    { method: "GET", path: "/api/v1/webhooks", description: "List all webhooks" },
    { method: "POST", path: "/api/v1/webhooks", description: "Create a webhook" },
    { method: "DELETE", path: "/api/v1/webhooks/:id", description: "Delete a webhook" },
  ],
};

const requestExample = `curl -X POST https://api.example.com/api/v1/conversations \\
  -H "Authorization: Bearer sk_live_your_api_key" \\
  -H "Content-Type: application/json" \\
  -d '{
    "customer_id": "cust_abc123",
    "channel": "live_chat",
    "message": "Hello, I need help!"
  }'`;

const responseExample = `{
  "id": "conv_xyz789",
  "customer_id": "cust_abc123",
  "channel": "live_chat",
  "status": "open",
  "created_at": "2026-03-09T14:30:00Z",
  "messages": [
    {
      "id": "msg_001",
      "role": "customer",
      "content": "Hello, I need help!",
      "created_at": "2026-03-09T14:30:00Z"
    }
  ]
}`;

/* ------------------------------------------------------------------ */
/* Page                                                                */
/* ------------------------------------------------------------------ */

export default function APIDocsPage() {
  const [activeSection, setActiveSection] = useState("Authentication");

  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="API Documentation"
        subtitle="Explore endpoints and integration guides"
      />

      <div className="grid gap-6 lg:grid-cols-4">
        {/* Sidebar Nav */}
        <Card padding="none" className="lg:col-span-1 h-fit">
          <CardHeader>Endpoints</CardHeader>
          <CardBody className="flex flex-col gap-0.5 p-2">
            {sections.map((section) => (
              <button
                key={section}
                onClick={() => setActiveSection(section)}
                className={cn(
                  "rounded-md px-3 py-2 text-left text-sm transition-colors",
                  activeSection === section
                    ? "bg-linkedin-blue-bg text-linkedin-blue font-medium"
                    : "text-linkedin-gray-70 hover:bg-linkedin-gray-10"
                )}
              >
                {section}
              </button>
            ))}
          </CardBody>
        </Card>

        {/* Main Content */}
        <div className="lg:col-span-3 flex flex-col gap-6">
          {/* Endpoints List */}
          <Card padding="none">
            <CardHeader>{activeSection}</CardHeader>
            <CardBody className="flex flex-col gap-3">
              {endpointsBySection[activeSection]?.map((ep, i) => (
                <div key={i} className="flex items-start gap-3 rounded-lg border border-linkedin-gray-20 p-3 hover:bg-linkedin-gray-10 transition-colors">
                  <span className={cn("rounded px-2 py-0.5 text-xs font-bold", methodColors[ep.method])}>
                    {ep.method}
                  </span>
                  <div>
                    <code className="text-sm font-mono text-linkedin-gray-90">{ep.path}</code>
                    <p className="mt-0.5 text-xs text-linkedin-gray-50">{ep.description}</p>
                  </div>
                </div>
              ))}
            </CardBody>
          </Card>

          {/* Request/Response Examples */}
          <div className="grid gap-6 lg:grid-cols-2">
            <Card padding="none">
              <CardHeader>Request Example</CardHeader>
              <CardBody>
                <pre className="overflow-x-auto rounded-lg bg-linkedin-gray-90 p-4 text-xs text-green-400 font-mono whitespace-pre-wrap">
                  {requestExample}
                </pre>
              </CardBody>
            </Card>

            <Card padding="none">
              <CardHeader>Response Example</CardHeader>
              <CardBody>
                <pre className="overflow-x-auto rounded-lg bg-linkedin-gray-90 p-4 text-xs text-green-400 font-mono whitespace-pre-wrap">
                  {responseExample}
                </pre>
              </CardBody>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
