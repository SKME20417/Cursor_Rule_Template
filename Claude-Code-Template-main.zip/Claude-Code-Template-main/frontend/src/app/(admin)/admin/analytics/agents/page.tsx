"use client";

import React, { useState } from "react";
import { cn } from "@/lib/utils/cn";
import {
  ArrowUpDown,
  ChevronUp,
  ChevronDown,
} from "lucide-react";
import { Card, CardBody, CardHeader } from "@/components/ui/card";
import { PageHeader } from "@/components/layout/page-header";

/* ------------------------------------------------------------------ */
/* Mock Data                                                           */
/* ------------------------------------------------------------------ */

interface AgentRow {
  rank: number;
  name: string;
  avatar: string;
  ticketsResolved: number;
  csat: number;
  avgResponseTime: string;
  resolutionRate: number;
}

const agentLeaderboard: AgentRow[] = [
  { rank: 1, name: "Sarah Chen", avatar: "SC", ticketsResolved: 234, csat: 4.9, avgResponseTime: "1m 12s", resolutionRate: 96 },
  { rank: 2, name: "James Wilson", avatar: "JW", ticketsResolved: 218, csat: 4.8, avgResponseTime: "1m 18s", resolutionRate: 94 },
  { rank: 3, name: "Maria Garcia", avatar: "MG", ticketsResolved: 205, csat: 4.7, avgResponseTime: "1m 25s", resolutionRate: 93 },
  { rank: 4, name: "Alex Kim", avatar: "AK", ticketsResolved: 198, csat: 4.7, avgResponseTime: "1m 30s", resolutionRate: 91 },
  { rank: 5, name: "David Brown", avatar: "DB", ticketsResolved: 187, csat: 4.6, avgResponseTime: "1m 35s", resolutionRate: 90 },
  { rank: 6, name: "Emma Davis", avatar: "ED", ticketsResolved: 175, csat: 4.5, avgResponseTime: "1m 42s", resolutionRate: 88 },
  { rank: 7, name: "Mike Johnson", avatar: "MJ", ticketsResolved: 162, csat: 4.5, avgResponseTime: "1m 48s", resolutionRate: 87 },
  { rank: 8, name: "Lisa Wang", avatar: "LW", ticketsResolved: 150, csat: 4.4, avgResponseTime: "1m 55s", resolutionRate: 85 },
  { rank: 9, name: "Tom Martinez", avatar: "TM", ticketsResolved: 143, csat: 4.3, avgResponseTime: "2m 05s", resolutionRate: 83 },
  { rank: 10, name: "Rachel Lee", avatar: "RL", ticketsResolved: 130, csat: 4.2, avgResponseTime: "2m 12s", resolutionRate: 81 },
];

type SortKey = "rank" | "ticketsResolved" | "csat" | "resolutionRate";

/* ------------------------------------------------------------------ */
/* Page                                                                */
/* ------------------------------------------------------------------ */

export default function AgentAnalyticsPage() {
  const [sortKey, setSortKey] = useState<SortKey>("rank");
  const [sortAsc, setSortAsc] = useState(true);

  const sorted = [...agentLeaderboard].sort((a, b) => {
    const mul = sortAsc ? 1 : -1;
    return (a[sortKey] - b[sortKey]) * mul;
  });

  function handleSort(key: SortKey) {
    if (sortKey === key) {
      setSortAsc(!sortAsc);
    } else {
      setSortKey(key);
      setSortAsc(true);
    }
  }

  function SortIcon({ column }: { column: SortKey }) {
    if (sortKey !== column) return <ArrowUpDown className="h-3 w-3 text-linkedin-gray-50" />;
    return sortAsc ? (
      <ChevronUp className="h-3 w-3 text-linkedin-blue" />
    ) : (
      <ChevronDown className="h-3 w-3 text-linkedin-blue" />
    );
  }

  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="Agent Analytics"
        subtitle="Agent performance and workload metrics"
      />

      {/* Leaderboard */}
      <Card padding="none">
        <CardHeader>Agent Leaderboard</CardHeader>
        <CardBody className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-linkedin-gray-20 text-left text-xs text-linkedin-gray-50">
                  <th className="px-4 py-3 font-medium">
                    <button onClick={() => handleSort("rank")} className="flex items-center gap-1">
                      Rank <SortIcon column="rank" />
                    </button>
                  </th>
                  <th className="px-4 py-3 font-medium">Agent</th>
                  <th className="px-4 py-3 font-medium">
                    <button onClick={() => handleSort("ticketsResolved")} className="flex items-center gap-1">
                      Tickets Resolved <SortIcon column="ticketsResolved" />
                    </button>
                  </th>
                  <th className="px-4 py-3 font-medium">
                    <button onClick={() => handleSort("csat")} className="flex items-center gap-1">
                      CSAT <SortIcon column="csat" />
                    </button>
                  </th>
                  <th className="px-4 py-3 font-medium">Avg Response Time</th>
                  <th className="px-4 py-3 font-medium">
                    <button onClick={() => handleSort("resolutionRate")} className="flex items-center gap-1">
                      Resolution Rate <SortIcon column="resolutionRate" />
                    </button>
                  </th>
                </tr>
              </thead>
              <tbody>
                {sorted.map((agent) => (
                  <tr
                    key={agent.name}
                    className="border-b border-linkedin-gray-20 last:border-0 transition-colors hover:bg-linkedin-gray-10"
                  >
                    <td className="px-4 py-3 font-medium text-linkedin-gray-90">#{agent.rank}</td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2">
                        <div className="flex h-8 w-8 items-center justify-center rounded-full bg-linkedin-blue-bg text-xs font-semibold text-linkedin-blue">
                          {agent.avatar}
                        </div>
                        <span className="font-medium text-linkedin-gray-90">{agent.name}</span>
                      </div>
                    </td>
                    <td className="px-4 py-3 text-linkedin-gray-70">{agent.ticketsResolved}</td>
                    <td className="px-4 py-3 text-linkedin-gray-70">{agent.csat}</td>
                    <td className="px-4 py-3 text-linkedin-gray-70">{agent.avgResponseTime}</td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2">
                        <div className="h-2 w-20 overflow-hidden rounded-full bg-linkedin-gray-20">
                          <div
                            className="h-full rounded-full bg-linkedin-blue"
                            style={{ width: `${agent.resolutionRate}%` }}
                          />
                        </div>
                        <span className="text-xs text-linkedin-gray-70">{agent.resolutionRate}%</span>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardBody>
      </Card>

      <div className="grid gap-6 lg:grid-cols-2">
        <Card padding="none">
          <CardHeader>CSAT by Agent</CardHeader>
          <CardBody>
            <div className="flex h-[250px] items-center justify-center rounded-lg border-2 border-dashed border-linkedin-gray-20 bg-linkedin-gray-10">
              <p className="text-sm text-linkedin-gray-50">Bar chart: CSAT scores by agent</p>
            </div>
          </CardBody>
        </Card>

        <Card padding="none">
          <CardHeader>Workload Distribution</CardHeader>
          <CardBody>
            <div className="flex h-[250px] items-center justify-center rounded-lg border-2 border-dashed border-linkedin-gray-20 bg-linkedin-gray-10">
              <p className="text-sm text-linkedin-gray-50">Stacked bar chart: Workload distribution per agent</p>
            </div>
          </CardBody>
        </Card>
      </div>
    </div>
  );
}
