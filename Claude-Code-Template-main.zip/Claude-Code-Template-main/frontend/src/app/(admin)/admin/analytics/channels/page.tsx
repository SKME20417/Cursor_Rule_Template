"use client";

import React from "react";
import { cn } from "@/lib/utils/cn";
import {
  MessageSquare,
  Mail,
  Phone,
  MessageCircle,
  Smartphone,
  Hash,
  Globe,
  TrendingUp,
  TrendingDown,
} from "lucide-react";
import { Card, CardBody, CardHeader } from "@/components/ui/card";
import { PageHeader } from "@/components/layout/page-header";

/* ------------------------------------------------------------------ */
/* Mock Data                                                           */
/* ------------------------------------------------------------------ */

const channelData = [
  { name: "Chat", icon: MessageSquare, volume: 5620, csat: 4.6, avgResolution: "12m", growth: 15, growthUp: true },
  { name: "Email", icon: Mail, volume: 3120, csat: 4.3, avgResolution: "2h 15m", growth: 8, growthUp: true },
  { name: "WhatsApp", icon: MessageCircle, volume: 1870, csat: 4.5, avgResolution: "18m", growth: 22, growthUp: true },
  { name: "Voice", icon: Phone, volume: 1250, csat: 4.2, avgResolution: "8m 30s", growth: -3, growthUp: false },
  { name: "SMS", icon: Smartphone, volume: 890, csat: 4.1, avgResolution: "25m", growth: 5, growthUp: true },
  { name: "Slack", icon: Hash, volume: 540, csat: 4.7, avgResolution: "6m", growth: 30, growthUp: true },
  { name: "Social", icon: Globe, volume: 320, csat: 4.0, avgResolution: "45m", growth: -8, growthUp: false },
] as const;

/* ------------------------------------------------------------------ */
/* Page                                                                */
/* ------------------------------------------------------------------ */

export default function ChannelAnalyticsPage() {
  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="Channel Analytics"
        subtitle="Performance metrics by support channel"
      />

      {/* Channel Table */}
      <Card padding="none">
        <CardHeader>Channel Performance</CardHeader>
        <CardBody className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-linkedin-gray-20 text-left text-xs text-linkedin-gray-50">
                  <th className="px-4 py-3 font-medium">Channel</th>
                  <th className="px-4 py-3 font-medium">Volume</th>
                  <th className="px-4 py-3 font-medium">CSAT</th>
                  <th className="px-4 py-3 font-medium">Avg Resolution Time</th>
                  <th className="px-4 py-3 font-medium">Growth %</th>
                </tr>
              </thead>
              <tbody>
                {channelData.map((channel) => (
                  <tr
                    key={channel.name}
                    className="border-b border-linkedin-gray-20 last:border-0 transition-colors hover:bg-linkedin-gray-10"
                  >
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2">
                        <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-linkedin-blue-bg">
                          <channel.icon className="h-4 w-4 text-linkedin-blue" />
                        </div>
                        <span className="font-medium text-linkedin-gray-90">{channel.name}</span>
                      </div>
                    </td>
                    <td className="px-4 py-3 text-linkedin-gray-70">{channel.volume.toLocaleString()}</td>
                    <td className="px-4 py-3 text-linkedin-gray-70">{channel.csat}</td>
                    <td className="px-4 py-3 text-linkedin-gray-70">{channel.avgResolution}</td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-1">
                        {channel.growthUp ? (
                          <TrendingUp className="h-3 w-3 text-linkedin-green" />
                        ) : (
                          <TrendingDown className="h-3 w-3 text-linkedin-red" />
                        )}
                        <span
                          className={cn(
                            "text-xs font-medium",
                            channel.growthUp ? "text-linkedin-green" : "text-linkedin-red",
                          )}
                        >
                          {channel.growthUp ? "+" : ""}{channel.growth}%
                        </span>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardBody>
      </Card>

      <div className="grid gap-6 lg:grid-cols-2">
        <Card padding="none">
          <CardHeader>Channel Volume Trend</CardHeader>
          <CardBody>
            <div className="flex h-[250px] items-center justify-center rounded-lg border-2 border-dashed border-linkedin-gray-20 bg-linkedin-gray-10">
              <p className="text-sm text-linkedin-gray-50">Multi-line chart: Volume trend per channel</p>
            </div>
          </CardBody>
        </Card>

        <Card padding="none">
          <CardHeader>Per-Channel Satisfaction</CardHeader>
          <CardBody>
            <div className="flex h-[250px] items-center justify-center rounded-lg border-2 border-dashed border-linkedin-gray-20 bg-linkedin-gray-10">
              <p className="text-sm text-linkedin-gray-50">Bar chart: CSAT satisfaction per channel</p>
            </div>
          </CardBody>
        </Card>
      </div>
    </div>
  );
}
