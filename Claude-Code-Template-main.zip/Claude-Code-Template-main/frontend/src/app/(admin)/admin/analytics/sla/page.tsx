"use client";

import React from "react";
import { cn } from "@/lib/utils/cn";
import {
  ShieldCheck,
  TrendingUp,
} from "lucide-react";
import { Card, CardBody, CardHeader } from "@/components/ui/card";
import { PageHeader } from "@/components/layout/page-header";

/* ------------------------------------------------------------------ */
/* Mock Data                                                           */
/* ------------------------------------------------------------------ */

const priorityBreakdown = [
  { label: "Critical", compliance: 89, color: "bg-linkedin-red" },
  { label: "High", compliance: 92, color: "bg-linkedin-orange" },
  { label: "Medium", compliance: 96, color: "bg-linkedin-blue" },
  { label: "Low", compliance: 98, color: "bg-linkedin-green" },
] as const;

const breachReasons = [
  { reason: "Agent unavailable", count: 12, percentage: 28.6 },
  { reason: "Complex escalation", count: 10, percentage: 23.8 },
  { reason: "Missing context from customer", count: 8, percentage: 19.0 },
  { reason: "Third-party dependency", count: 7, percentage: 16.7 },
  { reason: "System downtime", count: 5, percentage: 11.9 },
] as const;

/* ------------------------------------------------------------------ */
/* Page                                                                */
/* ------------------------------------------------------------------ */

export default function SLAAnalyticsPage() {
  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="SLA Analytics"
        subtitle="Service level agreement compliance tracking"
      />

      {/* Overall Compliance */}
      <Card hover>
        <CardBody>
          <div className="flex items-center gap-4">
            <div className="flex h-14 w-14 items-center justify-center rounded-xl bg-green-50">
              <ShieldCheck className="h-7 w-7 text-linkedin-green" />
            </div>
            <div>
              <p className="text-sm text-linkedin-gray-50">Overall SLA Compliance</p>
              <p className="text-4xl font-bold text-linkedin-green">94.2%</p>
              <div className="mt-1 flex items-center gap-1">
                <TrendingUp className="h-3 w-3 text-linkedin-green" />
                <span className="text-xs font-medium text-linkedin-green">+1.3% vs last month</span>
              </div>
            </div>
          </div>
        </CardBody>
      </Card>

      {/* By Priority Breakdown */}
      <Card padding="none">
        <CardHeader>Compliance by Priority</CardHeader>
        <CardBody>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {priorityBreakdown.map((item) => (
              <div key={item.label} className="rounded-lg border border-linkedin-gray-20 p-4">
                <p className="text-xs text-linkedin-gray-50">{item.label}</p>
                <p className="mt-1 text-2xl font-bold text-linkedin-gray-90">{item.compliance}%</p>
                <div className="mt-2 h-2 w-full overflow-hidden rounded-full bg-linkedin-gray-20">
                  <div
                    className={cn("h-full rounded-full", item.color)}
                    style={{ width: `${item.compliance}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </CardBody>
      </Card>

      {/* Compliance Over Time */}
      <Card padding="none">
        <CardHeader>Compliance Over Time</CardHeader>
        <CardBody>
          <div className="flex h-[300px] items-center justify-center rounded-lg border-2 border-dashed border-linkedin-gray-20 bg-linkedin-gray-10">
            <p className="text-sm text-linkedin-gray-50">
              Line chart: SLA compliance trend over time
            </p>
          </div>
        </CardBody>
      </Card>

      {/* Breach Reasons */}
      <Card padding="none">
        <CardHeader>Breach Reasons</CardHeader>
        <CardBody className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-linkedin-gray-20 text-left text-xs text-linkedin-gray-50">
                  <th className="px-4 py-3 font-medium">Reason</th>
                  <th className="px-4 py-3 font-medium">Count</th>
                  <th className="px-4 py-3 font-medium">Percentage</th>
                </tr>
              </thead>
              <tbody>
                {breachReasons.map((item) => (
                  <tr
                    key={item.reason}
                    className="border-b border-linkedin-gray-20 last:border-0 transition-colors hover:bg-linkedin-gray-10"
                  >
                    <td className="px-4 py-3 font-medium text-linkedin-gray-90">{item.reason}</td>
                    <td className="px-4 py-3 text-linkedin-gray-70">{item.count}</td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2">
                        <div className="h-2 w-20 overflow-hidden rounded-full bg-linkedin-gray-20">
                          <div
                            className="h-full rounded-full bg-linkedin-red"
                            style={{ width: `${item.percentage}%` }}
                          />
                        </div>
                        <span className="text-xs text-linkedin-gray-70">{item.percentage}%</span>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardBody>
      </Card>
    </div>
  );
}
