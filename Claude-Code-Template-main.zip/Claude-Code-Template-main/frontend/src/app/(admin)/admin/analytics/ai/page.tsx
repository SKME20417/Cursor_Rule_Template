"use client";

import React from "react";
import { cn } from "@/lib/utils/cn";
import {
  Bot,
  ArrowRightLeft,
  TrendingUp,
} from "lucide-react";
import { Card, CardBody, CardHeader } from "@/components/ui/card";
import { PageHeader } from "@/components/layout/page-header";

/* ------------------------------------------------------------------ */
/* Mock Data                                                           */
/* ------------------------------------------------------------------ */

const aiStats = [
  { label: "AI Resolution Rate", value: "72%", icon: Bot, trend: "+5%" },
  { label: "Fallback / Handoff Rate", value: "28%", icon: ArrowRightLeft, trend: "-5%" },
] as const;

const topIntents = [
  { intent: "Password Reset", count: 342, successRate: 94 },
  { intent: "Billing Inquiry", count: 287, successRate: 88 },
  { intent: "Order Status", count: 256, successRate: 91 },
  { intent: "Account Update", count: 198, successRate: 85 },
  { intent: "Product Information", count: 176, successRate: 79 },
] as const;

/* ------------------------------------------------------------------ */
/* Page                                                                */
/* ------------------------------------------------------------------ */

export default function AIAnalyticsPage() {
  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="AI Analytics"
        subtitle="AI resolution performance and accuracy"
      />

      {/* Stats */}
      <div className="grid gap-4 sm:grid-cols-2">
        {aiStats.map((stat) => (
          <Card key={stat.label} hover>
            <CardBody>
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-xs text-linkedin-gray-50">{stat.label}</p>
                  <p className="mt-1 text-3xl font-bold text-linkedin-gray-90">{stat.value}</p>
                  <div className="mt-1 flex items-center gap-1">
                    <TrendingUp className="h-3 w-3 text-linkedin-green" />
                    <span className="text-xs font-medium text-linkedin-green">{stat.trend}</span>
                  </div>
                </div>
                <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-linkedin-blue-bg">
                  <stat.icon className="h-5 w-5 text-linkedin-blue" />
                </div>
              </div>
            </CardBody>
          </Card>
        ))}
      </div>

      {/* AI Resolution Rate Trend */}
      <Card padding="none">
        <CardHeader>AI Resolution Rate Trend</CardHeader>
        <CardBody>
          <div className="flex h-[300px] items-center justify-center rounded-lg border-2 border-dashed border-linkedin-gray-20 bg-linkedin-gray-10">
            <p className="text-sm text-linkedin-gray-50">
              Line chart: AI resolution rate trend (currently 72%)
            </p>
          </div>
        </CardBody>
      </Card>

      <div className="grid gap-6 lg:grid-cols-2">
        <Card padding="none">
          <CardHeader>Confidence Score Distribution</CardHeader>
          <CardBody>
            <div className="flex h-[250px] items-center justify-center rounded-lg border-2 border-dashed border-linkedin-gray-20 bg-linkedin-gray-10">
              <p className="text-sm text-linkedin-gray-50">
                Histogram: AI confidence score distribution
              </p>
            </div>
          </CardBody>
        </Card>

        <Card padding="none">
          <CardHeader>Model Accuracy Comparison</CardHeader>
          <CardBody>
            <div className="flex h-[250px] items-center justify-center rounded-lg border-2 border-dashed border-linkedin-gray-20 bg-linkedin-gray-10">
              <p className="text-sm text-linkedin-gray-50">
                Bar chart: Model accuracy comparison across versions
              </p>
            </div>
          </CardBody>
        </Card>
      </div>

      {/* Top Intents */}
      <Card padding="none">
        <CardHeader>Top Intents Handled by AI</CardHeader>
        <CardBody className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-linkedin-gray-20 text-left text-xs text-linkedin-gray-50">
                  <th className="px-4 py-3 font-medium">Intent</th>
                  <th className="px-4 py-3 font-medium">Count</th>
                  <th className="px-4 py-3 font-medium">Success Rate</th>
                </tr>
              </thead>
              <tbody>
                {topIntents.map((intent) => (
                  <tr
                    key={intent.intent}
                    className="border-b border-linkedin-gray-20 last:border-0 transition-colors hover:bg-linkedin-gray-10"
                  >
                    <td className="px-4 py-3 font-medium text-linkedin-gray-90">{intent.intent}</td>
                    <td className="px-4 py-3 text-linkedin-gray-70">{intent.count}</td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2">
                        <div className="h-2 w-20 overflow-hidden rounded-full bg-linkedin-gray-20">
                          <div
                            className={cn(
                              "h-full rounded-full",
                              intent.successRate >= 90 ? "bg-linkedin-green" : "bg-linkedin-blue",
                            )}
                            style={{ width: `${intent.successRate}%` }}
                          />
                        </div>
                        <span className="text-xs text-linkedin-gray-70">{intent.successRate}%</span>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardBody>
      </Card>
    </div>
  );
}
