"use client";

import React, { useState } from "react";
import { cn } from "@/lib/utils/cn";
import {
  MessageSquare,
  CheckCircle,
  Star,
  Clock,
  Bot,
  TrendingUp,
  TrendingDown,
} from "lucide-react";
import { Card, CardBody, CardHeader } from "@/components/ui/card";
import { PageHeader } from "@/components/layout/page-header";

/* ------------------------------------------------------------------ */
/* Mock Data                                                           */
/* ------------------------------------------------------------------ */

const timeRanges = ["Today", "7d", "30d", "90d"] as const;

const kpiStats = [
  { label: "Total Conversations", value: "1,247", icon: MessageSquare, trend: "+12%", trendUp: true },
  { label: "Tickets Resolved", value: "892", icon: CheckCircle, trend: "+8%", trendUp: true },
  { label: "CSAT", value: "4.5", icon: Star, trend: "+0.2", trendUp: true },
  { label: "Avg Response Time", value: "1m 42s", icon: Clock, trend: "-15%", trendUp: true },
  { label: "AI vs Human", value: "72% / 28%", icon: Bot, trend: "+5%", trendUp: true },
] as const;

/* ------------------------------------------------------------------ */
/* Page                                                                */
/* ------------------------------------------------------------------ */

export default function AnalyticsPage() {
  const [selectedRange, setSelectedRange] = useState<string>("30d");

  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="Analytics"
        subtitle="Performance metrics and trends"
        actions={
          <div className="flex items-center gap-1 rounded-lg border border-linkedin-gray-20 bg-linkedin-white p-1">
            {timeRanges.map((range) => (
              <button
                key={range}
                onClick={() => setSelectedRange(range)}
                className={cn(
                  "rounded-md px-3 py-1.5 text-xs font-medium transition-colors",
                  selectedRange === range
                    ? "bg-linkedin-blue text-white"
                    : "text-linkedin-gray-70 hover:bg-linkedin-gray-10",
                )}
              >
                {range}
              </button>
            ))}
          </div>
        }
      />

      {/* KPI Row */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
        {kpiStats.map((stat) => (
          <Card key={stat.label} hover>
            <CardBody>
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-xs text-linkedin-gray-50">{stat.label}</p>
                  <p className="mt-1 text-2xl font-bold text-linkedin-gray-90">{stat.value}</p>
                  <div className="mt-1 flex items-center gap-1">
                    {stat.trendUp ? (
                      <TrendingUp className="h-3 w-3 text-linkedin-green" />
                    ) : (
                      <TrendingDown className="h-3 w-3 text-linkedin-red" />
                    )}
                    <span className="text-xs font-medium text-linkedin-green">{stat.trend}</span>
                  </div>
                </div>
                <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-linkedin-blue-bg">
                  <stat.icon className="h-5 w-5 text-linkedin-blue" />
                </div>
              </div>
            </CardBody>
          </Card>
        ))}
      </div>

      {/* Conversation Volume Chart */}
      <Card padding="none">
        <CardHeader>Conversation Volume</CardHeader>
        <CardBody>
          <div className="flex h-[300px] items-center justify-center rounded-lg border-2 border-dashed border-linkedin-gray-20 bg-linkedin-gray-10">
            <p className="text-sm text-linkedin-gray-50">
              Line chart: Daily conversation volume
            </p>
          </div>
        </CardBody>
      </Card>

      <div className="grid gap-6 lg:grid-cols-2">
        {/* Channel Distribution */}
        <Card padding="none">
          <CardHeader>Channel Distribution</CardHeader>
          <CardBody>
            <div className="flex h-[250px] items-center justify-center rounded-lg border-2 border-dashed border-linkedin-gray-20 bg-linkedin-gray-10">
              <p className="text-sm text-linkedin-gray-50">
                Pie chart: Chat 45%, Email 25%, WhatsApp 15%, Voice 10%, Other 5%
              </p>
            </div>
          </CardBody>
        </Card>

        {/* Resolution Time Trend */}
        <Card padding="none">
          <CardHeader>Resolution Time Trend</CardHeader>
          <CardBody>
            <div className="flex h-[250px] items-center justify-center rounded-lg border-2 border-dashed border-linkedin-gray-20 bg-linkedin-gray-10">
              <p className="text-sm text-linkedin-gray-50">
                Area chart: Resolution time trend over selected period
              </p>
            </div>
          </CardBody>
        </Card>
      </div>
    </div>
  );
}
