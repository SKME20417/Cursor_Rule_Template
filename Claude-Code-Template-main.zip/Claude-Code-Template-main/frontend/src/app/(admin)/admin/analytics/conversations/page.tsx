"use client";

import React from "react";
import { cn } from "@/lib/utils/cn";
import {
  MessageSquare,
  Clock,
  LogOut,
  TrendingUp,
  TrendingDown,
} from "lucide-react";
import { Card, CardBody, CardHeader } from "@/components/ui/card";
import { PageHeader } from "@/components/layout/page-header";

/* ------------------------------------------------------------------ */
/* Mock Data                                                           */
/* ------------------------------------------------------------------ */

const conversationStats = [
  { label: "Total Conversations", value: "1,247", icon: MessageSquare, trend: "+12%", trendUp: true },
  { label: "Avg Handle Time", value: "8m 34s", icon: Clock, trend: "-6%", trendUp: true },
  { label: "Abandon Rate", value: "4.2%", icon: LogOut, trend: "+0.3%", trendUp: false },
] as const;

const heatmapDays = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"] as const;
const heatmapHours = Array.from({ length: 24 }, (_, i) => i);

const heatmapData: readonly (readonly number[])[] = [
  [0, 0, 0, 0, 0, 0, 1, 2, 3, 4, 4, 3, 3, 4, 4, 3, 2, 2, 1, 1, 0, 0, 0, 0],
  [0, 0, 0, 0, 0, 0, 1, 2, 3, 4, 3, 3, 4, 4, 3, 3, 2, 2, 1, 1, 0, 0, 0, 0],
  [0, 0, 0, 0, 0, 1, 1, 2, 4, 4, 4, 3, 3, 4, 4, 3, 3, 2, 1, 1, 0, 0, 0, 0],
  [0, 0, 0, 0, 0, 0, 1, 2, 3, 3, 4, 4, 3, 3, 4, 3, 2, 2, 1, 1, 0, 0, 0, 0],
  [0, 0, 0, 0, 0, 0, 1, 2, 3, 3, 3, 3, 3, 3, 3, 2, 2, 1, 1, 0, 0, 0, 0, 0],
  [0, 0, 0, 0, 0, 0, 0, 1, 1, 2, 2, 2, 2, 2, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0],
  [0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 2, 2, 2, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0],
] as const;

const heatmapColors = [
  "bg-linkedin-gray-10",
  "bg-blue-100",
  "bg-blue-200",
  "bg-blue-400",
  "bg-linkedin-blue",
] as const;

/* ------------------------------------------------------------------ */
/* Page                                                                */
/* ------------------------------------------------------------------ */

export default function ConversationAnalyticsPage() {
  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="Conversation Analytics"
        subtitle="Analyze conversation volume and performance"
      />

      {/* Stat Cards */}
      <div className="grid gap-4 sm:grid-cols-3">
        {conversationStats.map((stat) => (
          <Card key={stat.label} hover>
            <CardBody>
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-xs text-linkedin-gray-50">{stat.label}</p>
                  <p className="mt-1 text-2xl font-bold text-linkedin-gray-90">{stat.value}</p>
                  <div className="mt-1 flex items-center gap-1">
                    {stat.trendUp ? (
                      <TrendingUp className="h-3 w-3 text-linkedin-green" />
                    ) : (
                      <TrendingDown className="h-3 w-3 text-linkedin-red" />
                    )}
                    <span
                      className={cn(
                        "text-xs font-medium",
                        stat.trendUp ? "text-linkedin-green" : "text-linkedin-red",
                      )}
                    >
                      {stat.trend}
                    </span>
                  </div>
                </div>
                <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-linkedin-blue-bg">
                  <stat.icon className="h-5 w-5 text-linkedin-blue" />
                </div>
              </div>
            </CardBody>
          </Card>
        ))}
      </div>

      {/* Volume Over Time */}
      <Card padding="none">
        <CardHeader>Volume Over Time</CardHeader>
        <CardBody>
          <div className="flex h-[300px] items-center justify-center rounded-lg border-2 border-dashed border-linkedin-gray-20 bg-linkedin-gray-10">
            <p className="text-sm text-linkedin-gray-50">
              Line chart: Conversation volume over time
            </p>
          </div>
        </CardBody>
      </Card>

      {/* Peak Hours Heatmap */}
      <Card padding="none">
        <CardHeader>Peak Hours</CardHeader>
        <CardBody>
          <div className="overflow-x-auto">
            <div className="min-w-[700px]">
              <div className="mb-1 flex">
                <div className="w-10 shrink-0" />
                {heatmapHours.map((h) => (
                  <div key={h} className="flex-1 text-center text-[10px] text-linkedin-gray-50">
                    {h}
                  </div>
                ))}
              </div>
              {heatmapDays.map((day, dayIdx) => (
                <div key={day} className="mb-0.5 flex items-center gap-0.5">
                  <div className="w-10 shrink-0 pr-2 text-right text-xs text-linkedin-gray-50">
                    {day}
                  </div>
                  {heatmapData[dayIdx].map((intensity, hourIdx) => (
                    <div
                      key={hourIdx}
                      className={cn("aspect-square flex-1 rounded-sm", heatmapColors[intensity])}
                      title={`${day} ${hourIdx}:00 — Intensity: ${intensity}`}
                    />
                  ))}
                </div>
              ))}
            </div>
          </div>
        </CardBody>
      </Card>

      {/* First Response Time Distribution */}
      <Card padding="none">
        <CardHeader>First Response Time Distribution</CardHeader>
        <CardBody>
          <div className="flex h-[250px] items-center justify-center rounded-lg border-2 border-dashed border-linkedin-gray-20 bg-linkedin-gray-10">
            <p className="text-sm text-linkedin-gray-50">
              Histogram: First response time distribution
            </p>
          </div>
        </CardBody>
      </Card>
    </div>
  );
}
