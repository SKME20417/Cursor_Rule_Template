"use client";

import React, { useState } from "react";
import { Plus, Copy, X, Key } from "lucide-react";
import { cn } from "@/lib/utils/cn";
import { Card, CardBody, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { PageHeader } from "@/components/layout/page-header";

/* ------------------------------------------------------------------ */
/* Mock Data                                                           */
/* ------------------------------------------------------------------ */

const apiKeys = [
  { key: "cplt_****abcd", name: "Production API", permissions: ["read", "write"], created: "2026-02-15", lastUsed: "2 min ago" },
  { key: "cplt_****efgh", name: "Analytics Service", permissions: ["read"], created: "2026-01-20", lastUsed: "1 hour ago" },
  { key: "cplt_****ijkl", name: "Webhook Handler", permissions: ["read", "write"], created: "2026-01-05", lastUsed: "3 hours ago" },
  { key: "cplt_****mnop", name: "Staging Environment", permissions: ["read", "write", "admin"], created: "2025-12-10", lastUsed: "2 days ago" },
];

/* ------------------------------------------------------------------ */
/* Page                                                                */
/* ------------------------------------------------------------------ */

export default function APIKeysPage() {
  const [showModal, setShowModal] = useState(false);
  const [generatedKey, setGeneratedKey] = useState<string | null>(null);
  const [newKeyName, setNewKeyName] = useState("");
  const [newKeyPerms, setNewKeyPerms] = useState({ read: true, write: false, admin: false });

  const handleGenerate = () => {
    setGeneratedKey("cplt_key_" + Math.random().toString(36).slice(2, 34));
  };

  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="API Keys"
        subtitle="Manage API keys for programmatic access"
        actions={
          <button
            onClick={() => { setShowModal(true); setGeneratedKey(null); setNewKeyName(""); }}
            className="inline-flex items-center gap-2 rounded-lg bg-linkedin-blue px-4 py-2 text-sm font-medium text-white hover:bg-linkedin-blue-dark transition-colors"
          >
            <Plus className="h-4 w-4" />
            Generate New Key
          </button>
        }
      />

      <Card padding="none">
        <CardBody className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-linkedin-gray-20 bg-linkedin-gray-10">
                  <th className="px-4 py-3 text-left font-medium text-linkedin-gray-70">Key</th>
                  <th className="px-4 py-3 text-left font-medium text-linkedin-gray-70">Name</th>
                  <th className="px-4 py-3 text-left font-medium text-linkedin-gray-70">Permissions</th>
                  <th className="px-4 py-3 text-left font-medium text-linkedin-gray-70">Created</th>
                  <th className="px-4 py-3 text-left font-medium text-linkedin-gray-70">Last Used</th>
                  <th className="px-4 py-3 text-left font-medium text-linkedin-gray-70">Actions</th>
                </tr>
              </thead>
              <tbody>
                {apiKeys.map((k, i) => (
                  <tr key={i} className="border-b border-linkedin-gray-20 last:border-0 hover:bg-linkedin-gray-10 transition-colors">
                    <td className="px-4 py-3">
                      <code className="rounded bg-linkedin-gray-10 px-2 py-0.5 text-xs font-mono text-linkedin-gray-70">{k.key}</code>
                    </td>
                    <td className="px-4 py-3 font-medium text-linkedin-gray-90">{k.name}</td>
                    <td className="px-4 py-3">
                      <div className="flex gap-1">
                        {k.permissions.map((p) => (
                          <Badge key={p} variant={p === "admin" ? "danger" : p === "write" ? "warning" : "primary"}>{p}</Badge>
                        ))}
                      </div>
                    </td>
                    <td className="px-4 py-3 text-linkedin-gray-50">{k.created}</td>
                    <td className="px-4 py-3 text-linkedin-gray-50">{k.lastUsed}</td>
                    <td className="px-4 py-3">
                      <button className="rounded-md px-3 py-1 text-xs font-medium text-linkedin-red hover:bg-red-50 transition-colors">
                        Revoke
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardBody>
      </Card>

      {/* Modal */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50">
          <div className="w-full max-w-md rounded-lg border border-linkedin-gray-20 bg-white shadow-lg">
            <div className="flex items-center justify-between border-b border-linkedin-gray-20 px-6 py-4">
              <h2 className="text-lg font-semibold text-linkedin-gray-90">Generate New API Key</h2>
              <button onClick={() => setShowModal(false)} className="text-linkedin-gray-50 hover:text-linkedin-gray-90">
                <X className="h-5 w-5" />
              </button>
            </div>
            <div className="flex flex-col gap-4 px-6 py-4">
              {!generatedKey ? (
                <>
                  <div className="flex flex-col gap-1">
                    <label className="text-sm font-medium text-linkedin-gray-90">Key Name</label>
                    <input type="text" value={newKeyName} onChange={(e) => setNewKeyName(e.target.value)} placeholder="e.g., Production API" className="w-full rounded-lg border border-linkedin-gray-30 bg-white px-3 py-2 text-sm text-linkedin-gray-90 focus:border-linkedin-blue focus:outline-none focus:ring-1 focus:ring-linkedin-blue" />
                  </div>
                  <div className="flex flex-col gap-2">
                    <label className="text-sm font-medium text-linkedin-gray-90">Permissions</label>
                    {(["read", "write", "admin"] as const).map((perm) => (
                      <label key={perm} className="flex items-center gap-2 cursor-pointer">
                        <input type="checkbox" checked={newKeyPerms[perm]} onChange={() => setNewKeyPerms((p) => ({ ...p, [perm]: !p[perm] }))} className="rounded border-linkedin-gray-30 text-linkedin-blue focus:ring-linkedin-blue" />
                        <span className="text-sm text-linkedin-gray-90 capitalize">{perm}</span>
                      </label>
                    ))}
                  </div>
                  <button onClick={handleGenerate} className="w-full rounded-lg bg-linkedin-blue px-4 py-2 text-sm font-medium text-white hover:bg-linkedin-blue-dark transition-colors">
                    Generate Key
                  </button>
                </>
              ) : (
                <>
                  <div className="rounded-lg border border-orange-200 bg-orange-50 p-3">
                    <p className="text-xs text-linkedin-gray-70">
                      This key will only be shown once. Copy it now and store it securely.
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <code className="flex-1 rounded-lg bg-linkedin-gray-90 px-3 py-2 text-xs font-mono text-green-400 break-all">
                      {generatedKey}
                    </code>
                    <button className="rounded-md border border-linkedin-gray-30 p-2 text-linkedin-gray-50 hover:bg-linkedin-gray-10 transition-colors">
                      <Copy className="h-4 w-4" />
                    </button>
                  </div>
                  <button onClick={() => setShowModal(false)} className="w-full rounded-lg bg-linkedin-blue px-4 py-2 text-sm font-medium text-white hover:bg-linkedin-blue-dark transition-colors">
                    Done
                  </button>
                </>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
