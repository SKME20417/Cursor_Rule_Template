"use client";

import React, { useState } from "react";
import { Download, User, ChevronDown, ChevronUp, Search } from "lucide-react";
import { cn } from "@/lib/utils/cn";
import { Card, CardBody, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { PageHeader } from "@/components/layout/page-header";

/* ------------------------------------------------------------------ */
/* Mock Data                                                           */
/* ------------------------------------------------------------------ */

const auditLogs = [
  { timestamp: "2026-03-09 14:32:15", user: "Sarah Chen", initials: "SC", action: "update", resource: "API Key", details: "Updated permissions for key sk_live_****xyz", ip: "192.168.1.42" },
  { timestamp: "2026-03-09 14:15:03", user: "James Wilson", initials: "JW", action: "create", resource: "Role", details: "Created role: Viewer with read-only permissions", ip: "192.168.1.38" },
  { timestamp: "2026-03-09 13:45:22", user: "Emily Park", initials: "EP", action: "export", resource: "Audit Log", details: "Exported 30-day audit log as CSV", ip: "192.168.1.55" },
  { timestamp: "2026-03-09 13:20:41", user: "Michael Torres", initials: "MT", action: "delete", resource: "API Key", details: "Revoked API key sk_live_****abc", ip: "10.0.0.15" },
  { timestamp: "2026-03-09 12:55:08", user: "Sarah Chen", initials: "SC", action: "update", resource: "Compliance", details: "Updated GDPR data retention policy to 2 years", ip: "192.168.1.42" },
  { timestamp: "2026-03-09 12:30:19", user: "James Wilson", initials: "JW", action: "login", resource: "Session", details: "Logged in from new device", ip: "203.45.67.89" },
  { timestamp: "2026-03-09 11:45:33", user: "Emily Park", initials: "EP", action: "create", resource: "Ticket", details: "Created ticket #4523 for customer data export", ip: "192.168.1.55" },
  { timestamp: "2026-03-09 11:20:47", user: "Michael Torres", initials: "MT", action: "update", resource: "User", details: "Changed role for user@example.com to Supervisor", ip: "10.0.0.15" },
  { timestamp: "2026-03-09 10:55:02", user: "Sarah Chen", initials: "SC", action: "create", resource: "Integration", details: "Connected Salesforce integration", ip: "192.168.1.42" },
  { timestamp: "2026-03-09 10:30:16", user: "James Wilson", initials: "JW", action: "delete", resource: "User", details: "Deactivated user account inactive@example.com", ip: "192.168.1.38" },
  { timestamp: "2026-03-09 10:05:29", user: "Emily Park", initials: "EP", action: "update", resource: "Settings", details: "Changed business hours to 8:00-18:00", ip: "192.168.1.55" },
  { timestamp: "2026-03-09 09:40:43", user: "Michael Torres", initials: "MT", action: "login", resource: "Session", details: "Logged in via SSO", ip: "10.0.0.15" },
  { timestamp: "2026-03-09 09:15:57", user: "Sarah Chen", initials: "SC", action: "export", resource: "Analytics", details: "Exported monthly analytics report", ip: "192.168.1.42" },
  { timestamp: "2026-03-09 08:50:11", user: "James Wilson", initials: "JW", action: "create", resource: "Workflow", details: "Created VIP Priority Routing workflow", ip: "192.168.1.38" },
  { timestamp: "2026-03-09 08:25:25", user: "Emily Park", initials: "EP", action: "update", resource: "Knowledge Base", details: "Published article: Getting Started Guide", ip: "192.168.1.55" },
];

const actionVariant: Record<string, "success" | "primary" | "warning" | "danger" | "info"> = {
  create: "success",
  update: "primary",
  delete: "danger",
  export: "info",
  login: "warning",
};

/* ------------------------------------------------------------------ */
/* Page                                                                */
/* ------------------------------------------------------------------ */

export default function AuditLogPage() {
  const [expandedRow, setExpandedRow] = useState<number | null>(null);
  const [searchUser, setSearchUser] = useState("");
  const [actionFilter, setActionFilter] = useState("all");

  const filtered = auditLogs.filter((log) => {
    const matchUser = log.user.toLowerCase().includes(searchUser.toLowerCase());
    const matchAction = actionFilter === "all" || log.action === actionFilter;
    return matchUser && matchAction;
  });

  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="Audit Log"
        subtitle="Track all system activity and changes"
        actions={
          <button className="inline-flex items-center gap-2 rounded-lg border border-linkedin-gray-30 bg-white px-4 py-2 text-sm font-medium text-linkedin-gray-70 hover:bg-linkedin-gray-10 transition-colors">
            <Download className="h-4 w-4" />
            Export CSV
          </button>
        }
      />

      {/* Filters */}
      <Card>
        <CardBody>
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="flex gap-3 flex-1">
              <input type="date" defaultValue="2026-03-01" className="rounded-lg border border-linkedin-gray-30 bg-white px-3 py-2 text-sm text-linkedin-gray-90 focus:border-linkedin-blue focus:outline-none focus:ring-1 focus:ring-linkedin-blue" />
              <input type="date" defaultValue="2026-03-09" className="rounded-lg border border-linkedin-gray-30 bg-white px-3 py-2 text-sm text-linkedin-gray-90 focus:border-linkedin-blue focus:outline-none focus:ring-1 focus:ring-linkedin-blue" />
            </div>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-linkedin-gray-50" />
              <input type="text" placeholder="Search user..." value={searchUser} onChange={(e) => setSearchUser(e.target.value)} className="rounded-lg border border-linkedin-gray-30 bg-white pl-10 pr-3 py-2 text-sm text-linkedin-gray-90 focus:border-linkedin-blue focus:outline-none focus:ring-1 focus:ring-linkedin-blue" />
            </div>
            <select value={actionFilter} onChange={(e) => setActionFilter(e.target.value)} className="rounded-lg border border-linkedin-gray-30 bg-white px-3 py-2 text-sm text-linkedin-gray-90 focus:border-linkedin-blue focus:outline-none focus:ring-1 focus:ring-linkedin-blue">
              <option value="all">All Actions</option>
              <option value="create">Create</option>
              <option value="update">Update</option>
              <option value="delete">Delete</option>
              <option value="export">Export</option>
              <option value="login">Login</option>
            </select>
          </div>
        </CardBody>
      </Card>

      {/* Table */}
      <Card padding="none">
        <CardBody className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-linkedin-gray-20 bg-linkedin-gray-10">
                  <th className="px-4 py-3 text-left font-medium text-linkedin-gray-70">Timestamp</th>
                  <th className="px-4 py-3 text-left font-medium text-linkedin-gray-70">User</th>
                  <th className="px-4 py-3 text-left font-medium text-linkedin-gray-70">Action</th>
                  <th className="px-4 py-3 text-left font-medium text-linkedin-gray-70">Resource</th>
                  <th className="px-4 py-3 text-left font-medium text-linkedin-gray-70">Details</th>
                  <th className="px-4 py-3 text-left font-medium text-linkedin-gray-70">IP Address</th>
                  <th className="px-4 py-3 w-8"></th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((log, i) => (
                  <React.Fragment key={i}>
                    <tr
                      className="border-b border-linkedin-gray-20 hover:bg-linkedin-gray-10 transition-colors cursor-pointer"
                      onClick={() => setExpandedRow(expandedRow === i ? null : i)}
                    >
                      <td className="px-4 py-3 text-linkedin-gray-50 tabular-nums whitespace-nowrap">{log.timestamp}</td>
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-2">
                          <div className="h-6 w-6 rounded-full bg-linkedin-blue flex items-center justify-center text-[10px] font-medium text-white">{log.initials}</div>
                          <span className="font-medium text-linkedin-gray-90">{log.user}</span>
                        </div>
                      </td>
                      <td className="px-4 py-3"><Badge variant={actionVariant[log.action]}>{log.action}</Badge></td>
                      <td className="px-4 py-3 text-linkedin-gray-70">{log.resource}</td>
                      <td className="px-4 py-3 text-linkedin-gray-50 max-w-xs truncate">{log.details}</td>
                      <td className="px-4 py-3 text-linkedin-gray-50 tabular-nums">{log.ip}</td>
                      <td className="px-4 py-3">
                        {expandedRow === i ? <ChevronUp className="h-4 w-4 text-linkedin-gray-50" /> : <ChevronDown className="h-4 w-4 text-linkedin-gray-50" />}
                      </td>
                    </tr>
                    {expandedRow === i && (
                      <tr className="bg-linkedin-gray-10">
                        <td colSpan={7} className="px-4 py-3">
                          <div className="text-sm text-linkedin-gray-70">
                            <p><strong>Full Details:</strong> {log.details}</p>
                            <p className="mt-1"><strong>IP:</strong> {log.ip} | <strong>Time:</strong> {log.timestamp}</p>
                          </div>
                        </td>
                      </tr>
                    )}
                  </React.Fragment>
                ))}
              </tbody>
            </table>
          </div>
        </CardBody>
      </Card>
    </div>
  );
}
