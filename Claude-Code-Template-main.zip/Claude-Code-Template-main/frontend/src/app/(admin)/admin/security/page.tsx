"use client";

import React from "react";
import {
  Shield,
  Key,
  ScrollText,
  CheckCircle,
  User,
} from "lucide-react";
import { cn } from "@/lib/utils/cn";
import { Card, CardBody, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { PageHeader } from "@/components/layout/page-header";

/* ------------------------------------------------------------------ */
/* Mock Data                                                           */
/* ------------------------------------------------------------------ */

const stats = [
  { label: "Roles", value: "4", sublabel: "defined", icon: Shield, color: "text-linkedin-blue" },
  { label: "Active API Keys", value: "12", sublabel: "active", icon: Key, color: "text-linkedin-orange" },
  { label: "Audit Events Today", value: "1,247", sublabel: "events", icon: ScrollText, color: "text-linkedin-gray-70" },
];

const auditEvents = [
  { user: "Sarah Chen", action: "Updated API key permissions", resource: "API Key sk_live_****xyz", timestamp: "2026-03-09 14:32" },
  { user: "James Wilson", action: "Created new role", resource: "Role: Viewer", timestamp: "2026-03-09 13:15" },
  { user: "Emily Park", action: "Exported audit log", resource: "Audit Log", timestamp: "2026-03-09 11:45" },
  { user: "Michael Torres", action: "Revoked API key", resource: "API Key sk_live_****abc", timestamp: "2026-03-09 10:20" },
  { user: "Sarah Chen", action: "Modified compliance settings", resource: "GDPR Configuration", timestamp: "2026-03-09 09:00" },
];

/* ------------------------------------------------------------------ */
/* Page                                                                */
/* ------------------------------------------------------------------ */

export default function SecurityOverviewPage() {
  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="Security"
        subtitle="Manage roles, API keys, audit logs, and compliance"
      />

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {stats.map((stat) => (
          <Card key={stat.label} hover>
            <CardBody>
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-xs text-linkedin-gray-50">{stat.label}</p>
                  <p className="mt-1 text-2xl font-bold text-linkedin-gray-90">{stat.value}</p>
                  <p className="text-xs text-linkedin-gray-50">{stat.sublabel}</p>
                </div>
                <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-linkedin-blue-bg">
                  <stat.icon className={cn("h-5 w-5", stat.color)} />
                </div>
              </div>
            </CardBody>
          </Card>
        ))}
        <Card hover>
          <CardBody>
            <div className="flex items-start justify-between">
              <div>
                <p className="text-xs text-linkedin-gray-50">Compliance Status</p>
                <div className="mt-2">
                  <Badge variant="success" size="md">GDPR Compliant</Badge>
                </div>
              </div>
              <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-green-50">
                <CheckCircle className="h-5 w-5 text-linkedin-green" />
              </div>
            </div>
          </CardBody>
        </Card>
      </div>

      <Card padding="none">
        <CardHeader>Recent Audit Events</CardHeader>
        <CardBody className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-linkedin-gray-20 bg-linkedin-gray-10">
                  <th className="px-4 py-3 text-left font-medium text-linkedin-gray-70">User</th>
                  <th className="px-4 py-3 text-left font-medium text-linkedin-gray-70">Action</th>
                  <th className="px-4 py-3 text-left font-medium text-linkedin-gray-70">Resource</th>
                  <th className="px-4 py-3 text-left font-medium text-linkedin-gray-70">Timestamp</th>
                </tr>
              </thead>
              <tbody>
                {auditEvents.map((event, i) => (
                  <tr key={i} className="border-b border-linkedin-gray-20 last:border-0 hover:bg-linkedin-gray-10 transition-colors">
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2">
                        <div className="h-6 w-6 rounded-full bg-linkedin-blue flex items-center justify-center">
                          <User className="h-3 w-3 text-white" />
                        </div>
                        <span className="font-medium text-linkedin-gray-90">{event.user}</span>
                      </div>
                    </td>
                    <td className="px-4 py-3 text-linkedin-gray-70">{event.action}</td>
                    <td className="px-4 py-3 text-linkedin-gray-50">{event.resource}</td>
                    <td className="px-4 py-3 text-linkedin-gray-50 tabular-nums">{event.timestamp}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardBody>
      </Card>
    </div>
  );
}
