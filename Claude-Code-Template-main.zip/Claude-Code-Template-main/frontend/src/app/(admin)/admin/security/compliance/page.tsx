"use client";

import React, { useState } from "react";
import { Shield, Search, Trash2 } from "lucide-react";
import { cn } from "@/lib/utils/cn";
import { Card, CardBody, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { PageHeader } from "@/components/layout/page-header";

/* ------------------------------------------------------------------ */
/* Mock Data                                                           */
/* ------------------------------------------------------------------ */

const retentionPolicies = [
  { dataType: "Conversations", period: "2 years", autoDelete: true },
  { dataType: "Recordings", period: "1 year", autoDelete: true },
  { dataType: "Logs", period: "90 days", autoDelete: true },
  { dataType: "Analytics", period: "3 years", autoDelete: false },
];

const exportRequests = [
  { customer: "john.doe@example.com", requested: "2026-03-08", status: "Pending" },
  { customer: "jane.smith@acme.com", requested: "2026-03-05", status: "Processing" },
  { customer: "bob.wilson@test.org", requested: "2026-03-01", status: "Completed" },
];

const exportStatusVariant: Record<string, "warning" | "primary" | "success"> = {
  Pending: "warning",
  Processing: "primary",
  Completed: "success",
};

/* ------------------------------------------------------------------ */
/* Page                                                                */
/* ------------------------------------------------------------------ */

export default function CompliancePage() {
  const [piiDetection, setPiiDetection] = useState(true);
  const [autoMask, setAutoMask] = useState(true);
  const [policies, setPolicies] = useState(retentionPolicies);
  const [deleteSearch, setDeleteSearch] = useState("");

  const toggleAutoDelete = (idx: number) => {
    setPolicies((prev) =>
      prev.map((p, i) => (i === idx ? { ...p, autoDelete: !p.autoDelete } : p))
    );
  };

  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="Compliance"
        subtitle="GDPR compliance, data retention, and privacy settings"
        actions={
          <button className="inline-flex items-center gap-2 rounded-lg bg-linkedin-blue px-4 py-2 text-sm font-medium text-white hover:bg-linkedin-blue-dark transition-colors">
            Save Changes
          </button>
        }
      />

      {/* GDPR Status */}
      <Card>
        <CardBody>
          <div className="flex items-center gap-3">
            <Shield className="h-6 w-6 text-linkedin-green" />
            <div>
              <h3 className="text-sm font-semibold text-linkedin-gray-90">GDPR Compliance Status</h3>
              <p className="text-xs text-linkedin-gray-50">All data processing is compliant with GDPR regulations</p>
            </div>
            <Badge variant="success" size="md" className="ml-auto">Compliant</Badge>
          </div>
        </CardBody>
      </Card>

      <div className="grid gap-6 lg:grid-cols-2">
        {/* Data Retention */}
        <Card padding="none">
          <CardHeader>Data Retention Policies</CardHeader>
          <CardBody className="p-0">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-linkedin-gray-20 bg-linkedin-gray-10">
                  <th className="px-4 py-3 text-left font-medium text-linkedin-gray-70">Data Type</th>
                  <th className="px-4 py-3 text-left font-medium text-linkedin-gray-70">Retention Period</th>
                  <th className="px-4 py-3 text-left font-medium text-linkedin-gray-70">Auto-Delete</th>
                </tr>
              </thead>
              <tbody>
                {policies.map((policy, i) => (
                  <tr key={i} className="border-b border-linkedin-gray-20 last:border-0 hover:bg-linkedin-gray-10 transition-colors">
                    <td className="px-4 py-3 font-medium text-linkedin-gray-90">{policy.dataType}</td>
                    <td className="px-4 py-3 text-linkedin-gray-70">{policy.period}</td>
                    <td className="px-4 py-3">
                      <button
                        onClick={() => toggleAutoDelete(i)}
                        className={cn(
                          "relative inline-flex h-5 w-9 items-center rounded-full transition-colors",
                          policy.autoDelete ? "bg-linkedin-green" : "bg-linkedin-gray-30"
                        )}
                      >
                        <span className={cn(
                          "inline-block h-3.5 w-3.5 rounded-full bg-white transition-transform",
                          policy.autoDelete ? "translate-x-4" : "translate-x-0.5"
                        )} />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </CardBody>
        </Card>

        {/* PII Detection */}
        <Card padding="none">
          <CardHeader>PII Detection</CardHeader>
          <CardBody className="flex flex-col gap-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-linkedin-gray-90">PII Detection</p>
                <p className="text-xs text-linkedin-gray-50">Automatically detect personally identifiable information</p>
              </div>
              <button
                onClick={() => setPiiDetection(!piiDetection)}
                className={cn(
                  "relative inline-flex h-6 w-11 items-center rounded-full transition-colors",
                  piiDetection ? "bg-linkedin-green" : "bg-linkedin-gray-30"
                )}
              >
                <span className={cn(
                  "inline-block h-4 w-4 rounded-full bg-white transition-transform",
                  piiDetection ? "translate-x-6" : "translate-x-1"
                )} />
              </button>
            </div>
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-linkedin-gray-90">Auto-Mask in Logs</p>
                <p className="text-xs text-linkedin-gray-50">Automatically mask PII in system logs</p>
              </div>
              <button
                onClick={() => setAutoMask(!autoMask)}
                className={cn(
                  "relative inline-flex h-6 w-11 items-center rounded-full transition-colors",
                  autoMask ? "bg-linkedin-green" : "bg-linkedin-gray-30"
                )}
              >
                <span className={cn(
                  "inline-block h-4 w-4 rounded-full bg-white transition-transform",
                  autoMask ? "translate-x-6" : "translate-x-1"
                )} />
              </button>
            </div>
          </CardBody>
        </Card>
      </div>

      {/* Data Export Requests */}
      <Card padding="none">
        <CardHeader>Data Export Requests</CardHeader>
        <CardBody className="p-0">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-linkedin-gray-20 bg-linkedin-gray-10">
                <th className="px-4 py-3 text-left font-medium text-linkedin-gray-70">Customer</th>
                <th className="px-4 py-3 text-left font-medium text-linkedin-gray-70">Requested</th>
                <th className="px-4 py-3 text-left font-medium text-linkedin-gray-70">Status</th>
                <th className="px-4 py-3 text-left font-medium text-linkedin-gray-70">Actions</th>
              </tr>
            </thead>
            <tbody>
              {exportRequests.map((req, i) => (
                <tr key={i} className="border-b border-linkedin-gray-20 last:border-0 hover:bg-linkedin-gray-10 transition-colors">
                  <td className="px-4 py-3 font-medium text-linkedin-gray-90">{req.customer}</td>
                  <td className="px-4 py-3 text-linkedin-gray-50">{req.requested}</td>
                  <td className="px-4 py-3"><Badge variant={exportStatusVariant[req.status]}>{req.status}</Badge></td>
                  <td className="px-4 py-3">
                    {req.status === "Pending" && (
                      <button className="rounded-md px-3 py-1 text-xs font-medium text-linkedin-blue hover:bg-linkedin-blue-bg transition-colors">Process</button>
                    )}
                    {req.status === "Completed" && (
                      <button className="rounded-md px-3 py-1 text-xs font-medium text-linkedin-blue hover:bg-linkedin-blue-bg transition-colors">Download</button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </CardBody>
      </Card>

      {/* Data Deletion */}
      <Card padding="none">
        <CardHeader>Data Deletion</CardHeader>
        <CardBody>
          <div className="flex gap-2">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-linkedin-gray-50" />
              <input type="text" value={deleteSearch} onChange={(e) => setDeleteSearch(e.target.value)} placeholder="Search customer by email..." className="w-full rounded-lg border border-linkedin-gray-30 bg-white pl-10 pr-3 py-2 text-sm text-linkedin-gray-90 focus:border-linkedin-blue focus:outline-none focus:ring-1 focus:ring-linkedin-blue" />
            </div>
            <button className="inline-flex items-center gap-2 rounded-lg bg-linkedin-red px-4 py-2 text-sm font-medium text-white hover:opacity-90 transition-opacity">
              <Trash2 className="h-4 w-4" />
              Process Deletion
            </button>
          </div>
        </CardBody>
      </Card>
    </div>
  );
}
