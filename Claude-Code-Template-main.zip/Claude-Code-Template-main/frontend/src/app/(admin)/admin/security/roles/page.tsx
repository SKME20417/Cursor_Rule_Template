"use client";

import React, { useState } from "react";
import { Save } from "lucide-react";
import { cn } from "@/lib/utils/cn";
import { Card, CardBody, CardHeader } from "@/components/ui/card";
import { PageHeader } from "@/components/layout/page-header";

/* ------------------------------------------------------------------ */
/* Mock Data                                                           */
/* ------------------------------------------------------------------ */

const roles = ["Admin", "Supervisor", "Agent", "Customer"] as const;
type Role = (typeof roles)[number];

const resources = [
  "Tickets",
  "Conversations",
  "Analytics",
  "Knowledge Base",
  "Agents",
  "Settings",
  "Integrations",
  "Security",
];

const actions = ["View", "Create", "Edit", "Delete"] as const;

const initialPermissions: Record<Role, Record<string, Record<string, boolean>>> = {
  Admin: Object.fromEntries(resources.map((r) => [r, Object.fromEntries(actions.map((a) => [a, true]))])),
  Supervisor: Object.fromEntries(
    resources.map((r) => [
      r,
      {
        View: true,
        Create: !["Settings", "Security", "Integrations"].includes(r),
        Edit: !["Security", "Integrations"].includes(r),
        Delete: ["Tickets", "Conversations"].includes(r),
      },
    ])
  ),
  Agent: Object.fromEntries(
    resources.map((r) => [
      r,
      {
        View: ["Tickets", "Conversations", "Knowledge Base"].includes(r),
        Create: ["Tickets", "Conversations"].includes(r),
        Edit: ["Tickets", "Conversations"].includes(r),
        Delete: false,
      },
    ])
  ),
  Customer: Object.fromEntries(
    resources.map((r) => [
      r,
      {
        View: ["Tickets", "Knowledge Base"].includes(r),
        Create: r === "Tickets",
        Edit: false,
        Delete: false,
      },
    ])
  ),
};

/* ------------------------------------------------------------------ */
/* Page                                                                */
/* ------------------------------------------------------------------ */

export default function RolesPage() {
  const [activeRole, setActiveRole] = useState<Role>("Admin");
  const [permissions, setPermissions] = useState(initialPermissions);

  const togglePermission = (resource: string, action: string) => {
    setPermissions((prev) => ({
      ...prev,
      [activeRole]: {
        ...prev[activeRole],
        [resource]: {
          ...prev[activeRole][resource],
          [action]: !prev[activeRole][resource][action],
        },
      },
    }));
  };

  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="Roles & Permissions"
        subtitle="Manage user roles and their access permissions"
        actions={
          <button className="inline-flex items-center gap-2 rounded-lg bg-linkedin-blue px-4 py-2 text-sm font-medium text-white hover:bg-linkedin-blue-dark transition-colors">
            <Save className="h-4 w-4" />
            Save Changes
          </button>
        }
      />

      {/* Role Tabs */}
      <div className="flex border-b border-linkedin-gray-20">
        {roles.map((role) => (
          <button
            key={role}
            onClick={() => setActiveRole(role)}
            className={cn(
              "px-6 py-3 text-sm font-medium transition-colors border-b-2",
              activeRole === role
                ? "border-linkedin-blue text-linkedin-blue"
                : "border-transparent text-linkedin-gray-50 hover:text-linkedin-gray-90"
            )}
          >
            {role}
            {role === "Customer" && (
              <span className="ml-1 text-xs text-linkedin-gray-50">(read-only)</span>
            )}
          </button>
        ))}
      </div>

      {/* Permission Matrix */}
      <Card padding="none">
        <CardHeader>Permission Matrix - {activeRole}</CardHeader>
        <CardBody className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-linkedin-gray-20 bg-linkedin-gray-10">
                  <th className="px-4 py-3 text-left font-medium text-linkedin-gray-70">Resource</th>
                  {actions.map((action) => (
                    <th key={action} className="px-4 py-3 text-center font-medium text-linkedin-gray-70">{action}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {resources.map((resource) => (
                  <tr key={resource} className="border-b border-linkedin-gray-20 last:border-0 hover:bg-linkedin-gray-10 transition-colors">
                    <td className="px-4 py-3 font-medium text-linkedin-gray-90">{resource}</td>
                    {actions.map((action) => (
                      <td key={action} className="px-4 py-3 text-center">
                        <input
                          type="checkbox"
                          checked={permissions[activeRole][resource][action]}
                          onChange={() => togglePermission(resource, action)}
                          className="h-4 w-4 rounded border-linkedin-gray-30 text-linkedin-blue focus:ring-linkedin-blue"
                        />
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardBody>
      </Card>
    </div>
  );
}
