"use client";
import { cn } from "@/lib/utils/cn";
import { Hash, Bell, CheckCircle, AlertTriangle } from "lucide-react";

const MOCK_NOTIFICATION_CHANNELS = [
  { channel: "#alerts", purpose: "SLA breaches" },
  { channel: "#escalations", purpose: "Escalations" },
];

const MOCK_ALERT_TYPES = [
  { type: "SLA breach", enabled: true },
  { type: "Escalation", enabled: true },
  { type: "System error", enabled: true },
  { type: "High priority ticket", enabled: false },
];

export default function SlackIntegrationPage() {
  return (
    <div className="max-w-4xl mx-auto px-4 py-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-semibold text-linkedin-black">Slack Integration</h1>
          <p className="text-sm text-linkedin-gray-70 mt-1">Configure Slack workspace notifications and alerts</p>
        </div>
        <span className="badge bg-linkedin-green/10 text-linkedin-green">Connected</span>
      </div>

      <div className="card p-6 space-y-4">
        <h2 className="text-base font-semibold text-linkedin-black">Workspace Connection</h2>
        <div className="rounded-lg bg-green-50 border border-green-200 p-4 flex items-center gap-3">
          <CheckCircle className="w-5 h-5 text-linkedin-green" />
          <div>
            <p className="text-sm font-medium text-linkedin-black">Connected: Acme Corp</p>
            <p className="text-xs text-linkedin-gray-50">Workspace is active and receiving notifications</p>
          </div>
        </div>
      </div>

      <div className="card p-6 space-y-4">
        <h2 className="text-base font-semibold text-linkedin-black">Notification Channels</h2>
        <div className="space-y-3">
          {MOCK_NOTIFICATION_CHANNELS.map((nc) => (
            <div key={nc.channel} className="flex items-center justify-between rounded-lg border border-linkedin-gray-20 bg-linkedin-gray-10/50 px-4 py-3">
              <div className="flex items-center gap-3">
                <Hash className="w-4 h-4 text-linkedin-gray-50" />
                <div>
                  <span className="text-sm font-medium text-linkedin-black">{nc.channel}</span>
                  <p className="text-xs text-linkedin-gray-50">{nc.purpose}</p>
                </div>
              </div>
              <span className="badge text-xs bg-linkedin-green/10 text-linkedin-green">Active</span>
            </div>
          ))}
        </div>
      </div>

      <div className="card p-6 space-y-4">
        <h2 className="text-base font-semibold text-linkedin-black">Alert Types</h2>
        <div className="space-y-3">
          {MOCK_ALERT_TYPES.map((alert) => (
            <label key={alert.type} className="flex items-center justify-between rounded-lg border border-linkedin-gray-20 px-4 py-3 hover:bg-linkedin-gray-10/50 transition-colors cursor-pointer">
              <div className="flex items-center gap-3">
                <AlertTriangle className="w-4 h-4 text-linkedin-gray-50" />
                <span className="text-sm text-linkedin-black">{alert.type}</span>
              </div>
              <input
                type="checkbox"
                defaultChecked={alert.enabled}
                className="w-4 h-4 accent-linkedin-blue"
              />
            </label>
          ))}
        </div>
      </div>

      <div className="flex justify-end"><button className="btn-primary">Save Changes</button></div>
    </div>
  );
}
