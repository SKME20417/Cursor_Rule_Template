"use client";
import { cn } from "@/lib/utils/cn";
import { Kanban, RefreshCw, ArrowRight } from "lucide-react";

const MOCK_ESCALATION_MAPPINGS = [
  { priority: "Critical", issueType: "Bug" },
  { priority: "High", issueType: "Task" },
  { priority: "Medium", issueType: "Task" },
  { priority: "Low", issueType: "Subtask" },
];

export default function JiraIntegrationPage() {
  return (
    <div className="max-w-4xl mx-auto px-4 py-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-semibold text-linkedin-black">Jira Integration</h1>
          <p className="text-sm text-linkedin-gray-70 mt-1">Configure Jira project management and escalation mapping</p>
        </div>
        <span className="badge bg-linkedin-green/10 text-linkedin-green">Connected</span>
      </div>

      <div className="card p-6 space-y-4">
        <h2 className="text-base font-semibold text-linkedin-black">Connection Settings</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-linkedin-gray-70 mb-1">Instance URL</label>
            <input className="input-field" defaultValue="https://acme.atlassian.net" />
          </div>
          <div>
            <label className="block text-sm font-medium text-linkedin-gray-70 mb-1">Email</label>
            <input className="input-field" defaultValue="admin@acme.com" />
          </div>
          <div className="md:col-span-2">
            <label className="block text-sm font-medium text-linkedin-gray-70 mb-1">API Token</label>
            <input className="input-field" type="password" defaultValue="jira_api_token_xxxxx" />
          </div>
        </div>
      </div>

      <div className="card p-6 space-y-4">
        <h2 className="text-base font-semibold text-linkedin-black">Project Settings</h2>
        <div>
          <label className="block text-sm font-medium text-linkedin-gray-70 mb-1">Default Project</label>
          <select className="input-field" defaultValue="SUPPORT">
            <option value="SUPPORT">SUPPORT</option>
            <option value="ENGINEERING">ENGINEERING</option>
          </select>
        </div>
      </div>

      <div className="card p-6 space-y-4">
        <h2 className="text-base font-semibold text-linkedin-black">Escalation Mapping</h2>
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-linkedin-gray-20">
              <th className="text-left py-2 font-medium text-linkedin-gray-70">Ticket Priority</th>
              <th className="text-left py-2 font-medium text-linkedin-gray-70">Jira Issue Type</th>
            </tr>
          </thead>
          <tbody>
            {MOCK_ESCALATION_MAPPINGS.map((m, i) => (
              <tr key={i} className="border-b border-linkedin-gray-10">
                <td className="py-3">
                  <span className={cn(
                    "badge text-xs",
                    m.priority === "Critical" ? "bg-red-100 text-red-700" :
                    m.priority === "High" ? "bg-orange-100 text-orange-700" :
                    m.priority === "Medium" ? "bg-yellow-100 text-yellow-700" :
                    "bg-linkedin-gray-10 text-linkedin-gray-70"
                  )}>{m.priority}</span>
                </td>
                <td className="py-3">
                  <code className="rounded bg-linkedin-gray-10 px-2 py-0.5 text-xs font-mono">{m.issueType}</code>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="card p-6 space-y-4">
        <h2 className="text-base font-semibold text-linkedin-black">Automation</h2>
        <label className="flex items-center gap-3">
          <input type="checkbox" defaultChecked className="w-4 h-4 accent-linkedin-blue" />
          <span className="text-sm">Auto-create Jira issue on ticket escalation</span>
        </label>
      </div>

      <div className="flex justify-end"><button className="btn-primary">Save Changes</button></div>
    </div>
  );
}
