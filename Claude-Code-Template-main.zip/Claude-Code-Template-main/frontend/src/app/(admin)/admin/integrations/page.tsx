"use client";
import { cn } from "@/lib/utils/cn";
import { Database, BarChart3, Headphones, Kanban, Hash, CreditCard, Settings } from "lucide-react";

const MOCK_INTEGRATIONS = [
  { name: "Salesforce", category: "CRM", icon: Database, connected: true, href: "/integrations/crm" },
  { name: "HubSpot", category: "CRM", icon: BarChart3, connected: false, href: "/integrations/crm" },
  { name: "Zendesk", category: "Helpdesk", icon: Headphones, connected: true, href: "/integrations/zendesk" },
  { name: "Jira", category: "Project Mgmt", icon: Kanban, connected: true, href: "/integrations/jira" },
  { name: "Slack", category: "Messaging", icon: Hash, connected: true, href: "/integrations/slack" },
  { name: "Stripe", category: "Payments", icon: CreditCard, connected: false, href: "/integrations/stripe" },
];

export default function IntegrationsHubPage() {
  return (
    <div className="max-w-5xl mx-auto px-4 py-6 space-y-6">
      <div>
        <h1 className="text-xl font-semibold text-linkedin-black">Integrations</h1>
        <p className="text-sm text-linkedin-gray-70 mt-1">Connect and manage third-party integrations</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {MOCK_INTEGRATIONS.map((intg) => (
          <div key={intg.name} className="card p-6 space-y-4 hover:shadow-md transition-shadow">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-3">
                <div className={cn(
                  "flex h-10 w-10 items-center justify-center rounded-lg",
                  intg.connected ? "bg-linkedin-blue/10" : "bg-linkedin-gray-10"
                )}>
                  <intg.icon className={cn("w-5 h-5", intg.connected ? "text-linkedin-blue" : "text-linkedin-gray-50")} />
                </div>
                <div>
                  <h3 className="text-sm font-semibold text-linkedin-black">{intg.name}</h3>
                  <span className="badge text-xs bg-linkedin-gray-10 text-linkedin-gray-70">{intg.category}</span>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1.5">
                <span className={cn(
                  "h-2 w-2 rounded-full",
                  intg.connected ? "bg-linkedin-green" : "bg-linkedin-gray-30"
                )} />
                <span className={cn(
                  "text-xs font-medium",
                  intg.connected ? "text-linkedin-green" : "text-linkedin-gray-50"
                )}>
                  {intg.connected ? "Connected" : "Not configured"}
                </span>
              </div>
              <a href={intg.href} className="inline-flex items-center gap-1 text-xs font-medium text-linkedin-blue hover:underline">
                <Settings className="w-3 h-3" />
                Configure
              </a>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
