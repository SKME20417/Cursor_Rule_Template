"use client";
import { cn } from "@/lib/utils/cn";
import { Headphones, RefreshCw, CheckCircle } from "lucide-react";

const MOCK_STATUS_MAPPINGS = [
  { internal: "created", zendesk: "new" },
  { internal: "in_progress", zendesk: "open" },
  { internal: "resolved", zendesk: "solved" },
  { internal: "closed", zendesk: "closed" },
];

export default function ZendeskIntegrationPage() {
  return (
    <div className="max-w-4xl mx-auto px-4 py-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-semibold text-linkedin-black">Zendesk Integration</h1>
          <p className="text-sm text-linkedin-gray-70 mt-1">Configure Zendesk helpdesk ticket synchronization</p>
        </div>
        <span className="badge bg-linkedin-green/10 text-linkedin-green">Connected</span>
      </div>

      <div className="card p-6 space-y-4">
        <h2 className="text-base font-semibold text-linkedin-black">Connection Settings</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-linkedin-gray-70 mb-1">Subdomain</label>
            <input className="input-field" defaultValue="acme" />
            <p className="text-xs text-linkedin-gray-50 mt-1">acme.zendesk.com</p>
          </div>
          <div>
            <label className="block text-sm font-medium text-linkedin-gray-70 mb-1">Agent Email</label>
            <input className="input-field" defaultValue="admin@acme.com" />
          </div>
          <div className="md:col-span-2">
            <label className="block text-sm font-medium text-linkedin-gray-70 mb-1">API Token</label>
            <input className="input-field" type="password" defaultValue="zendesk_api_token_xxxxx" />
          </div>
        </div>
        <button className="btn-secondary text-sm flex items-center gap-1">
          <RefreshCw className="w-4 h-4" />
          Test Connection
        </button>
      </div>

      <div className="card p-6 space-y-4">
        <h2 className="text-base font-semibold text-linkedin-black">Status Mapping</h2>
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-linkedin-gray-20">
              <th className="text-left py-2 font-medium text-linkedin-gray-70">Internal Status</th>
              <th className="text-left py-2 font-medium text-linkedin-gray-70">Zendesk Status</th>
            </tr>
          </thead>
          <tbody>
            {MOCK_STATUS_MAPPINGS.map((m, i) => (
              <tr key={i} className="border-b border-linkedin-gray-10">
                <td className="py-3">
                  <code className="rounded bg-linkedin-gray-10 px-2 py-0.5 text-xs font-mono">{m.internal}</code>
                </td>
                <td className="py-3">
                  <code className="rounded bg-linkedin-gray-10 px-2 py-0.5 text-xs font-mono">{m.zendesk}</code>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="card p-6 space-y-4">
        <h2 className="text-base font-semibold text-linkedin-black">Sync Settings</h2>
        <label className="flex items-center gap-3">
          <input type="checkbox" defaultChecked className="w-4 h-4 accent-linkedin-blue" />
          <span className="text-sm">Enable ticket synchronization</span>
        </label>
      </div>

      <div className="flex justify-end"><button className="btn-primary">Save Changes</button></div>
    </div>
  );
}
