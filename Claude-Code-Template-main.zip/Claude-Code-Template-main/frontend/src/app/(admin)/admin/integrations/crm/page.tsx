"use client";
import { cn } from "@/lib/utils/cn";
import { Database, RefreshCw, CheckCircle } from "lucide-react";

const MOCK_FIELD_MAPPINGS = [
  { source: "name", target: "Name" },
  { source: "email", target: "Email" },
  { source: "company", target: "Company" },
  { source: "phone", target: "Phone" },
  { source: "plan", target: "Account_Type" },
];

export default function CRMIntegrationPage() {
  return (
    <div className="max-w-4xl mx-auto px-4 py-6 space-y-6">
      <div>
        <h1 className="text-xl font-semibold text-linkedin-black">CRM Integration</h1>
        <p className="text-sm text-linkedin-gray-70 mt-1">Configure Salesforce or HubSpot CRM connection</p>
      </div>

      <div className="card p-6 space-y-4">
        <h2 className="text-base font-semibold text-linkedin-black">CRM Provider</h2>
        <div className="flex gap-2">
          <button className={cn("px-4 py-2 text-sm font-medium rounded-lg border transition-colors", "bg-linkedin-blue text-white border-linkedin-blue")}>
            Salesforce
          </button>
          <button className={cn("px-4 py-2 text-sm font-medium rounded-lg border transition-colors", "bg-white text-linkedin-gray-70 border-linkedin-gray-20 hover:bg-linkedin-gray-10")}>
            HubSpot
          </button>
        </div>
      </div>

      <div className="card p-6 space-y-4">
        <h2 className="text-base font-semibold text-linkedin-black">API Configuration</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-linkedin-gray-70 mb-1">API Key</label>
            <input className="input-field" type="password" defaultValue="sf_api_key_xxxxx" />
          </div>
          <div>
            <label className="block text-sm font-medium text-linkedin-gray-70 mb-1">Instance URL</label>
            <input className="input-field" defaultValue="https://acme.salesforce.com" />
          </div>
        </div>
        <button className="btn-secondary text-sm flex items-center gap-1">
          <RefreshCw className="w-4 h-4" />
          Test Connection
        </button>
      </div>

      <div className="card p-6 space-y-4">
        <h2 className="text-base font-semibold text-linkedin-black">Sync Direction</h2>
        <div className="space-y-2">
          <label className="flex items-center gap-3">
            <input type="radio" name="syncDirection" defaultChecked className="w-4 h-4 accent-linkedin-blue" />
            <span className="text-sm">Bi-directional</span>
          </label>
          <label className="flex items-center gap-3">
            <input type="radio" name="syncDirection" className="w-4 h-4 accent-linkedin-blue" />
            <span className="text-sm">Inbound only (CRM to Platform)</span>
          </label>
          <label className="flex items-center gap-3">
            <input type="radio" name="syncDirection" className="w-4 h-4 accent-linkedin-blue" />
            <span className="text-sm">Outbound only (Platform to CRM)</span>
          </label>
        </div>
      </div>

      <div className="card p-6 space-y-4">
        <h2 className="text-base font-semibold text-linkedin-black">Field Mapping</h2>
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-linkedin-gray-20">
              <th className="text-left py-2 font-medium text-linkedin-gray-70">Platform Field</th>
              <th className="text-left py-2 font-medium text-linkedin-gray-70">CRM Field</th>
            </tr>
          </thead>
          <tbody>
            {MOCK_FIELD_MAPPINGS.map((m, i) => (
              <tr key={i} className="border-b border-linkedin-gray-10">
                <td className="py-3">
                  <code className="rounded bg-linkedin-gray-10 px-2 py-0.5 text-xs font-mono">{m.source}</code>
                </td>
                <td className="py-3">
                  <code className="rounded bg-linkedin-gray-10 px-2 py-0.5 text-xs font-mono">{m.target}</code>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="card p-6 space-y-4">
        <h2 className="text-base font-semibold text-linkedin-black">Sync Status</h2>
        <div className="flex items-center gap-2 text-sm text-linkedin-gray-70">
          <CheckCircle className="w-4 h-4 text-linkedin-green" />
          <span>Last synced: 5 minutes ago &middot; 12,450 contacts synced</span>
        </div>
        <label className="flex items-center gap-3">
          <input type="checkbox" defaultChecked className="w-4 h-4 accent-linkedin-blue" />
          <span className="text-sm">Enable automatic sync</span>
        </label>
      </div>

      <div className="flex justify-end"><button className="btn-primary">Save Changes</button></div>
    </div>
  );
}
