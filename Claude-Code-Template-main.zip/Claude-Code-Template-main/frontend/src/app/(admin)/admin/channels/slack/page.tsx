"use client";
import { cn } from "@/lib/utils/cn";
import { Hash, Plus, X, CheckCircle, Terminal } from "lucide-react";

const MOCK_CHANNELS = ["#support", "#help", "#feedback"];

const MOCK_COMMANDS = [
  { command: "/support", description: "Create a new support ticket" },
  { command: "/ticket", description: "Look up ticket status by ID" },
  { command: "/kb", description: "Search the knowledge base" },
];

export default function SlackChannelConfigPage() {
  return (
    <div className="max-w-4xl mx-auto px-4 py-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-semibold text-linkedin-black">Slack Configuration</h1>
          <p className="text-sm text-linkedin-gray-70 mt-1">Configure Slack bot and channel monitoring</p>
        </div>
        <span className="badge bg-linkedin-green/10 text-linkedin-green">Connected</span>
      </div>

      <div className="card p-6 space-y-4">
        <h2 className="text-base font-semibold text-linkedin-black">Bot Credentials</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-linkedin-gray-70 mb-1">Bot Token</label>
            <input className="input-field" type="password" defaultValue="xoxb-xxxxxxxxxxxx" />
          </div>
          <div>
            <label className="block text-sm font-medium text-linkedin-gray-70 mb-1">Signing Secret</label>
            <input className="input-field" type="password" defaultValue="signing_secret_xxxxx" />
          </div>
        </div>
        <div className="rounded-lg bg-green-50 border border-green-200 p-3 flex items-center gap-2">
          <CheckCircle className="w-4 h-4 text-linkedin-green" />
          <span className="text-sm text-linkedin-black">Connected Workspace: <strong>Acme Support</strong></span>
        </div>
      </div>

      <div className="card p-6 space-y-4">
        <h2 className="text-base font-semibold text-linkedin-black">Monitored Channels</h2>
        <div className="flex items-center gap-2">
          <input className="input-field flex-1" placeholder="#channel-name" />
          <button className="btn-primary text-sm flex items-center gap-1">
            <Plus className="w-4 h-4" />
            Add
          </button>
        </div>
        <div className="space-y-2">
          {MOCK_CHANNELS.map((ch) => (
            <div key={ch} className="flex items-center justify-between rounded-lg border border-linkedin-gray-20 bg-linkedin-gray-10/50 px-3 py-2">
              <div className="flex items-center gap-2">
                <Hash className="w-4 h-4 text-linkedin-gray-50" />
                <span className="text-sm font-medium text-linkedin-black">{ch.replace("#", "")}</span>
              </div>
              <button className="text-linkedin-gray-50 hover:text-red-600 transition-colors">
                <X className="w-4 h-4" />
              </button>
            </div>
          ))}
        </div>
      </div>

      <div className="card p-6 space-y-4">
        <h2 className="text-base font-semibold text-linkedin-black">Slash Commands</h2>
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-linkedin-gray-20">
              <th className="text-left py-2 font-medium text-linkedin-gray-70">Command</th>
              <th className="text-left py-2 font-medium text-linkedin-gray-70">Description</th>
              <th className="text-left py-2 font-medium text-linkedin-gray-70">Status</th>
            </tr>
          </thead>
          <tbody>
            {MOCK_COMMANDS.map((cmd, i) => (
              <tr key={i} className="border-b border-linkedin-gray-10">
                <td className="py-3">
                  <code className="rounded bg-linkedin-gray-10 px-2 py-0.5 text-xs font-mono text-linkedin-blue">{cmd.command}</code>
                </td>
                <td className="py-3 text-linkedin-gray-70">{cmd.description}</td>
                <td className="py-3">
                  <span className="badge text-xs bg-linkedin-green/10 text-linkedin-green">Active</span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="flex justify-end"><button className="btn-primary">Save Changes</button></div>
    </div>
  );
}
