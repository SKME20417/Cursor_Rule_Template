"use client";
import { cn } from "@/lib/utils/cn";
import { Phone, Send, MessageSquare, Plus } from "lucide-react";

const MOCK_TEMPLATES = [
  { name: "Verification Code", body: "Your code is {{code}}. Expires in 10 min." },
  { name: "Order Shipped", body: "Hi {{name}}, your order #{{order_id}} has shipped!" },
];

export default function SMSConfigPage() {
  return (
    <div className="max-w-4xl mx-auto px-4 py-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-semibold text-linkedin-black">SMS Configuration</h1>
          <p className="text-sm text-linkedin-gray-70 mt-1">Configure your SMS provider and messaging settings</p>
        </div>
        <span className="badge bg-linkedin-green/10 text-linkedin-green">Active</span>
      </div>

      <div className="card p-6 space-y-4">
        <h2 className="text-base font-semibold text-linkedin-black">Provider Settings</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-linkedin-gray-70 mb-1">Provider</label>
            <select className="input-field" defaultValue="twilio">
              <option value="twilio">Twilio</option>
              <option value="vonage">Vonage</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-linkedin-gray-70 mb-1">Phone Number</label>
            <input className="input-field" defaultValue="+1 (555) 123-4567" />
          </div>
          <div>
            <label className="block text-sm font-medium text-linkedin-gray-70 mb-1">Account SID</label>
            <input className="input-field" defaultValue="AC1234567890abcdef" />
          </div>
          <div>
            <label className="block text-sm font-medium text-linkedin-gray-70 mb-1">Auth Token</label>
            <input className="input-field" type="password" defaultValue="auth_token_xxxxx" />
          </div>
        </div>
      </div>

      <div className="card p-6 space-y-4">
        <h2 className="text-base font-semibold text-linkedin-black">Test SMS</h2>
        <div className="flex items-end gap-3">
          <div className="flex-1">
            <label className="block text-sm font-medium text-linkedin-gray-70 mb-1">Recipient Phone Number</label>
            <input className="input-field" placeholder="+1 (555) 000-0000" />
          </div>
          <button className="btn-primary text-sm flex items-center gap-1">
            <Send className="w-4 h-4" />
            Test SMS
          </button>
        </div>
        <p className="text-xs text-linkedin-gray-50">Sends a test message to verify your SMS configuration.</p>
      </div>

      <div className="card p-6 space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-base font-semibold text-linkedin-black">SMS Templates</h2>
          <button className="btn-primary text-sm"><Plus className="w-4 h-4 mr-1" />Add Template</button>
        </div>
        <div className="divide-y divide-linkedin-gray-10">
          {MOCK_TEMPLATES.map((t, i) => (
            <div key={i} className="py-3">
              <div className="flex items-center gap-2 mb-1">
                <MessageSquare className="w-4 h-4 text-linkedin-blue" />
                <span className="text-sm font-medium text-linkedin-black">{t.name}</span>
              </div>
              <p className="text-xs text-linkedin-gray-50 ml-6">{t.body}</p>
            </div>
          ))}
        </div>
      </div>

      <div className="flex justify-end"><button className="btn-primary">Save Changes</button></div>
    </div>
  );
}
