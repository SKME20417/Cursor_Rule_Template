"use client";
import { cn } from "@/lib/utils/cn";
import { MessageCircle, Shield, CheckCircle, Plus } from "lucide-react";

const MOCK_TEMPLATES = [
  { name: "Welcome Message", status: "approved", language: "English" },
  { name: "Order Update", status: "approved", language: "English" },
  { name: "Support Follow-up", status: "pending", language: "Spanish" },
];

export default function WhatsAppConfigPage() {
  return (
    <div className="max-w-4xl mx-auto px-4 py-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-semibold text-linkedin-black">WhatsApp Configuration</h1>
          <p className="text-sm text-linkedin-gray-70 mt-1">Configure your WhatsApp Business API integration</p>
        </div>
        <span className="badge bg-linkedin-green/10 text-linkedin-green">Connected</span>
      </div>

      <div className="card p-6 space-y-4">
        <h2 className="text-base font-semibold text-linkedin-black">API Credentials</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-linkedin-gray-70 mb-1">Phone Number ID</label>
            <input className="input-field" defaultValue="1234567890" />
          </div>
          <div>
            <label className="block text-sm font-medium text-linkedin-gray-70 mb-1">Business Account ID</label>
            <input className="input-field" defaultValue="9876543210" />
          </div>
          <div className="md:col-span-2">
            <label className="block text-sm font-medium text-linkedin-gray-70 mb-1">API Token</label>
            <input className="input-field" type="password" defaultValue="whatsapp_token_xxxxx" />
          </div>
        </div>
        <button className="btn-secondary text-sm">Verify Connection</button>
      </div>

      <div className="card p-6 space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-base font-semibold text-linkedin-black">Message Templates</h2>
          <button className="btn-primary text-sm"><Plus className="w-4 h-4 mr-1" />Add Template</button>
        </div>
        <table className="w-full text-sm">
          <thead><tr className="border-b border-linkedin-gray-20">
            <th className="text-left py-2 font-medium text-linkedin-gray-70">Name</th>
            <th className="text-left py-2 font-medium text-linkedin-gray-70">Status</th>
            <th className="text-left py-2 font-medium text-linkedin-gray-70">Language</th>
          </tr></thead>
          <tbody>
            {MOCK_TEMPLATES.map((t, i) => (
              <tr key={i} className="border-b border-linkedin-gray-10">
                <td className="py-3">{t.name}</td>
                <td className="py-3"><span className={cn("badge text-xs", t.status === "approved" ? "bg-linkedin-green/10 text-linkedin-green" : "bg-yellow-100 text-yellow-700")}>{t.status}</span></td>
                <td className="py-3 text-linkedin-gray-70">{t.language}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="card p-6 space-y-4">
        <h2 className="text-base font-semibold text-linkedin-black">Opt-in Settings</h2>
        <label className="flex items-center gap-3">
          <input type="checkbox" defaultChecked className="w-4 h-4 accent-linkedin-blue" />
          <span className="text-sm">Require double opt-in before sending messages</span>
        </label>
      </div>

      <div className="flex justify-end"><button className="btn-primary">Save Changes</button></div>
    </div>
  );
}
