"use client";
import { cn } from "@/lib/utils/cn";
import { Facebook, Twitter, Instagram, CheckCircle, Link2 } from "lucide-react";

const MOCK_PLATFORMS = [
  { name: "Facebook", icon: Facebook, connected: true, autoResponse: true, responseTarget: "30" },
  { name: "Twitter / X", icon: Twitter, connected: false, autoResponse: false, responseTarget: "60" },
  { name: "Instagram", icon: Instagram, connected: false, autoResponse: false, responseTarget: "60" },
];

export default function SocialConfigPage() {
  return (
    <div className="max-w-4xl mx-auto px-4 py-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-semibold text-linkedin-black">Social Media Channels</h1>
          <p className="text-sm text-linkedin-gray-70 mt-1">Manage social media platform connections and auto-response settings</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {MOCK_PLATFORMS.map((platform) => (
          <div key={platform.name} className="card p-6 space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className={cn(
                  "flex h-10 w-10 items-center justify-center rounded-lg",
                  platform.connected ? "bg-linkedin-blue/10" : "bg-linkedin-gray-10"
                )}>
                  <platform.icon className={cn("w-5 h-5", platform.connected ? "text-linkedin-blue" : "text-linkedin-gray-50")} />
                </div>
                <h2 className="text-sm font-semibold text-linkedin-black">{platform.name}</h2>
              </div>
            </div>

            <div className="flex items-center justify-between">
              <span className="text-sm text-linkedin-gray-70">Status</span>
              {platform.connected ? (
                <div className="flex items-center gap-1 text-linkedin-green">
                  <CheckCircle className="w-4 h-4" />
                  <span className="text-xs font-medium">Connected</span>
                </div>
              ) : (
                <button className="btn-primary text-xs flex items-center gap-1">
                  <Link2 className="w-3 h-3" />
                  Connect
                </button>
              )}
            </div>

            <div className="flex items-center justify-between">
              <span className="text-sm text-linkedin-gray-70">Auto-Response</span>
              <button className={cn(
                "relative inline-flex h-5 w-9 items-center rounded-full transition-colors",
                platform.autoResponse ? "bg-linkedin-green" : "bg-linkedin-gray-30"
              )}>
                <span className={cn(
                  "inline-block h-3.5 w-3.5 rounded-full bg-white transition-transform",
                  platform.autoResponse ? "translate-x-4" : "translate-x-0.5"
                )} />
              </button>
            </div>

            <div>
              <label className="block text-xs text-linkedin-gray-70 mb-1">Response Time Target (min)</label>
              <input className="input-field text-sm" defaultValue={platform.responseTarget} />
            </div>
          </div>
        ))}
      </div>

      <div className="flex justify-end"><button className="btn-primary">Save Changes</button></div>
    </div>
  );
}
