"use client";

import React, { useState } from "react";
import { Copy, MessageCircle, Check } from "lucide-react";
import { cn } from "@/lib/utils/cn";
import { Card, CardBody, CardHeader } from "@/components/ui/card";
import { PageHeader } from "@/components/layout/page-header";

/* ------------------------------------------------------------------ */
/* Mock Data                                                           */
/* ------------------------------------------------------------------ */

const daysOfWeek = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
const defaultChecked = ["Mon", "Tue", "Wed", "Thu", "Fri"];

const embedCode = `<script>
  (function() {
    var w = window;
    var d = document;
    var s = d.createElement('script');
    s.src = 'https://widget.example.com/chat.js';
    s.async = true;
    s.dataset.widgetId = 'wgt_abc123';
    d.body.appendChild(s);
  })();
</script>`;

/* ------------------------------------------------------------------ */
/* Page                                                                */
/* ------------------------------------------------------------------ */

export default function LiveChatConfigPage() {
  const [widgetColor, setWidgetColor] = useState("#0a66c2");
  const [position, setPosition] = useState("bottom-right");
  const [greeting, setGreeting] = useState("Hi there! How can we help you today?");
  const [checkedDays, setCheckedDays] = useState<Set<string>>(new Set(defaultChecked));
  const [startTime, setStartTime] = useState("09:00");
  const [endTime, setEndTime] = useState("17:00");
  const [copied, setCopied] = useState(false);

  const toggleDay = (day: string) => {
    setCheckedDays((prev) => {
      const next = new Set(prev);
      if (next.has(day)) next.delete(day);
      else next.add(day);
      return next;
    });
  };

  const handleCopy = () => {
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="Live Chat Configuration"
        subtitle="Customize your chat widget appearance and behavior"
        actions={
          <button className="inline-flex items-center gap-2 rounded-lg bg-linkedin-blue px-4 py-2 text-sm font-medium text-white hover:bg-linkedin-blue-dark transition-colors">
            Save Changes
          </button>
        }
      />

      <div className="grid gap-6 lg:grid-cols-2">
        {/* Widget Settings */}
        <div className="flex flex-col gap-6">
          <Card padding="none">
            <CardHeader>Widget Appearance</CardHeader>
            <CardBody className="flex flex-col gap-4">
              <div className="flex flex-col gap-1">
                <label className="text-sm font-medium text-linkedin-gray-90">Widget Color</label>
                <div className="flex items-center gap-3">
                  <input
                    type="color"
                    value={widgetColor}
                    onChange={(e) => setWidgetColor(e.target.value)}
                    className="h-10 w-10 cursor-pointer rounded-lg border border-linkedin-gray-30"
                  />
                  <input
                    type="text"
                    value={widgetColor}
                    onChange={(e) => setWidgetColor(e.target.value)}
                    className="w-32 rounded-lg border border-linkedin-gray-30 bg-white px-3 py-2 text-sm text-linkedin-gray-90 focus:border-linkedin-blue focus:outline-none focus:ring-1 focus:ring-linkedin-blue"
                  />
                </div>
              </div>

              <div className="flex flex-col gap-1">
                <label className="text-sm font-medium text-linkedin-gray-90">Widget Position</label>
                <select
                  value={position}
                  onChange={(e) => setPosition(e.target.value)}
                  className="w-full rounded-lg border border-linkedin-gray-30 bg-white px-3 py-2 text-sm text-linkedin-gray-90 focus:border-linkedin-blue focus:outline-none focus:ring-1 focus:ring-linkedin-blue"
                >
                  <option value="bottom-right">Bottom Right</option>
                  <option value="bottom-left">Bottom Left</option>
                </select>
              </div>
            </CardBody>
          </Card>

          <Card padding="none">
            <CardHeader>Business Hours</CardHeader>
            <CardBody className="flex flex-col gap-4">
              <div className="flex flex-wrap gap-2">
                {daysOfWeek.map((day) => (
                  <button
                    key={day}
                    onClick={() => toggleDay(day)}
                    className={cn(
                      "rounded-lg px-3 py-1.5 text-xs font-medium transition-colors",
                      checkedDays.has(day)
                        ? "bg-linkedin-blue text-white"
                        : "bg-linkedin-gray-10 text-linkedin-gray-50 hover:bg-linkedin-gray-20"
                    )}
                  >
                    {day}
                  </button>
                ))}
              </div>
              <div className="flex items-center gap-3">
                <div className="flex flex-col gap-1">
                  <label className="text-xs text-linkedin-gray-50">Start Time</label>
                  <input
                    type="time"
                    value={startTime}
                    onChange={(e) => setStartTime(e.target.value)}
                    className="rounded-lg border border-linkedin-gray-30 bg-white px-3 py-2 text-sm text-linkedin-gray-90 focus:border-linkedin-blue focus:outline-none focus:ring-1 focus:ring-linkedin-blue"
                  />
                </div>
                <span className="mt-5 text-linkedin-gray-50">to</span>
                <div className="flex flex-col gap-1">
                  <label className="text-xs text-linkedin-gray-50">End Time</label>
                  <input
                    type="time"
                    value={endTime}
                    onChange={(e) => setEndTime(e.target.value)}
                    className="rounded-lg border border-linkedin-gray-30 bg-white px-3 py-2 text-sm text-linkedin-gray-90 focus:border-linkedin-blue focus:outline-none focus:ring-1 focus:ring-linkedin-blue"
                  />
                </div>
              </div>
            </CardBody>
          </Card>

          <Card padding="none">
            <CardHeader>Auto-Greeting</CardHeader>
            <CardBody>
              <textarea
                value={greeting}
                onChange={(e) => setGreeting(e.target.value)}
                rows={3}
                className="w-full rounded-lg border border-linkedin-gray-30 bg-white px-3 py-2 text-sm text-linkedin-gray-90 focus:border-linkedin-blue focus:outline-none focus:ring-1 focus:ring-linkedin-blue resize-none"
              />
            </CardBody>
          </Card>

          <Card padding="none">
            <CardHeader>Embed Code</CardHeader>
            <CardBody>
              <div className="relative">
                <pre className="overflow-x-auto rounded-lg bg-linkedin-gray-90 p-4 text-xs text-green-400 font-mono">
                  {embedCode}
                </pre>
                <button
                  onClick={handleCopy}
                  className="absolute right-2 top-2 inline-flex items-center gap-1 rounded-md bg-linkedin-gray-70 px-2 py-1 text-xs font-medium text-white hover:bg-linkedin-gray-50 transition-colors"
                >
                  {copied ? <Check className="h-3 w-3" /> : <Copy className="h-3 w-3" />}
                  {copied ? "Copied!" : "Copy"}
                </button>
              </div>
            </CardBody>
          </Card>
        </div>

        {/* Preview */}
        <div>
          <Card padding="none">
            <CardHeader>Widget Preview</CardHeader>
            <CardBody>
              <div className="relative rounded-lg border border-linkedin-gray-20 bg-linkedin-gray-10 p-6" style={{ minHeight: 400 }}>
                <p className="text-center text-xs text-linkedin-gray-50 mt-4">Website preview area</p>
                <div className={cn("absolute bottom-4", position === "bottom-right" ? "right-4" : "left-4")}>
                  <div className="mb-3 w-72 rounded-lg bg-white shadow-lg border border-linkedin-gray-20 overflow-hidden">
                    <div className="px-4 py-3 text-white text-sm font-medium" style={{ backgroundColor: widgetColor }}>
                      Support Chat
                    </div>
                    <div className="p-4">
                      <div className="rounded-lg bg-linkedin-gray-10 p-3 text-xs text-linkedin-gray-70">
                        {greeting}
                      </div>
                    </div>
                    <div className="border-t border-linkedin-gray-20 px-4 py-2">
                      <input
                        type="text"
                        placeholder="Type a message..."
                        disabled
                        className="w-full bg-transparent text-xs text-linkedin-gray-50"
                      />
                    </div>
                  </div>
                  <div
                    className="flex h-12 w-12 items-center justify-center rounded-full shadow-lg cursor-pointer ml-auto"
                    style={{ backgroundColor: widgetColor }}
                  >
                    <MessageCircle className="h-6 w-6 text-white" />
                  </div>
                </div>
              </div>
            </CardBody>
          </Card>
        </div>
      </div>
    </div>
  );
}
