"use client";

import React, { useState } from "react";
import { Mail, Send, CheckCircle, Pencil } from "lucide-react";
import { cn } from "@/lib/utils/cn";
import { Card, CardBody, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { PageHeader } from "@/components/layout/page-header";

/* ------------------------------------------------------------------ */
/* Mock Data                                                           */
/* ------------------------------------------------------------------ */

const templates = [
  { name: "Welcome Email", description: "Sent when a new customer creates an account", status: "Active" },
  { name: "Auto-Reply", description: "Automatic acknowledgment for incoming emails", status: "Active" },
  { name: "Resolution Confirmation", description: "Sent when a ticket is marked as resolved", status: "Active" },
];

/* ------------------------------------------------------------------ */
/* Page                                                                */
/* ------------------------------------------------------------------ */

export default function EmailConfigPage() {
  const [smtpHost, setSmtpHost] = useState("smtp.example.com");
  const [smtpPort, setSmtpPort] = useState("587");
  const [smtpUser, setSmtpUser] = useState("support@example.com");
  const [smtpPass] = useState("••••••••••••");
  const [encryption, setEncryption] = useState("tls");
  const [imapHost, setImapHost] = useState("imap.example.com");
  const [imapPort, setImapPort] = useState("993");
  const [imapUser, setImapUser] = useState("support@example.com");
  const [imapPass] = useState("••••••••••••");
  const [autoReply, setAutoReply] = useState(true);
  const [autoReplyTemplate, setAutoReplyTemplate] = useState("auto-reply");

  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="Email Configuration"
        subtitle="Configure SMTP and IMAP settings for email channel"
        actions={
          <button className="inline-flex items-center gap-2 rounded-lg bg-linkedin-blue px-4 py-2 text-sm font-medium text-white hover:bg-linkedin-blue-dark transition-colors">
            Save Changes
          </button>
        }
      />

      <div className="grid gap-6 lg:grid-cols-2">
        {/* SMTP Settings */}
        <Card padding="none">
          <CardHeader>SMTP Settings (Outgoing)</CardHeader>
          <CardBody className="flex flex-col gap-4">
            <div className="flex flex-col gap-1">
              <label className="text-sm font-medium text-linkedin-gray-90">Host</label>
              <input type="text" value={smtpHost} onChange={(e) => setSmtpHost(e.target.value)} className="w-full rounded-lg border border-linkedin-gray-30 bg-white px-3 py-2 text-sm text-linkedin-gray-90 focus:border-linkedin-blue focus:outline-none focus:ring-1 focus:ring-linkedin-blue" />
            </div>
            <div className="flex flex-col gap-1">
              <label className="text-sm font-medium text-linkedin-gray-90">Port</label>
              <input type="text" value={smtpPort} onChange={(e) => setSmtpPort(e.target.value)} className="w-full rounded-lg border border-linkedin-gray-30 bg-white px-3 py-2 text-sm text-linkedin-gray-90 focus:border-linkedin-blue focus:outline-none focus:ring-1 focus:ring-linkedin-blue" />
            </div>
            <div className="flex flex-col gap-1">
              <label className="text-sm font-medium text-linkedin-gray-90">Username</label>
              <input type="text" value={smtpUser} onChange={(e) => setSmtpUser(e.target.value)} className="w-full rounded-lg border border-linkedin-gray-30 bg-white px-3 py-2 text-sm text-linkedin-gray-90 focus:border-linkedin-blue focus:outline-none focus:ring-1 focus:ring-linkedin-blue" />
            </div>
            <div className="flex flex-col gap-1">
              <label className="text-sm font-medium text-linkedin-gray-90">Password</label>
              <input type="password" value={smtpPass} readOnly className="w-full rounded-lg border border-linkedin-gray-30 bg-linkedin-gray-10 px-3 py-2 text-sm text-linkedin-gray-90" />
            </div>
            <div className="flex flex-col gap-1">
              <label className="text-sm font-medium text-linkedin-gray-90">Encryption</label>
              <select value={encryption} onChange={(e) => setEncryption(e.target.value)} className="w-full rounded-lg border border-linkedin-gray-30 bg-white px-3 py-2 text-sm text-linkedin-gray-90 focus:border-linkedin-blue focus:outline-none focus:ring-1 focus:ring-linkedin-blue">
                <option value="tls">TLS</option>
                <option value="ssl">SSL</option>
              </select>
            </div>
            <button className="self-start inline-flex items-center gap-2 rounded-lg border border-linkedin-gray-30 bg-white px-4 py-2 text-sm font-medium text-linkedin-gray-70 hover:bg-linkedin-gray-10 transition-colors">
              <Send className="h-4 w-4" />
              Test Connection
            </button>
          </CardBody>
        </Card>

        {/* IMAP Settings */}
        <Card padding="none">
          <CardHeader>IMAP Settings (Incoming)</CardHeader>
          <CardBody className="flex flex-col gap-4">
            <div className="flex flex-col gap-1">
              <label className="text-sm font-medium text-linkedin-gray-90">Host</label>
              <input type="text" value={imapHost} onChange={(e) => setImapHost(e.target.value)} className="w-full rounded-lg border border-linkedin-gray-30 bg-white px-3 py-2 text-sm text-linkedin-gray-90 focus:border-linkedin-blue focus:outline-none focus:ring-1 focus:ring-linkedin-blue" />
            </div>
            <div className="flex flex-col gap-1">
              <label className="text-sm font-medium text-linkedin-gray-90">Port</label>
              <input type="text" value={imapPort} onChange={(e) => setImapPort(e.target.value)} className="w-full rounded-lg border border-linkedin-gray-30 bg-white px-3 py-2 text-sm text-linkedin-gray-90 focus:border-linkedin-blue focus:outline-none focus:ring-1 focus:ring-linkedin-blue" />
            </div>
            <div className="flex flex-col gap-1">
              <label className="text-sm font-medium text-linkedin-gray-90">Username</label>
              <input type="text" value={imapUser} onChange={(e) => setImapUser(e.target.value)} className="w-full rounded-lg border border-linkedin-gray-30 bg-white px-3 py-2 text-sm text-linkedin-gray-90 focus:border-linkedin-blue focus:outline-none focus:ring-1 focus:ring-linkedin-blue" />
            </div>
            <div className="flex flex-col gap-1">
              <label className="text-sm font-medium text-linkedin-gray-90">Password</label>
              <input type="password" value={imapPass} readOnly className="w-full rounded-lg border border-linkedin-gray-30 bg-linkedin-gray-10 px-3 py-2 text-sm text-linkedin-gray-90" />
            </div>
            <button className="self-start inline-flex items-center gap-2 rounded-lg border border-linkedin-gray-30 bg-white px-4 py-2 text-sm font-medium text-linkedin-gray-70 hover:bg-linkedin-gray-10 transition-colors">
              <Send className="h-4 w-4" />
              Test Connection
            </button>
          </CardBody>
        </Card>
      </div>

      {/* Email Templates */}
      <Card padding="none">
        <CardHeader>Email Templates</CardHeader>
        <CardBody className="p-0">
          <div className="divide-y divide-linkedin-gray-20">
            {templates.map((tpl) => (
              <div key={tpl.name} className="flex items-center justify-between px-4 py-3 hover:bg-linkedin-gray-10 transition-colors">
                <div className="flex items-center gap-3">
                  <Mail className="h-4 w-4 text-linkedin-blue" />
                  <div>
                    <p className="text-sm font-medium text-linkedin-gray-90">{tpl.name}</p>
                    <p className="text-xs text-linkedin-gray-50">{tpl.description}</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <Badge variant="success">{tpl.status}</Badge>
                  <button className="rounded-md p-1.5 text-linkedin-gray-50 hover:bg-linkedin-gray-20 transition-colors">
                    <Pencil className="h-3.5 w-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </CardBody>
      </Card>

      {/* Auto-Reply */}
      <Card padding="none">
        <CardHeader>Auto-Reply Settings</CardHeader>
        <CardBody className="flex flex-col gap-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-linkedin-gray-90">Enable Auto-Reply</p>
              <p className="text-xs text-linkedin-gray-50">Automatically respond to incoming emails</p>
            </div>
            <button
              onClick={() => setAutoReply(!autoReply)}
              className={cn(
                "relative inline-flex h-6 w-11 items-center rounded-full transition-colors",
                autoReply ? "bg-linkedin-green" : "bg-linkedin-gray-30"
              )}
            >
              <span className={cn(
                "inline-block h-4 w-4 rounded-full bg-white transition-transform",
                autoReply ? "translate-x-6" : "translate-x-1"
              )} />
            </button>
          </div>
          {autoReply && (
            <div className="flex flex-col gap-1">
              <label className="text-sm font-medium text-linkedin-gray-90">Auto-Reply Template</label>
              <select value={autoReplyTemplate} onChange={(e) => setAutoReplyTemplate(e.target.value)} className="w-full rounded-lg border border-linkedin-gray-30 bg-white px-3 py-2 text-sm text-linkedin-gray-90 focus:border-linkedin-blue focus:outline-none focus:ring-1 focus:ring-linkedin-blue">
                <option value="auto-reply">Auto-Reply</option>
                <option value="welcome">Welcome Email</option>
                <option value="resolution">Resolution Confirmation</option>
              </select>
            </div>
          )}
        </CardBody>
      </Card>
    </div>
  );
}
