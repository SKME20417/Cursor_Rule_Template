"use client";

import React from "react";
import {
  MessageCircle,
  Mail,
  MessageSquare,
  Phone,
  Hash,
  Share2,
  Settings,
} from "lucide-react";
import { cn } from "@/lib/utils/cn";
import { Card, CardBody } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { PageHeader } from "@/components/layout/page-header";

/* ------------------------------------------------------------------ */
/* Mock Data                                                           */
/* ------------------------------------------------------------------ */

const channels = [
  { name: "Live Chat", icon: MessageCircle, active: true, volume: "1.2K/day", href: "/channels/live-chat" },
  { name: "Email", icon: Mail, active: true, volume: "450/day", href: "/channels/email" },
  { name: "WhatsApp", icon: MessageSquare, active: true, volume: "320/day", href: "/channels/whatsapp" },
  { name: "SMS", icon: Phone, active: true, volume: "85/day", href: "/channels/sms" },
  { name: "Slack", icon: Hash, active: true, volume: "120/day", href: "/channels/slack" },
  { name: "Social Media", icon: Share2, active: false, volume: "-", href: "/channels/social" },
];

/* ------------------------------------------------------------------ */
/* Page                                                                */
/* ------------------------------------------------------------------ */

export default function ChannelsOverviewPage() {
  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="Channels"
        subtitle="Manage communication channels and their configurations"
      />

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {channels.map((channel) => (
          <Card key={channel.name} hover>
            <CardBody>
              <div className="flex flex-col gap-4">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <div className={cn(
                      "flex h-10 w-10 items-center justify-center rounded-lg",
                      channel.active ? "bg-linkedin-blue-bg" : "bg-linkedin-gray-10"
                    )}>
                      <channel.icon className={cn(
                        "h-5 w-5",
                        channel.active ? "text-linkedin-blue" : "text-linkedin-gray-50"
                      )} />
                    </div>
                    <div>
                      <h3 className="text-sm font-semibold text-linkedin-gray-90">{channel.name}</h3>
                      <p className="text-xs text-linkedin-gray-50">Volume: {channel.volume}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className={cn(
                      "relative inline-flex h-5 w-9 items-center rounded-full transition-colors cursor-pointer",
                      channel.active ? "bg-linkedin-green" : "bg-linkedin-gray-30"
                    )}>
                      <div className={cn(
                        "inline-block h-3.5 w-3.5 rounded-full bg-white transition-transform",
                        channel.active ? "translate-x-4" : "translate-x-0.5"
                      )} />
                    </div>
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <Badge variant={channel.active ? "success" : "default"}>
                    {channel.active ? "Active" : "Inactive"}
                  </Badge>
                  <a
                    href={channel.href}
                    className="inline-flex items-center gap-1 text-xs font-medium text-linkedin-blue hover:underline"
                  >
                    <Settings className="h-3 w-3" />
                    Configure
                  </a>
                </div>
              </div>
            </CardBody>
          </Card>
        ))}
      </div>
    </div>
  );
}
