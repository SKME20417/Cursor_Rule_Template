"use client";

import React from "react";
import { cn } from "@/lib/utils/cn";
import {
  MessageSquare,
  Bot,
  Headphones,
  Brain,
  ArrowRight,
} from "lucide-react";
import { Card, CardBody } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { PageHeader } from "@/components/layout/page-header";

/* ------------------------------------------------------------------ */
/* Mock Data                                                           */
/* ------------------------------------------------------------------ */

const aiSystems = [
  {
    name: "Chatbot",
    description: "Customer-facing AI chatbot for self-service",
    icon: MessageSquare,
    status: "active" as const,
    metric: "Accuracy: 94.2%",
    href: "/admin/ai-config/chatbot",
    color: "bg-linkedin-blue-bg text-linkedin-blue",
  },
  {
    name: "Agent Copilot",
    description: "Agent assist with suggestions and drafting",
    icon: Bot,
    status: "active" as const,
    metric: "Acceptance Rate: 78%",
    href: "/admin/ai-config/copilot",
    color: "bg-green-50 text-linkedin-green",
  },
  {
    name: "Voice AI",
    description: "Speech-to-text and voice bot capabilities",
    icon: Headphones,
    status: "beta" as const,
    metric: "Call Handling: 62%",
    href: "/admin/ai-config/voice",
    color: "bg-purple-50 text-purple-600",
  },
  {
    name: "NLP Pipeline",
    description: "Intent classification, sentiment analysis, entity extraction",
    icon: Brain,
    status: "active" as const,
    metric: "Model v3.2 / v2.1 / v1.4",
    href: "/admin/ai-config/nlp",
    color: "bg-orange-50 text-linkedin-orange",
  },
] as const;

const statusVariant: Record<string, "success" | "warning" | "default"> = {
  active: "success",
  beta: "warning",
  inactive: "default",
};

/* ------------------------------------------------------------------ */
/* Page                                                                */
/* ------------------------------------------------------------------ */

export default function AIConfigPage() {
  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="AI Configuration"
        subtitle="Manage and configure AI systems"
      />

      <div className="grid gap-4 sm:grid-cols-2">
        {aiSystems.map((sys) => (
          <a key={sys.name} href={sys.href}>
            <Card hover>
              <CardBody>
                <div className="flex items-start gap-4">
                  <div className={cn("flex h-12 w-12 items-center justify-center rounded-xl", sys.color)}>
                    <sys.icon className="h-6 w-6" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <h3 className="font-semibold text-linkedin-gray-90">{sys.name}</h3>
                      <div className="flex items-center gap-1.5">
                        <span className={cn(
                          "h-2 w-2 rounded-full",
                          sys.status === "active" ? "bg-linkedin-green" : sys.status === "beta" ? "bg-linkedin-orange" : "bg-linkedin-gray-50",
                        )} />
                        <Badge variant={statusVariant[sys.status]} size="sm">{sys.status}</Badge>
                      </div>
                    </div>
                    <p className="mt-1 text-sm text-linkedin-gray-50">{sys.description}</p>
                    <div className="mt-3 flex items-center justify-between">
                      <span className="text-sm text-linkedin-gray-70">{sys.metric}</span>
                      <span className="flex items-center gap-1 text-sm font-medium text-linkedin-blue">
                        Configure <ArrowRight className="h-3.5 w-3.5" />
                      </span>
                    </div>
                  </div>
                </div>
              </CardBody>
            </Card>
          </a>
        ))}
      </div>
    </div>
  );
}
