"use client";

import React, { useState } from "react";
import { cn } from "@/lib/utils/cn";
import {
  Save,
  Play,
  ToggleLeft,
  ToggleRight,
} from "lucide-react";
import { Card, CardBody, CardHeader } from "@/components/ui/card";
import { PageHeader } from "@/components/layout/page-header";

/* ------------------------------------------------------------------ */
/* Mock Data                                                           */
/* ------------------------------------------------------------------ */

const sttModels = ["Whisper", "Google STT", "AWS Transcribe"] as const;
const ttsVoices = ["Alloy", "Echo", "Nova"] as const;

/* ------------------------------------------------------------------ */
/* Page                                                                */
/* ------------------------------------------------------------------ */

export default function VoiceConfigPage() {
  const [sttModel, setSttModel] = useState("Whisper");
  const [ttsVoice, setTtsVoice] = useState("Alloy");
  const [voiceBotEnabled, setVoiceBotEnabled] = useState(true);
  const [greeting, setGreeting] = useState(
    "Hello! Thank you for calling Acme support. How can I help you today?",
  );
  const [confidenceThreshold, setConfidenceThreshold] = useState(0.6);
  const [maxTurns, setMaxTurns] = useState(8);

  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="Voice AI Configuration"
        subtitle="Configure speech-to-text and voice bot settings"
      />

      {/* STT Model */}
      <Card padding="none">
        <CardHeader>Speech-to-Text</CardHeader>
        <CardBody>
          <div>
            <label className="mb-1 block text-sm font-medium text-linkedin-gray-70">STT Model</label>
            <select
              value={sttModel}
              onChange={(e) => setSttModel(e.target.value)}
              className="w-full rounded-lg border border-linkedin-gray-20 px-3 py-2 text-sm text-linkedin-gray-90 focus:border-linkedin-blue focus:outline-none"
            >
              {sttModels.map((m) => (
                <option key={m} value={m}>{m}</option>
              ))}
            </select>
          </div>
        </CardBody>
      </Card>

      {/* TTS Voice */}
      <Card padding="none">
        <CardHeader>Text-to-Speech</CardHeader>
        <CardBody>
          <div className="flex flex-col gap-4">
            <div>
              <label className="mb-1 block text-sm font-medium text-linkedin-gray-70">TTS Voice</label>
              <select
                value={ttsVoice}
                onChange={(e) => setTtsVoice(e.target.value)}
                className="w-full rounded-lg border border-linkedin-gray-20 px-3 py-2 text-sm text-linkedin-gray-90 focus:border-linkedin-blue focus:outline-none"
              >
                {ttsVoices.map((v) => (
                  <option key={v} value={v}>{v}</option>
                ))}
              </select>
            </div>
            <button className="flex w-fit items-center gap-2 rounded-lg border border-linkedin-blue px-4 py-2 text-sm font-medium text-linkedin-blue transition-colors hover:bg-linkedin-blue-bg">
              <Play className="h-4 w-4" />
              Preview Voice
            </button>
          </div>
        </CardBody>
      </Card>

      {/* Voice Bot Settings */}
      <Card padding="none">
        <CardHeader>Voice Bot Settings</CardHeader>
        <CardBody>
          <div className="flex flex-col gap-5">
            <div className="flex items-center justify-between rounded-lg border border-linkedin-gray-20 p-4">
              <div>
                <p className="text-sm font-medium text-linkedin-gray-90">Voice Bot</p>
                <p className="text-xs text-linkedin-gray-50">Enable or disable the voice bot</p>
              </div>
              <button onClick={() => setVoiceBotEnabled(!voiceBotEnabled)}>
                {voiceBotEnabled ? (
                  <ToggleRight className="h-7 w-7 text-linkedin-green" />
                ) : (
                  <ToggleLeft className="h-7 w-7 text-linkedin-gray-50" />
                )}
              </button>
            </div>
            <div>
              <label className="mb-1 block text-sm font-medium text-linkedin-gray-70">Greeting Message</label>
              <textarea
                value={greeting}
                onChange={(e) => setGreeting(e.target.value)}
                rows={3}
                className="w-full rounded-lg border border-linkedin-gray-20 px-3 py-2 text-sm text-linkedin-gray-90 focus:border-linkedin-blue focus:outline-none focus:ring-1 focus:ring-linkedin-blue"
              />
            </div>
          </div>
        </CardBody>
      </Card>

      {/* Handoff Conditions */}
      <Card padding="none">
        <CardHeader>Handoff Conditions</CardHeader>
        <CardBody>
          <div className="flex flex-col gap-5">
            <div>
              <label className="mb-1 block text-sm font-medium text-linkedin-gray-70">
                Confidence Threshold: {confidenceThreshold}
              </label>
              <input
                type="range"
                min="0.3"
                max="0.9"
                step="0.05"
                value={confidenceThreshold}
                onChange={(e) => setConfidenceThreshold(parseFloat(e.target.value))}
                className="w-full accent-linkedin-blue"
              />
              <div className="flex justify-between text-xs text-linkedin-gray-50">
                <span>Low (0.3)</span>
                <span>High (0.9)</span>
              </div>
            </div>
            <div>
              <label className="mb-1 block text-sm font-medium text-linkedin-gray-70">Max Turns Before Handoff</label>
              <input
                type="number"
                value={maxTurns}
                onChange={(e) => setMaxTurns(parseInt(e.target.value))}
                min={1}
                max={20}
                className="w-full rounded-lg border border-linkedin-gray-20 px-3 py-2 text-sm text-linkedin-gray-90 focus:border-linkedin-blue focus:outline-none focus:ring-1 focus:ring-linkedin-blue"
              />
            </div>
          </div>
        </CardBody>
      </Card>

      {/* Save */}
      <div className="flex justify-end">
        <button className="flex items-center gap-2 rounded-lg bg-linkedin-blue px-6 py-2.5 text-sm font-medium text-white transition-colors hover:bg-linkedin-blue-dark">
          <Save className="h-4 w-4" />
          Save Configuration
        </button>
      </div>
    </div>
  );
}
