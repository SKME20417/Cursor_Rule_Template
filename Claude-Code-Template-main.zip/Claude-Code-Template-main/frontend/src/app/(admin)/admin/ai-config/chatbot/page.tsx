"use client";

import React, { useState } from "react";
import { cn } from "@/lib/utils/cn";
import {
  Save,
  MessageSquare,
  Send,
} from "lucide-react";
import { Card, CardBody, CardHeader } from "@/components/ui/card";
import { PageHeader } from "@/components/layout/page-header";

/* ------------------------------------------------------------------ */
/* Mock Data                                                           */
/* ------------------------------------------------------------------ */

const modelOptions = ["GPT-4", "Claude 3.5", "Llama 3"] as const;

const defaultSystemPrompt = `You are a helpful customer support assistant for Acme Inc. You help customers with billing questions, account management, and technical issues. Be concise, professional, and empathetic. Always verify the customer's identity before making account changes. If you are unsure about something, offer to connect the customer with a human agent.`;

/* ------------------------------------------------------------------ */
/* Page                                                                */
/* ------------------------------------------------------------------ */

export default function ChatbotConfigPage() {
  const [model, setModel] = useState("GPT-4");
  const [temperature, setTemperature] = useState(0.3);
  const [maxTokens, setMaxTokens] = useState(1000);
  const [systemPrompt, setSystemPrompt] = useState(defaultSystemPrompt);
  const [maxResponseLength, setMaxResponseLength] = useState(500);
  const [blockedTopics, setBlockedTopics] = useState("competitor pricing\ninternal processes\nemployee information");
  const [fallbackMessage, setFallbackMessage] = useState("I'm sorry, I wasn't able to help with that. Let me connect you with a human agent who can assist you further.");
  const [testInput, setTestInput] = useState("");

  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="Chatbot Configuration"
        subtitle="Configure the customer-facing AI chatbot"
      />

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="flex flex-col gap-6 lg:col-span-2">
          {/* Model Settings */}
          <Card padding="none">
            <CardHeader>Model Settings</CardHeader>
            <CardBody>
              <div className="flex flex-col gap-5">
                <div>
                  <label className="mb-1 block text-sm font-medium text-linkedin-gray-70">Model</label>
                  <select
                    value={model}
                    onChange={(e) => setModel(e.target.value)}
                    className="w-full rounded-lg border border-linkedin-gray-20 px-3 py-2 text-sm text-linkedin-gray-90 focus:border-linkedin-blue focus:outline-none"
                  >
                    {modelOptions.map((m) => (
                      <option key={m} value={m}>{m}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="mb-1 block text-sm font-medium text-linkedin-gray-70">
                    Temperature: {temperature}
                  </label>
                  <input
                    type="range"
                    min="0"
                    max="1"
                    step="0.1"
                    value={temperature}
                    onChange={(e) => setTemperature(parseFloat(e.target.value))}
                    className="w-full accent-linkedin-blue"
                  />
                  <div className="flex justify-between text-xs text-linkedin-gray-50">
                    <span>Precise (0)</span>
                    <span>Creative (1)</span>
                  </div>
                </div>
                <div>
                  <label className="mb-1 block text-sm font-medium text-linkedin-gray-70">
                    Max Tokens: {maxTokens}
                  </label>
                  <input
                    type="range"
                    min="100"
                    max="4000"
                    step="100"
                    value={maxTokens}
                    onChange={(e) => setMaxTokens(parseInt(e.target.value))}
                    className="w-full accent-linkedin-blue"
                  />
                  <div className="flex justify-between text-xs text-linkedin-gray-50">
                    <span>100</span>
                    <span>4000</span>
                  </div>
                </div>
              </div>
            </CardBody>
          </Card>

          {/* System Prompt */}
          <Card padding="none">
            <CardHeader>System Prompt</CardHeader>
            <CardBody>
              <textarea
                value={systemPrompt}
                onChange={(e) => setSystemPrompt(e.target.value)}
                rows={8}
                className="w-full rounded-lg border border-linkedin-gray-20 px-3 py-2 text-sm text-linkedin-gray-90 placeholder:text-linkedin-gray-50 focus:border-linkedin-blue focus:outline-none focus:ring-1 focus:ring-linkedin-blue"
              />
            </CardBody>
          </Card>

          {/* Guardrails */}
          <Card padding="none">
            <CardHeader>Guardrails</CardHeader>
            <CardBody>
              <div className="flex flex-col gap-4">
                <div>
                  <label className="mb-1 block text-sm font-medium text-linkedin-gray-70">Max Response Length (characters)</label>
                  <input
                    type="number"
                    value={maxResponseLength}
                    onChange={(e) => setMaxResponseLength(parseInt(e.target.value))}
                    className="w-full rounded-lg border border-linkedin-gray-20 px-3 py-2 text-sm text-linkedin-gray-90 focus:border-linkedin-blue focus:outline-none focus:ring-1 focus:ring-linkedin-blue"
                  />
                </div>
                <div>
                  <label className="mb-1 block text-sm font-medium text-linkedin-gray-70">Blocked Topics (one per line)</label>
                  <textarea
                    value={blockedTopics}
                    onChange={(e) => setBlockedTopics(e.target.value)}
                    rows={3}
                    className="w-full rounded-lg border border-linkedin-gray-20 px-3 py-2 text-sm text-linkedin-gray-90 focus:border-linkedin-blue focus:outline-none focus:ring-1 focus:ring-linkedin-blue"
                  />
                </div>
                <div>
                  <label className="mb-1 block text-sm font-medium text-linkedin-gray-70">Fallback Message</label>
                  <textarea
                    value={fallbackMessage}
                    onChange={(e) => setFallbackMessage(e.target.value)}
                    rows={2}
                    className="w-full rounded-lg border border-linkedin-gray-20 px-3 py-2 text-sm text-linkedin-gray-90 focus:border-linkedin-blue focus:outline-none focus:ring-1 focus:ring-linkedin-blue"
                  />
                </div>
              </div>
            </CardBody>
          </Card>

          {/* Save */}
          <div className="flex justify-end">
            <button className="flex items-center gap-2 rounded-lg bg-linkedin-blue px-6 py-2.5 text-sm font-medium text-white transition-colors hover:bg-linkedin-blue-dark">
              <Save className="h-4 w-4" />
              Save Configuration
            </button>
          </div>
        </div>

        {/* Test Chat */}
        <Card padding="none" className="h-fit sticky top-4">
          <CardHeader>
            <div className="flex items-center gap-2">
              <MessageSquare className="h-4 w-4 text-linkedin-blue" />
              Test Chat
            </div>
          </CardHeader>
          <CardBody>
            <div className="flex min-h-[300px] flex-col gap-3">
              <div className="max-w-[80%] rounded-lg bg-linkedin-gray-10 p-3 text-sm text-linkedin-gray-70">
                Hi! How can I help you today?
              </div>
              <div className="ml-auto max-w-[80%] rounded-lg bg-linkedin-blue p-3 text-sm text-white">
                I need to update my billing info
              </div>
              <div className="max-w-[80%] rounded-lg bg-linkedin-gray-10 p-3 text-sm text-linkedin-gray-70">
                I can help you with that! For security, please verify your email address first, then navigate to Settings &gt; Billing to update your payment method.
              </div>
            </div>
            <div className="mt-4 flex gap-2">
              <input
                type="text"
                value={testInput}
                onChange={(e) => setTestInput(e.target.value)}
                placeholder="Type a test message..."
                className="flex-1 rounded-lg border border-linkedin-gray-20 px-3 py-2 text-sm focus:border-linkedin-blue focus:outline-none"
              />
              <button className="flex items-center justify-center rounded-lg bg-linkedin-blue px-3 py-2 text-white hover:bg-linkedin-blue-dark">
                <Send className="h-4 w-4" />
              </button>
            </div>
          </CardBody>
        </Card>
      </div>
    </div>
  );
}
