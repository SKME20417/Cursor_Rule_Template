"use client";

import React, { useState } from "react";
import { cn } from "@/lib/utils/cn";
import {
  RefreshCw,
  Send,
  AlertTriangle,
} from "lucide-react";
import { Card, CardBody, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { PageHeader } from "@/components/layout/page-header";

/* ------------------------------------------------------------------ */
/* Mock Data                                                           */
/* ------------------------------------------------------------------ */

interface Correction {
  id: string;
  originalOutput: string;
  agentCorrection: string;
  category: string;
  date: string;
  selected: boolean;
}

const initialCorrections: Correction[] = [
  {
    id: "1",
    originalOutput: "Your refund has been processed.",
    agentCorrection: "Your refund of $49.99 has been processed and will appear in 3-5 business days.",
    category: "Billing",
    date: "2026-03-09",
    selected: false,
  },
  {
    id: "2",
    originalOutput: "Please reset your password.",
    agentCorrection: "You can reset your password at account.acme.com/reset. You'll receive a confirmation email within 2 minutes.",
    category: "Account",
    date: "2026-03-08",
    selected: false,
  },
  {
    id: "3",
    originalOutput: "Contact billing for that.",
    agentCorrection: "I can help you update your billing information directly. What would you like to change?",
    category: "Billing",
    date: "2026-03-08",
    selected: false,
  },
  {
    id: "4",
    originalOutput: "That feature is not available.",
    agentCorrection: "That feature is currently on our roadmap and expected to launch in Q2. I can add you to the waitlist if you'd like.",
    category: "Product",
    date: "2026-03-07",
    selected: false,
  },
  {
    id: "5",
    originalOutput: "I don't understand your question.",
    agentCorrection: "Could you provide more details about the issue you're experiencing? For example, what steps led to the error?",
    category: "General",
    date: "2026-03-07",
    selected: false,
  },
];

interface TrainingRun {
  date: string;
  modelVersion: string;
  accuracyBefore: number;
  accuracyAfter: number;
  status: "completed" | "in_progress" | "failed";
}

const trainingHistory: TrainingRun[] = [
  { date: "2026-03-01", modelVersion: "v3.2", accuracyBefore: 93.8, accuracyAfter: 96.1, status: "completed" },
  { date: "2026-02-15", modelVersion: "v3.1", accuracyBefore: 92.1, accuracyAfter: 95.3, status: "completed" },
  { date: "2026-01-20", modelVersion: "v3.0", accuracyBefore: 91.0, accuracyAfter: 94.7, status: "completed" },
];

const statusBadge: Record<string, "success" | "warning" | "danger"> = {
  completed: "success",
  in_progress: "warning",
  failed: "danger",
};

/* ------------------------------------------------------------------ */
/* Page                                                                */
/* ------------------------------------------------------------------ */

export default function TrainingPage() {
  const [corrections, setCorrections] = useState(initialCorrections);
  const [showConfirm, setShowConfirm] = useState(false);

  const selectedCount = corrections.filter((c) => c.selected).length;
  const pendingCount = corrections.length;

  function toggleSelection(id: string) {
    setCorrections((prev) =>
      prev.map((c) => (c.id === id ? { ...c, selected: !c.selected } : c)),
    );
  }

  function toggleAll() {
    const allSelected = corrections.every((c) => c.selected);
    setCorrections((prev) => prev.map((c) => ({ ...c, selected: !allSelected })));
  }

  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="Training"
        subtitle="Review corrections and retrain models"
        actions={
          <div className="flex items-center gap-2">
            <Badge variant="warning" size="md">
              {pendingCount} Pending Corrections
            </Badge>
            <button
              onClick={() => setShowConfirm(true)}
              className="flex items-center gap-2 rounded-lg bg-linkedin-blue px-4 py-2 text-sm font-medium text-white transition-colors hover:bg-linkedin-blue-dark"
            >
              <RefreshCw className="h-4 w-4" />
              Retrain Model
            </button>
          </div>
        }
      />

      {/* Confirmation Modal */}
      {showConfirm && (
        <Card>
          <CardBody>
            <div className="flex items-start gap-3">
              <AlertTriangle className="mt-0.5 h-5 w-5 shrink-0 text-linkedin-orange" />
              <div className="flex-1">
                <p className="font-medium text-linkedin-gray-90">Confirm Model Retraining</p>
                <p className="mt-1 text-sm text-linkedin-gray-50">
                  This will start a new training run using approved corrections. The process may take 30-60 minutes.
                </p>
                <div className="mt-3 flex gap-2">
                  <button
                    onClick={() => setShowConfirm(false)}
                    className="rounded-lg bg-linkedin-blue px-4 py-2 text-sm font-medium text-white transition-colors hover:bg-linkedin-blue-dark"
                  >
                    Confirm Retrain
                  </button>
                  <button
                    onClick={() => setShowConfirm(false)}
                    className="rounded-lg border border-linkedin-gray-20 px-4 py-2 text-sm font-medium text-linkedin-gray-70 transition-colors hover:bg-linkedin-gray-10"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            </div>
          </CardBody>
        </Card>
      )}

      {/* Recent Corrections */}
      <Card padding="none">
        <CardHeader>
          <div className="flex items-center justify-between">
            <span>Recent Corrections</span>
            <div className="flex items-center gap-2">
              {selectedCount > 0 && (
                <button className="flex items-center gap-1 rounded-lg bg-linkedin-blue px-3 py-1.5 text-xs font-medium text-white transition-colors hover:bg-linkedin-blue-dark">
                  <Send className="h-3 w-3" />
                  Submit Batch ({selectedCount})
                </button>
              )}
            </div>
          </div>
        </CardHeader>
        <CardBody className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-linkedin-gray-20 text-left text-xs text-linkedin-gray-50">
                  <th className="px-4 py-3 font-medium">
                    <input
                      type="checkbox"
                      checked={corrections.every((c) => c.selected)}
                      onChange={toggleAll}
                      className="accent-linkedin-blue"
                    />
                  </th>
                  <th className="px-4 py-3 font-medium">Original AI Output</th>
                  <th className="px-4 py-3 font-medium">Agent Correction</th>
                  <th className="px-4 py-3 font-medium">Category</th>
                  <th className="px-4 py-3 font-medium">Date</th>
                </tr>
              </thead>
              <tbody>
                {corrections.map((correction) => (
                  <tr
                    key={correction.id}
                    className={cn(
                      "border-b border-linkedin-gray-20 last:border-0 transition-colors",
                      correction.selected ? "bg-linkedin-blue-bg" : "hover:bg-linkedin-gray-10",
                    )}
                  >
                    <td className="px-4 py-3">
                      <input
                        type="checkbox"
                        checked={correction.selected}
                        onChange={() => toggleSelection(correction.id)}
                        className="accent-linkedin-blue"
                      />
                    </td>
                    <td className="px-4 py-3 max-w-[250px]">
                      <p className="text-linkedin-gray-70">{correction.originalOutput}</p>
                    </td>
                    <td className="px-4 py-3 max-w-[250px]">
                      <p className="text-linkedin-gray-90">{correction.agentCorrection}</p>
                    </td>
                    <td className="px-4 py-3">
                      <Badge variant="default" size="sm">{correction.category}</Badge>
                    </td>
                    <td className="px-4 py-3 text-linkedin-gray-50">{correction.date}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardBody>
      </Card>

      {/* Training History */}
      <Card padding="none">
        <CardHeader>Training History</CardHeader>
        <CardBody className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-linkedin-gray-20 text-left text-xs text-linkedin-gray-50">
                  <th className="px-4 py-3 font-medium">Date</th>
                  <th className="px-4 py-3 font-medium">Model Version</th>
                  <th className="px-4 py-3 font-medium">Accuracy Before</th>
                  <th className="px-4 py-3 font-medium">Accuracy After</th>
                  <th className="px-4 py-3 font-medium">Status</th>
                </tr>
              </thead>
              <tbody>
                {trainingHistory.map((run) => (
                  <tr
                    key={run.date}
                    className="border-b border-linkedin-gray-20 last:border-0 transition-colors hover:bg-linkedin-gray-10"
                  >
                    <td className="px-4 py-3 text-linkedin-gray-90">{run.date}</td>
                    <td className="px-4 py-3">
                      <code className="rounded bg-linkedin-gray-10 px-2 py-0.5 text-xs">{run.modelVersion}</code>
                    </td>
                    <td className="px-4 py-3 tabular-nums text-linkedin-gray-70">{run.accuracyBefore}%</td>
                    <td className="px-4 py-3 tabular-nums font-medium text-linkedin-green">{run.accuracyAfter}%</td>
                    <td className="px-4 py-3">
                      <Badge variant={statusBadge[run.status]} size="sm">{run.status}</Badge>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardBody>
      </Card>
    </div>
  );
}
