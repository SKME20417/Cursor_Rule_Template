"use client";

import React, { useState } from "react";
import { cn } from "@/lib/utils/cn";
import {
  Save,
  ToggleLeft,
  ToggleRight,
} from "lucide-react";
import { Card, CardBody, CardHeader } from "@/components/ui/card";
import { PageHeader } from "@/components/layout/page-header";

/* ------------------------------------------------------------------ */
/* Mock Data                                                           */
/* ------------------------------------------------------------------ */

interface FeatureToggle {
  id: string;
  label: string;
  description: string;
  enabled: boolean;
}

const initialFeatures: FeatureToggle[] = [
  { id: "replies", label: "Suggested Replies", description: "Show AI-generated reply suggestions to agents", enabled: true },
  { id: "email", label: "Email Drafting", description: "Auto-draft email responses based on conversation context", enabled: true },
  { id: "summary", label: "Conversation Summary", description: "Generate summaries of ongoing conversations", enabled: true },
  { id: "kb", label: "KB Suggestions", description: "Recommend relevant knowledge base articles", enabled: true },
];

const tonePresets = [
  { value: "professional", label: "Professional", description: "Formal and business-appropriate" },
  { value: "friendly", label: "Friendly", description: "Warm and approachable" },
  { value: "empathetic", label: "Empathetic", description: "Understanding and compassionate" },
] as const;

/* ------------------------------------------------------------------ */
/* Page                                                                */
/* ------------------------------------------------------------------ */

export default function CopilotConfigPage() {
  const [suggestions, setSuggestions] = useState(3);
  const [confidenceThreshold, setConfidenceThreshold] = useState(0.7);
  const [features, setFeatures] = useState(initialFeatures);
  const [tone, setTone] = useState("professional");

  function toggleFeature(id: string) {
    setFeatures((prev) =>
      prev.map((f) => (f.id === id ? { ...f, enabled: !f.enabled } : f)),
    );
  }

  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="Copilot Configuration"
        subtitle="Configure the agent assist AI copilot"
      />

      {/* Suggestion Settings */}
      <Card padding="none">
        <CardHeader>Suggestion Settings</CardHeader>
        <CardBody>
          <div className="flex flex-col gap-5">
            <div>
              <label className="mb-1 block text-sm font-medium text-linkedin-gray-70">
                Number of Suggestions: {suggestions}
              </label>
              <input
                type="range"
                min="1"
                max="5"
                step="1"
                value={suggestions}
                onChange={(e) => setSuggestions(parseInt(e.target.value))}
                className="w-full accent-linkedin-blue"
              />
              <div className="flex justify-between text-xs text-linkedin-gray-50">
                <span>1</span>
                <span>5</span>
              </div>
            </div>
            <div>
              <label className="mb-1 block text-sm font-medium text-linkedin-gray-70">
                Confidence Threshold: {confidenceThreshold}
              </label>
              <input
                type="range"
                min="0.5"
                max="1.0"
                step="0.05"
                value={confidenceThreshold}
                onChange={(e) => setConfidenceThreshold(parseFloat(e.target.value))}
                className="w-full accent-linkedin-blue"
              />
              <div className="flex justify-between text-xs text-linkedin-gray-50">
                <span>Low (0.5) - more suggestions</span>
                <span>High (1.0) - fewer suggestions</span>
              </div>
            </div>
          </div>
        </CardBody>
      </Card>

      {/* Feature Toggles */}
      <Card padding="none">
        <CardHeader>Feature Toggles</CardHeader>
        <CardBody>
          <div className="flex flex-col gap-4">
            {features.map((feature) => (
              <div
                key={feature.id}
                className="flex items-center justify-between rounded-lg border border-linkedin-gray-20 p-4"
              >
                <div>
                  <p className="text-sm font-medium text-linkedin-gray-90">{feature.label}</p>
                  <p className="text-xs text-linkedin-gray-50">{feature.description}</p>
                </div>
                <button onClick={() => toggleFeature(feature.id)} className="shrink-0">
                  {feature.enabled ? (
                    <ToggleRight className="h-7 w-7 text-linkedin-green" />
                  ) : (
                    <ToggleLeft className="h-7 w-7 text-linkedin-gray-50" />
                  )}
                </button>
              </div>
            ))}
          </div>
        </CardBody>
      </Card>

      {/* Tone Presets */}
      <Card padding="none">
        <CardHeader>Tone Preset</CardHeader>
        <CardBody>
          <div className="flex flex-col gap-3">
            {tonePresets.map((preset) => (
              <label
                key={preset.value}
                className={cn(
                  "flex cursor-pointer items-center gap-3 rounded-lg border p-4 transition-colors",
                  tone === preset.value
                    ? "border-linkedin-blue bg-linkedin-blue-bg"
                    : "border-linkedin-gray-20 hover:bg-linkedin-gray-10",
                )}
              >
                <input
                  type="radio"
                  name="tone"
                  value={preset.value}
                  checked={tone === preset.value}
                  onChange={(e) => setTone(e.target.value)}
                  className="accent-linkedin-blue"
                />
                <div>
                  <p className="text-sm font-medium text-linkedin-gray-90">{preset.label}</p>
                  <p className="text-xs text-linkedin-gray-50">{preset.description}</p>
                </div>
              </label>
            ))}
          </div>
        </CardBody>
      </Card>

      {/* Save */}
      <div className="flex justify-end">
        <button className="flex items-center gap-2 rounded-lg bg-linkedin-blue px-6 py-2.5 text-sm font-medium text-white transition-colors hover:bg-linkedin-blue-dark">
          <Save className="h-4 w-4" />
          Save Configuration
        </button>
      </div>
    </div>
  );
}
