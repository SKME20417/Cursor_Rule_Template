"use client";

import React, { useState } from "react";
import { cn } from "@/lib/utils/cn";
import {
  Save,
  ToggleLeft,
  ToggleRight,
  Search,
  Brain,
} from "lucide-react";
import { Card, CardBody, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { PageHeader } from "@/components/layout/page-header";

/* ------------------------------------------------------------------ */
/* Mock Data                                                           */
/* ------------------------------------------------------------------ */

interface Classifier {
  id: string;
  name: string;
  enabled: boolean;
  confidenceThreshold: number;
  modelVersion: string;
  modelOptions: string[];
  lastUpdated: string;
}

const initialClassifiers: Classifier[] = [
  { id: "intent", name: "Intent Detection", enabled: true, confidenceThreshold: 0.8, modelVersion: "v3.2", modelOptions: ["v3.2", "v3.1", "v3.0"], lastUpdated: "2026-03-01" },
  { id: "sentiment", name: "Sentiment Analysis", enabled: true, confidenceThreshold: 0.7, modelVersion: "v2.1", modelOptions: ["v2.1", "v2.0", "v1.5"], lastUpdated: "2026-02-20" },
  { id: "urgency", name: "Urgency Classification", enabled: true, confidenceThreshold: 0.75, modelVersion: "v1.4", modelOptions: ["v1.4", "v1.3", "v1.2"], lastUpdated: "2026-02-15" },
  { id: "escalation", name: "Escalation Detection", enabled: true, confidenceThreshold: 0.85, modelVersion: "v2.0", modelOptions: ["v2.0", "v1.8", "v1.5"], lastUpdated: "2026-02-10" },
  { id: "language", name: "Language Detection", enabled: true, confidenceThreshold: 0.9, modelVersion: "v1.2", modelOptions: ["v1.2", "v1.1", "v1.0"], lastUpdated: "2026-01-25" },
];

const mockClassificationResult = {
  intent: { label: "Billing Inquiry", confidence: 0.92 },
  sentiment: { label: "Frustrated", confidence: 0.78 },
  urgency: { label: "High", confidence: 0.85 },
  escalation: { label: "No", confidence: 0.65 },
  language: { label: "English", confidence: 0.99 },
} as const;

/* ------------------------------------------------------------------ */
/* Page                                                                */
/* ------------------------------------------------------------------ */

export default function NLPConfigPage() {
  const [classifiers, setClassifiers] = useState(initialClassifiers);
  const [testText, setTestText] = useState("");
  const [showResults, setShowResults] = useState(false);

  function toggleClassifier(id: string) {
    setClassifiers((prev) =>
      prev.map((c) => (c.id === id ? { ...c, enabled: !c.enabled } : c)),
    );
  }

  function updateThreshold(id: string, value: number) {
    setClassifiers((prev) =>
      prev.map((c) => (c.id === id ? { ...c, confidenceThreshold: value } : c)),
    );
  }

  function updateVersion(id: string, version: string) {
    setClassifiers((prev) =>
      prev.map((c) => (c.id === id ? { ...c, modelVersion: version } : c)),
    );
  }

  function handleAnalyze() {
    if (testText.trim()) {
      setShowResults(true);
    }
  }

  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="NLP Configuration"
        subtitle="Configure natural language processing classifiers"
      />

      {/* Classifier Cards */}
      <div className="grid gap-4 sm:grid-cols-1">
        {classifiers.map((clf) => (
          <Card key={clf.id} padding="none">
            <CardBody>
              <div className="flex flex-col gap-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Brain className="h-5 w-5 text-linkedin-blue" />
                    <div>
                      <p className="font-medium text-linkedin-gray-90">{clf.name}</p>
                      <p className="text-xs text-linkedin-gray-50">Last updated: {clf.lastUpdated}</p>
                    </div>
                  </div>
                  <button onClick={() => toggleClassifier(clf.id)}>
                    {clf.enabled ? (
                      <ToggleRight className="h-7 w-7 text-linkedin-green" />
                    ) : (
                      <ToggleLeft className="h-7 w-7 text-linkedin-gray-50" />
                    )}
                  </button>
                </div>
                <div className="grid gap-4 sm:grid-cols-2">
                  <div>
                    <label className="mb-1 block text-xs font-medium text-linkedin-gray-70">
                      Confidence Threshold: {clf.confidenceThreshold}
                    </label>
                    <input
                      type="range"
                      min="0.5"
                      max="1.0"
                      step="0.05"
                      value={clf.confidenceThreshold}
                      onChange={(e) => updateThreshold(clf.id, parseFloat(e.target.value))}
                      className="w-full accent-linkedin-blue"
                      disabled={!clf.enabled}
                    />
                  </div>
                  <div>
                    <label className="mb-1 block text-xs font-medium text-linkedin-gray-70">Model Version</label>
                    <select
                      value={clf.modelVersion}
                      onChange={(e) => updateVersion(clf.id, e.target.value)}
                      disabled={!clf.enabled}
                      className="w-full rounded-lg border border-linkedin-gray-20 px-3 py-2 text-sm text-linkedin-gray-90 focus:border-linkedin-blue focus:outline-none disabled:opacity-50"
                    >
                      {clf.modelOptions.map((v) => (
                        <option key={v} value={v}>{v}</option>
                      ))}
                    </select>
                  </div>
                </div>
              </div>
            </CardBody>
          </Card>
        ))}
      </div>

      {/* Test Classification */}
      <Card padding="none">
        <CardHeader>
          <div className="flex items-center gap-2">
            <Search className="h-4 w-4 text-linkedin-blue" />
            Test Classification
          </div>
        </CardHeader>
        <CardBody>
          <div className="flex flex-col gap-4">
            <textarea
              value={testText}
              onChange={(e) => { setTestText(e.target.value); setShowResults(false); }}
              placeholder="Enter text to classify..."
              rows={3}
              className="w-full rounded-lg border border-linkedin-gray-20 px-3 py-2 text-sm text-linkedin-gray-90 placeholder:text-linkedin-gray-50 focus:border-linkedin-blue focus:outline-none focus:ring-1 focus:ring-linkedin-blue"
            />
            <button
              onClick={handleAnalyze}
              className="w-fit rounded-lg bg-linkedin-blue px-4 py-2 text-sm font-medium text-white transition-colors hover:bg-linkedin-blue-dark"
            >
              Analyze
            </button>
            {showResults && (
              <div className="rounded-lg border border-linkedin-gray-20 p-4">
                <p className="mb-3 text-sm font-medium text-linkedin-gray-90">Classification Results</p>
                <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
                  {Object.entries(mockClassificationResult).map(([key, result]) => (
                    <div key={key} className="rounded-lg bg-linkedin-gray-10 p-3">
                      <p className="text-xs text-linkedin-gray-50 capitalize">{key.replace("_", " ")}</p>
                      <p className="mt-1 font-medium text-linkedin-gray-90">{result.label}</p>
                      <div className="mt-1 flex items-center gap-1">
                        <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-linkedin-gray-20">
                          <div
                            className={cn(
                              "h-full rounded-full",
                              result.confidence >= 0.85 ? "bg-linkedin-green" : result.confidence >= 0.7 ? "bg-linkedin-blue" : "bg-linkedin-orange",
                            )}
                            style={{ width: `${result.confidence * 100}%` }}
                          />
                        </div>
                        <span className="text-xs text-linkedin-gray-50">{(result.confidence * 100).toFixed(0)}%</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </CardBody>
      </Card>

      {/* Save */}
      <div className="flex justify-end">
        <button className="flex items-center gap-2 rounded-lg bg-linkedin-blue px-6 py-2.5 text-sm font-medium text-white transition-colors hover:bg-linkedin-blue-dark">
          <Save className="h-4 w-4" />
          Save Configuration
        </button>
      </div>
    </div>
  );
}
