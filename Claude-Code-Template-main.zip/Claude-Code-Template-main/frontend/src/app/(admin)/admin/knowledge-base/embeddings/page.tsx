"use client";

import React, { useState } from "react";
import {
  Database,
  Cpu,
  Clock,
  RefreshCw,
  AlertTriangle,
  Layers,
  Zap,
} from "lucide-react";
import { cn } from "@/lib/utils/cn";
import { Card, CardBody, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { PageHeader } from "@/components/layout/page-header";

/* ------------------------------------------------------------------ */
/* Page                                                                */
/* ------------------------------------------------------------------ */

export default function EmbeddingsPage() {
  const [model, setModel] = useState("openai-3-small");
  const [chunkSize, setChunkSize] = useState("512");
  const [chunkOverlap, setChunkOverlap] = useState("50");
  const [isReindexing, setIsReindexing] = useState(false);

  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="Embeddings"
        subtitle="Configure embedding models and index health"
      />

      <div className="grid gap-6 lg:grid-cols-2">
        {/* Configuration */}
        <Card padding="none">
          <CardHeader>Embedding Configuration</CardHeader>
          <CardBody className="flex flex-col gap-4">
            <div className="flex flex-col gap-1">
              <label className="text-sm font-medium text-linkedin-gray-90">Embedding Model</label>
              <select
                value={model}
                onChange={(e) => setModel(e.target.value)}
                className="w-full rounded-lg border border-linkedin-gray-30 bg-white px-3 py-2 text-sm text-linkedin-gray-90 focus:border-linkedin-blue focus:outline-none focus:ring-1 focus:ring-linkedin-blue"
              >
                <option value="openai-3-small">OpenAI text-embedding-3-small</option>
                <option value="cohere-v3">Cohere embed-v3</option>
                <option value="local">Local model</option>
              </select>
            </div>

            <div className="flex flex-col gap-1">
              <label className="text-sm font-medium text-linkedin-gray-90">Chunk Size (tokens)</label>
              <input
                type="number"
                value={chunkSize}
                onChange={(e) => setChunkSize(e.target.value)}
                className="w-full rounded-lg border border-linkedin-gray-30 bg-white px-3 py-2 text-sm text-linkedin-gray-90 focus:border-linkedin-blue focus:outline-none focus:ring-1 focus:ring-linkedin-blue"
              />
            </div>

            <div className="flex flex-col gap-1">
              <label className="text-sm font-medium text-linkedin-gray-90">Chunk Overlap (tokens)</label>
              <input
                type="number"
                value={chunkOverlap}
                onChange={(e) => setChunkOverlap(e.target.value)}
                className="w-full rounded-lg border border-linkedin-gray-30 bg-white px-3 py-2 text-sm text-linkedin-gray-90 focus:border-linkedin-blue focus:outline-none focus:ring-1 focus:ring-linkedin-blue"
              />
            </div>

            <button className="self-start inline-flex items-center gap-2 rounded-lg bg-linkedin-blue px-4 py-2 text-sm font-medium text-white hover:bg-linkedin-blue-dark transition-colors">
              Save Configuration
            </button>
          </CardBody>
        </Card>

        {/* Index Health */}
        <Card padding="none">
          <CardHeader>Index Health</CardHeader>
          <CardBody className="flex flex-col gap-4">
            <div className="grid grid-cols-3 gap-4">
              <div className="flex flex-col items-center rounded-lg bg-linkedin-gray-10 p-4">
                <Layers className="h-5 w-5 text-linkedin-blue mb-1" />
                <p className="text-xl font-bold text-linkedin-gray-90 tabular-nums">12,456</p>
                <p className="text-xs text-linkedin-gray-50">Total Chunks</p>
              </div>
              <div className="flex flex-col items-center rounded-lg bg-linkedin-gray-10 p-4">
                <Zap className="h-5 w-5 text-linkedin-orange mb-1" />
                <p className="text-xl font-bold text-linkedin-gray-90 tabular-nums">23ms</p>
                <p className="text-xs text-linkedin-gray-50">Avg Embed Time</p>
              </div>
              <div className="flex flex-col items-center rounded-lg bg-linkedin-gray-10 p-4">
                <Clock className="h-5 w-5 text-linkedin-green mb-1" />
                <p className="text-xl font-bold text-linkedin-gray-90">2 days</p>
                <p className="text-xs text-linkedin-gray-50">Last Re-index</p>
              </div>
            </div>

            <div className="rounded-lg border border-orange-200 bg-orange-50 p-3">
              <div className="flex items-start gap-2">
                <AlertTriangle className="h-4 w-4 text-linkedin-orange mt-0.5 shrink-0" />
                <p className="text-xs text-linkedin-gray-70">
                  Re-indexing all documents will temporarily increase latency. This process may take several minutes depending on the number of documents.
                </p>
              </div>
            </div>

            <button
              onClick={() => setIsReindexing(!isReindexing)}
              className="inline-flex items-center gap-2 rounded-lg border border-linkedin-orange bg-white px-4 py-2 text-sm font-medium text-linkedin-orange hover:bg-orange-50 transition-colors"
            >
              <RefreshCw className={cn("h-4 w-4", isReindexing && "animate-spin")} />
              Re-index All Documents
            </button>

            {isReindexing && (
              <div className="flex flex-col gap-1">
                <div className="flex items-center justify-between text-xs text-linkedin-gray-50">
                  <span>Re-indexing in progress...</span>
                  <span>45%</span>
                </div>
                <div className="h-2 rounded-full bg-linkedin-gray-20">
                  <div className="h-full w-[45%] rounded-full bg-linkedin-blue transition-all" />
                </div>
              </div>
            )}
          </CardBody>
        </Card>
      </div>
    </div>
  );
}
