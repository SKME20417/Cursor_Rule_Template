"use client";

import React, { useState } from "react";
import {
  Search,
  Filter,
  ChevronLeft,
  ChevronRight,
  Trash2,
  Archive,
  Send,
} from "lucide-react";
import { cn } from "@/lib/utils/cn";
import { Card, CardBody, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { PageHeader } from "@/components/layout/page-header";

/* ------------------------------------------------------------------ */
/* Mock Data                                                           */
/* ------------------------------------------------------------------ */

const statusVariant: Record<string, "success" | "warning" | "default"> = {
  Published: "success",
  Draft: "warning",
  Archived: "default",
};

const articles = [
  { title: "Getting Started with API Integration", category: "Technical", status: "Published", author: "Sarah Chen", views: 1245, updated: "2026-03-09" },
  { title: "Billing FAQ", category: "Account & Billing", status: "Draft", author: "Emily Park", views: 0, updated: "2026-03-08" },
  { title: "Troubleshooting Connection Issues", category: "Troubleshooting", status: "Published", author: "James Wilson", views: 876, updated: "2026-03-08" },
  { title: "Webhook Setup Instructions", category: "Technical", status: "Published", author: "Sarah Chen", views: 543, updated: "2026-03-07" },
  { title: "Account Security Best Practices", category: "Account & Billing", status: "Published", author: "Michael Torres", views: 432, updated: "2026-03-06" },
  { title: "Advanced Configuration Guide", category: "Technical", status: "Draft", author: "James Wilson", views: 0, updated: "2026-03-05" },
  { title: "Mobile App Setup", category: "Getting Started", status: "Published", author: "Emily Park", views: 321, updated: "2026-03-04" },
  { title: "Data Export Guide", category: "Technical", status: "Published", author: "Sarah Chen", views: 234, updated: "2026-03-03" },
  { title: "Legacy API Migration", category: "Technical", status: "Archived", author: "Michael Torres", views: 156, updated: "2026-02-28" },
  { title: "Onboarding Checklist", category: "Getting Started", status: "Published", author: "Emily Park", views: 789, updated: "2026-03-01" },
];

const categories = ["All", "Technical", "Account & Billing", "Troubleshooting", "Getting Started"];

/* ------------------------------------------------------------------ */
/* Page                                                                */
/* ------------------------------------------------------------------ */

export default function ArticlesListPage() {
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("All");
  const [selected, setSelected] = useState<Set<number>>(new Set());

  const filtered = articles.filter((a) => {
    const matchSearch = a.title.toLowerCase().includes(search.toLowerCase());
    const matchCategory = category === "All" || a.category === category;
    return matchSearch && matchCategory;
  });

  const toggleSelect = (idx: number) => {
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(idx)) next.delete(idx);
      else next.add(idx);
      return next;
    });
  };

  const toggleAll = () => {
    if (selected.size === filtered.length) setSelected(new Set());
    else setSelected(new Set(filtered.map((_, i) => i)));
  };

  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="Articles"
        subtitle="Manage knowledge base articles"
        actions={
          <a
            href="/knowledge-base/articles/new"
            className="inline-flex items-center gap-2 rounded-lg bg-linkedin-blue px-4 py-2 text-sm font-medium text-white hover:bg-linkedin-blue-dark transition-colors"
          >
            New Article
          </a>
        }
      />

      {/* Search & Filter */}
      <Card>
        <CardBody>
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-linkedin-gray-50" />
              <input
                type="text"
                placeholder="Search articles..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="w-full rounded-lg border border-linkedin-gray-30 bg-white pl-10 pr-3 py-2 text-sm text-linkedin-gray-90 focus:border-linkedin-blue focus:outline-none focus:ring-1 focus:ring-linkedin-blue"
              />
            </div>
            <div className="flex items-center gap-2">
              <Filter className="h-4 w-4 text-linkedin-gray-50" />
              {categories.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setCategory(cat)}
                  className={cn(
                    "rounded-full px-3 py-1 text-xs font-medium transition-colors",
                    category === cat
                      ? "bg-linkedin-blue text-white"
                      : "bg-linkedin-gray-10 text-linkedin-gray-70 hover:bg-linkedin-gray-20"
                  )}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>
        </CardBody>
      </Card>

      {/* Bulk Actions */}
      {selected.size > 0 && (
        <div className="flex items-center gap-3 rounded-lg bg-linkedin-blue-bg px-4 py-2">
          <span className="text-sm font-medium text-linkedin-blue">{selected.size} selected</span>
          <button className="inline-flex items-center gap-1 rounded-md bg-linkedin-green px-3 py-1 text-xs font-medium text-white hover:opacity-90">
            <Send className="h-3 w-3" /> Publish
          </button>
          <button className="inline-flex items-center gap-1 rounded-md bg-linkedin-gray-50 px-3 py-1 text-xs font-medium text-white hover:opacity-90">
            <Archive className="h-3 w-3" /> Archive
          </button>
          <button className="inline-flex items-center gap-1 rounded-md bg-linkedin-red px-3 py-1 text-xs font-medium text-white hover:opacity-90">
            <Trash2 className="h-3 w-3" /> Delete
          </button>
        </div>
      )}

      {/* Table */}
      <Card padding="none">
        <CardBody className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-linkedin-gray-20 bg-linkedin-gray-10">
                  <th className="px-4 py-3 text-left">
                    <input
                      type="checkbox"
                      checked={selected.size === filtered.length && filtered.length > 0}
                      onChange={toggleAll}
                      className="rounded border-linkedin-gray-30"
                    />
                  </th>
                  <th className="px-4 py-3 text-left font-medium text-linkedin-gray-70">Title</th>
                  <th className="px-4 py-3 text-left font-medium text-linkedin-gray-70">Category</th>
                  <th className="px-4 py-3 text-left font-medium text-linkedin-gray-70">Status</th>
                  <th className="px-4 py-3 text-left font-medium text-linkedin-gray-70">Author</th>
                  <th className="px-4 py-3 text-left font-medium text-linkedin-gray-70">Views</th>
                  <th className="px-4 py-3 text-left font-medium text-linkedin-gray-70">Last Updated</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((article, i) => (
                  <tr key={i} className="border-b border-linkedin-gray-20 last:border-0 hover:bg-linkedin-gray-10 transition-colors">
                    <td className="px-4 py-3">
                      <input
                        type="checkbox"
                        checked={selected.has(i)}
                        onChange={() => toggleSelect(i)}
                        className="rounded border-linkedin-gray-30"
                      />
                    </td>
                    <td className="px-4 py-3 font-medium text-linkedin-blue hover:underline cursor-pointer">{article.title}</td>
                    <td className="px-4 py-3 text-linkedin-gray-70">{article.category}</td>
                    <td className="px-4 py-3">
                      <Badge variant={statusVariant[article.status]}>{article.status}</Badge>
                    </td>
                    <td className="px-4 py-3 text-linkedin-gray-70">{article.author}</td>
                    <td className="px-4 py-3 text-linkedin-gray-70 tabular-nums">{article.views.toLocaleString()}</td>
                    <td className="px-4 py-3 text-linkedin-gray-50">{article.updated}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardBody>
      </Card>

      {/* Pagination */}
      <div className="flex items-center justify-between">
        <p className="text-sm text-linkedin-gray-50">Showing 1-10 of 156 articles</p>
        <div className="flex items-center gap-1">
          <button className="rounded-md border border-linkedin-gray-30 p-2 text-linkedin-gray-50 hover:bg-linkedin-gray-10">
            <ChevronLeft className="h-4 w-4" />
          </button>
          {[1, 2, 3, 4, 5].map((p) => (
            <button
              key={p}
              className={cn(
                "rounded-md px-3 py-1.5 text-sm font-medium",
                p === 1 ? "bg-linkedin-blue text-white" : "text-linkedin-gray-70 hover:bg-linkedin-gray-10"
              )}
            >
              {p}
            </button>
          ))}
          <button className="rounded-md border border-linkedin-gray-30 p-2 text-linkedin-gray-50 hover:bg-linkedin-gray-10">
            <ChevronRight className="h-4 w-4" />
          </button>
        </div>
      </div>
    </div>
  );
}
