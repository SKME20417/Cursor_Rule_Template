"use client";

import React from "react";
import {
  FileText,
  Upload,
  RefreshCw,
  BookOpen,
  FilePlus,
  CheckCircle,
  FileEdit,
  Activity,
} from "lucide-react";
import { cn } from "@/lib/utils/cn";
import { Card, CardBody, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { PageHeader } from "@/components/layout/page-header";

/* ------------------------------------------------------------------ */
/* Mock Data                                                           */
/* ------------------------------------------------------------------ */

const stats = [
  { label: "Total Articles", value: "156", icon: BookOpen, color: "text-linkedin-blue" },
  { label: "Published", value: "134", icon: CheckCircle, color: "text-linkedin-green" },
  { label: "Drafts", value: "22", icon: FileEdit, color: "text-linkedin-orange" },
  { label: "Total Documents", value: "45", icon: FileText, color: "text-linkedin-blue" },
];

const recentChanges = [
  { title: "Getting Started with API Integration", action: "published", author: "Sarah Chen", date: "2026-03-09" },
  { title: "Troubleshooting Connection Issues", action: "updated", author: "James Wilson", date: "2026-03-09" },
  { title: "Billing FAQ", action: "created", author: "Emily Park", date: "2026-03-08" },
  { title: "Advanced Configuration Guide", action: "updated", author: "Michael Torres", date: "2026-03-08" },
  { title: "Webhook Setup Instructions", action: "published", author: "Sarah Chen", date: "2026-03-07" },
];

const actionBadgeVariant: Record<string, "success" | "primary" | "warning"> = {
  published: "success",
  updated: "primary",
  created: "warning",
};

/* ------------------------------------------------------------------ */
/* Page                                                                */
/* ------------------------------------------------------------------ */

export default function KnowledgeBaseDashboardPage() {
  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="Knowledge Base"
        subtitle="Manage articles, documents, and embeddings"
        actions={
          <div className="flex items-center gap-2">
            <button className="inline-flex items-center gap-2 rounded-lg bg-linkedin-blue px-4 py-2 text-sm font-medium text-white hover:bg-linkedin-blue-dark transition-colors">
              <FilePlus className="h-4 w-4" />
              New Article
            </button>
            <button className="inline-flex items-center gap-2 rounded-lg border border-linkedin-gray-30 bg-white px-4 py-2 text-sm font-medium text-linkedin-gray-70 hover:bg-linkedin-gray-10 transition-colors">
              <Upload className="h-4 w-4" />
              Bulk Import
            </button>
            <button className="inline-flex items-center gap-2 rounded-lg border border-linkedin-gray-30 bg-white px-4 py-2 text-sm font-medium text-linkedin-gray-70 hover:bg-linkedin-gray-10 transition-colors">
              <RefreshCw className="h-4 w-4" />
              Re-index All
            </button>
          </div>
        }
      />

      {/* Stats */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
        {stats.map((stat) => (
          <Card key={stat.label} hover>
            <CardBody>
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-xs text-linkedin-gray-50">{stat.label}</p>
                  <p className="mt-1 text-2xl font-bold text-linkedin-gray-90">{stat.value}</p>
                </div>
                <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-linkedin-blue-bg">
                  <stat.icon className={cn("h-5 w-5", stat.color)} />
                </div>
              </div>
            </CardBody>
          </Card>
        ))}
        <Card hover>
          <CardBody>
            <div className="flex items-start justify-between">
              <div>
                <p className="text-xs text-linkedin-gray-50">Embedding Health</p>
                <p className="mt-1 text-lg font-bold text-linkedin-green">Healthy</p>
              </div>
              <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-green-50">
                <Activity className="h-5 w-5 text-linkedin-green" />
              </div>
            </div>
          </CardBody>
        </Card>
      </div>

      {/* Recent Changes */}
      <Card padding="none">
        <CardHeader>Recent Changes</CardHeader>
        <CardBody className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-linkedin-gray-20 bg-linkedin-gray-10">
                  <th className="px-4 py-3 text-left font-medium text-linkedin-gray-70">Article Title</th>
                  <th className="px-4 py-3 text-left font-medium text-linkedin-gray-70">Action</th>
                  <th className="px-4 py-3 text-left font-medium text-linkedin-gray-70">Author</th>
                  <th className="px-4 py-3 text-left font-medium text-linkedin-gray-70">Date</th>
                </tr>
              </thead>
              <tbody>
                {recentChanges.map((change, i) => (
                  <tr key={i} className="border-b border-linkedin-gray-20 last:border-0 hover:bg-linkedin-gray-10 transition-colors">
                    <td className="px-4 py-3 font-medium text-linkedin-gray-90">{change.title}</td>
                    <td className="px-4 py-3">
                      <Badge variant={actionBadgeVariant[change.action]}>{change.action}</Badge>
                    </td>
                    <td className="px-4 py-3 text-linkedin-gray-70">{change.author}</td>
                    <td className="px-4 py-3 text-linkedin-gray-50">{change.date}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardBody>
      </Card>
    </div>
  );
}
