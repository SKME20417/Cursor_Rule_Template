"use client";

import React from "react";
import {
  Upload,
  Globe,
  FileText,
  RotateCcw,
  X,
  CheckCircle,
  Loader2,
  AlertCircle,
} from "lucide-react";
import { cn } from "@/lib/utils/cn";
import { Card, CardBody, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { PageHeader } from "@/components/layout/page-header";

/* ------------------------------------------------------------------ */
/* Mock Data                                                           */
/* ------------------------------------------------------------------ */

const importQueue = [
  { filename: "product-guide-v3.pdf", type: "PDF", status: "Complete", progress: 100, chunks: 42, color: "success" as const },
  { filename: "faq-database.csv", type: "CSV", status: "Processing", progress: 68, chunks: 24, color: "primary" as const },
  { filename: "release-notes.html", type: "HTML", status: "Uploading", progress: 35, chunks: 0, color: "warning" as const },
  { filename: "setup-instructions.txt", type: "TXT", status: "Error", progress: 0, chunks: 0, color: "danger" as const },
];

const statusIcons: Record<string, React.ReactNode> = {
  Complete: <CheckCircle className="h-4 w-4 text-linkedin-green" />,
  Processing: <Loader2 className="h-4 w-4 text-linkedin-blue animate-spin" />,
  Uploading: <Upload className="h-4 w-4 text-linkedin-orange" />,
  Error: <AlertCircle className="h-4 w-4 text-linkedin-red" />,
};

/* ------------------------------------------------------------------ */
/* Page                                                                */
/* ------------------------------------------------------------------ */

export default function ImportsPage() {
  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="Bulk Import"
        subtitle="Import documents into the knowledge base"
      />

      <div className="grid gap-6 lg:grid-cols-2">
        {/* File Upload */}
        <Card padding="none">
          <CardHeader>Upload Files</CardHeader>
          <CardBody>
            <div className="flex flex-col items-center justify-center rounded-lg border-2 border-dashed border-linkedin-gray-30 bg-linkedin-gray-10 px-6 py-12 text-center hover:border-linkedin-blue hover:bg-linkedin-blue-bg transition-colors cursor-pointer">
              <Upload className="h-10 w-10 text-linkedin-gray-50 mb-3" />
              <p className="text-sm font-medium text-linkedin-gray-90">
                Drop files here or click to browse
              </p>
              <p className="mt-1 text-xs text-linkedin-gray-50">
                Accepts PDF, CSV, HTML, TXT
              </p>
            </div>
          </CardBody>
        </Card>

        {/* URL Scraping */}
        <Card padding="none">
          <CardHeader>URL Scraping</CardHeader>
          <CardBody>
            <div className="flex flex-col gap-3">
              <div className="flex gap-2">
                <div className="relative flex-1">
                  <Globe className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-linkedin-gray-50" />
                  <input
                    type="url"
                    placeholder="Enter URL to scrape"
                    className="w-full rounded-lg border border-linkedin-gray-30 bg-white pl-10 pr-3 py-2 text-sm text-linkedin-gray-90 focus:border-linkedin-blue focus:outline-none focus:ring-1 focus:ring-linkedin-blue"
                  />
                </div>
                <button className="inline-flex items-center gap-2 rounded-lg bg-linkedin-blue px-4 py-2 text-sm font-medium text-white hover:bg-linkedin-blue-dark transition-colors">
                  Scrape
                </button>
              </div>
              <p className="text-xs text-linkedin-gray-50">
                Enter a URL to scrape its content and import it as a knowledge base document.
              </p>
            </div>
          </CardBody>
        </Card>
      </div>

      {/* Import Queue */}
      <Card padding="none">
        <CardHeader>Import Queue</CardHeader>
        <CardBody className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-linkedin-gray-20 bg-linkedin-gray-10">
                  <th className="px-4 py-3 text-left font-medium text-linkedin-gray-70">Filename</th>
                  <th className="px-4 py-3 text-left font-medium text-linkedin-gray-70">Type</th>
                  <th className="px-4 py-3 text-left font-medium text-linkedin-gray-70">Status</th>
                  <th className="px-4 py-3 text-left font-medium text-linkedin-gray-70">Progress</th>
                  <th className="px-4 py-3 text-left font-medium text-linkedin-gray-70">Chunks</th>
                  <th className="px-4 py-3 text-left font-medium text-linkedin-gray-70">Actions</th>
                </tr>
              </thead>
              <tbody>
                {importQueue.map((item, i) => (
                  <tr key={i} className="border-b border-linkedin-gray-20 last:border-0 hover:bg-linkedin-gray-10 transition-colors">
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2">
                        <FileText className="h-4 w-4 text-linkedin-gray-50" />
                        <span className="font-medium text-linkedin-gray-90">{item.filename}</span>
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <Badge>{item.type}</Badge>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2">
                        {statusIcons[item.status]}
                        <Badge variant={item.color}>{item.status}</Badge>
                      </div>
                    </td>
                    <td className="px-4 py-3 w-40">
                      <div className="flex items-center gap-2">
                        <div className="h-2 flex-1 rounded-full bg-linkedin-gray-20">
                          <div
                            className={cn(
                              "h-full rounded-full transition-all",
                              item.status === "Error" ? "bg-linkedin-red" :
                              item.status === "Complete" ? "bg-linkedin-green" : "bg-linkedin-blue"
                            )}
                            style={{ width: `${item.progress}%` }}
                          />
                        </div>
                        <span className="text-xs tabular-nums text-linkedin-gray-50">{item.progress}%</span>
                      </div>
                    </td>
                    <td className="px-4 py-3 text-linkedin-gray-70 tabular-nums">
                      {item.chunks > 0 ? item.chunks : "-"}
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-1">
                        {item.status === "Error" && (
                          <button className="rounded-md p-1.5 text-linkedin-blue hover:bg-linkedin-blue-bg transition-colors" title="Retry">
                            <RotateCcw className="h-3.5 w-3.5" />
                          </button>
                        )}
                        {(item.status === "Uploading" || item.status === "Processing") && (
                          <button className="rounded-md p-1.5 text-linkedin-red hover:bg-red-50 transition-colors" title="Cancel">
                            <X className="h-3.5 w-3.5" />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardBody>
      </Card>
    </div>
  );
}
