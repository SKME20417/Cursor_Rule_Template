"use client";

import React, { useState } from "react";
import {
  Plus,
  GripVertical,
  Pencil,
  Trash2,
  ChevronRight,
  ChevronDown,
  FolderOpen,
} from "lucide-react";
import { cn } from "@/lib/utils/cn";
import { Card, CardBody, CardHeader } from "@/components/ui/card";
import { PageHeader } from "@/components/layout/page-header";

/* ------------------------------------------------------------------ */
/* Mock Data                                                           */
/* ------------------------------------------------------------------ */

interface Category {
  id: string;
  name: string;
  count: number;
  children?: Category[];
}

const categories: Category[] = [
  { id: "1", name: "Getting Started", count: 12 },
  { id: "2", name: "Account & Billing", count: 8 },
  {
    id: "3",
    name: "Technical Support",
    count: 23,
    children: [
      { id: "3a", name: "API Issues", count: 10 },
      { id: "3b", name: "Infrastructure", count: 13 },
    ],
  },
  { id: "4", name: "Integrations", count: 15 },
  { id: "5", name: "Troubleshooting", count: 18 },
];

/* ------------------------------------------------------------------ */
/* CategoryRow                                                         */
/* ------------------------------------------------------------------ */

function CategoryRow({
  category,
  depth = 0,
}: {
  category: Category;
  depth?: number;
}) {
  const [expanded, setExpanded] = useState(true);
  const hasChildren = category.children && category.children.length > 0;

  return (
    <>
      <div
        className={cn(
          "flex items-center gap-3 border-b border-linkedin-gray-20 px-4 py-3 hover:bg-linkedin-gray-10 transition-colors",
        )}
        style={{ paddingLeft: `${depth * 24 + 16}px` }}
      >
        <GripVertical className="h-4 w-4 shrink-0 cursor-grab text-linkedin-gray-30" />
        {hasChildren ? (
          <button onClick={() => setExpanded(!expanded)} className="shrink-0">
            {expanded ? (
              <ChevronDown className="h-4 w-4 text-linkedin-gray-50" />
            ) : (
              <ChevronRight className="h-4 w-4 text-linkedin-gray-50" />
            )}
          </button>
        ) : (
          <span className="w-4 shrink-0" />
        )}
        <FolderOpen className="h-4 w-4 shrink-0 text-linkedin-blue" />
        <span className="flex-1 text-sm font-medium text-linkedin-gray-90">
          {category.name}
        </span>
        <span className="rounded-full bg-linkedin-gray-10 px-2 py-0.5 text-xs font-medium text-linkedin-gray-50 tabular-nums">
          {category.count} articles
        </span>
        <div className="flex items-center gap-1">
          <button className="rounded-md p-1.5 text-linkedin-gray-50 hover:bg-linkedin-gray-20 hover:text-linkedin-gray-90 transition-colors">
            <Pencil className="h-3.5 w-3.5" />
          </button>
          <button className="rounded-md p-1.5 text-linkedin-gray-50 hover:bg-red-50 hover:text-linkedin-red transition-colors">
            <Trash2 className="h-3.5 w-3.5" />
          </button>
        </div>
      </div>
      {hasChildren &&
        expanded &&
        category.children!.map((child) => (
          <CategoryRow key={child.id} category={child} depth={depth + 1} />
        ))}
    </>
  );
}

/* ------------------------------------------------------------------ */
/* Page                                                                */
/* ------------------------------------------------------------------ */

export default function CategoriesPage() {
  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="Categories"
        subtitle="Organize knowledge base articles into categories"
        actions={
          <button className="inline-flex items-center gap-2 rounded-lg bg-linkedin-blue px-4 py-2 text-sm font-medium text-white hover:bg-linkedin-blue-dark transition-colors">
            <Plus className="h-4 w-4" />
            Add Category
          </button>
        }
      />

      <Card padding="none">
        <CardHeader>Category Tree</CardHeader>
        <div>
          {categories.map((cat) => (
            <CategoryRow key={cat.id} category={cat} />
          ))}
        </div>
      </Card>
    </div>
  );
}
