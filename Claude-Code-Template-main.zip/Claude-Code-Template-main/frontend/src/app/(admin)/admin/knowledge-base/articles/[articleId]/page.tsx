"use client";

import React, { useState } from "react";
import {
  Bold,
  Italic,
  Heading1,
  Heading2,
  List,
  ListOrdered,
  Link,
  Code,
  Image,
  Save,
  Send,
  Eye,
  History,
  ChevronDown,
  ChevronUp,
} from "lucide-react";
import { cn } from "@/lib/utils/cn";
import { Card, CardBody, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { PageHeader } from "@/components/layout/page-header";

/* ------------------------------------------------------------------ */
/* Mock Data                                                           */
/* ------------------------------------------------------------------ */

const mockArticle = {
  title: "Getting Started with API Integration",
  content: `## Overview\n\nThis guide walks you through the process of integrating with our API. You'll learn how to authenticate, make requests, and handle responses.\n\n## Prerequisites\n\n- An active account with API access enabled\n- Your API key (found in Settings > API Keys)\n- A REST client or programming language of your choice\n\n## Authentication\n\nAll API requests require authentication via Bearer token. Include your API key in the Authorization header:\n\n\`\`\`\nAuthorization: Bearer sk_live_your_api_key\n\`\`\`\n\n## Making Your First Request\n\nSend a GET request to the /api/v1/conversations endpoint to retrieve your recent conversations.`,
  category: "technical",
  tags: "api, integration, getting-started",
  status: "published",
};

const versionHistory = [
  { version: "v3", author: "Sarah Chen", date: "2026-03-09 14:30", changes: "Updated authentication section" },
  { version: "v2", author: "Sarah Chen", date: "2026-03-07 10:15", changes: "Added code examples" },
  { version: "v1", author: "James Wilson", date: "2026-03-05 09:00", changes: "Initial draft" },
];

/* ------------------------------------------------------------------ */
/* Page                                                                */
/* ------------------------------------------------------------------ */

export default function EditArticlePage() {
  const [title, setTitle] = useState(mockArticle.title);
  const [content, setContent] = useState(mockArticle.content);
  const [category, setCategory] = useState(mockArticle.category);
  const [tags, setTags] = useState(mockArticle.tags);
  const [status, setStatus] = useState(mockArticle.status);
  const [showHistory, setShowHistory] = useState(false);
  const [showPreview, setShowPreview] = useState(false);

  const toolbarButtons = [
    { icon: Bold, label: "Bold" },
    { icon: Italic, label: "Italic" },
    { icon: Heading1, label: "H1" },
    { icon: Heading2, label: "H2" },
    { icon: List, label: "Bullet List" },
    { icon: ListOrdered, label: "Numbered List" },
    { icon: Link, label: "Link" },
    { icon: Code, label: "Code" },
    { icon: Image, label: "Image" },
  ];

  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="Edit Article"
        subtitle="Modify an existing knowledge base article"
        actions={
          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowPreview(!showPreview)}
              className="inline-flex items-center gap-2 rounded-lg border border-linkedin-gray-30 bg-white px-4 py-2 text-sm font-medium text-linkedin-gray-70 hover:bg-linkedin-gray-10 transition-colors"
            >
              <Eye className="h-4 w-4" />
              Preview
            </button>
            <button className="inline-flex items-center gap-2 rounded-lg border border-linkedin-gray-30 bg-white px-4 py-2 text-sm font-medium text-linkedin-gray-70 hover:bg-linkedin-gray-10 transition-colors">
              <Save className="h-4 w-4" />
              Save Draft
            </button>
            <button className="inline-flex items-center gap-2 rounded-lg bg-linkedin-blue px-4 py-2 text-sm font-medium text-white hover:bg-linkedin-blue-dark transition-colors">
              <Send className="h-4 w-4" />
              Publish
            </button>
          </div>
        }
      />

      {/* Preview Mode */}
      {showPreview && (
        <Card padding="none">
          <CardHeader>Preview</CardHeader>
          <CardBody>
            <h1 className="text-2xl font-bold text-linkedin-gray-90 mb-4">{title}</h1>
            <div className="prose prose-sm max-w-none text-linkedin-gray-70 whitespace-pre-wrap">
              {content}
            </div>
          </CardBody>
        </Card>
      )}

      <div className="grid gap-6 lg:grid-cols-3">
        {/* Main Editor */}
        <div className="lg:col-span-2 flex flex-col gap-4">
          <Card>
            <CardBody>
              <input
                type="text"
                placeholder="Article title..."
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="w-full border-0 bg-transparent text-2xl font-bold text-linkedin-gray-90 placeholder:text-linkedin-gray-30 focus:outline-none"
              />
            </CardBody>
          </Card>

          <Card padding="none">
            <div className="flex items-center gap-1 border-b border-linkedin-gray-20 px-4 py-2">
              {toolbarButtons.map((btn) => (
                <button
                  key={btn.label}
                  title={btn.label}
                  className="rounded-md p-2 text-linkedin-gray-50 hover:bg-linkedin-gray-10 hover:text-linkedin-gray-90 transition-colors"
                >
                  <btn.icon className="h-4 w-4" />
                </button>
              ))}
            </div>
            <CardBody>
              <textarea
                value={content}
                onChange={(e) => setContent(e.target.value)}
                placeholder="Start writing your article..."
                rows={20}
                className="w-full resize-none border-0 bg-transparent text-sm text-linkedin-gray-90 placeholder:text-linkedin-gray-30 focus:outline-none leading-relaxed"
              />
            </CardBody>
          </Card>

          {/* Version History */}
          <Card padding="none">
            <button
              onClick={() => setShowHistory(!showHistory)}
              className="flex w-full items-center justify-between px-4 py-3 text-left font-semibold text-linkedin-gray-90 hover:bg-linkedin-gray-10 transition-colors"
            >
              <div className="flex items-center gap-2">
                <History className="h-4 w-4" />
                Version History
              </div>
              {showHistory ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
            </button>
            {showHistory && (
              <CardBody className="border-t border-linkedin-gray-20 p-0">
                <div className="divide-y divide-linkedin-gray-20">
                  {versionHistory.map((v) => (
                    <div key={v.version} className="flex items-center justify-between px-4 py-3 hover:bg-linkedin-gray-10 transition-colors">
                      <div className="flex items-center gap-3">
                        <Badge variant="primary">{v.version}</Badge>
                        <div>
                          <p className="text-sm font-medium text-linkedin-gray-90">{v.changes}</p>
                          <p className="text-xs text-linkedin-gray-50">{v.author} - {v.date}</p>
                        </div>
                      </div>
                      <button className="text-xs font-medium text-linkedin-blue hover:underline">Restore</button>
                    </div>
                  ))}
                </div>
              </CardBody>
            )}
          </Card>
        </div>

        {/* Sidebar */}
        <div className="flex flex-col gap-4">
          <Card padding="none">
            <CardHeader>Article Settings</CardHeader>
            <CardBody className="flex flex-col gap-4">
              <div className="flex flex-col gap-1">
                <label className="text-sm font-medium text-linkedin-gray-90">Category</label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="w-full rounded-lg border border-linkedin-gray-30 bg-white px-3 py-2 text-sm text-linkedin-gray-90 focus:border-linkedin-blue focus:outline-none focus:ring-1 focus:ring-linkedin-blue"
                >
                  <option value="technical">Technical</option>
                  <option value="account-billing">Account & Billing</option>
                  <option value="getting-started">Getting Started</option>
                  <option value="troubleshooting">Troubleshooting</option>
                  <option value="integrations">Integrations</option>
                </select>
              </div>

              <div className="flex flex-col gap-1">
                <label className="text-sm font-medium text-linkedin-gray-90">Tags</label>
                <input
                  type="text"
                  value={tags}
                  onChange={(e) => setTags(e.target.value)}
                  className="w-full rounded-lg border border-linkedin-gray-30 bg-white px-3 py-2 text-sm text-linkedin-gray-90 focus:border-linkedin-blue focus:outline-none focus:ring-1 focus:ring-linkedin-blue"
                />
                <p className="text-xs text-linkedin-gray-50">Comma separated</p>
              </div>

              <div className="flex flex-col gap-1">
                <label className="text-sm font-medium text-linkedin-gray-90">Status</label>
                <select
                  value={status}
                  onChange={(e) => setStatus(e.target.value)}
                  className="w-full rounded-lg border border-linkedin-gray-30 bg-white px-3 py-2 text-sm text-linkedin-gray-90 focus:border-linkedin-blue focus:outline-none focus:ring-1 focus:ring-linkedin-blue"
                >
                  <option value="draft">Draft</option>
                  <option value="published">Published</option>
                </select>
              </div>

              <div className="flex flex-col gap-1">
                <label className="text-sm font-medium text-linkedin-gray-90">Author</label>
                <div className="flex items-center gap-2 rounded-lg border border-linkedin-gray-20 bg-linkedin-gray-10 px-3 py-2">
                  <div className="h-6 w-6 rounded-full bg-linkedin-blue flex items-center justify-center text-white text-xs font-medium">
                    SC
                  </div>
                  <span className="text-sm text-linkedin-gray-70">Sarah Chen</span>
                </div>
              </div>
            </CardBody>
          </Card>
        </div>
      </div>
    </div>
  );
}
