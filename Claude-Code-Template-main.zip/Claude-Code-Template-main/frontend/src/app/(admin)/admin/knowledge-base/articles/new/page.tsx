"use client";

import React, { useState } from "react";
import {
  Bold,
  Italic,
  Heading1,
  Heading2,
  List,
  ListOrdered,
  Link,
  Code,
  Image,
  Save,
  Send,
} from "lucide-react";
import { cn } from "@/lib/utils/cn";
import { Card, CardBody, CardHeader } from "@/components/ui/card";
import { PageHeader } from "@/components/layout/page-header";

/* ------------------------------------------------------------------ */
/* Page                                                                */
/* ------------------------------------------------------------------ */

export default function NewArticlePage() {
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [category, setCategory] = useState("technical");
  const [tags, setTags] = useState("");
  const [status, setStatus] = useState("draft");

  const toolbarButtons = [
    { icon: Bold, label: "Bold" },
    { icon: Italic, label: "Italic" },
    { icon: Heading1, label: "H1" },
    { icon: Heading2, label: "H2" },
    { icon: List, label: "Bullet List" },
    { icon: ListOrdered, label: "Numbered List" },
    { icon: Link, label: "Link" },
    { icon: Code, label: "Code" },
    { icon: Image, label: "Image" },
  ];

  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="New Article"
        subtitle="Create a new knowledge base article"
        actions={
          <div className="flex items-center gap-2">
            <button className="inline-flex items-center gap-2 rounded-lg border border-linkedin-gray-30 bg-white px-4 py-2 text-sm font-medium text-linkedin-gray-70 hover:bg-linkedin-gray-10 transition-colors">
              <Save className="h-4 w-4" />
              Save Draft
            </button>
            <button className="inline-flex items-center gap-2 rounded-lg bg-linkedin-blue px-4 py-2 text-sm font-medium text-white hover:bg-linkedin-blue-dark transition-colors">
              <Send className="h-4 w-4" />
              Publish
            </button>
          </div>
        }
      />

      <div className="grid gap-6 lg:grid-cols-3">
        {/* Main Editor */}
        <div className="lg:col-span-2 flex flex-col gap-4">
          <Card>
            <CardBody>
              <input
                type="text"
                placeholder="Article title..."
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="w-full border-0 bg-transparent text-2xl font-bold text-linkedin-gray-90 placeholder:text-linkedin-gray-30 focus:outline-none"
              />
            </CardBody>
          </Card>

          <Card padding="none">
            <div className="flex items-center gap-1 border-b border-linkedin-gray-20 px-4 py-2">
              {toolbarButtons.map((btn) => (
                <button
                  key={btn.label}
                  title={btn.label}
                  className="rounded-md p-2 text-linkedin-gray-50 hover:bg-linkedin-gray-10 hover:text-linkedin-gray-90 transition-colors"
                >
                  <btn.icon className="h-4 w-4" />
                </button>
              ))}
            </div>
            <CardBody>
              <textarea
                value={content}
                onChange={(e) => setContent(e.target.value)}
                placeholder="Start writing your article..."
                rows={20}
                className="w-full resize-none border-0 bg-transparent text-sm text-linkedin-gray-90 placeholder:text-linkedin-gray-30 focus:outline-none leading-relaxed"
              />
            </CardBody>
          </Card>
        </div>

        {/* Sidebar */}
        <div className="flex flex-col gap-4">
          <Card padding="none">
            <CardHeader>Article Settings</CardHeader>
            <CardBody className="flex flex-col gap-4">
              <div className="flex flex-col gap-1">
                <label className="text-sm font-medium text-linkedin-gray-90">Category</label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="w-full rounded-lg border border-linkedin-gray-30 bg-white px-3 py-2 text-sm text-linkedin-gray-90 focus:border-linkedin-blue focus:outline-none focus:ring-1 focus:ring-linkedin-blue"
                >
                  <option value="technical">Technical</option>
                  <option value="account-billing">Account & Billing</option>
                  <option value="getting-started">Getting Started</option>
                  <option value="troubleshooting">Troubleshooting</option>
                  <option value="integrations">Integrations</option>
                </select>
              </div>

              <div className="flex flex-col gap-1">
                <label className="text-sm font-medium text-linkedin-gray-90">Tags</label>
                <input
                  type="text"
                  placeholder="api, integration, setup"
                  value={tags}
                  onChange={(e) => setTags(e.target.value)}
                  className="w-full rounded-lg border border-linkedin-gray-30 bg-white px-3 py-2 text-sm text-linkedin-gray-90 focus:border-linkedin-blue focus:outline-none focus:ring-1 focus:ring-linkedin-blue"
                />
                <p className="text-xs text-linkedin-gray-50">Comma separated</p>
              </div>

              <div className="flex flex-col gap-1">
                <label className="text-sm font-medium text-linkedin-gray-90">Status</label>
                <select
                  value={status}
                  onChange={(e) => setStatus(e.target.value)}
                  className="w-full rounded-lg border border-linkedin-gray-30 bg-white px-3 py-2 text-sm text-linkedin-gray-90 focus:border-linkedin-blue focus:outline-none focus:ring-1 focus:ring-linkedin-blue"
                >
                  <option value="draft">Draft</option>
                  <option value="published">Published</option>
                </select>
              </div>

              <div className="flex flex-col gap-1">
                <label className="text-sm font-medium text-linkedin-gray-90">Author</label>
                <div className="flex items-center gap-2 rounded-lg border border-linkedin-gray-20 bg-linkedin-gray-10 px-3 py-2">
                  <div className="h-6 w-6 rounded-full bg-linkedin-blue flex items-center justify-center text-white text-xs font-medium">
                    SC
                  </div>
                  <span className="text-sm text-linkedin-gray-70">Sarah Chen</span>
                </div>
              </div>
            </CardBody>
          </Card>
        </div>
      </div>
    </div>
  );
}
