"use client";

import React, { useState } from "react";
import { cn } from "@/lib/utils/cn";
import {
  Ticket,
  AlertCircle,
  Clock,
  CheckCircle,
  ShieldAlert,
} from "lucide-react";
import { Card, CardBody } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { PageHeader } from "@/components/layout/page-header";

/* ------------------------------------------------------------------ */
/* Mock Data                                                           */
/* ------------------------------------------------------------------ */

const ticketStats = [
  { label: "Open", value: "234", icon: Ticket, color: "bg-linkedin-blue-bg text-linkedin-blue" },
  { label: "Pending", value: "67", icon: Clock, color: "bg-orange-50 text-linkedin-orange" },
  { label: "Resolved Today", value: "89", icon: CheckCircle, color: "bg-green-50 text-linkedin-green" },
  { label: "SLA Breached", value: "5", icon: ShieldAlert, color: "bg-red-50 text-linkedin-red" },
] as const;

type TicketStatus = "open" | "pending" | "in_progress" | "resolved" | "closed";
type TicketPriority = "critical" | "high" | "medium" | "low";

interface TicketRow {
  id: string;
  subject: string;
  customer: string;
  status: TicketStatus;
  priority: TicketPriority;
  assignee: string;
  created: string;
  slaOk: boolean;
}

const mockTickets: TicketRow[] = [
  { id: "TKT-4521", subject: "Cannot access billing portal", customer: "John Smith", status: "open", priority: "high", assignee: "Sarah Chen", created: "10 min ago", slaOk: true },
  { id: "TKT-4520", subject: "Refund request for order #8821", customer: "Emily Roberts", status: "in_progress", priority: "medium", assignee: "James Wilson", created: "25 min ago", slaOk: true },
  { id: "TKT-4519", subject: "API integration failing", customer: "Tech Corp", status: "open", priority: "critical", assignee: "Emma Davis", created: "30 min ago", slaOk: false },
  { id: "TKT-4518", subject: "Password reset not working", customer: "Mike Thompson", status: "pending", priority: "medium", assignee: "AI Bot", created: "45 min ago", slaOk: true },
  { id: "TKT-4517", subject: "Feature request: dark mode", customer: "Lisa Anderson", status: "open", priority: "low", assignee: "David Brown", created: "1 hour ago", slaOk: true },
  { id: "TKT-4516", subject: "Data export timeout error", customer: "Global Inc", status: "in_progress", priority: "high", assignee: "Maria Garcia", created: "1.5 hours ago", slaOk: true },
  { id: "TKT-4515", subject: "Account locked after failed attempts", customer: "Tom Baker", status: "resolved", priority: "high", assignee: "Alex Kim", created: "2 hours ago", slaOk: true },
  { id: "TKT-4514", subject: "Webhook delivery failures", customer: "StartupXYZ", status: "open", priority: "critical", assignee: "Emma Davis", created: "2.5 hours ago", slaOk: false },
  { id: "TKT-4513", subject: "Incorrect invoice amount", customer: "Jane Cooper", status: "pending", priority: "medium", assignee: "Sarah Chen", created: "3 hours ago", slaOk: true },
  { id: "TKT-4512", subject: "Mobile app crash on login", customer: "Robert Lee", status: "in_progress", priority: "high", assignee: "Mike Johnson", created: "3.5 hours ago", slaOk: false },
];

const statusBadge: Record<TicketStatus, "default" | "primary" | "success" | "warning" | "info"> = {
  open: "primary",
  pending: "warning",
  in_progress: "info",
  resolved: "success",
  closed: "default",
};

const priorityBadge: Record<TicketPriority, "default" | "danger" | "warning" | "success"> = {
  critical: "danger",
  high: "warning",
  medium: "default",
  low: "success",
};

/* ------------------------------------------------------------------ */
/* Page                                                                */
/* ------------------------------------------------------------------ */

export default function TicketsPage() {
  const [filterStatus, setFilterStatus] = useState("all");
  const [filterPriority, setFilterPriority] = useState("all");
  const [filterAssignee, setFilterAssignee] = useState("all");

  const assignees = [...new Set(mockTickets.map((t) => t.assignee))];

  const filtered = mockTickets.filter((ticket) => {
    if (filterStatus !== "all" && ticket.status !== filterStatus) return false;
    if (filterPriority !== "all" && ticket.priority !== filterPriority) return false;
    if (filterAssignee !== "all" && ticket.assignee !== filterAssignee) return false;
    return true;
  });

  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="Tickets"
        subtitle="All support tickets"
      />

      {/* Stats */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {ticketStats.map((stat) => (
          <Card key={stat.label} hover>
            <CardBody>
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-xs text-linkedin-gray-50">{stat.label}</p>
                  <p className={cn(
                    "mt-1 text-2xl font-bold",
                    stat.label === "SLA Breached" ? "text-linkedin-red" : "text-linkedin-gray-90",
                  )}>
                    {stat.value}
                  </p>
                </div>
                <div className={cn("flex h-9 w-9 items-center justify-center rounded-lg", stat.color)}>
                  <stat.icon className="h-5 w-5" />
                </div>
              </div>
            </CardBody>
          </Card>
        ))}
      </div>

      {/* Filters */}
      <Card padding="none">
        <CardBody>
          <div className="flex flex-wrap items-center gap-3">
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="rounded-lg border border-linkedin-gray-20 px-3 py-2 text-sm text-linkedin-gray-70 focus:border-linkedin-blue focus:outline-none"
            >
              <option value="all">All Statuses</option>
              <option value="open">Open</option>
              <option value="pending">Pending</option>
              <option value="in_progress">In Progress</option>
              <option value="resolved">Resolved</option>
              <option value="closed">Closed</option>
            </select>
            <select
              value={filterPriority}
              onChange={(e) => setFilterPriority(e.target.value)}
              className="rounded-lg border border-linkedin-gray-20 px-3 py-2 text-sm text-linkedin-gray-70 focus:border-linkedin-blue focus:outline-none"
            >
              <option value="all">All Priorities</option>
              <option value="critical">Critical</option>
              <option value="high">High</option>
              <option value="medium">Medium</option>
              <option value="low">Low</option>
            </select>
            <select
              value={filterAssignee}
              onChange={(e) => setFilterAssignee(e.target.value)}
              className="rounded-lg border border-linkedin-gray-20 px-3 py-2 text-sm text-linkedin-gray-70 focus:border-linkedin-blue focus:outline-none"
            >
              <option value="all">All Assignees</option>
              {assignees.map((a) => (
                <option key={a} value={a}>{a}</option>
              ))}
            </select>
          </div>
        </CardBody>
      </Card>

      {/* Ticket Table */}
      <Card padding="none">
        <CardBody className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-linkedin-gray-20 text-left text-xs text-linkedin-gray-50">
                  <th className="px-4 py-3 font-medium">ID</th>
                  <th className="px-4 py-3 font-medium">Subject</th>
                  <th className="px-4 py-3 font-medium">Customer</th>
                  <th className="px-4 py-3 font-medium">Status</th>
                  <th className="px-4 py-3 font-medium">Priority</th>
                  <th className="px-4 py-3 font-medium">Assignee</th>
                  <th className="px-4 py-3 font-medium">Created</th>
                  <th className="px-4 py-3 font-medium">SLA</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((ticket) => (
                  <tr
                    key={ticket.id}
                    className="border-b border-linkedin-gray-20 last:border-0 cursor-pointer transition-colors hover:bg-linkedin-gray-10"
                  >
                    <td className="px-4 py-3 font-medium text-linkedin-blue">{ticket.id}</td>
                    <td className="px-4 py-3 max-w-[200px] truncate font-medium text-linkedin-gray-90">{ticket.subject}</td>
                    <td className="px-4 py-3 text-linkedin-gray-70">{ticket.customer}</td>
                    <td className="px-4 py-3">
                      <Badge variant={statusBadge[ticket.status]} size="sm">
                        {ticket.status.replace("_", " ")}
                      </Badge>
                    </td>
                    <td className="px-4 py-3">
                      <Badge variant={priorityBadge[ticket.priority]} size="sm">{ticket.priority}</Badge>
                    </td>
                    <td className="px-4 py-3 text-linkedin-gray-70">{ticket.assignee}</td>
                    <td className="px-4 py-3 text-linkedin-gray-50">{ticket.created}</td>
                    <td className="px-4 py-3">
                      {ticket.slaOk ? (
                        <CheckCircle className="h-4 w-4 text-linkedin-green" />
                      ) : (
                        <AlertCircle className="h-4 w-4 text-linkedin-red" />
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardBody>
      </Card>
    </div>
  );
}
