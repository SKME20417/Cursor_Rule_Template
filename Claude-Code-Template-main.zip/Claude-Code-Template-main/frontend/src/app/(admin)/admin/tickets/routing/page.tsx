"use client";

import React, { useState } from "react";
import { cn } from "@/lib/utils/cn";
import {
  Plus,
  GripVertical,
  ChevronDown,
  ChevronUp,
  ToggleLeft,
  ToggleRight,
} from "lucide-react";
import { Card, CardBody } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { PageHeader } from "@/components/layout/page-header";

/* ------------------------------------------------------------------ */
/* Mock Data                                                           */
/* ------------------------------------------------------------------ */

interface RoutingRule {
  id: string;
  priority: number;
  name: string;
  conditionSummary: string;
  action: string;
  enabled: boolean;
  conditionDetail: string;
  actionDetail: string;
}

const initialRules: RoutingRule[] = [
  {
    id: "1",
    priority: 1,
    name: "VIP Customers",
    conditionSummary: "Customer tier = VIP",
    action: "Route to VIP Team",
    enabled: true,
    conditionDetail: "When customer.tier equals 'VIP' OR customer.annual_value > $50,000",
    actionDetail: "Assign to VIP Support team using round-robin. Set priority to High. Send VIP acknowledgment template.",
  },
  {
    id: "2",
    priority: 2,
    name: "Technical Issues",
    conditionSummary: "Category = Technical",
    action: "Route to Tech Support",
    enabled: true,
    conditionDetail: "When ticket.category equals 'Technical' OR ticket.tags contains 'bug', 'integration', 'api'",
    actionDetail: "Assign to Technical Support team. Escalate to Tier 2 if unresolved after 2 hours.",
  },
  {
    id: "3",
    priority: 3,
    name: "Billing Inquiries",
    conditionSummary: "Category = Billing",
    action: "Tier 1 Round Robin",
    enabled: true,
    conditionDetail: "When ticket.category equals 'Billing' OR ticket.subject contains 'invoice', 'payment', 'refund'",
    actionDetail: "Assign to Support Tier 1 using round-robin distribution. Apply Billing SLA policy.",
  },
  {
    id: "4",
    priority: 4,
    name: "High Priority",
    conditionSummary: "Priority = High or Critical",
    action: "Senior Agents",
    enabled: true,
    conditionDetail: "When ticket.priority IN ('high', 'critical') AND ticket.category != 'Technical'",
    actionDetail: "Assign to senior agents with < 5 active tickets. Send Slack notification to #escalations.",
  },
  {
    id: "5",
    priority: 5,
    name: "Off-hours",
    conditionSummary: "Outside business hours",
    action: "AI Bot",
    enabled: false,
    conditionDetail: "When current_time NOT BETWEEN 09:00 AND 18:00 (UTC-5) OR day_of_week IN ('Saturday', 'Sunday')",
    actionDetail: "Route to AI Bot for automated handling. Queue for human review next business day if unresolved.",
  },
];

/* ------------------------------------------------------------------ */
/* Page                                                                */
/* ------------------------------------------------------------------ */

export default function RoutingRulesPage() {
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [rules, setRules] = useState(initialRules);

  function toggleExpand(id: string) {
    setExpandedId(expandedId === id ? null : id);
  }

  function toggleEnabled(id: string) {
    setRules((prev) =>
      prev.map((r) => (r.id === id ? { ...r, enabled: !r.enabled } : r)),
    );
  }

  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="Routing Rules"
        subtitle="Configure ticket routing and assignment"
        actions={
          <button className="flex items-center gap-2 rounded-lg bg-linkedin-blue px-4 py-2 text-sm font-medium text-white transition-colors hover:bg-linkedin-blue-dark">
            <Plus className="h-4 w-4" />
            Add Rule
          </button>
        }
      />

      <Card padding="none">
        <CardBody className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-linkedin-gray-20 text-left text-xs text-linkedin-gray-50">
                  <th className="w-10 px-4 py-3 font-medium" />
                  <th className="px-4 py-3 font-medium">Priority</th>
                  <th className="px-4 py-3 font-medium">Name</th>
                  <th className="px-4 py-3 font-medium">Condition</th>
                  <th className="px-4 py-3 font-medium">Action</th>
                  <th className="px-4 py-3 font-medium">Status</th>
                  <th className="w-10 px-4 py-3 font-medium" />
                </tr>
              </thead>
              <tbody>
                {rules.map((rule) => (
                  <React.Fragment key={rule.id}>
                    <tr className="border-b border-linkedin-gray-20 transition-colors hover:bg-linkedin-gray-10">
                      <td className="px-4 py-3">
                        <GripVertical className="h-4 w-4 cursor-grab text-linkedin-gray-50" />
                      </td>
                      <td className="px-4 py-3">
                        <Badge variant="default" size="sm">#{rule.priority}</Badge>
                      </td>
                      <td className="px-4 py-3 font-medium text-linkedin-gray-90">{rule.name}</td>
                      <td className="px-4 py-3 text-linkedin-gray-70">{rule.conditionSummary}</td>
                      <td className="px-4 py-3 text-linkedin-gray-70">{rule.action}</td>
                      <td className="px-4 py-3">
                        <button onClick={() => toggleEnabled(rule.id)} className="flex items-center">
                          {rule.enabled ? (
                            <ToggleRight className="h-6 w-6 text-linkedin-green" />
                          ) : (
                            <ToggleLeft className="h-6 w-6 text-linkedin-gray-50" />
                          )}
                        </button>
                      </td>
                      <td className="px-4 py-3">
                        <button onClick={() => toggleExpand(rule.id)}>
                          {expandedId === rule.id ? (
                            <ChevronUp className="h-4 w-4 text-linkedin-gray-50" />
                          ) : (
                            <ChevronDown className="h-4 w-4 text-linkedin-gray-50" />
                          )}
                        </button>
                      </td>
                    </tr>
                    {expandedId === rule.id && (
                      <tr className="border-b border-linkedin-gray-20 bg-linkedin-gray-10">
                        <td colSpan={7} className="px-8 py-4">
                          <div className="grid gap-4 sm:grid-cols-2">
                            <div>
                              <p className="mb-1 text-xs font-medium text-linkedin-gray-50">Condition Details</p>
                              <p className="text-sm text-linkedin-gray-90">{rule.conditionDetail}</p>
                            </div>
                            <div>
                              <p className="mb-1 text-xs font-medium text-linkedin-gray-50">Action Details</p>
                              <p className="text-sm text-linkedin-gray-90">{rule.actionDetail}</p>
                            </div>
                          </div>
                        </td>
                      </tr>
                    )}
                  </React.Fragment>
                ))}
              </tbody>
            </table>
          </div>
        </CardBody>
      </Card>
    </div>
  );
}
