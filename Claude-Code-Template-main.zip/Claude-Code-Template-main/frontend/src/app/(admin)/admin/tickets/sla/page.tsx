"use client";

import React from "react";
import { cn } from "@/lib/utils/cn";
import {
  Plus,
  Clock,
  CheckCircle,
  Edit,
  Trash2,
  Shield,
} from "lucide-react";
import { Card, CardBody } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { PageHeader } from "@/components/layout/page-header";

/* ------------------------------------------------------------------ */
/* Mock Data                                                           */
/* ------------------------------------------------------------------ */

interface SLAPolicy {
  id: string;
  name: string;
  firstResponseTarget: string;
  resolutionTarget: string;
  businessHours: string;
  appliedTo: string[];
  variant: "default" | "primary" | "success";
}

const policies: SLAPolicy[] = [
  {
    id: "1",
    name: "Standard",
    firstResponseTarget: "4 hours",
    resolutionTarget: "24 hours",
    businessHours: "Mon-Fri, 9AM-6PM",
    appliedTo: ["General", "Low Priority"],
    variant: "default",
  },
  {
    id: "2",
    name: "Premium",
    firstResponseTarget: "1 hour",
    resolutionTarget: "8 hours",
    businessHours: "Mon-Fri, 8AM-8PM",
    appliedTo: ["High Priority", "Business Tier"],
    variant: "primary",
  },
  {
    id: "3",
    name: "Enterprise",
    firstResponseTarget: "15 minutes",
    resolutionTarget: "4 hours",
    businessHours: "24/7",
    appliedTo: ["Critical", "Enterprise Tier", "VIP"],
    variant: "success",
  },
];

/* ------------------------------------------------------------------ */
/* Page                                                                */
/* ------------------------------------------------------------------ */

export default function SLAPoliciesPage() {
  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="SLA Policies"
        subtitle="Define service level agreements for tickets"
        actions={
          <button className="flex items-center gap-2 rounded-lg bg-linkedin-blue px-4 py-2 text-sm font-medium text-white transition-colors hover:bg-linkedin-blue-dark">
            <Plus className="h-4 w-4" />
            Add Policy
          </button>
        }
      />

      <div className="grid gap-4 lg:grid-cols-3">
        {policies.map((policy) => (
          <Card key={policy.id} hover>
            <CardBody>
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-2">
                  <Shield className="h-5 w-5 text-linkedin-blue" />
                  <h3 className="text-lg font-semibold text-linkedin-gray-90">{policy.name}</h3>
                </div>
                <div className="flex items-center gap-1">
                  <button className="rounded p-1 transition-colors hover:bg-linkedin-gray-10">
                    <Edit className="h-4 w-4 text-linkedin-gray-50" />
                  </button>
                  <button className="rounded p-1 transition-colors hover:bg-red-50">
                    <Trash2 className="h-4 w-4 text-linkedin-gray-50 hover:text-linkedin-red" />
                  </button>
                </div>
              </div>

              <div className="mt-4 flex flex-col gap-3">
                <div className="flex items-center justify-between text-sm">
                  <div className="flex items-center gap-1.5 text-linkedin-gray-50">
                    <Clock className="h-3.5 w-3.5" />
                    <span>First Response</span>
                  </div>
                  <span className="font-medium text-linkedin-gray-90">{policy.firstResponseTarget}</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <div className="flex items-center gap-1.5 text-linkedin-gray-50">
                    <CheckCircle className="h-3.5 w-3.5" />
                    <span>Resolution</span>
                  </div>
                  <span className="font-medium text-linkedin-gray-90">{policy.resolutionTarget}</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-linkedin-gray-50">Business Hours</span>
                  <span className="text-linkedin-gray-90">{policy.businessHours}</span>
                </div>
              </div>

              <div className="mt-4">
                <p className="mb-2 text-xs text-linkedin-gray-50">Applied To</p>
                <div className="flex flex-wrap gap-1.5">
                  {policy.appliedTo.map((tag) => (
                    <Badge key={tag} variant={policy.variant} size="sm">{tag}</Badge>
                  ))}
                </div>
              </div>
            </CardBody>
          </Card>
        ))}
      </div>
    </div>
  );
}
