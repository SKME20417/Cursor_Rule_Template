"use client";

import React from "react";
import { cn } from "@/lib/utils/cn";
import {
  Users,
  MessageSquare,
  Ticket,
  Star,
  Bot,
  BarChart3,
  BookOpen,
  Activity,
  AlertTriangle,
  CheckCircle,
  TrendingUp,
  TrendingDown,
  ArrowRight,
  Wifi,
  Mic,
  Brain,
  Search,
} from "lucide-react";
import { Card, CardBody, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { PageHeader } from "@/components/layout/page-header";

/* ------------------------------------------------------------------ */
/* Mock Data                                                           */
/* ------------------------------------------------------------------ */

const overviewStats = [
  { label: "Total Agents", value: "24", icon: Users, trend: "+12%", trendUp: true },
  { label: "Active Conversations", value: "156", icon: MessageSquare, trend: "+8%", trendUp: true },
  { label: "Tickets Today", value: "89", icon: Ticket, trend: "+5%", trendUp: true },
  { label: "CSAT Score", value: "4.5/5.0", icon: Star, trend: "+3%", trendUp: true },
  { label: "AI Resolution Rate", value: "72%", icon: Bot, trend: "-3%", trendUp: false },
] as const;

const systemServices = [
  { name: "Gateway", status: "healthy" as const, latency: "12ms" },
  { name: "Chat", status: "healthy" as const, latency: "45ms" },
  { name: "Voice", status: "degraded" as const, latency: "230ms" },
  { name: "Tickets", status: "healthy" as const, latency: "38ms" },
  { name: "RAG", status: "healthy" as const, latency: "120ms" },
  { name: "NLP", status: "down" as const, latency: "N/A" },
] as const;

const recentAlerts = [
  { id: "1", message: "NLP service unresponsive — failover active", time: "2 min ago", severity: "critical" as const },
  { id: "2", message: "Voice latency exceeding 200ms threshold", time: "8 min ago", severity: "warning" as const },
  { id: "3", message: "Successful deployment v3.2.1", time: "1 hour ago", severity: "info" as const },
] as const;

const quickActions = [
  { label: "Manage Agents", icon: Users, href: "/admin/agents", color: "bg-linkedin-blue-bg text-linkedin-blue" },
  { label: "Analytics", icon: BarChart3, href: "/admin/analytics", color: "bg-green-50 text-linkedin-green" },
  { label: "AI Config", icon: Bot, href: "/admin/ai-config", color: "bg-purple-50 text-purple-600" },
  { label: "Knowledge Base", icon: BookOpen, href: "/admin/knowledge-base", color: "bg-orange-50 text-linkedin-orange" },
] as const;

/* ------------------------------------------------------------------ */
/* Helpers                                                             */
/* ------------------------------------------------------------------ */

const statusDot: Record<string, string> = {
  healthy: "bg-linkedin-green",
  degraded: "bg-linkedin-orange",
  down: "bg-linkedin-red",
};

const alertSeverityConfig = {
  critical: { variant: "danger" as const, icon: AlertTriangle },
  warning: { variant: "warning" as const, icon: AlertTriangle },
  info: { variant: "primary" as const, icon: CheckCircle },
};

/* ------------------------------------------------------------------ */
/* Page                                                                */
/* ------------------------------------------------------------------ */

export default function AdminDashboardPage() {
  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="Admin Dashboard"
        subtitle="Overview of your support operations"
      />

      {/* Stats Row */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
        {overviewStats.map((stat) => (
          <Card key={stat.label} hover>
            <CardBody>
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-xs text-linkedin-gray-50">{stat.label}</p>
                  <p className="mt-1 text-2xl font-bold text-linkedin-gray-90">
                    {stat.value}
                  </p>
                  <div className="mt-1 flex items-center gap-1">
                    {stat.trendUp ? (
                      <TrendingUp className="h-3 w-3 text-linkedin-green" />
                    ) : (
                      <TrendingDown className="h-3 w-3 text-linkedin-red" />
                    )}
                    <span
                      className={cn(
                        "text-xs font-medium",
                        stat.trendUp ? "text-linkedin-green" : "text-linkedin-red",
                      )}
                    >
                      {stat.trend}
                    </span>
                  </div>
                </div>
                <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-linkedin-blue-bg">
                  <stat.icon className="h-5 w-5 text-linkedin-blue" />
                </div>
              </div>
            </CardBody>
          </Card>
        ))}
      </div>

      {/* System Health */}
      <Card padding="none">
        <CardHeader>
          <div className="flex items-center gap-2">
            <Activity className="h-4 w-4 text-linkedin-blue" />
            <span>System Health</span>
          </div>
        </CardHeader>
        <CardBody>
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {systemServices.map((svc) => (
              <div
                key={svc.name}
                className="flex items-center justify-between rounded-lg border border-linkedin-gray-20 px-4 py-3"
              >
                <div className="flex items-center gap-2">
                  <span className={cn("h-2.5 w-2.5 rounded-full", statusDot[svc.status])} />
                  <span className="text-sm font-medium text-linkedin-gray-90">{svc.name}</span>
                </div>
                <span className="text-xs text-linkedin-gray-50">{svc.latency}</span>
              </div>
            ))}
          </div>
        </CardBody>
      </Card>

      <div className="grid gap-6 lg:grid-cols-2">
        {/* Recent Alerts */}
        <Card padding="none">
          <CardHeader>
            <div className="flex items-center gap-2">
              <AlertTriangle className="h-4 w-4 text-linkedin-orange" />
              <span>Recent Alerts</span>
            </div>
          </CardHeader>
          <CardBody>
            <div className="flex flex-col gap-3">
              {recentAlerts.map((alert) => {
                const cfg = alertSeverityConfig[alert.severity];
                return (
                  <div key={alert.id} className="flex items-start gap-2">
                    <cfg.icon className="mt-0.5 h-4 w-4 shrink-0 text-linkedin-orange" />
                    <div className="flex-1">
                      <p className="text-sm text-linkedin-gray-90">{alert.message}</p>
                      <p className="text-xs text-linkedin-gray-50">{alert.time}</p>
                    </div>
                    <Badge variant={cfg.variant} size="sm">
                      {alert.severity}
                    </Badge>
                  </div>
                );
              })}
            </div>
          </CardBody>
        </Card>

        {/* Quick Actions */}
        <Card padding="none">
          <CardHeader>
            <span>Quick Actions</span>
          </CardHeader>
          <CardBody>
            <div className="grid grid-cols-2 gap-3">
              {quickActions.map((action) => (
                <a
                  key={action.label}
                  href={action.href}
                  className="flex flex-col items-center gap-2 rounded-lg border border-linkedin-gray-20 p-4 transition-shadow hover:shadow-md"
                >
                  <div
                    className={cn(
                      "flex h-10 w-10 items-center justify-center rounded-lg",
                      action.color,
                    )}
                  >
                    <action.icon className="h-5 w-5" />
                  </div>
                  <span className="text-xs font-medium text-linkedin-gray-90 text-center">
                    {action.label}
                  </span>
                  <ArrowRight className="h-3 w-3 text-linkedin-gray-50" />
                </a>
              ))}
            </div>
          </CardBody>
        </Card>
      </div>
    </div>
  );
}
