"use client";

import {
  LayoutDashboard,
  BarChart3,
  Users,
  Ticket,
  Bot,
  BookOpen,
  Radio,
  Puzzle,
  Zap,
  Shield,
  Activity,
  Code2,
  Settings,
} from "lucide-react";
import { ResponsiveShell } from "@/components/layout/responsive-shell";
import type { SidebarItem } from "@/components/layout/sidebar";

const adminSidebarSections: { label: string; items: SidebarItem[] }[] = [
  {
    label: "Overview",
    items: [
      { label: "Dashboard", href: "/admin/dashboard", icon: LayoutDashboard },
    ],
  },
  {
    label: "Support",
    items: [
      { label: "Analytics", href: "/admin/analytics", icon: BarChart3 },
      { label: "Agents", href: "/admin/agents", icon: Users },
      { label: "Tickets", href: "/admin/tickets", icon: Ticket },
    ],
  },
  {
    label: "AI",
    items: [
      { label: "AI Config", href: "/admin/ai-config", icon: Bot },
      { label: "Knowledge Base", href: "/admin/knowledge-base", icon: BookOpen },
    ],
  },
  {
    label: "Channels",
    items: [
      { label: "Channel Config", href: "/admin/channels", icon: Radio },
    ],
  },
  {
    label: "Operations",
    items: [
      { label: "Integrations", href: "/admin/integrations", icon: Puzzle },
      { label: "Automation", href: "/admin/automation", icon: Zap },
    ],
  },
  {
    label: "System",
    items: [
      { label: "Security", href: "/admin/security", icon: Shield },
      { label: "Monitoring", href: "/admin/monitoring", icon: Activity },
      { label: "Developers", href: "/admin/developers", icon: Code2 },
      { label: "Settings", href: "/admin/settings", icon: Settings },
    ],
  },
];

// Flatten for the items prop fallback
const allAdminItems = adminSidebarSections.flatMap((s) => s.items);

export default function AdminLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <ResponsiveShell
      sidebarItems={allAdminItems}
      sidebarSections={adminSidebarSections}
    >
      {children}
    </ResponsiveShell>
  );
}
