export default function Loading() {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-linkedin-gray-05">
      <div className="h-10 w-10 animate-spin rounded-full border-4 border-linkedin-gray-20 border-t-linkedin-blue" />
      <p className="mt-4 text-sm font-medium text-linkedin-gray-50">
        AI Support Copilot
      </p>
    </div>
  );
}
