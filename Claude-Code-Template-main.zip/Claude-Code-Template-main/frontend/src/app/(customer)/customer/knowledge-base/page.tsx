"use client";

import React, { useState } from "react";
import { cn } from "@/lib/utils/cn";
import {
  Search,
  BookOpen,
  CreditCard,
  Wrench,
  Puzzle,
  Code,
  AlertCircle,
  HelpCircle,
  MessageSquare,
  ArrowRight,
  Clock,
} from "lucide-react";

// ----- Inline types -----
interface KBCategory {
  slug: string;
  label: string;
  icon: React.ElementType;
  articleCount: number;
  color: string;
  bg: string;
}

interface PopularArticle {
  id: string;
  title: string;
  snippet: string;
  category: string;
  readTime: string;
}

// ----- Mock data -----
const CATEGORIES: KBCategory[] = [
  {
    slug: "getting-started",
    label: "Getting Started",
    icon: BookOpen,
    articleCount: 12,
    color: "text-linkedin-blue",
    bg: "bg-linkedin-blue-bg",
  },
  {
    slug: "account-billing",
    label: "Account & Billing",
    icon: CreditCard,
    articleCount: 8,
    color: "text-linkedin-green",
    bg: "bg-green-50",
  },
  {
    slug: "technical-support",
    label: "Technical Support",
    icon: Wrench,
    articleCount: 15,
    color: "text-linkedin-orange",
    bg: "bg-orange-50",
  },
  {
    slug: "integrations",
    label: "Integrations",
    icon: Puzzle,
    articleCount: 22,
    color: "text-purple-600",
    bg: "bg-purple-50",
  },
  {
    slug: "api-docs",
    label: "API Docs",
    icon: Code,
    articleCount: 18,
    color: "text-cyan-600",
    bg: "bg-cyan-50",
  },
  {
    slug: "troubleshooting",
    label: "Troubleshooting",
    icon: AlertCircle,
    articleCount: 10,
    color: "text-linkedin-red",
    bg: "bg-red-50",
  },
];

const POPULAR_ARTICLES: PopularArticle[] = [
  {
    id: "art-1",
    title: "How to reset your password",
    snippet:
      "Step-by-step guide to resetting your account password securely.",
    category: "Account & Billing",
    readTime: "3 min read",
  },
  {
    id: "art-2",
    title: "Setting up your first integration",
    snippet:
      "Connect your favorite tools with our platform in just a few clicks.",
    category: "Integrations",
    readTime: "5 min read",
  },
  {
    id: "art-3",
    title: "Understanding API rate limits",
    snippet:
      "Learn about rate limits, quotas, and best practices for API usage.",
    category: "API Docs",
    readTime: "4 min read",
  },
  {
    id: "art-4",
    title: "Troubleshooting webhook delivery failures",
    snippet:
      "Common causes of webhook failures and how to resolve them quickly.",
    category: "Troubleshooting",
    readTime: "6 min read",
  },
];

// ----- Page -----
export default function KnowledgeBaseHomePage() {
  const [query, setQuery] = useState("");

  return (
    <div className="page-container space-y-8">
      {/* Hero search */}
      <div className="rounded-2xl bg-gradient-to-r from-linkedin-blue to-blue-400 px-6 py-14 text-center">
        <h1 className="text-3xl font-bold text-white">How can we help?</h1>
        <p className="mt-2 text-sm text-white/80">
          Search our knowledge base for instant answers
        </p>
        <div className="mx-auto mt-6 max-w-lg relative">
          <Search className="pointer-events-none absolute left-4 top-1/2 h-5 w-5 -translate-y-1/2 text-linkedin-gray-50" />
          <input
            type="text"
            placeholder="Search articles, guides, and FAQs..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="w-full rounded-xl border-0 bg-white py-3.5 pl-12 pr-4 text-sm text-linkedin-gray-90 shadow-lg placeholder:text-linkedin-gray-50 focus:outline-none focus:ring-2 focus:ring-white/60"
          />
        </div>
      </div>

      {/* Category grid */}
      <section>
        <h2 className="mb-4 text-lg font-semibold text-linkedin-gray-90">
          Browse by Category
        </h2>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {CATEGORIES.map((cat) => {
            const Icon = cat.icon;
            return (
              <a
                key={cat.slug}
                href={`/knowledge-base/${cat.slug}`}
                className="group flex items-center gap-4 rounded-lg border border-linkedin-gray-20 bg-linkedin-white p-5 shadow-card transition-shadow hover:shadow-md"
              >
                <div
                  className={cn(
                    "flex h-12 w-12 shrink-0 items-center justify-center rounded-full",
                    cat.bg,
                  )}
                >
                  <Icon className={cn("h-6 w-6", cat.color)} />
                </div>
                <div>
                  <p className="text-sm font-semibold text-linkedin-gray-90 group-hover:text-linkedin-blue transition-colors">
                    {cat.label}
                  </p>
                  <p className="mt-0.5 text-xs text-linkedin-gray-50">
                    {cat.articleCount} articles
                  </p>
                </div>
              </a>
            );
          })}
        </div>
      </section>

      {/* Popular articles */}
      <section>
        <h2 className="mb-4 text-lg font-semibold text-linkedin-gray-90">
          Popular Articles
        </h2>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          {POPULAR_ARTICLES.map((article) => (
            <a
              key={article.id}
              href={`/knowledge-base/articles/${article.id}`}
              className="group rounded-lg border border-linkedin-gray-20 bg-linkedin-white p-5 shadow-card transition-shadow hover:shadow-md"
            >
              <div className="flex items-start justify-between gap-2">
                <h3 className="text-sm font-semibold text-linkedin-gray-90 group-hover:text-linkedin-blue transition-colors">
                  {article.title}
                </h3>
                <ArrowRight className="mt-0.5 h-4 w-4 shrink-0 text-linkedin-gray-30 group-hover:text-linkedin-blue transition-colors" />
              </div>
              <p className="mt-1.5 text-xs text-linkedin-gray-50 line-clamp-2">
                {article.snippet}
              </p>
              <div className="mt-3 flex items-center gap-3 text-xs text-linkedin-gray-50">
                <span className="inline-flex items-center gap-1 rounded-full bg-linkedin-gray-10 px-2 py-0.5">
                  {article.category}
                </span>
                <span className="inline-flex items-center gap-1">
                  <Clock className="h-3 w-3" />
                  {article.readTime}
                </span>
              </div>
            </a>
          ))}
        </div>
      </section>

      {/* CTA banner */}
      <section className="rounded-lg border border-linkedin-gray-20 bg-linkedin-white p-8 text-center shadow-card">
        <HelpCircle className="mx-auto h-10 w-10 text-linkedin-gray-30" />
        <h3 className="mt-3 text-lg font-semibold text-linkedin-gray-90">
          Can&apos;t find what you need?
        </h3>
        <p className="mt-1 text-sm text-linkedin-gray-50">
          Our support team is ready to help you with any question.
        </p>
        <a
          href="/chat"
          className="mt-4 inline-flex items-center gap-2 rounded-full bg-linkedin-blue px-6 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-linkedin-blue-hover"
        >
          <MessageSquare className="h-4 w-4" />
          Contact Support
        </a>
      </section>
    </div>
  );
}
