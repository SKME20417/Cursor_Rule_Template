"use client";

import React from "react";
import { cn } from "@/lib/utils/cn";
import {
  BookOpen,
  CreditCard,
  Wrench,
  Puzzle,
  Code,
  AlertCircle,
  Clock,
  ChevronRight,
} from "lucide-react";

// ----- Inline types -----
interface CategoryArticle {
  id: string;
  title: string;
  snippet: string;
  date: string;
  readTime: string;
}

interface SidebarCategory {
  slug: string;
  label: string;
  icon: React.ElementType;
  count: number;
}

// ----- Mock data -----
const CURRENT_CATEGORY = {
  slug: "technical-support",
  label: "Technical Support",
  description:
    "Find solutions to common technical issues, troubleshoot errors, and get guidance from our engineering team.",
  icon: Wrench,
  color: "text-linkedin-orange",
  bg: "bg-orange-50",
};

const ARTICLES: CategoryArticle[] = [
  {
    id: "art-10",
    title: "Resolving connection timeout errors",
    snippet:
      "Connection timeouts can occur due to network issues, firewall rules, or server overload. This guide covers the most common causes and solutions.",
    date: "2026-03-05",
    readTime: "4 min read",
  },
  {
    id: "art-11",
    title: "How to clear your application cache",
    snippet:
      "Stale cache data can cause unexpected behavior. Learn how to safely clear your cache without losing important data.",
    date: "2026-03-02",
    readTime: "3 min read",
  },
  {
    id: "art-12",
    title: "Debugging failed webhook deliveries",
    snippet:
      "Webhooks can fail for many reasons including network issues, invalid endpoints, or payload size limits.",
    date: "2026-02-28",
    readTime: "6 min read",
  },
  {
    id: "art-13",
    title: "Understanding error codes and messages",
    snippet:
      "A comprehensive reference of all error codes returned by the platform, with explanations and recommended actions.",
    date: "2026-02-25",
    readTime: "8 min read",
  },
  {
    id: "art-14",
    title: "Configuring email notification delivery",
    snippet:
      "Set up and troubleshoot email notifications including SMTP configuration, SPF records, and delivery monitoring.",
    date: "2026-02-20",
    readTime: "5 min read",
  },
  {
    id: "art-15",
    title: "Performance optimization best practices",
    snippet:
      "Tips and techniques to improve your application performance, including caching strategies and query optimization.",
    date: "2026-02-15",
    readTime: "7 min read",
  },
];

const SIDEBAR_CATEGORIES: SidebarCategory[] = [
  { slug: "getting-started", label: "Getting Started", icon: BookOpen, count: 12 },
  { slug: "account-billing", label: "Account & Billing", icon: CreditCard, count: 8 },
  { slug: "technical-support", label: "Technical Support", icon: Wrench, count: 15 },
  { slug: "integrations", label: "Integrations", icon: Puzzle, count: 22 },
  { slug: "api-docs", label: "API Docs", icon: Code, count: 18 },
  { slug: "troubleshooting", label: "Troubleshooting", icon: AlertCircle, count: 10 },
];

// ----- Page -----
export default function KnowledgeBaseCategoryPage() {
  return (
    <div className="page-container space-y-6">
      {/* Breadcrumb */}
      <nav className="flex items-center gap-1.5 text-sm text-linkedin-gray-50">
        <a href="/" className="hover:text-linkedin-blue transition-colors">
          Home
        </a>
        <ChevronRight className="h-3.5 w-3.5" />
        <a
          href="/knowledge-base"
          className="hover:text-linkedin-blue transition-colors"
        >
          Knowledge Base
        </a>
        <ChevronRight className="h-3.5 w-3.5" />
        <span className="font-medium text-linkedin-gray-90">
          {CURRENT_CATEGORY.label}
        </span>
      </nav>

      <div className="flex flex-col gap-6 lg:flex-row">
        {/* Main content */}
        <div className="flex-1 min-w-0 space-y-4">
          {/* Category header */}
          <div className="rounded-lg border border-linkedin-gray-20 bg-linkedin-white p-6 shadow-card">
            <div className="flex items-center gap-3">
              <div
                className={cn(
                  "flex h-12 w-12 items-center justify-center rounded-full",
                  CURRENT_CATEGORY.bg,
                )}
              >
                <CURRENT_CATEGORY.icon
                  className={cn("h-6 w-6", CURRENT_CATEGORY.color)}
                />
              </div>
              <div>
                <h1 className="text-xl font-semibold text-linkedin-gray-90">
                  {CURRENT_CATEGORY.label}
                </h1>
                <p className="mt-0.5 text-sm text-linkedin-gray-50">
                  {ARTICLES.length} articles
                </p>
              </div>
            </div>
            <p className="mt-3 text-sm text-linkedin-gray-70">
              {CURRENT_CATEGORY.description}
            </p>
          </div>

          {/* Article list */}
          <div className="rounded-lg border border-linkedin-gray-20 bg-linkedin-white shadow-card divide-y divide-linkedin-gray-20">
            {ARTICLES.map((article) => (
              <a
                key={article.id}
                href={`/knowledge-base/articles/${article.id}`}
                className="block px-5 py-4 transition-colors hover:bg-linkedin-gray-10"
              >
                <h3 className="text-sm font-semibold text-linkedin-gray-90 hover:text-linkedin-blue transition-colors">
                  {article.title}
                </h3>
                <p className="mt-1 text-xs text-linkedin-gray-50 line-clamp-2">
                  {article.snippet}
                </p>
                <div className="mt-2 flex items-center gap-3 text-xs text-linkedin-gray-50">
                  <span className="inline-flex items-center gap-1">
                    <Clock className="h-3 w-3" />
                    {article.readTime}
                  </span>
                  <span>{article.date}</span>
                </div>
              </a>
            ))}
          </div>
        </div>

        {/* Sidebar */}
        <aside className="w-full lg:w-64 shrink-0">
          <div className="rounded-lg border border-linkedin-gray-20 bg-linkedin-white shadow-card">
            <div className="border-b border-linkedin-gray-20 px-4 py-3">
              <h2 className="text-sm font-semibold text-linkedin-gray-90">
                Other Categories
              </h2>
            </div>
            <div className="divide-y divide-linkedin-gray-20">
              {SIDEBAR_CATEGORIES.map((cat) => {
                const Icon = cat.icon;
                const isActive = cat.slug === CURRENT_CATEGORY.slug;
                return (
                  <a
                    key={cat.slug}
                    href={`/knowledge-base/${cat.slug}`}
                    className={cn(
                      "flex items-center gap-3 px-4 py-3 text-sm transition-colors",
                      isActive
                        ? "bg-linkedin-blue-bg font-semibold text-linkedin-blue"
                        : "text-linkedin-gray-70 hover:bg-linkedin-gray-10",
                    )}
                  >
                    <Icon className="h-4 w-4 shrink-0" />
                    <span className="flex-1">{cat.label}</span>
                    <span className="text-xs text-linkedin-gray-50">
                      {cat.count}
                    </span>
                  </a>
                );
              })}
            </div>
          </div>
        </aside>
      </div>
    </div>
  );
}
