"use client";

import React, { useState } from "react";
import { cn } from "@/lib/utils/cn";
import {
  ChevronRight,
  ThumbsUp,
  ThumbsDown,
  BookOpen,
  MessageSquare,
  Clock,
  User,
} from "lucide-react";

// ----- Inline types -----
interface RelatedArticle {
  id: string;
  title: string;
  category: string;
  readTime: string;
}

// ----- Mock data -----
const MOCK_ARTICLE = {
  id: "art-1",
  title: "How to reset your password",
  category: "Account & Billing",
  categorySlug: "account-billing",
  author: "Support Team",
  updatedAt: "2026-02-15",
  readTime: "3 min read",
  content: `## Steps to Reset Your Password

If you've forgotten your password or need to change it, follow these steps:

### Method 1: From the Login Page

1. Navigate to the login page at app.example.com/login
2. Click the "Forgot Password?" link below the password field
3. Enter the email address associated with your account
4. Check your email for a password reset link
5. Click the link and enter your new password
6. Your password must be at least 12 characters and include uppercase, lowercase, numbers, and special characters

### Method 2: From Account Settings

If you're already logged in:

1. Go to Settings > Security
2. Click "Change Password"
3. Enter your current password
4. Enter and confirm your new password
5. Click "Update Password"

### Code Example

\`\`\`bash
curl -X POST https://api.example.com/auth/reset-password \\
  -H "Content-Type: application/json" \\
  -d '{"email": "user@example.com"}'
\`\`\`

### Troubleshooting

- Didn't receive the email? Check your spam/junk folder. The email comes from noreply@example.com
- Link expired? Password reset links expire after 1 hour. Request a new one.
- Still having issues? Contact our support team for assistance.

### Security Tips

- Use a unique password not shared with other services
- Consider using a password manager
- Enable two-factor authentication for extra security`,
};

const RELATED_ARTICLES: RelatedArticle[] = [
  {
    id: "art-20",
    title: "Setting up two-factor authentication",
    category: "Account & Billing",
    readTime: "4 min read",
  },
  {
    id: "art-21",
    title: "Managing account security settings",
    category: "Account & Billing",
    readTime: "5 min read",
  },
  {
    id: "art-22",
    title: "What to do if your account is compromised",
    category: "Troubleshooting",
    readTime: "3 min read",
  },
];

// ----- Helpers -----
function renderMarkdown(content: string): React.ReactNode[] {
  const lines = content.split("\n");
  const elements: React.ReactNode[] = [];
  let inCodeBlock = false;
  let codeLines: string[] = [];

  lines.forEach((line, i) => {
    if (line.startsWith("```")) {
      if (inCodeBlock) {
        elements.push(
          <pre
            key={`code-${i}`}
            className="my-4 overflow-x-auto rounded-lg bg-linkedin-gray-90 p-4 text-xs text-green-300 font-mono"
          >
            <code>{codeLines.join("\n")}</code>
          </pre>,
        );
        codeLines = [];
        inCodeBlock = false;
      } else {
        inCodeBlock = true;
      }
      return;
    }

    if (inCodeBlock) {
      codeLines.push(line);
      return;
    }

    if (line.startsWith("## ")) {
      elements.push(
        <h2
          key={i}
          className="mt-8 mb-3 text-lg font-semibold text-linkedin-gray-90"
        >
          {line.replace("## ", "")}
        </h2>,
      );
    } else if (line.startsWith("### ")) {
      elements.push(
        <h3
          key={i}
          className="mt-6 mb-2 text-base font-semibold text-linkedin-gray-90"
        >
          {line.replace("### ", "")}
        </h3>,
      );
    } else if (line.match(/^\d+\./)) {
      elements.push(
        <p key={i} className="ml-4 my-1 text-sm text-linkedin-gray-70">
          {line}
        </p>,
      );
    } else if (line.startsWith("- ")) {
      elements.push(
        <li key={i} className="ml-6 my-1 text-sm text-linkedin-gray-70 list-disc">
          {line.replace("- ", "")}
        </li>,
      );
    } else if (line.trim() === "") {
      elements.push(<div key={i} className="h-2" />);
    } else {
      elements.push(
        <p key={i} className="my-1 text-sm text-linkedin-gray-70">
          {line}
        </p>,
      );
    }
  });

  return elements;
}

// ----- Page -----
export default function KnowledgeBaseArticlePage() {
  const [feedback, setFeedback] = useState<"yes" | "no" | null>(null);

  return (
    <div className="mx-auto max-w-3xl px-4 py-8">
      {/* Breadcrumb */}
      <nav className="mb-6 flex items-center gap-1.5 text-sm text-linkedin-gray-50">
        <a href="/" className="hover:text-linkedin-blue transition-colors">
          Home
        </a>
        <ChevronRight className="h-3.5 w-3.5" />
        <a
          href="/knowledge-base"
          className="hover:text-linkedin-blue transition-colors"
        >
          Knowledge Base
        </a>
        <ChevronRight className="h-3.5 w-3.5" />
        <a
          href={`/knowledge-base/${MOCK_ARTICLE.categorySlug}`}
          className="hover:text-linkedin-blue transition-colors"
        >
          {MOCK_ARTICLE.category}
        </a>
        <ChevronRight className="h-3.5 w-3.5" />
        <span className="font-medium text-linkedin-gray-90">
          {MOCK_ARTICLE.title}
        </span>
      </nav>

      {/* Article */}
      <div className="rounded-lg border border-linkedin-gray-20 bg-linkedin-white p-6 shadow-card">
        <h1 className="text-2xl font-bold text-linkedin-gray-90">
          {MOCK_ARTICLE.title}
        </h1>
        <div className="mt-2 flex flex-wrap items-center gap-4 text-xs text-linkedin-gray-50">
          <span className="inline-flex items-center gap-1">
            <User className="h-3 w-3" />
            {MOCK_ARTICLE.author}
          </span>
          <span>Updated {MOCK_ARTICLE.updatedAt}</span>
          <span className="inline-flex items-center gap-1">
            <Clock className="h-3 w-3" />
            {MOCK_ARTICLE.readTime}
          </span>
        </div>

        <div className="mt-6">{renderMarkdown(MOCK_ARTICLE.content)}</div>
      </div>

      {/* Feedback */}
      <div className="mt-6 rounded-lg border border-linkedin-gray-20 bg-linkedin-white p-6 shadow-card text-center">
        {feedback === null ? (
          <>
            <h3 className="text-base font-semibold text-linkedin-gray-90">
              Was this article helpful?
            </h3>
            <div className="mt-3 flex justify-center gap-3">
              <button
                onClick={() => setFeedback("yes")}
                className="inline-flex items-center gap-1.5 rounded-full border border-linkedin-blue px-4 py-2 text-sm font-semibold text-linkedin-blue transition-colors hover:bg-linkedin-blue-bg"
              >
                <ThumbsUp className="h-4 w-4" />
                Yes
              </button>
              <button
                onClick={() => setFeedback("no")}
                className="inline-flex items-center gap-1.5 rounded-full border border-linkedin-gray-30 px-4 py-2 text-sm font-semibold text-linkedin-gray-70 transition-colors hover:bg-linkedin-gray-10"
              >
                <ThumbsDown className="h-4 w-4" />
                No
              </button>
            </div>
          </>
        ) : (
          <p className="text-sm font-medium text-linkedin-green">
            Thank you for your feedback!
          </p>
        )}
      </div>

      {/* Related articles */}
      <div className="mt-6 rounded-lg border border-linkedin-gray-20 bg-linkedin-white shadow-card">
        <div className="border-b border-linkedin-gray-20 px-4 py-3">
          <h3 className="flex items-center gap-2 text-sm font-semibold text-linkedin-gray-90">
            <BookOpen className="h-4 w-4 text-linkedin-blue" />
            Related Articles
          </h3>
        </div>
        <div className="divide-y divide-linkedin-gray-20">
          {RELATED_ARTICLES.map((article) => (
            <a
              key={article.id}
              href={`/knowledge-base/articles/${article.id}`}
              className="flex items-center justify-between px-4 py-3 text-sm transition-colors hover:bg-linkedin-gray-10"
            >
              <div className="flex items-center gap-2">
                <BookOpen className="h-3.5 w-3.5 shrink-0 text-linkedin-gray-50" />
                <span className="text-linkedin-blue">{article.title}</span>
              </div>
              <span className="shrink-0 text-xs text-linkedin-gray-50">
                {article.readTime}
              </span>
            </a>
          ))}
        </div>
      </div>

      {/* CTA */}
      <div className="mt-6 rounded-lg border border-linkedin-gray-20 bg-linkedin-white p-6 shadow-card text-center">
        <h3 className="text-base font-semibold text-linkedin-gray-90">
          Still need help?
        </h3>
        <p className="mt-1 text-sm text-linkedin-gray-50">
          Our support team is ready to assist you.
        </p>
        <a
          href="/chat"
          className="mt-3 inline-flex items-center gap-2 rounded-full bg-linkedin-blue px-5 py-2 text-sm font-semibold text-white transition-colors hover:bg-linkedin-blue-hover"
        >
          <MessageSquare className="h-4 w-4" />
          Start a Chat
        </a>
      </div>
    </div>
  );
}
