"use client";

import React from "react";
import { cn } from "@/lib/utils/cn";
import {
  MessageSquare,
  Ticket,
  BookOpen,
  Phone,
  ArrowRight,
  Clock,
  CheckCircle2,
  AlertCircle,
} from "lucide-react";

// ----- Inline types -----
interface QuickAction {
  label: string;
  description: string;
  icon: React.ElementType;
  href: string;
  color: string;
  bg: string;
}

interface RecentTicket {
  id: string;
  subject: string;
  status: "open" | "in_progress" | "resolved";
  date: string;
}

interface RecentConversation {
  id: string;
  agentName: string;
  lastMessage: string;
  date: string;
  channel: string;
}

interface FaqArticle {
  id: string;
  title: string;
  views: number;
}

// ----- Mock data -----
const QUICK_ACTIONS: QuickAction[] = [
  {
    label: "Start Chat",
    description: "Chat with our AI or an agent",
    icon: MessageSquare,
    href: "/chat",
    color: "text-linkedin-blue",
    bg: "bg-linkedin-blue-bg",
  },
  {
    label: "Submit Ticket",
    description: "Create a support request",
    icon: Ticket,
    href: "/tickets/new",
    color: "text-linkedin-green",
    bg: "bg-green-50",
  },
  {
    label: "Browse KB",
    description: "Search knowledge base articles",
    icon: BookOpen,
    href: "/knowledge-base",
    color: "text-purple-600",
    bg: "bg-purple-50",
  },
  {
    label: "Call Support",
    description: "Request a callback",
    icon: Phone,
    href: "/call",
    color: "text-linkedin-orange",
    bg: "bg-orange-50",
  },
];

const RECENT_TICKETS: RecentTicket[] = [
  {
    id: "TKT-1042",
    subject: "Unable to export analytics report",
    status: "open",
    date: "2026-03-08",
  },
  {
    id: "TKT-1038",
    subject: "Billing discrepancy for February",
    status: "in_progress",
    date: "2026-03-07",
  },
  {
    id: "TKT-1031",
    subject: "Feature request: Dark mode",
    status: "resolved",
    date: "2026-03-05",
  },
  {
    id: "TKT-1025",
    subject: "Login issues with SSO",
    status: "resolved",
    date: "2026-03-03",
  },
  {
    id: "TKT-1019",
    subject: "API rate limit too low",
    status: "resolved",
    date: "2026-03-01",
  },
];

const RECENT_CONVERSATIONS: RecentConversation[] = [
  {
    id: "conv-1",
    agentName: "Mike Chen",
    lastMessage: "The refund will appear within 3-5 business days.",
    date: "2026-03-09",
    channel: "web",
  },
  {
    id: "conv-2",
    agentName: "AI Assistant",
    lastMessage: "Your password has been reset. Please check your email.",
    date: "2026-03-08",
    channel: "email",
  },
  {
    id: "conv-3",
    agentName: "Lisa Park",
    lastMessage: "I've escalated this to our engineering team.",
    date: "2026-03-06",
    channel: "whatsapp",
  },
];

const FAQ_ARTICLES: FaqArticle[] = [
  { id: "faq-1", title: "How to reset your password", views: 12450 },
  { id: "faq-2", title: "Understanding your invoice", views: 8920 },
  { id: "faq-3", title: "Setting up two-factor authentication", views: 7340 },
  { id: "faq-4", title: "Managing team member permissions", views: 5120 },
  { id: "faq-5", title: "API integration getting started guide", views: 4680 },
];

const TICKET_STATUS_CONFIG: Record<
  string,
  { label: string; icon: React.ElementType; className: string }
> = {
  open: {
    label: "Open",
    icon: AlertCircle,
    className: "text-linkedin-orange bg-orange-50",
  },
  in_progress: {
    label: "In Progress",
    icon: Clock,
    className: "text-linkedin-blue bg-linkedin-blue-bg",
  },
  resolved: {
    label: "Resolved",
    icon: CheckCircle2,
    className: "text-linkedin-green bg-green-50",
  },
};

export default function CustomerHomePage() {
  return (
    <div className="page-container space-y-6">
      {/* Welcome banner */}
      <div className="rounded-lg border border-linkedin-gray-20 bg-linkedin-white p-6 shadow-card">
        <h1 className="text-xl font-semibold text-linkedin-gray-90">
          Welcome back, Sarah
        </h1>
        <p className="mt-1 text-sm text-linkedin-gray-50">
          How can we help you today? Choose from the options below or start a
          conversation.
        </p>
      </div>

      {/* Quick actions grid */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {QUICK_ACTIONS.map((action) => {
          const Icon = action.icon;
          return (
            <a
              key={action.label}
              href={action.href}
              className="group flex flex-col items-center gap-3 rounded-lg border border-linkedin-gray-20 bg-linkedin-white p-6 shadow-card transition-shadow hover:shadow-md"
            >
              <div
                className={cn(
                  "flex h-12 w-12 items-center justify-center rounded-full",
                  action.bg,
                )}
              >
                <Icon className={cn("h-6 w-6", action.color)} />
              </div>
              <div className="text-center">
                <p className="text-sm font-semibold text-linkedin-gray-90">
                  {action.label}
                </p>
                <p className="mt-0.5 text-xs text-linkedin-gray-50">
                  {action.description}
                </p>
              </div>
            </a>
          );
        })}
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        {/* Recent tickets */}
        <div className="lg:col-span-2 rounded-lg border border-linkedin-gray-20 bg-linkedin-white shadow-card">
          <div className="flex items-center justify-between border-b border-linkedin-gray-20 px-4 py-3">
            <h2 className="text-sm font-semibold text-linkedin-gray-90">
              Recent Tickets
            </h2>
            <a
              href="/tickets"
              className="inline-flex items-center gap-1 text-xs font-medium text-linkedin-blue hover:text-linkedin-blue-hover"
            >
              View all
              <ArrowRight className="h-3 w-3" />
            </a>
          </div>
          <div className="divide-y divide-linkedin-gray-20">
            {RECENT_TICKETS.map((ticket) => {
              const statusConfig = TICKET_STATUS_CONFIG[ticket.status];
              const StatusIcon = statusConfig.icon;
              return (
                <div
                  key={ticket.id}
                  className="flex items-center justify-between px-4 py-3 transition-colors hover:bg-linkedin-gray-10"
                >
                  <div className="flex items-center gap-3">
                    <span className="text-xs font-mono text-linkedin-gray-50">
                      {ticket.id}
                    </span>
                    <span className="text-sm text-linkedin-gray-70">
                      {ticket.subject}
                    </span>
                  </div>
                  <div className="flex items-center gap-3">
                    <span
                      className={cn(
                        "inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-xs font-medium",
                        statusConfig.className,
                      )}
                    >
                      <StatusIcon className="h-3 w-3" />
                      {statusConfig.label}
                    </span>
                    <span className="text-xs text-linkedin-gray-50">
                      {ticket.date}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Recent conversations */}
        <div className="rounded-lg border border-linkedin-gray-20 bg-linkedin-white shadow-card">
          <div className="flex items-center justify-between border-b border-linkedin-gray-20 px-4 py-3">
            <h2 className="text-sm font-semibold text-linkedin-gray-90">
              Recent Conversations
            </h2>
            <a
              href="/chat"
              className="inline-flex items-center gap-1 text-xs font-medium text-linkedin-blue hover:text-linkedin-blue-hover"
            >
              View all
              <ArrowRight className="h-3 w-3" />
            </a>
          </div>
          <div className="divide-y divide-linkedin-gray-20">
            {RECENT_CONVERSATIONS.map((conv) => (
              <a
                key={conv.id}
                href={`/chat/${conv.id}`}
                className="flex flex-col gap-1 px-4 py-3 transition-colors hover:bg-linkedin-gray-10"
              >
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium text-linkedin-gray-90">
                    {conv.agentName}
                  </span>
                  <span className="text-xs text-linkedin-gray-50">
                    {conv.date}
                  </span>
                </div>
                <p className="truncate text-xs text-linkedin-gray-50">
                  {conv.lastMessage}
                </p>
              </a>
            ))}
          </div>
        </div>
      </div>

      {/* FAQ section */}
      <div className="rounded-lg border border-linkedin-gray-20 bg-linkedin-white shadow-card">
        <div className="flex items-center justify-between border-b border-linkedin-gray-20 px-4 py-3">
          <h2 className="text-sm font-semibold text-linkedin-gray-90">
            Popular Articles
          </h2>
          <a
            href="/knowledge-base"
            className="inline-flex items-center gap-1 text-xs font-medium text-linkedin-blue hover:text-linkedin-blue-hover"
          >
            Browse all
            <ArrowRight className="h-3 w-3" />
          </a>
        </div>
        <div className="divide-y divide-linkedin-gray-20">
          {FAQ_ARTICLES.map((article) => (
            <a
              key={article.id}
              href={`/knowledge-base/${article.id}`}
              className="flex items-center justify-between px-4 py-3 transition-colors hover:bg-linkedin-gray-10"
            >
              <div className="flex items-center gap-2">
                <BookOpen className="h-4 w-4 text-linkedin-gray-50" />
                <span className="text-sm text-linkedin-gray-70">
                  {article.title}
                </span>
              </div>
              <span className="text-xs text-linkedin-gray-50">
                {article.views.toLocaleString()} views
              </span>
            </a>
          ))}
        </div>
      </div>
    </div>
  );
}
