"use client";

import React, { useState } from "react";
import { cn } from "@/lib/utils/cn";
import {
  Send,
  Paperclip,
  Star,
  ChevronLeft,
} from "lucide-react";
import { Avatar } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { TicketStatusBadge } from "@/components/tickets/ticket-status-badge";
import { TicketPriorityBadge } from "@/components/tickets/ticket-priority-badge";
import { TicketTimeline } from "@/components/tickets/ticket-timeline";
import { formatDate, formatRelativeTime } from "@/lib/utils/format-date";

/* ------------------------------------------------------------------ */
/* Mock data                                                           */
/* ------------------------------------------------------------------ */

const MOCK_TICKET = {
  id: "t1",
  shortId: "T-1001",
  subject: "Cannot access billing dashboard",
  status: "in_progress" as const,
  priority: "high" as const,
  category: "Billing",
  assignee: "Agent Mike",
  createdAt: "2026-03-08T10:00:00Z",
  updatedAt: "2026-03-09T08:30:00Z",
};

const MOCK_MESSAGES = [
  {
    id: "m1",
    sender: "Sarah Chen",
    senderType: "customer" as const,
    content:
      "I'm unable to access the billing dashboard. I keep getting a 403 error when I try to navigate to it. I've tried clearing my cache and using a different browser.",
    timestamp: "2026-03-08T10:00:00Z",
  },
  {
    id: "m2",
    sender: "Agent Mike",
    senderType: "agent" as const,
    content:
      "Hi Sarah, thank you for reaching out. I'm looking into this issue now. Could you confirm which plan you're on and whether you've had access to the billing dashboard before?",
    timestamp: "2026-03-08T11:30:00Z",
  },
  {
    id: "m3",
    sender: "Sarah Chen",
    senderType: "customer" as const,
    content:
      "Yes, I'm on the Pro plan and I've accessed the billing dashboard many times before. This started happening yesterday.",
    timestamp: "2026-03-08T12:00:00Z",
  },
];

const MOCK_TIMELINE = [
  {
    id: "e1",
    type: "created" as const,
    description: "Ticket created via email",
    actor: "Sarah Chen",
    timestamp: "2026-03-08T10:00:00Z",
  },
  {
    id: "e2",
    type: "assigned" as const,
    description: "Assigned to Agent Mike",
    actor: "System",
    timestamp: "2026-03-08T10:02:00Z",
  },
  {
    id: "e3",
    type: "status_changed" as const,
    description: "Status changed to In Progress",
    actor: "Agent Mike",
    timestamp: "2026-03-08T11:30:00Z",
  },
];

const MOCK_ATTACHMENTS = [
  { id: "a1", name: "screenshot-error.png", size: "245 KB" },
];

/* ------------------------------------------------------------------ */
/* Page                                                                */
/* ------------------------------------------------------------------ */

export default function CustomerTicketDetailPage() {
  const [replyText, setReplyText] = useState("");
  const [showCsat, setShowCsat] = useState(
    MOCK_TICKET.status === "resolved",
  );
  const [csatRating, setCsatRating] = useState<number | null>(null);

  return (
    <div className="mx-auto max-w-4xl px-4 py-8">
      {/* Back link */}
      <a
        href="/tickets"
        className="mb-4 inline-flex items-center gap-1 text-sm text-linkedin-blue hover:underline"
      >
        <ChevronLeft className="h-4 w-4" />
        Back to Tickets
      </a>

      {/* Ticket header */}
      <Card padding="lg" className="mb-6">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div>
            <p className="text-xs font-mono text-linkedin-gray-50">
              #{MOCK_TICKET.shortId}
            </p>
            <h1 className="mt-1 text-xl font-bold text-linkedin-gray-90">
              {MOCK_TICKET.subject}
            </h1>
            <div className="mt-2 flex flex-wrap items-center gap-2">
              <TicketStatusBadge status={MOCK_TICKET.status} />
              <TicketPriorityBadge priority={MOCK_TICKET.priority} />
              <Badge variant="info" size="sm">
                {MOCK_TICKET.category}
              </Badge>
            </div>
          </div>
          <div className="text-right text-xs text-linkedin-gray-50">
            <p>
              Created {formatDate(MOCK_TICKET.createdAt)}
            </p>
            <p>
              Updated {formatRelativeTime(MOCK_TICKET.updatedAt)}
            </p>
            {MOCK_TICKET.assignee && (
              <p className="mt-1 text-sm text-linkedin-gray-70">
                Agent: <span className="font-medium">{MOCK_TICKET.assignee}</span>
              </p>
            )}
          </div>
        </div>
      </Card>

      {/* Conversation thread */}
      <div className="space-y-4 mb-6">
        {MOCK_MESSAGES.map((msg) => (
          <div
            key={msg.id}
            className={cn(
              "flex gap-3",
              msg.senderType === "customer" ? "flex-row" : "flex-row-reverse",
            )}
          >
            <Avatar
              name={msg.sender}
              size="sm"
              className="mt-1 shrink-0"
            />
            <div
              className={cn(
                "max-w-[75%] rounded-lg p-3",
                msg.senderType === "customer"
                  ? "bg-linkedin-gray-10"
                  : "bg-linkedin-blue-bg",
              )}
            >
              <div className="flex items-center gap-2 mb-1">
                <span className="text-xs font-semibold text-linkedin-gray-90">
                  {msg.sender}
                </span>
                <span className="text-[10px] text-linkedin-gray-50">
                  {formatRelativeTime(msg.timestamp)}
                </span>
              </div>
              <p className="text-sm text-linkedin-gray-70 whitespace-pre-wrap">
                {msg.content}
              </p>
            </div>
          </div>
        ))}
      </div>

      {/* Reply input */}
      {MOCK_TICKET.status !== "closed" && (
        <Card padding="md" className="mb-6">
          <Textarea
            placeholder="Type your reply..."
            value={replyText}
            onChange={(e) => setReplyText(e.target.value)}
            rows={3}
            autoResize
          />
          <div className="mt-3 flex items-center justify-between">
            <button
              type="button"
              className="text-linkedin-gray-50 hover:text-linkedin-blue transition-colors"
              aria-label="Attach file"
            >
              <Paperclip className="h-5 w-5" />
            </button>
            <Button
              size="sm"
              disabled={!replyText.trim()}
              iconLeft={<Send className="h-3.5 w-3.5" />}
            >
              Send Reply
            </Button>
          </div>
        </Card>
      )}

      {/* Attachments */}
      {MOCK_ATTACHMENTS.length > 0 && (
        <Card padding="md" className="mb-6">
          <h3 className="mb-2 text-sm font-semibold text-linkedin-gray-90">
            Attachments
          </h3>
          <ul className="space-y-1">
            {MOCK_ATTACHMENTS.map((att) => (
              <li
                key={att.id}
                className="flex items-center gap-2 text-sm text-linkedin-blue hover:underline cursor-pointer"
              >
                <Paperclip className="h-3.5 w-3.5" />
                {att.name}
                <span className="text-xs text-linkedin-gray-50">
                  ({att.size})
                </span>
              </li>
            ))}
          </ul>
        </Card>
      )}

      {/* Status updates timeline */}
      <Card padding="md" className="mb-6">
        <h3 className="mb-4 text-sm font-semibold text-linkedin-gray-90">
          Activity
        </h3>
        <TicketTimeline events={MOCK_TIMELINE} />
      </Card>

      {/* CSAT prompt */}
      {showCsat && csatRating === null && (
        <Card padding="lg" className="text-center">
          <h3 className="text-lg font-semibold text-linkedin-gray-90">
            How was your experience?
          </h3>
          <p className="mt-1 text-sm text-linkedin-gray-50">
            Your feedback helps us improve our support.
          </p>
          <div className="mt-4 flex justify-center gap-2">
            {[1, 2, 3, 4, 5].map((rating) => (
              <button
                key={rating}
                type="button"
                onClick={() => setCsatRating(rating)}
                className="rounded-full p-2 text-linkedin-gray-30 hover:text-linkedin-orange transition-colors"
                aria-label={`Rate ${rating} out of 5`}
              >
                <Star className="h-8 w-8" />
              </button>
            ))}
          </div>
        </Card>
      )}

      {csatRating !== null && (
        <Card padding="lg" className="text-center">
          <p className="text-sm text-linkedin-green font-medium">
            Thank you for your feedback!
          </p>
        </Card>
      )}
    </div>
  );
}
