"use client";

import React, { useState } from "react";
import { Plus, Inbox } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Tabs } from "@/components/ui/tabs";
import { Pagination } from "@/components/ui/pagination";
import { TicketCard } from "@/components/tickets/ticket-card";

/* ------------------------------------------------------------------ */
/* Mock data                                                           */
/* ------------------------------------------------------------------ */

const MOCK_TICKETS = [
  {
    id: "t1",
    shortId: "T-1001",
    subject: "Cannot access billing dashboard",
    status: "in_progress" as const,
    priority: "high" as const,
    customerName: "Sarah Chen",
    assignee: "Agent Mike",
    lastActivity: "2026-03-09T08:30:00Z",
    slaDeadline: "2026-03-09T18:00:00Z",
    channel: "email",
  },
  {
    id: "t2",
    shortId: "T-1002",
    subject: "Feature request: dark mode support",
    status: "created" as const,
    priority: "low" as const,
    customerName: "Sarah Chen",
    lastActivity: "2026-03-08T14:00:00Z",
    channel: "web",
  },
  {
    id: "t3",
    shortId: "T-1003",
    subject: "API rate limiting returning 429 errors",
    status: "resolved" as const,
    priority: "critical" as const,
    customerName: "Sarah Chen",
    assignee: "Agent Lisa",
    lastActivity: "2026-03-07T09:15:00Z",
    channel: "chat",
  },
  {
    id: "t4",
    shortId: "T-1004",
    subject: "How to export data in CSV format?",
    status: "closed" as const,
    priority: "medium" as const,
    customerName: "Sarah Chen",
    assignee: "Agent Mike",
    lastActivity: "2026-03-05T16:45:00Z",
    channel: "email",
  },
];

const TAB_ITEMS = [
  { key: "all", label: "All" },
  { key: "open", label: "Open" },
  { key: "resolved", label: "Resolved" },
  { key: "closed", label: "Closed" },
];

const OPEN_STATUSES = ["created", "assigned", "in_progress"];

/* ------------------------------------------------------------------ */
/* Page                                                                */
/* ------------------------------------------------------------------ */

export default function CustomerTicketsPage() {
  const [activeTab, setActiveTab] = useState("all");
  const [currentPage, setCurrentPage] = useState(1);
  const perPage = 10;

  const filtered = MOCK_TICKETS.filter((t) => {
    if (activeTab === "all") return true;
    if (activeTab === "open") return OPEN_STATUSES.includes(t.status);
    return t.status === activeTab;
  });

  const totalPages = Math.max(1, Math.ceil(filtered.length / perPage));
  const paginated = filtered.slice(
    (currentPage - 1) * perPage,
    currentPage * perPage,
  );

  return (
    <div className="mx-auto max-w-4xl px-4 py-8">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold text-linkedin-gray-90">
          My Tickets
        </h1>
        <Button
          iconLeft={<Plus className="h-4 w-4" />}
          onClick={() => {
            /* navigate to /tickets/new */
          }}
        >
          Submit New Ticket
        </Button>
      </div>

      {/* Tabs */}
      <Tabs
        items={TAB_ITEMS}
        activeKey={activeTab}
        onChange={(key) => {
          setActiveTab(key);
          setCurrentPage(1);
        }}
        className="mb-6"
      />

      {/* Ticket list */}
      {paginated.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-16 text-center">
          <Inbox className="h-12 w-12 text-linkedin-gray-30 mb-3" />
          <p className="text-lg font-semibold text-linkedin-gray-70">
            No tickets found
          </p>
          <p className="mt-1 text-sm text-linkedin-gray-50">
            {activeTab === "all"
              ? "You haven't submitted any tickets yet."
              : `No ${activeTab} tickets.`}
          </p>
          <Button
            className="mt-4"
            iconLeft={<Plus className="h-4 w-4" />}
            onClick={() => {
              /* navigate */
            }}
          >
            Submit Your First Ticket
          </Button>
        </div>
      ) : (
        <div className="space-y-3">
          {paginated.map((ticket) => (
            <TicketCard
              key={ticket.id}
              ticket={ticket}
              onClick={() => {
                /* navigate to /tickets/[ticketId] */
              }}
            />
          ))}
        </div>
      )}

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="mt-6 flex justify-center">
          <Pagination
            currentPage={currentPage}
            totalPages={totalPages}
            onPageChange={setCurrentPage}
          />
        </div>
      )}
    </div>
  );
}
