"use client";

import React, { useState } from "react";
import { CheckCircle2, Lightbulb, BookOpen } from "lucide-react";
import { Card } from "@/components/ui/card";
import { TicketForm } from "@/components/tickets/ticket-form";

/* ------------------------------------------------------------------ */
/* Mock data                                                           */
/* ------------------------------------------------------------------ */

const SUGGESTED_ARTICLES = [
  {
    id: "kb-1",
    title: "How to reset your password",
    url: "/knowledge-base/articles/kb-1",
  },
  {
    id: "kb-2",
    title: "Understanding billing cycles",
    url: "/knowledge-base/articles/kb-2",
  },
  {
    id: "kb-3",
    title: "API rate limits explained",
    url: "/knowledge-base/articles/kb-3",
  },
];

/* ------------------------------------------------------------------ */
/* Page                                                                */
/* ------------------------------------------------------------------ */

export default function NewTicketPage() {
  const [submitted, setSubmitted] = useState(false);
  const [ticketId, setTicketId] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  function handleSubmit(data: {
    subject: string;
    description: string;
    category: string;
    priority: string;
    channel: string;
    attachments: File[];
  }) {
    setLoading(true);
    // Simulate API call
    setTimeout(() => {
      setTicketId("T-1099");
      setSubmitted(true);
      setLoading(false);
    }, 1500);
  }

  if (submitted && ticketId) {
    return (
      <div className="mx-auto max-w-2xl px-4 py-16 text-center">
        <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-green-50">
          <CheckCircle2 className="h-8 w-8 text-linkedin-green" />
        </div>
        <h1 className="text-2xl font-bold text-linkedin-gray-90">
          Ticket Submitted
        </h1>
        <p className="mt-2 text-sm text-linkedin-gray-50">
          Your ticket{" "}
          <span className="font-mono font-semibold text-linkedin-blue">
            #{ticketId}
          </span>{" "}
          has been created. We&apos;ll get back to you shortly.
        </p>
        <div className="mt-6 flex justify-center gap-3">
          <a
            href={`/tickets/${ticketId}`}
            className="inline-flex items-center rounded-full bg-linkedin-blue px-4 py-2 text-sm font-semibold text-linkedin-white hover:bg-linkedin-blue-hover transition-colors"
          >
            View Ticket
          </a>
          <a
            href="/tickets"
            className="inline-flex items-center rounded-full border border-linkedin-blue px-4 py-2 text-sm font-semibold text-linkedin-blue hover:bg-linkedin-blue-bg transition-colors"
          >
            Back to Tickets
          </a>
        </div>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-4xl px-4 py-8">
      <h1 className="mb-2 text-2xl font-bold text-linkedin-gray-90">
        Submit a New Ticket
      </h1>
      <p className="mb-6 text-sm text-linkedin-gray-50">
        Describe your issue and we&apos;ll route it to the right team.
      </p>

      <div className="flex flex-col gap-6 lg:flex-row">
        {/* Form */}
        <div className="flex-1">
          <Card padding="lg">
            <TicketForm onSubmit={handleSubmit} loading={loading} />
          </Card>
        </div>

        {/* Sidebar suggestions */}
        <aside className="w-full shrink-0 lg:w-72">
          <Card padding="none">
            <div className="border-b border-linkedin-gray-20 px-4 py-3">
              <h3 className="flex items-center gap-2 text-sm font-semibold text-linkedin-gray-90">
                <Lightbulb className="h-4 w-4 text-linkedin-orange" />
                You might find this helpful
              </h3>
            </div>
            <ul className="divide-y divide-linkedin-gray-20">
              {SUGGESTED_ARTICLES.map((article) => (
                <li key={article.id}>
                  <a
                    href={article.url}
                    className="flex items-center gap-2 px-4 py-3 text-sm text-linkedin-blue hover:bg-linkedin-gray-10 transition-colors"
                  >
                    <BookOpen className="h-4 w-4 shrink-0 text-linkedin-gray-50" />
                    {article.title}
                  </a>
                </li>
              ))}
            </ul>
          </Card>
        </aside>
      </div>
    </div>
  );
}
