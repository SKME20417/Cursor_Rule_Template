"use client";

import React, { useState } from "react";
import { cn } from "@/lib/utils/cn";
import { Settings, Bell, Globe, Clock } from "lucide-react";

// ----- Mock data -----
const LANGUAGE_OPTIONS = [
  { value: "en", label: "English" },
  { value: "es", label: "Spanish" },
  { value: "fr", label: "French" },
  { value: "de", label: "German" },
  { value: "pt", label: "Portuguese" },
  { value: "ja", label: "Japanese" },
];

const TIMEZONE_OPTIONS = [
  { value: "America/New_York", label: "Eastern Time (UTC-5)" },
  { value: "America/Chicago", label: "Central Time (UTC-6)" },
  { value: "America/Denver", label: "Mountain Time (UTC-7)" },
  { value: "America/Los_Angeles", label: "Pacific Time (UTC-8)" },
  { value: "Europe/London", label: "GMT (UTC+0)" },
  { value: "Europe/Berlin", label: "CET (UTC+1)" },
  { value: "Asia/Tokyo", label: "JST (UTC+9)" },
];

// ----- Page -----
export default function CustomerSettingsPage() {
  const [emailNotifs, setEmailNotifs] = useState(true);
  const [pushNotifs, setPushNotifs] = useState(true);
  const [smsNotifs, setSmsNotifs] = useState(false);
  const [language, setLanguage] = useState("en");
  const [timezone, setTimezone] = useState("America/New_York");

  return (
    <div className="mx-auto max-w-2xl px-4 py-8">
      <div className="flex items-center gap-3">
        <Settings className="h-6 w-6 text-linkedin-blue" />
        <h1 className="text-2xl font-bold text-linkedin-gray-90">Settings</h1>
      </div>
      <p className="mt-1 text-sm text-linkedin-gray-50">
        Manage your notification and display preferences.
      </p>

      {/* Notification Preferences */}
      <div className="mt-6 rounded-lg border border-linkedin-gray-20 bg-linkedin-white p-6 shadow-card">
        <div className="flex items-center gap-2 mb-4">
          <Bell className="h-5 w-5 text-linkedin-gray-70" />
          <h2 className="text-base font-semibold text-linkedin-gray-90">
            Notification Preferences
          </h2>
        </div>

        <div className="space-y-4">
          <ToggleRow
            label="Email notifications"
            description="Receive ticket and chat updates via email"
            checked={emailNotifs}
            onChange={setEmailNotifs}
          />
          <ToggleRow
            label="Push notifications"
            description="Browser push notifications for real-time updates"
            checked={pushNotifs}
            onChange={setPushNotifs}
          />
          <ToggleRow
            label="SMS notifications"
            description="Text messages for urgent matters only"
            checked={smsNotifs}
            onChange={setSmsNotifs}
          />
        </div>
      </div>

      {/* Language */}
      <div className="mt-4 rounded-lg border border-linkedin-gray-20 bg-linkedin-white p-6 shadow-card">
        <div className="flex items-center gap-2 mb-4">
          <Globe className="h-5 w-5 text-linkedin-gray-70" />
          <h2 className="text-base font-semibold text-linkedin-gray-90">
            Language
          </h2>
        </div>
        <select
          value={language}
          onChange={(e) => setLanguage(e.target.value)}
          className="w-full appearance-none rounded-lg border border-linkedin-gray-30 bg-linkedin-white px-3 py-2 pr-9 text-sm text-linkedin-gray-90 focus:border-linkedin-blue focus:outline-none focus:ring-1 focus:ring-linkedin-blue"
        >
          {LANGUAGE_OPTIONS.map((opt) => (
            <option key={opt.value} value={opt.value}>
              {opt.label}
            </option>
          ))}
        </select>
      </div>

      {/* Timezone */}
      <div className="mt-4 rounded-lg border border-linkedin-gray-20 bg-linkedin-white p-6 shadow-card">
        <div className="flex items-center gap-2 mb-4">
          <Clock className="h-5 w-5 text-linkedin-gray-70" />
          <h2 className="text-base font-semibold text-linkedin-gray-90">
            Timezone
          </h2>
        </div>
        <select
          value={timezone}
          onChange={(e) => setTimezone(e.target.value)}
          className="w-full appearance-none rounded-lg border border-linkedin-gray-30 bg-linkedin-white px-3 py-2 pr-9 text-sm text-linkedin-gray-90 focus:border-linkedin-blue focus:outline-none focus:ring-1 focus:ring-linkedin-blue"
        >
          {TIMEZONE_OPTIONS.map((opt) => (
            <option key={opt.value} value={opt.value}>
              {opt.label}
            </option>
          ))}
        </select>
      </div>

      {/* Save */}
      <div className="mt-6">
        <button className="rounded-full bg-linkedin-blue px-6 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-linkedin-blue-hover">
          Save
        </button>
      </div>
    </div>
  );
}

// ----- Toggle row helper -----
function ToggleRow({
  label,
  description,
  checked,
  onChange,
}: {
  label: string;
  description: string;
  checked: boolean;
  onChange: (v: boolean) => void;
}) {
  return (
    <div className="flex items-center justify-between gap-4">
      <div>
        <p className="text-sm font-medium text-linkedin-gray-90">{label}</p>
        <p className="text-xs text-linkedin-gray-50">{description}</p>
      </div>
      <button
        role="switch"
        aria-checked={checked}
        onClick={() => onChange(!checked)}
        className={cn(
          "relative inline-flex h-6 w-11 shrink-0 items-center rounded-full transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-linkedin-blue focus-visible:ring-offset-2",
          checked ? "bg-linkedin-blue" : "bg-linkedin-gray-30",
        )}
      >
        <span
          className={cn(
            "pointer-events-none block h-4 w-4 rounded-full bg-white shadow-sm transition-transform",
            checked ? "translate-x-6" : "translate-x-1",
          )}
        />
      </button>
    </div>
  );
}
