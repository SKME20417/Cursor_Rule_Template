"use client";

import React, { useState } from "react";
import { VideoRoom, type Participant } from "@/components/video/video-room";
import { Send } from "lucide-react";

const MOCK_PARTICIPANTS: Participant[] = [
  { id: "c1", name: "You", videoEnabled: true, audioEnabled: true, isSpeaking: false },
  { id: "a1", name: "Support Agent", videoEnabled: true, audioEnabled: true, isSpeaking: true },
];

interface ChatMessage {
  id: string;
  sender: "customer" | "agent";
  text: string;
  timestamp: string;
}

const MOCK_MESSAGES: ChatMessage[] = [
  { id: "m1", sender: "agent", text: "Hello! How can I help you today?", timestamp: "2:30 PM" },
  { id: "m2", sender: "customer", text: "I need help with my subscription.", timestamp: "2:31 PM" },
];

function ChatPanel() {
  const [messages, setMessages] = useState<ChatMessage[]>(MOCK_MESSAGES);
  const [input, setInput] = useState("");

  const handleSend = () => {
    if (!input.trim()) return;
    setMessages((prev) => [
      ...prev,
      {
        id: `m${prev.length + 1}`,
        sender: "customer",
        text: input.trim(),
        timestamp: new Date().toLocaleTimeString([], {
          hour: "2-digit",
          minute: "2-digit",
        }),
      },
    ]);
    setInput("");
  };

  return (
    <div className="flex h-full flex-col">
      <div className="flex-1 overflow-y-auto p-3 space-y-2">
        {messages.map((msg) => (
          <div
            key={msg.id}
            className={`flex ${msg.sender === "customer" ? "justify-end" : "justify-start"}`}
          >
            <div
              className={`max-w-[80%] rounded-lg px-3 py-2 text-sm ${
                msg.sender === "customer"
                  ? "bg-linkedin-blue text-linkedin-white"
                  : "bg-linkedin-gray-10 text-linkedin-gray-90"
              }`}
            >
              <p>{msg.text}</p>
              <p
                className={`mt-0.5 text-xs ${
                  msg.sender === "customer"
                    ? "text-blue-200"
                    : "text-linkedin-gray-50"
                }`}
              >
                {msg.timestamp}
              </p>
            </div>
          </div>
        ))}
      </div>
      <div className="border-t border-linkedin-gray-20 p-2">
        <div className="flex items-center gap-2">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && handleSend()}
            placeholder="Type a message..."
            className="flex-1 rounded-full border border-linkedin-gray-30 px-3 py-1.5 text-sm text-linkedin-gray-90 placeholder:text-linkedin-gray-50 focus:border-linkedin-blue focus:outline-none"
          />
          <button
            type="button"
            onClick={handleSend}
            disabled={!input.trim()}
            className="flex h-8 w-8 items-center justify-center rounded-full bg-linkedin-blue text-linkedin-white hover:bg-linkedin-blue-hover disabled:opacity-50 transition-colors"
          >
            <Send className="h-4 w-4" />
          </button>
        </div>
      </div>
    </div>
  );
}

export default function CustomerVideoCallPage() {
  return (
    <div className="h-screen">
      <VideoRoom
        participants={MOCK_PARTICIPANTS}
        localParticipantId="c1"
        isFullScreen
        onLeave={() => {/* navigate away */}}
        chatPanel={<ChatPanel />}
      />
    </div>
  );
}
