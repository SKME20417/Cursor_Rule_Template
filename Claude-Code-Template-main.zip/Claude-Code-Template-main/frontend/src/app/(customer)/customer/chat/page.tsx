"use client";

import React from "react";
import { cn } from "@/lib/utils/cn";
import {
  MessageSquare,
  Plus,
  Clock,
  CheckCircle2,
  AlertCircle,
} from "lucide-react";
import { ChannelBadge } from "@/components/chat/channel-badge";

// ----- Inline types -----
interface CustomerConversation {
  id: string;
  agentName: string;
  lastMessage: string;
  date: string;
  status: "active" | "waiting" | "resolved";
  channel: string;
}

// ----- Mock data -----
const CONVERSATIONS: CustomerConversation[] = [
  {
    id: "conv-1",
    agentName: "Mike Chen",
    lastMessage:
      "The refund will appear on your card within 3-5 business days. Is there anything else?",
    date: "2026-03-09T14:30:00Z",
    status: "active",
    channel: "web",
  },
  {
    id: "conv-2",
    agentName: "AI Assistant",
    lastMessage:
      "Your password has been reset successfully. You should receive a confirmation email.",
    date: "2026-03-08T10:15:00Z",
    status: "resolved",
    channel: "email",
  },
  {
    id: "conv-3",
    agentName: "Lisa Park",
    lastMessage:
      "I've escalated this to our engineering team. They'll look into the integration issue.",
    date: "2026-03-06T16:45:00Z",
    status: "waiting",
    channel: "whatsapp",
  },
  {
    id: "conv-4",
    agentName: "AI Assistant",
    lastMessage:
      "Your subscription has been updated to the Pro plan. The change takes effect immediately.",
    date: "2026-03-04T09:20:00Z",
    status: "resolved",
    channel: "chat",
  },
];

const STATUS_CONFIG: Record<
  string,
  { label: string; icon: React.ElementType; className: string }
> = {
  active: {
    label: "Active",
    icon: MessageSquare,
    className: "text-linkedin-green bg-green-50",
  },
  waiting: {
    label: "Waiting",
    icon: Clock,
    className: "text-linkedin-orange bg-orange-50",
  },
  resolved: {
    label: "Resolved",
    icon: CheckCircle2,
    className: "text-linkedin-gray-50 bg-linkedin-gray-10",
  },
};

function formatDate(dateStr: string): string {
  const date = new Date(dateStr);
  const now = new Date();
  const diffDays = Math.floor(
    (now.getTime() - date.getTime()) / (1000 * 60 * 60 * 24),
  );
  if (diffDays === 0) return "Today";
  if (diffDays === 1) return "Yesterday";
  return date.toLocaleDateString(undefined, {
    month: "short",
    day: "numeric",
  });
}

export default function CustomerChatListPage() {
  return (
    <div className="page-container space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-semibold text-linkedin-gray-90">
            Your Conversations
          </h1>
          <p className="mt-1 text-sm text-linkedin-gray-50">
            View and continue your support conversations.
          </p>
        </div>
        <a
          href="/chat/new"
          className="inline-flex items-center gap-2 rounded-full bg-linkedin-blue px-5 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-linkedin-blue-hover"
        >
          <Plus className="h-4 w-4" />
          Start new conversation
        </a>
      </div>

      {/* Conversation list */}
      {CONVERSATIONS.length === 0 ? (
        <div className="flex flex-col items-center justify-center gap-4 rounded-lg border border-linkedin-gray-20 bg-linkedin-white py-16 shadow-card">
          <div className="flex h-16 w-16 items-center justify-center rounded-full bg-linkedin-blue-bg">
            <MessageSquare className="h-8 w-8 text-linkedin-blue" />
          </div>
          <div className="text-center">
            <p className="text-sm font-semibold text-linkedin-gray-90">
              No conversations yet
            </p>
            <p className="mt-1 text-xs text-linkedin-gray-50">
              Start a new conversation to get help from our team.
            </p>
          </div>
          <a
            href="/chat/new"
            className="inline-flex items-center gap-2 rounded-full bg-linkedin-blue px-5 py-2 text-sm font-semibold text-white transition-colors hover:bg-linkedin-blue-hover"
          >
            <Plus className="h-4 w-4" />
            Start conversation
          </a>
        </div>
      ) : (
        <div className="divide-y divide-linkedin-gray-20 rounded-lg border border-linkedin-gray-20 bg-linkedin-white shadow-card">
          {CONVERSATIONS.map((conv) => {
            const statusConfig = STATUS_CONFIG[conv.status];
            const StatusIcon = statusConfig.icon;
            return (
              <a
                key={conv.id}
                href={`/chat/${conv.id}`}
                className="flex items-center gap-4 px-4 py-4 transition-colors hover:bg-linkedin-gray-10"
              >
                {/* Agent avatar */}
                <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-linkedin-blue-bg text-sm font-semibold text-linkedin-blue">
                  {conv.agentName
                    .split(" ")
                    .map((w) => w[0])
                    .join("")
                    .slice(0, 2)}
                </span>

                {/* Content */}
                <div className="flex min-w-0 flex-1 flex-col gap-0.5">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-semibold text-linkedin-gray-90">
                      {conv.agentName}
                    </span>
                    <ChannelBadge channel={conv.channel} />
                  </div>
                  <p className="truncate text-xs text-linkedin-gray-50">
                    {conv.lastMessage}
                  </p>
                </div>

                {/* Meta */}
                <div className="flex shrink-0 flex-col items-end gap-1">
                  <span className="text-xs text-linkedin-gray-50">
                    {formatDate(conv.date)}
                  </span>
                  <span
                    className={cn(
                      "inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-xs font-medium",
                      statusConfig.className,
                    )}
                  >
                    <StatusIcon className="h-3 w-3" />
                    {statusConfig.label}
                  </span>
                </div>
              </a>
            );
          })}
        </div>
      )}
    </div>
  );
}
