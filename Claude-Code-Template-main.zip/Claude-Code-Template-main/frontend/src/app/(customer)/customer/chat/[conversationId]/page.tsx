"use client";

import React from "react";
import { cn } from "@/lib/utils/cn";
import { ChatWindow } from "@/components/chat/chat-window";
import { CsatPrompt } from "@/components/chat/csat-prompt";

interface CustomerChatPageProps {
  params: { conversationId: string };
}

export default function CustomerChatPage({ params }: CustomerChatPageProps) {
  const { conversationId } = params;

  return (
    <div className="flex h-[calc(100vh-64px)] flex-col">
      <ChatWindow
        conversationId={conversationId}
        className="flex-1"
      />
    </div>
  );
}
