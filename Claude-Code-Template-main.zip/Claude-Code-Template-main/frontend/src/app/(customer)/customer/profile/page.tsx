"use client";

import React, { useState } from "react";
import { cn } from "@/lib/utils/cn";
import {
  Camera,
  Mail,
  Phone,
  Building,
  Globe,
  Download,
  Trash2,
  AlertTriangle,
} from "lucide-react";

// ----- Mock data -----
const MOCK_PROFILE = {
  fullName: "Sarah Johnson",
  email: "sarah.johnson@techcorp.com",
  phone: "+1 (555) 234-5678",
  company: "TechCorp Inc.",
  language: "en",
};

const LANGUAGE_OPTIONS = [
  { value: "en", label: "English" },
  { value: "es", label: "Spanish" },
  { value: "fr", label: "French" },
  { value: "de", label: "German" },
  { value: "pt", label: "Portuguese" },
  { value: "ja", label: "Japanese" },
];

// ----- Page -----
export default function CustomerProfilePage() {
  const [fullName, setFullName] = useState(MOCK_PROFILE.fullName);
  const [phone, setPhone] = useState(MOCK_PROFILE.phone);
  const [company, setCompany] = useState(MOCK_PROFILE.company);
  const [language, setLanguage] = useState(MOCK_PROFILE.language);

  const [emailNotifications, setEmailNotifications] = useState(true);
  const [smsNotifications, setSmsNotifications] = useState(false);
  const [chatNotifications, setChatNotifications] = useState(true);

  return (
    <div className="mx-auto max-w-2xl px-4 py-8">
      <h1 className="text-2xl font-bold text-linkedin-gray-90">My Profile</h1>
      <p className="mt-1 text-sm text-linkedin-gray-50">
        Manage your personal information and preferences
      </p>

      {/* Avatar upload */}
      <div className="mt-6 rounded-lg border border-linkedin-gray-20 bg-linkedin-white p-6 shadow-card">
        <div className="flex items-center gap-6">
          <div className="relative">
            <div className="flex h-20 w-20 items-center justify-center rounded-full bg-linkedin-blue-bg text-2xl font-bold text-linkedin-blue">
              SJ
            </div>
            <button
              className="absolute bottom-0 right-0 flex h-8 w-8 items-center justify-center rounded-full border-2 border-linkedin-white bg-linkedin-blue text-white transition-colors hover:bg-linkedin-blue-hover"
              aria-label="Upload photo"
            >
              <Camera className="h-4 w-4" />
            </button>
          </div>
          <div>
            <p className="text-sm font-semibold text-linkedin-gray-90">
              Profile Photo
            </p>
            <p className="mt-0.5 text-xs text-linkedin-gray-50">
              JPG, PNG or GIF. Max 5MB.
            </p>
          </div>
        </div>

        {/* Form */}
        <div className="mt-6 space-y-4">
          <div>
            <label className="mb-1 block text-sm font-medium text-linkedin-gray-90">
              Full Name
            </label>
            <input
              type="text"
              value={fullName}
              onChange={(e) => setFullName(e.target.value)}
              className="w-full rounded-lg border border-linkedin-gray-30 bg-linkedin-white px-3 py-2 text-sm text-linkedin-gray-90 focus:border-linkedin-blue focus:outline-none focus:ring-1 focus:ring-linkedin-blue"
            />
          </div>

          <div>
            <label className="mb-1 block text-sm font-medium text-linkedin-gray-90">
              Email
            </label>
            <div className="relative">
              <Mail className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-linkedin-gray-50" />
              <input
                type="email"
                value={MOCK_PROFILE.email}
                readOnly
                className="w-full rounded-lg border border-linkedin-gray-30 bg-linkedin-gray-10 pl-9 pr-3 py-2 text-sm text-linkedin-gray-50 cursor-not-allowed"
              />
            </div>
            <p className="mt-1 text-xs text-linkedin-gray-50">
              Contact support to change your email address.
            </p>
          </div>

          <div>
            <label className="mb-1 block text-sm font-medium text-linkedin-gray-90">
              Phone
            </label>
            <div className="relative">
              <Phone className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-linkedin-gray-50" />
              <input
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full rounded-lg border border-linkedin-gray-30 bg-linkedin-white pl-9 pr-3 py-2 text-sm text-linkedin-gray-90 focus:border-linkedin-blue focus:outline-none focus:ring-1 focus:ring-linkedin-blue"
              />
            </div>
          </div>

          <div>
            <label className="mb-1 block text-sm font-medium text-linkedin-gray-90">
              Company
            </label>
            <div className="relative">
              <Building className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-linkedin-gray-50" />
              <input
                type="text"
                value={company}
                onChange={(e) => setCompany(e.target.value)}
                className="w-full rounded-lg border border-linkedin-gray-30 bg-linkedin-white pl-9 pr-3 py-2 text-sm text-linkedin-gray-90 focus:border-linkedin-blue focus:outline-none focus:ring-1 focus:ring-linkedin-blue"
              />
            </div>
          </div>

          <div>
            <label className="mb-1 block text-sm font-medium text-linkedin-gray-90">
              Language
            </label>
            <div className="relative">
              <Globe className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-linkedin-gray-50" />
              <select
                value={language}
                onChange={(e) => setLanguage(e.target.value)}
                className="w-full appearance-none rounded-lg border border-linkedin-gray-30 bg-linkedin-white pl-9 pr-9 py-2 text-sm text-linkedin-gray-90 focus:border-linkedin-blue focus:outline-none focus:ring-1 focus:ring-linkedin-blue"
              >
                {LANGUAGE_OPTIONS.map((opt) => (
                  <option key={opt.value} value={opt.value}>
                    {opt.label}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>

        <button className="mt-6 rounded-full bg-linkedin-blue px-6 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-linkedin-blue-hover">
          Save Changes
        </button>
      </div>

      {/* Divider */}
      <div className="my-6 border-t border-linkedin-gray-20" />

      {/* Notification Preferences */}
      <div className="rounded-lg border border-linkedin-gray-20 bg-linkedin-white p-6 shadow-card">
        <h2 className="text-lg font-semibold text-linkedin-gray-90">
          Notification Preferences
        </h2>
        <p className="mt-1 text-sm text-linkedin-gray-50">
          Choose how you want to receive notifications.
        </p>

        <div className="mt-4 space-y-4">
          <ToggleRow
            label="Email notifications"
            description="Receive updates about your tickets via email"
            checked={emailNotifications}
            onChange={setEmailNotifications}
          />
          <ToggleRow
            label="SMS notifications"
            description="Get text messages for urgent updates"
            checked={smsNotifications}
            onChange={setSmsNotifications}
          />
          <ToggleRow
            label="Chat notifications"
            description="In-app notifications for chat messages"
            checked={chatNotifications}
            onChange={setChatNotifications}
          />
        </div>
      </div>

      {/* Divider */}
      <div className="my-6 border-t border-linkedin-gray-20" />

      {/* Data & Privacy */}
      <div className="rounded-lg border border-linkedin-gray-20 bg-linkedin-white p-6 shadow-card">
        <h2 className="text-lg font-semibold text-linkedin-gray-90">
          Data & Privacy
        </h2>
        <p className="mt-1 text-sm text-linkedin-gray-50">
          Manage your personal data and account.
        </p>

        <div className="mt-4 flex flex-wrap gap-3">
          <button className="inline-flex items-center gap-2 rounded-full border border-linkedin-blue px-5 py-2 text-sm font-semibold text-linkedin-blue transition-colors hover:bg-linkedin-blue-bg">
            <Download className="h-4 w-4" />
            Export my data
          </button>
          <button className="inline-flex items-center gap-2 rounded-full border border-red-300 px-5 py-2 text-sm font-semibold text-linkedin-red transition-colors hover:bg-red-50">
            <Trash2 className="h-4 w-4" />
            Delete my account
          </button>
        </div>
        <div className="mt-3 flex items-start gap-2 rounded-lg bg-orange-50 p-3">
          <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-linkedin-orange" />
          <p className="text-xs text-linkedin-gray-70">
            Deleting your account is permanent and cannot be undone. All your
            data, tickets, and conversation history will be permanently removed.
          </p>
        </div>
      </div>
    </div>
  );
}

// ----- Toggle row helper -----
function ToggleRow({
  label,
  description,
  checked,
  onChange,
}: {
  label: string;
  description: string;
  checked: boolean;
  onChange: (v: boolean) => void;
}) {
  return (
    <div className="flex items-center justify-between gap-4">
      <div>
        <p className="text-sm font-medium text-linkedin-gray-90">{label}</p>
        <p className="text-xs text-linkedin-gray-50">{description}</p>
      </div>
      <button
        role="switch"
        aria-checked={checked}
        onClick={() => onChange(!checked)}
        className={cn(
          "relative inline-flex h-6 w-11 shrink-0 items-center rounded-full transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-linkedin-blue focus-visible:ring-offset-2",
          checked ? "bg-linkedin-blue" : "bg-linkedin-gray-30",
        )}
      >
        <span
          className={cn(
            "pointer-events-none block h-4 w-4 rounded-full bg-white shadow-sm transition-transform",
            checked ? "translate-x-6" : "translate-x-1",
          )}
        />
      </button>
    </div>
  );
}
