"use client";

import { Home, MessageCircle, Ticket, BookOpen, User } from "lucide-react";
import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";
import { MobileNav, type MobileNavItem } from "@/components/layout/mobile-nav";

const mobileNavItems: MobileNavItem[] = [
  { label: "Home", href: "/", icon: Home },
  { label: "Chat", href: "/chat", icon: MessageCircle },
  { label: "Tickets", href: "/tickets", icon: Ticket },
  { label: "KB", href: "/knowledge-base", icon: BookOpen },
  { label: "Account", href: "/account", icon: User },
];

export default function CustomerLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main className="flex-1 page-container pb-20 md:pb-6">{children}</main>
      <Footer className="hidden md:block" />
      <MobileNav items={mobileNavItems} />
    </div>
  );
}
