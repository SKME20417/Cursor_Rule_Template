"use client";

import React, { useEffect, useState, useRef } from "react";
import { cn } from "@/lib/utils/cn";

interface RealTimeCounterProps {
  value: number;
  label: string;
  animationDuration?: number;
  className?: string;
}

function RealTimeCounter({
  value,
  label,
  animationDuration = 600,
  className,
}: RealTimeCounterProps) {
  const [displayValue, setDisplayValue] = useState(value);
  const prevValue = useRef(value);

  useEffect(() => {
    const start = prevValue.current;
    const end = value;
    const diff = end - start;

    if (diff === 0) return;

    const startTime = performance.now();
    let rafId: number;

    const animate = (currentTime: number) => {
      const elapsed = currentTime - startTime;
      const progress = Math.min(elapsed / animationDuration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      setDisplayValue(Math.round(start + diff * eased));

      if (progress < 1) {
        rafId = requestAnimationFrame(animate);
      } else {
        prevValue.current = end;
      }
    };

    rafId = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(rafId);
  }, [value, animationDuration]);

  return (
    <div className={cn("flex items-center gap-3", className)}>
      <span className="relative flex h-2.5 w-2.5">
        <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-linkedin-green opacity-75" />
        <span className="relative inline-flex h-2.5 w-2.5 rounded-full bg-linkedin-green" />
      </span>
      <div>
        <p className="text-2xl font-bold text-linkedin-gray-90 tabular-nums">
          {displayValue.toLocaleString()}
        </p>
        <p className="text-xs text-linkedin-gray-50">{label}</p>
      </div>
    </div>
  );
}

RealTimeCounter.displayName = "RealTimeCounter";

export { RealTimeCounter };
