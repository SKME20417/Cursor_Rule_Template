"use client";

import React from "react";
import { cn } from "@/lib/utils/cn";
import {
  ResponsiveContainer,
  LineChart as RechartsLineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
} from "recharts";

interface Series {
  key: string;
  name: string;
  color?: string;
}

interface LineChartProps {
  data: Record<string, string | number>[];
  xAxisKey: string;
  series: Series[];
  height?: number;
  className?: string;
}

const LINKEDIN_COLORS = [
  "#0a66c2",
  "#057642",
  "#b24020",
  "#915907",
  "#5f3b96",
  "#0073b1",
];

function LineChartComponent({
  data,
  xAxisKey,
  series,
  height = 300,
  className,
}: LineChartProps) {
  return (
    <div className={cn("w-full", className)}>
      <ResponsiveContainer width="100%" height={height}>
        <RechartsLineChart data={data} margin={{ top: 5, right: 20, left: 0, bottom: 5 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#e0e0e0" />
          <XAxis
            dataKey={xAxisKey}
            tick={{ fontSize: 12, fill: "#666666" }}
            tickLine={false}
            axisLine={{ stroke: "#e0e0e0" }}
          />
          <YAxis
            tick={{ fontSize: 12, fill: "#666666" }}
            tickLine={false}
            axisLine={{ stroke: "#e0e0e0" }}
          />
          <Tooltip
            contentStyle={{
              backgroundColor: "#ffffff",
              border: "1px solid #e0e0e0",
              borderRadius: "8px",
              fontSize: "12px",
            }}
          />
          <Legend
            wrapperStyle={{ fontSize: "12px" }}
          />
          {series.map((s, i) => (
            <Line
              key={s.key}
              type="monotone"
              dataKey={s.key}
              name={s.name}
              stroke={s.color ?? LINKEDIN_COLORS[i % LINKEDIN_COLORS.length]}
              strokeWidth={2}
              dot={{ r: 3 }}
              activeDot={{ r: 5 }}
            />
          ))}
        </RechartsLineChart>
      </ResponsiveContainer>
    </div>
  );
}

LineChartComponent.displayName = "LineChart";

export { LineChartComponent as LineChart };
