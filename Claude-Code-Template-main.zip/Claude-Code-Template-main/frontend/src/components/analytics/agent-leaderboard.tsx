"use client";

import React, { useState } from "react";
import { cn } from "@/lib/utils/cn";
import { ChevronUp, ChevronDown, Trophy } from "lucide-react";

interface AgentStats {
  id: string;
  name: string;
  avatarUrl?: string;
  ticketsResolved: number;
  avgCsat: number;
  avgResponseTime: string;
}

interface AgentLeaderboardProps {
  agents: AgentStats[];
  className?: string;
}

type SortKey = "ticketsResolved" | "avgCsat" | "avgResponseTime";

function AgentLeaderboard({ agents, className }: AgentLeaderboardProps) {
  const [sortKey, setSortKey] = useState<SortKey>("ticketsResolved");
  const [sortDir, setSortDir] = useState<"asc" | "desc">("desc");

  const toggleSort = (key: SortKey) => {
    if (sortKey === key) {
      setSortDir((d) => (d === "asc" ? "desc" : "asc"));
    } else {
      setSortKey(key);
      setSortDir("desc");
    }
  };

  const sorted = [...agents].sort((a, b) => {
    const dir = sortDir === "asc" ? 1 : -1;
    if (sortKey === "avgResponseTime") {
      return a.avgResponseTime.localeCompare(b.avgResponseTime) * dir;
    }
    return ((a[sortKey] as number) - (b[sortKey] as number)) * dir;
  });

  const SortIcon = ({ field }: { field: SortKey }) => {
    if (sortKey !== field) return null;
    return sortDir === "asc" ? (
      <ChevronUp className="h-3 w-3" />
    ) : (
      <ChevronDown className="h-3 w-3" />
    );
  };

  const rankColors = ["text-yellow-500", "text-linkedin-gray-50", "text-orange-600"];

  return (
    <div
      className={cn(
        "rounded-lg border border-linkedin-gray-20 bg-linkedin-white",
        className,
      )}
    >
      <div className="border-b border-linkedin-gray-20 px-4 py-3">
        <h3 className="text-sm font-semibold text-linkedin-gray-90">
          Agent Leaderboard
        </h3>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-linkedin-gray-20">
              <th className="px-4 py-2 text-left text-xs font-semibold text-linkedin-gray-50 w-12">
                #
              </th>
              <th className="px-4 py-2 text-left text-xs font-semibold text-linkedin-gray-50">
                Agent
              </th>
              {(
                [
                  ["ticketsResolved", "Resolved"],
                  ["avgCsat", "Avg CSAT"],
                  ["avgResponseTime", "Avg Response"],
                ] as [SortKey, string][]
              ).map(([key, label]) => (
                <th
                  key={key}
                  onClick={() => toggleSort(key)}
                  className="cursor-pointer px-4 py-2 text-left text-xs font-semibold text-linkedin-gray-50 hover:text-linkedin-gray-90 transition-colors"
                >
                  <span className="inline-flex items-center gap-1">
                    {label}
                    <SortIcon field={key} />
                  </span>
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-linkedin-gray-20">
            {sorted.map((agent, idx) => {
              const isTopThree = idx < 3;
              return (
                <tr
                  key={agent.id}
                  className={cn(
                    "transition-colors hover:bg-linkedin-gray-10",
                    isTopThree && "bg-yellow-50/30",
                  )}
                >
                  <td className="px-4 py-2.5">
                    {isTopThree ? (
                      <Trophy className={cn("h-4 w-4", rankColors[idx])} />
                    ) : (
                      <span className="text-xs text-linkedin-gray-50">
                        {idx + 1}
                      </span>
                    )}
                  </td>
                  <td className="px-4 py-2.5">
                    <div className="flex items-center gap-2">
                      <div className="flex h-7 w-7 flex-shrink-0 items-center justify-center rounded-full bg-linkedin-blue-bg text-xs font-bold text-linkedin-blue">
                        {agent.name
                          .split(" ")
                          .map((n) => n[0])
                          .join("")
                          .toUpperCase()
                          .slice(0, 2)}
                      </div>
                      <span className="font-medium text-linkedin-gray-90">
                        {agent.name}
                      </span>
                    </div>
                  </td>
                  <td className="px-4 py-2.5 font-semibold text-linkedin-gray-90 tabular-nums">
                    {agent.ticketsResolved}
                  </td>
                  <td className="px-4 py-2.5">
                    <span
                      className={cn(
                        "font-semibold tabular-nums",
                        agent.avgCsat >= 4.5
                          ? "text-linkedin-green"
                          : agent.avgCsat >= 3.5
                            ? "text-linkedin-orange"
                            : "text-linkedin-red",
                      )}
                    >
                      {agent.avgCsat.toFixed(1)}
                    </span>
                  </td>
                  <td className="px-4 py-2.5 font-mono text-xs text-linkedin-gray-70 tabular-nums">
                    {agent.avgResponseTime}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}

AgentLeaderboard.displayName = "AgentLeaderboard";

export { AgentLeaderboard };
