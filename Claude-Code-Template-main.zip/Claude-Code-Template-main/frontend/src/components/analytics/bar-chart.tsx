"use client";

import React from "react";
import { cn } from "@/lib/utils/cn";
import {
  ResponsiveContainer,
  BarChart as RechartsBarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
} from "recharts";

interface BarSeries {
  key: string;
  name: string;
  color?: string;
  stackId?: string;
}

interface BarChartProps {
  data: Record<string, string | number>[];
  xAxisKey: string;
  series: BarSeries[];
  height?: number;
  className?: string;
}

const LINKEDIN_COLORS = [
  "#0a66c2",
  "#057642",
  "#b24020",
  "#915907",
  "#5f3b96",
  "#0073b1",
];

function BarChartComponent({
  data,
  xAxisKey,
  series,
  height = 300,
  className,
}: BarChartProps) {
  return (
    <div className={cn("w-full", className)}>
      <ResponsiveContainer width="100%" height={height}>
        <RechartsBarChart data={data} margin={{ top: 5, right: 20, left: 0, bottom: 5 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#e0e0e0" />
          <XAxis
            dataKey={xAxisKey}
            tick={{ fontSize: 12, fill: "#666666" }}
            tickLine={false}
            axisLine={{ stroke: "#e0e0e0" }}
          />
          <YAxis
            tick={{ fontSize: 12, fill: "#666666" }}
            tickLine={false}
            axisLine={{ stroke: "#e0e0e0" }}
          />
          <Tooltip
            contentStyle={{
              backgroundColor: "#ffffff",
              border: "1px solid #e0e0e0",
              borderRadius: "8px",
              fontSize: "12px",
            }}
          />
          <Legend wrapperStyle={{ fontSize: "12px" }} />
          {series.map((s, i) => (
            <Bar
              key={s.key}
              dataKey={s.key}
              name={s.name}
              fill={s.color ?? LINKEDIN_COLORS[i % LINKEDIN_COLORS.length]}
              stackId={s.stackId}
              radius={[4, 4, 0, 0]}
            />
          ))}
        </RechartsBarChart>
      </ResponsiveContainer>
    </div>
  );
}

BarChartComponent.displayName = "BarChart";

export { BarChartComponent as BarChart };
