"use client";

import React from "react";
import { cn } from "@/lib/utils/cn";
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ReferenceLine,
} from "recharts";

interface SlaDataPoint {
  period: string;
  met: number;
  breached: number;
}

interface SlaComplianceChartProps {
  data: SlaDataPoint[];
  targetPercentage?: number;
  height?: number;
  className?: string;
}

function SlaComplianceChart({
  data,
  targetPercentage = 95,
  height = 300,
  className,
}: SlaComplianceChartProps) {
  const enriched = data.map((d) => {
    const total = d.met + d.breached;
    return {
      ...d,
      metPct: total > 0 ? Math.round((d.met / total) * 100) : 0,
    };
  });

  return (
    <div className={cn("w-full", className)}>
      <ResponsiveContainer width="100%" height={height}>
        <BarChart data={enriched} margin={{ top: 5, right: 20, left: 0, bottom: 5 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#e0e0e0" />
          <XAxis
            dataKey="period"
            tick={{ fontSize: 12, fill: "#666666" }}
            tickLine={false}
            axisLine={{ stroke: "#e0e0e0" }}
          />
          <YAxis
            tick={{ fontSize: 12, fill: "#666666" }}
            tickLine={false}
            axisLine={{ stroke: "#e0e0e0" }}
          />
          <Tooltip
            contentStyle={{
              backgroundColor: "#ffffff",
              border: "1px solid #e0e0e0",
              borderRadius: "8px",
              fontSize: "12px",
            }}
            formatter={(value: number, name: string) => [
              value,
              name === "met" ? "Met" : "Breached",
            ]}
          />
          <Legend wrapperStyle={{ fontSize: "12px" }} />
          <ReferenceLine
            y={targetPercentage}
            stroke="#b24020"
            strokeDasharray="5 5"
            label={{
              value: `Target: ${targetPercentage}%`,
              position: "right",
              fontSize: 11,
              fill: "#b24020",
            }}
          />
          <Bar
            dataKey="met"
            name="Met"
            stackId="sla"
            fill="#057642"
            radius={[0, 0, 0, 0]}
          />
          <Bar
            dataKey="breached"
            name="Breached"
            stackId="sla"
            fill="#b24020"
            radius={[4, 4, 0, 0]}
          />
        </BarChart>
      </ResponsiveContainer>

      {/* Percentage labels */}
      <div className="mt-2 flex justify-between px-4">
        {enriched.map((d) => (
          <span
            key={d.period}
            className={cn(
              "text-xs font-semibold tabular-nums",
              d.metPct >= targetPercentage
                ? "text-linkedin-green"
                : "text-linkedin-red",
            )}
          >
            {d.metPct}%
          </span>
        ))}
      </div>
    </div>
  );
}

SlaComplianceChart.displayName = "SlaComplianceChart";

export { SlaComplianceChart };
