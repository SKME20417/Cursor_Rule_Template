"use client";

import React, { useState } from "react";
import { cn } from "@/lib/utils/cn";
import { Calendar } from "lucide-react";

interface TimeRangeSelectorProps {
  value: string;
  onChange: (value: string) => void;
  presets?: { label: string; value: string }[];
  showCustom?: boolean;
  className?: string;
}

const DEFAULT_PRESETS = [
  { label: "Today", value: "today" },
  { label: "7d", value: "7d" },
  { label: "30d", value: "30d" },
  { label: "90d", value: "90d" },
];

function TimeRangeSelector({
  value,
  onChange,
  presets = DEFAULT_PRESETS,
  showCustom = true,
  className,
}: TimeRangeSelectorProps) {
  const [showDatePicker, setShowDatePicker] = useState(false);
  const [customStart, setCustomStart] = useState("");
  const [customEnd, setCustomEnd] = useState("");

  const handleCustomApply = () => {
    if (customStart && customEnd) {
      onChange(`${customStart}:${customEnd}`);
      setShowDatePicker(false);
    }
  };

  return (
    <div className={cn("relative flex items-center gap-1", className)}>
      {presets.map((preset) => (
        <button
          key={preset.value}
          type="button"
          onClick={() => onChange(preset.value)}
          className={cn(
            "rounded-full px-3 py-1 text-xs font-medium transition-colors",
            value === preset.value
              ? "bg-linkedin-blue text-linkedin-white"
              : "text-linkedin-gray-50 hover:bg-linkedin-gray-10 hover:text-linkedin-gray-90",
          )}
        >
          {preset.label}
        </button>
      ))}

      {showCustom && (
        <>
          <button
            type="button"
            onClick={() => setShowDatePicker((p) => !p)}
            className={cn(
              "flex items-center gap-1 rounded-full px-3 py-1 text-xs font-medium transition-colors",
              value.includes(":")
                ? "bg-linkedin-blue text-linkedin-white"
                : "text-linkedin-gray-50 hover:bg-linkedin-gray-10 hover:text-linkedin-gray-90",
            )}
          >
            <Calendar className="h-3 w-3" />
            Custom
          </button>

          {showDatePicker && (
            <div className="absolute top-full right-0 mt-1 z-50 rounded-lg border border-linkedin-gray-20 bg-linkedin-white p-3 shadow-lg">
              <div className="flex flex-col gap-2">
                <label className="text-xs text-linkedin-gray-50">
                  Start
                  <input
                    type="date"
                    value={customStart}
                    onChange={(e) => setCustomStart(e.target.value)}
                    className="mt-0.5 block w-full rounded border border-linkedin-gray-30 px-2 py-1 text-xs text-linkedin-gray-90 focus:border-linkedin-blue focus:outline-none"
                  />
                </label>
                <label className="text-xs text-linkedin-gray-50">
                  End
                  <input
                    type="date"
                    value={customEnd}
                    onChange={(e) => setCustomEnd(e.target.value)}
                    className="mt-0.5 block w-full rounded border border-linkedin-gray-30 px-2 py-1 text-xs text-linkedin-gray-90 focus:border-linkedin-blue focus:outline-none"
                  />
                </label>
                <button
                  type="button"
                  onClick={handleCustomApply}
                  disabled={!customStart || !customEnd}
                  className="rounded-full bg-linkedin-blue px-3 py-1 text-xs font-semibold text-linkedin-white hover:bg-linkedin-blue-hover disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  Apply
                </button>
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}

TimeRangeSelector.displayName = "TimeRangeSelector";

export { TimeRangeSelector };
