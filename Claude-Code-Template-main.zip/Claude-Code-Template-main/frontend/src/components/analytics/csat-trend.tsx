"use client";

import React from "react";
import { cn } from "@/lib/utils/cn";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ReferenceLine,
} from "recharts";

interface CsatDataPoint {
  period: string;
  score: number;
}

interface CsatTrendProps {
  data: CsatDataPoint[];
  benchmark?: number;
  height?: number;
  className?: string;
}

function CsatTrend({
  data,
  benchmark = 4.0,
  height = 300,
  className,
}: CsatTrendProps) {
  return (
    <div className={cn("w-full", className)}>
      <ResponsiveContainer width="100%" height={height}>
        <LineChart data={data} margin={{ top: 5, right: 20, left: 0, bottom: 5 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#e0e0e0" />
          <XAxis
            dataKey="period"
            tick={{ fontSize: 12, fill: "#666666" }}
            tickLine={false}
            axisLine={{ stroke: "#e0e0e0" }}
          />
          <YAxis
            domain={[1, 5]}
            ticks={[1, 2, 3, 4, 5]}
            tick={{ fontSize: 12, fill: "#666666" }}
            tickLine={false}
            axisLine={{ stroke: "#e0e0e0" }}
          />
          <Tooltip
            contentStyle={{
              backgroundColor: "#ffffff",
              border: "1px solid #e0e0e0",
              borderRadius: "8px",
              fontSize: "12px",
            }}
            formatter={(value: number) => [value.toFixed(2), "CSAT Score"]}
          />
          <ReferenceLine
            y={benchmark}
            stroke="#86888a"
            strokeDasharray="5 5"
            label={{
              value: `Benchmark: ${benchmark}`,
              position: "right",
              fontSize: 11,
              fill: "#86888a",
            }}
          />
          <Line
            type="monotone"
            dataKey="score"
            name="CSAT Score"
            stroke="#0a66c2"
            strokeWidth={2}
            dot={{ r: 4, fill: "#0a66c2" }}
            activeDot={{ r: 6 }}
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}

CsatTrend.displayName = "CsatTrend";

export { CsatTrend };
