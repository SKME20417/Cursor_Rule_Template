"use client";

import React from "react";
import { cn } from "@/lib/utils/cn";

interface ChartContainerProps {
  title: string;
  description?: string;
  timeRangeSelector?: React.ReactNode;
  loading?: boolean;
  children: React.ReactNode;
  className?: string;
}

function ChartContainer({
  title,
  description,
  timeRangeSelector,
  loading = false,
  children,
  className,
}: ChartContainerProps) {
  return (
    <div
      className={cn(
        "rounded-lg border border-linkedin-gray-20 bg-linkedin-white shadow-card",
        className,
      )}
    >
      <div className="flex flex-wrap items-start justify-between gap-2 border-b border-linkedin-gray-20 px-4 py-3">
        <div>
          <h3 className="text-sm font-semibold text-linkedin-gray-90">
            {title}
          </h3>
          {description && (
            <p className="mt-0.5 text-xs text-linkedin-gray-50">
              {description}
            </p>
          )}
        </div>
        {timeRangeSelector && <div>{timeRangeSelector}</div>}
      </div>

      <div className="p-4">
        {loading ? (
          <div className="flex flex-col gap-3">
            <div className="h-4 w-1/3 animate-pulse rounded bg-linkedin-gray-20" />
            <div className="h-48 w-full animate-pulse rounded-lg bg-linkedin-gray-20" />
          </div>
        ) : (
          children
        )}
      </div>
    </div>
  );
}

ChartContainer.displayName = "ChartContainer";

export { ChartContainer };
