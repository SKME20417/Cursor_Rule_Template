"use client";

import React, { useState } from "react";
import { cn } from "@/lib/utils/cn";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  BarChart,
  Bar,
} from "recharts";

interface AiAccuracyDataPoint {
  period: string;
  accuracy: number;
  fallbackRate: number;
  handoffRate: number;
}

interface ConfidenceBucket {
  range: string;
  count: number;
}

interface AiAccuracyChartProps {
  trendData: AiAccuracyDataPoint[];
  confidenceDistribution?: ConfidenceBucket[];
  height?: number;
  className?: string;
}

function AiAccuracyChart({
  trendData,
  confidenceDistribution = [],
  height = 300,
  className,
}: AiAccuracyChartProps) {
  const [view, setView] = useState<"trend" | "distribution">("trend");

  return (
    <div className={cn("w-full", className)}>
      {confidenceDistribution.length > 0 && (
        <div className="mb-3 flex gap-1">
          <button
            type="button"
            onClick={() => setView("trend")}
            className={cn(
              "rounded-full px-3 py-1 text-xs font-medium transition-colors",
              view === "trend"
                ? "bg-linkedin-blue text-linkedin-white"
                : "text-linkedin-gray-50 hover:bg-linkedin-gray-10",
            )}
          >
            Trend
          </button>
          <button
            type="button"
            onClick={() => setView("distribution")}
            className={cn(
              "rounded-full px-3 py-1 text-xs font-medium transition-colors",
              view === "distribution"
                ? "bg-linkedin-blue text-linkedin-white"
                : "text-linkedin-gray-50 hover:bg-linkedin-gray-10",
            )}
          >
            Confidence Distribution
          </button>
        </div>
      )}

      {view === "trend" ? (
        <ResponsiveContainer width="100%" height={height}>
          <LineChart data={trendData} margin={{ top: 5, right: 20, left: 0, bottom: 5 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#e0e0e0" />
            <XAxis
              dataKey="period"
              tick={{ fontSize: 12, fill: "#666666" }}
              tickLine={false}
              axisLine={{ stroke: "#e0e0e0" }}
            />
            <YAxis
              tick={{ fontSize: 12, fill: "#666666" }}
              tickLine={false}
              axisLine={{ stroke: "#e0e0e0" }}
              domain={[0, 100]}
              unit="%"
            />
            <Tooltip
              contentStyle={{
                backgroundColor: "#ffffff",
                border: "1px solid #e0e0e0",
                borderRadius: "8px",
                fontSize: "12px",
              }}
              formatter={(value: number) => [`${value}%`]}
            />
            <Legend wrapperStyle={{ fontSize: "12px" }} />
            <Line
              type="monotone"
              dataKey="accuracy"
              name="Accuracy"
              stroke="#0a66c2"
              strokeWidth={2}
              dot={{ r: 3 }}
            />
            <Line
              type="monotone"
              dataKey="fallbackRate"
              name="Fallback Rate"
              stroke="#b24020"
              strokeWidth={2}
              dot={{ r: 3 }}
            />
            <Line
              type="monotone"
              dataKey="handoffRate"
              name="Handoff Rate"
              stroke="#915907"
              strokeWidth={2}
              dot={{ r: 3 }}
            />
          </LineChart>
        </ResponsiveContainer>
      ) : (
        <ResponsiveContainer width="100%" height={height}>
          <BarChart
            data={confidenceDistribution}
            margin={{ top: 5, right: 20, left: 0, bottom: 5 }}
          >
            <CartesianGrid strokeDasharray="3 3" stroke="#e0e0e0" />
            <XAxis
              dataKey="range"
              tick={{ fontSize: 12, fill: "#666666" }}
              tickLine={false}
              axisLine={{ stroke: "#e0e0e0" }}
            />
            <YAxis
              tick={{ fontSize: 12, fill: "#666666" }}
              tickLine={false}
              axisLine={{ stroke: "#e0e0e0" }}
            />
            <Tooltip
              contentStyle={{
                backgroundColor: "#ffffff",
                border: "1px solid #e0e0e0",
                borderRadius: "8px",
                fontSize: "12px",
              }}
            />
            <Bar
              dataKey="count"
              name="Responses"
              fill="#0a66c2"
              radius={[4, 4, 0, 0]}
            />
          </BarChart>
        </ResponsiveContainer>
      )}
    </div>
  );
}

AiAccuracyChart.displayName = "AiAccuracyChart";

export { AiAccuracyChart };
