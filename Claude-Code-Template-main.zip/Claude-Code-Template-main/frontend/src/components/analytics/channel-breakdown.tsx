"use client";

import React from "react";
import { cn } from "@/lib/utils/cn";
import {
  MessageSquare,
  Mail,
  Phone,
  Video,
  Globe,
  MessagesSquare,
} from "lucide-react";

interface ChannelData {
  channel: string;
  count: number;
  percentage: number;
}

interface ChannelBreakdownProps {
  data: ChannelData[];
  total?: number;
  className?: string;
}

const channelIcons: Record<string, React.ReactNode> = {
  chat: <MessageSquare className="h-4 w-4" />,
  email: <Mail className="h-4 w-4" />,
  phone: <Phone className="h-4 w-4" />,
  video: <Video className="h-4 w-4" />,
  web: <Globe className="h-4 w-4" />,
  social: <MessagesSquare className="h-4 w-4" />,
};

const channelColors: Record<string, string> = {
  chat: "bg-linkedin-blue",
  email: "bg-linkedin-green",
  phone: "bg-linkedin-orange",
  video: "bg-purple-500",
  web: "bg-cyan-500",
  social: "bg-pink-500",
};

function ChannelBreakdown({
  data,
  total,
  className,
}: ChannelBreakdownProps) {
  const computedTotal = total ?? data.reduce((sum, d) => sum + d.count, 0);

  return (
    <div className={cn("space-y-3", className)}>
      {data.map((item) => {
        const pct =
          item.percentage ?? (computedTotal > 0 ? (item.count / computedTotal) * 100 : 0);
        const barColor = channelColors[item.channel.toLowerCase()] ?? "bg-linkedin-gray-50";
        const icon = channelIcons[item.channel.toLowerCase()] ?? (
          <MessageSquare className="h-4 w-4" />
        );

        return (
          <div key={item.channel} className="flex items-center gap-3">
            <div className="flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-lg bg-linkedin-gray-10 text-linkedin-gray-50">
              {icon}
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between mb-1">
                <span className="text-sm font-medium text-linkedin-gray-90 capitalize">
                  {item.channel}
                </span>
                <div className="flex items-center gap-2">
                  <span className="text-sm font-semibold text-linkedin-gray-90 tabular-nums">
                    {item.count.toLocaleString()}
                  </span>
                  <span className="text-xs text-linkedin-gray-50 tabular-nums w-10 text-right">
                    {Math.round(pct)}%
                  </span>
                </div>
              </div>
              <div className="h-1.5 w-full overflow-hidden rounded-full bg-linkedin-gray-20">
                <div
                  className={cn("h-full rounded-full transition-all duration-500", barColor)}
                  style={{ width: `${pct}%` }}
                />
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}

ChannelBreakdown.displayName = "ChannelBreakdown";

export { ChannelBreakdown };
