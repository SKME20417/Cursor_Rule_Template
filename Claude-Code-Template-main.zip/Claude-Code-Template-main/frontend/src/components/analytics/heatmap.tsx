"use client";

import React, { useState } from "react";
import { cn } from "@/lib/utils/cn";

interface HeatmapData {
  day: number;
  hour: number;
  value: number;
}

interface HeatmapProps {
  data: HeatmapData[];
  maxValue?: number;
  className?: string;
}

const DAYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
const HOURS = Array.from({ length: 24 }, (_, i) =>
  i === 0 ? "12a" : i < 12 ? `${i}a` : i === 12 ? "12p" : `${i - 12}p`,
);

function getIntensityClass(value: number, max: number): string {
  if (max === 0) return "bg-linkedin-gray-10";
  const ratio = value / max;
  if (ratio === 0) return "bg-linkedin-gray-10";
  if (ratio < 0.25) return "bg-blue-100";
  if (ratio < 0.5) return "bg-blue-200";
  if (ratio < 0.75) return "bg-blue-400";
  return "bg-linkedin-blue";
}

function Heatmap({ data, maxValue, className }: HeatmapProps) {
  const [tooltip, setTooltip] = useState<{
    day: number;
    hour: number;
    value: number;
    x: number;
    y: number;
  } | null>(null);

  const computedMax =
    maxValue ?? Math.max(...data.map((d) => d.value), 1);

  const getValue = (day: number, hour: number): number => {
    const entry = data.find((d) => d.day === day && d.hour === hour);
    return entry?.value ?? 0;
  };

  return (
    <div className={cn("w-full overflow-x-auto", className)}>
      <div className="relative min-w-[640px]">
        {/* Hour labels */}
        <div className="flex pl-10 mb-1">
          {HOURS.filter((_, i) => i % 3 === 0).map((label, i) => (
            <span
              key={i}
              className="text-xs text-linkedin-gray-50"
              style={{ width: `${(3 / 24) * 100}%` }}
            >
              {label}
            </span>
          ))}
        </div>

        {/* Grid */}
        {DAYS.map((day, dayIdx) => (
          <div key={day} className="flex items-center gap-1 mb-0.5">
            <span className="w-9 text-xs text-linkedin-gray-50 text-right pr-1">
              {day}
            </span>
            <div className="flex flex-1 gap-0.5">
              {Array.from({ length: 24 }, (_, hour) => {
                const value = getValue(dayIdx, hour);
                return (
                  <div
                    key={hour}
                    className={cn(
                      "flex-1 h-6 rounded-sm cursor-pointer transition-opacity hover:opacity-80",
                      getIntensityClass(value, computedMax),
                    )}
                    onMouseEnter={(e) => {
                      const rect = e.currentTarget.getBoundingClientRect();
                      setTooltip({
                        day: dayIdx,
                        hour,
                        value,
                        x: rect.left + rect.width / 2,
                        y: rect.top,
                      });
                    }}
                    onMouseLeave={() => setTooltip(null)}
                  />
                );
              })}
            </div>
          </div>
        ))}

        {/* Tooltip */}
        {tooltip && (
          <div
            className="fixed z-50 -translate-x-1/2 -translate-y-full whitespace-nowrap rounded-md bg-linkedin-gray-90 px-2.5 py-1.5 text-xs text-linkedin-white shadow-lg pointer-events-none"
            style={{ left: tooltip.x, top: tooltip.y - 8 }}
          >
            {DAYS[tooltip.day]} {HOURS[tooltip.hour]}: {tooltip.value}
          </div>
        )}

        {/* Legend */}
        <div className="mt-3 flex items-center justify-end gap-1 pl-10">
          <span className="text-xs text-linkedin-gray-50 mr-1">Less</span>
          {["bg-linkedin-gray-10", "bg-blue-100", "bg-blue-200", "bg-blue-400", "bg-linkedin-blue"].map(
            (cls) => (
              <div key={cls} className={cn("h-3 w-3 rounded-sm", cls)} />
            ),
          )}
          <span className="text-xs text-linkedin-gray-50 ml-1">More</span>
        </div>
      </div>
    </div>
  );
}

Heatmap.displayName = "Heatmap";

export { Heatmap };
export type { HeatmapData };
