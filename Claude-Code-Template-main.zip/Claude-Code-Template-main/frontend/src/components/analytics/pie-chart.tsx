"use client";

import React from "react";
import { cn } from "@/lib/utils/cn";
import {
  ResponsiveContainer,
  PieChart as RechartsPieChart,
  Pie,
  Cell,
  Legend,
  Tooltip,
} from "recharts";

interface PieChartDataItem {
  name: string;
  value: number;
  color?: string;
}

interface PieChartProps {
  data: PieChartDataItem[];
  centerLabel?: string;
  centerValue?: string | number;
  height?: number;
  className?: string;
}

const LINKEDIN_COLORS = [
  "#0a66c2",
  "#057642",
  "#b24020",
  "#915907",
  "#5f3b96",
  "#0073b1",
  "#86888a",
];

function PieChartComponent({
  data,
  centerLabel,
  centerValue,
  height = 300,
  className,
}: PieChartProps) {
  const total = data.reduce((sum, d) => sum + d.value, 0);

  return (
    <div className={cn("w-full", className)}>
      <ResponsiveContainer width="100%" height={height}>
        <RechartsPieChart>
          <Pie
            data={data}
            cx="50%"
            cy="50%"
            innerRadius={60}
            outerRadius={90}
            paddingAngle={2}
            dataKey="value"
          >
            {data.map((entry, i) => (
              <Cell
                key={entry.name}
                fill={entry.color ?? LINKEDIN_COLORS[i % LINKEDIN_COLORS.length]}
              />
            ))}
          </Pie>
          <Tooltip
            contentStyle={{
              backgroundColor: "#ffffff",
              border: "1px solid #e0e0e0",
              borderRadius: "8px",
              fontSize: "12px",
            }}
          />
          <Legend
            wrapperStyle={{ fontSize: "12px" }}
            layout="horizontal"
            verticalAlign="bottom"
          />
          {/* Center label */}
          {(centerLabel || centerValue !== undefined) && (
            <text
              x="50%"
              y="50%"
              textAnchor="middle"
              dominantBaseline="middle"
            >
              {centerValue !== undefined && (
                <tspan
                  x="50%"
                  dy="-8"
                  fontSize="20"
                  fontWeight="bold"
                  fill="#1d2226"
                >
                  {centerValue ?? total}
                </tspan>
              )}
              {centerLabel && (
                <tspan
                  x="50%"
                  dy="20"
                  fontSize="11"
                  fill="#86888a"
                >
                  {centerLabel}
                </tspan>
              )}
            </text>
          )}
        </RechartsPieChart>
      </ResponsiveContainer>
    </div>
  );
}

PieChartComponent.displayName = "PieChart";

export { PieChartComponent as PieChart };
