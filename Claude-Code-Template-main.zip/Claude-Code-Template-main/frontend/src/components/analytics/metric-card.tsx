"use client";

import React from "react";
import { cn } from "@/lib/utils/cn";
import { TrendingUp, TrendingDown } from "lucide-react";

interface MetricCardProps {
  title: string;
  value: string | number;
  trend?: {
    direction: "up" | "down";
    percentage: number;
    isPositive: boolean;
  };
  subtitle?: string;
  icon?: React.ReactNode;
  className?: string;
}

function MetricCard({
  title,
  value,
  trend,
  subtitle,
  icon,
  className,
}: MetricCardProps) {
  return (
    <div
      className={cn(
        "rounded-lg border border-linkedin-gray-20 bg-linkedin-white p-4 shadow-card",
        className,
      )}
    >
      <div className="flex items-start justify-between">
        <div className="flex-1 min-w-0">
          <p className="text-xs font-medium text-linkedin-gray-50 uppercase tracking-wide">
            {title}
          </p>
          <p className="mt-1 text-2xl font-bold text-linkedin-gray-90 tabular-nums">
            {value}
          </p>
          {trend && (
            <div className="mt-1 flex items-center gap-1">
              {trend.direction === "up" ? (
                <TrendingUp
                  className={cn(
                    "h-3.5 w-3.5",
                    trend.isPositive ? "text-linkedin-green" : "text-linkedin-red",
                  )}
                />
              ) : (
                <TrendingDown
                  className={cn(
                    "h-3.5 w-3.5",
                    trend.isPositive ? "text-linkedin-green" : "text-linkedin-red",
                  )}
                />
              )}
              <span
                className={cn(
                  "text-xs font-semibold",
                  trend.isPositive ? "text-linkedin-green" : "text-linkedin-red",
                )}
              >
                {trend.percentage}%
              </span>
            </div>
          )}
          {subtitle && (
            <p className="mt-1 text-xs text-linkedin-gray-50">{subtitle}</p>
          )}
        </div>
        {icon && (
          <div className="flex h-10 w-10 flex-shrink-0 items-center justify-center rounded-full bg-linkedin-blue-bg text-linkedin-blue">
            {icon}
          </div>
        )}
      </div>
    </div>
  );
}

MetricCard.displayName = "MetricCard";

export { MetricCard };
