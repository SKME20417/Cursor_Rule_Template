"use client";

import React from "react";
import { cn } from "@/lib/utils/cn";
import type { WorkflowNode as WorkflowNodeType } from "@/types/automation.types";
import { ActionType } from "@/types/automation.types";
import { Zap, GitBranch, Play, Clock, X } from "lucide-react";

interface WorkflowNodeProps {
  node: WorkflowNodeType;
  isSelected: boolean;
  description?: string;
  onClick: () => void;
  onDelete?: () => void;
}

type NodeKind = "trigger" | "condition" | "action" | "delay";

function getNodeKind(actionType: ActionType): NodeKind {
  if (actionType === ActionType.CONDITION) return "condition";
  if (actionType === ActionType.DELAY) return "delay";
  return "action";
}

const kindConfig: Record<NodeKind, { bg: string; border: string; iconBg: string; icon: React.ReactNode; badge: string }> = {
  trigger: {
    bg: "bg-green-50",
    border: "border-green-300",
    iconBg: "bg-green-100",
    icon: <Play className="h-4 w-4 text-green-600" />,
    badge: "Trigger",
  },
  condition: {
    bg: "bg-yellow-50",
    border: "border-yellow-300",
    iconBg: "bg-yellow-100",
    icon: <GitBranch className="h-4 w-4 text-yellow-600" />,
    badge: "Condition",
  },
  action: {
    bg: "bg-blue-50",
    border: "border-blue-300",
    iconBg: "bg-blue-100",
    icon: <Zap className="h-4 w-4 text-blue-600" />,
    badge: "Action",
  },
  delay: {
    bg: "bg-gray-50",
    border: "border-gray-300",
    iconBg: "bg-gray-100",
    icon: <Clock className="h-4 w-4 text-gray-600" />,
    badge: "Delay",
  },
};

export function WorkflowNode({ node, isSelected, description, onClick, onDelete }: WorkflowNodeProps) {
  const kind = getNodeKind(node.action.type);
  const config = kindConfig[kind];

  return (
    <div className="group relative" title={description}>
      <button
        type="button"
        onClick={onClick}
        className={cn(
          "relative flex w-[180px] items-center gap-3 rounded-lg border-2 p-3 text-left shadow-sm transition-all",
          config.bg,
          config.border,
          isSelected && "ring-2 ring-linkedin-blue ring-offset-2",
          "hover:shadow-md",
        )}
        style={{ minHeight: "80px" }}
      >
        {/* Input connection point (top) */}
        <div className="absolute left-1/2 -top-1.5 h-3 w-3 -translate-x-1/2 rounded-full border-2 border-linkedin-gray-40 bg-linkedin-white" />

        {/* Icon */}
        <div className={cn("flex h-8 w-8 shrink-0 items-center justify-center rounded-lg", config.iconBg)}>
          {config.icon}
        </div>

        {/* Label + badge */}
        <div className="flex-1 overflow-hidden">
          <p className="truncate text-sm font-medium text-linkedin-gray-90">{node.label}</p>
          <span className="text-[10px] font-medium uppercase tracking-wide text-linkedin-gray-50">
            {config.badge}
          </span>
        </div>

        {/* Output connection point (bottom) */}
        <div className="absolute left-1/2 -bottom-1.5 h-3 w-3 -translate-x-1/2 rounded-full border-2 border-linkedin-gray-40 bg-linkedin-white" />
      </button>

      {/* Delete button on hover */}
      {onDelete && (
        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            onDelete();
          }}
          aria-label="Delete node"
          className="absolute -top-2 -right-2 z-10 flex h-5 w-5 items-center justify-center rounded-full bg-linkedin-red text-linkedin-white opacity-0 shadow-sm transition-opacity group-hover:opacity-100"
        >
          <X className="h-3 w-3" />
        </button>
      )}

      {/* Hover tooltip */}
      {description && (
        <div className="pointer-events-none absolute -bottom-8 left-1/2 z-20 -translate-x-1/2 whitespace-nowrap rounded bg-linkedin-gray-90 px-2 py-1 text-[10px] text-linkedin-white opacity-0 shadow-md transition-opacity group-hover:opacity-100">
          {description}
        </div>
      )}
    </div>
  );
}
