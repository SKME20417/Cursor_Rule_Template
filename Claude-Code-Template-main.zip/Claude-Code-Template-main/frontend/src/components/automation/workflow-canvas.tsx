"use client";

import React, { useCallback, useRef, useState } from "react";
import { cn } from "@/lib/utils/cn";
import { Plus, ZoomIn, ZoomOut } from "lucide-react";
import type { WorkflowNode as WorkflowNodeType, WorkflowEdge } from "@/types/automation.types";
import { WorkflowNode } from "./workflow-node";

interface WorkflowCanvasProps {
  nodes: WorkflowNodeType[];
  edges: WorkflowEdge[];
  selectedNodeId: string | null;
  onSelectNode: (nodeId: string | null) => void;
  onAddNode: () => void;
  className?: string;
}

export function WorkflowCanvas({
  nodes,
  edges,
  selectedNodeId,
  onSelectNode,
  onAddNode,
  className,
}: WorkflowCanvasProps) {
  const canvasRef = useRef<HTMLDivElement>(null);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const [zoom, setZoom] = useState(1);
  const [isPanning, setIsPanning] = useState(false);
  const panStartRef = useRef({ x: 0, y: 0, panX: 0, panY: 0 });

  const handleZoomIn = () => setZoom((z) => Math.min(z + 0.1, 2));
  const handleZoomOut = () => setZoom((z) => Math.max(z - 0.1, 0.3));

  const handleMouseDown = useCallback(
    (e: React.MouseEvent) => {
      // Only pan when clicking on the canvas background, not on nodes
      if ((e.target as HTMLElement).closest("[data-workflow-node]")) return;

      setIsPanning(true);
      panStartRef.current = {
        x: e.clientX,
        y: e.clientY,
        panX: pan.x,
        panY: pan.y,
      };
    },
    [pan],
  );

  const handleMouseMove = useCallback(
    (e: React.MouseEvent) => {
      if (!isPanning) return;
      const dx = e.clientX - panStartRef.current.x;
      const dy = e.clientY - panStartRef.current.y;
      setPan({
        x: panStartRef.current.panX + dx,
        y: panStartRef.current.panY + dy,
      });
    },
    [isPanning],
  );

  const handleMouseUp = useCallback(() => {
    setIsPanning(false);
  }, []);

  /** Render SVG connection lines between linked nodes. */
  function renderEdges() {
    return edges.map((edge) => {
      const source = nodes.find((n) => n.id === edge.sourceNodeId);
      const target = nodes.find((n) => n.id === edge.targetNodeId);
      if (!source || !target) return null;

      const sx = source.positionX + 120; // center-right of source
      const sy = source.positionY + 40;  // vertical center
      const tx = target.positionX;       // left edge of target
      const ty = target.positionY + 40;

      const midX = (sx + tx) / 2;

      return (
        <g key={edge.id}>
          <path
            d={`M ${sx} ${sy} C ${midX} ${sy}, ${midX} ${ty}, ${tx} ${ty}`}
            fill="none"
            stroke="#0a66c2"
            strokeWidth={2}
            strokeOpacity={0.5}
          />
          {edge.conditionLabel && (
            <text
              x={midX}
              y={(sy + ty) / 2 - 8}
              textAnchor="middle"
              className="fill-linkedin-gray-60 text-[10px]"
            >
              {edge.conditionLabel}
            </text>
          )}
        </g>
      );
    });
  }

  return (
    <div
      ref={canvasRef}
      className={cn(
        "relative overflow-hidden rounded-lg border border-linkedin-gray-20 bg-linkedin-gray-05",
        isPanning ? "cursor-grabbing" : "cursor-grab",
        className,
      )}
      style={{ minHeight: 500 }}
      onMouseDown={handleMouseDown}
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
      onMouseLeave={handleMouseUp}
    >
      {/* Grid dot background pattern */}
      <div
        className="pointer-events-none absolute inset-0"
        style={{
          backgroundImage: "radial-gradient(circle, #d1d5db 1px, transparent 1px)",
          backgroundSize: "24px 24px",
        }}
      />

      {/* Panned + zoomed content layer */}
      <div
        className="absolute inset-0 origin-top-left"
        style={{ transform: `translate(${pan.x}px, ${pan.y}px) scale(${zoom})` }}
      >
        {/* Edge SVG overlay */}
        <svg className="pointer-events-none absolute inset-0 h-[2000px] w-[3000px]">
          {renderEdges()}
        </svg>

        {/* Nodes */}
        {nodes.map((node) => (
          <div
            key={node.id}
            className="absolute"
            style={{ left: node.positionX, top: node.positionY }}
            data-workflow-node
          >
            <WorkflowNode
              node={node}
              isSelected={selectedNodeId === node.id}
              onClick={() => onSelectNode(node.id)}
            />
          </div>
        ))}
      </div>

      {/* Zoom controls */}
      <div className="absolute top-4 right-4 z-10 flex flex-col gap-1 rounded-lg border border-linkedin-gray-20 bg-linkedin-white shadow-sm">
        <button
          type="button"
          onClick={handleZoomIn}
          aria-label="Zoom in"
          className="flex h-8 w-8 items-center justify-center rounded-t-lg text-linkedin-gray-50 transition-colors hover:bg-linkedin-gray-10 hover:text-linkedin-gray-90"
        >
          <ZoomIn className="h-4 w-4" />
        </button>
        <div className="border-t border-linkedin-gray-20 px-1 py-0.5 text-center text-[10px] tabular-nums text-linkedin-gray-50">
          {Math.round(zoom * 100)}%
        </div>
        <button
          type="button"
          onClick={handleZoomOut}
          aria-label="Zoom out"
          className="flex h-8 w-8 items-center justify-center rounded-b-lg text-linkedin-gray-50 transition-colors hover:bg-linkedin-gray-10 hover:text-linkedin-gray-90"
        >
          <ZoomOut className="h-4 w-4" />
        </button>
      </div>

      {/* Minimap */}
      {nodes.length > 0 && (
        <div className="absolute bottom-14 right-4 z-10 h-20 w-32 rounded-md border border-linkedin-gray-20 bg-linkedin-white/90 p-1 shadow-sm">
          <div className="relative h-full w-full overflow-hidden">
            {nodes.map((node) => {
              const maxX = Math.max(...nodes.map((n) => n.positionX + 240), 1);
              const maxY = Math.max(...nodes.map((n) => n.positionY + 60), 1);
              const x = (node.positionX / maxX) * 100;
              const y = (node.positionY / maxY) * 100;
              return (
                <div
                  key={node.id}
                  className={cn(
                    "absolute h-1.5 w-3 rounded-sm",
                    selectedNodeId === node.id
                      ? "bg-linkedin-blue"
                      : "bg-linkedin-gray-50",
                  )}
                  style={{ left: `${x}%`, top: `${y}%` }}
                />
              );
            })}
          </div>
        </div>
      )}

      {/* Add node button */}
      <button
        type="button"
        onClick={onAddNode}
        className="absolute bottom-4 right-4 z-10 flex items-center gap-2 rounded-full bg-linkedin-blue px-4 py-2.5 text-sm font-semibold text-linkedin-white shadow-lg transition-colors hover:bg-linkedin-blue-hover"
      >
        <Plus className="h-4 w-4" />
        Add Step
      </button>
    </div>
  );
}
