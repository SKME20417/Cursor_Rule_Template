"use client";

import React, { useCallback, useState } from "react";
import { cn } from "@/lib/utils/cn";
import { Plus, Trash2 } from "lucide-react";
import { Select } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

type LogicOperator = "AND" | "OR";

interface Condition {
  id: string;
  field: string;
  operator: string;
  value: string;
}

interface ConditionGroup {
  conditions: Condition[];
  logic: LogicOperator;
}

const FIELD_OPTIONS = [
  { value: "status", label: "Status" },
  { value: "priority", label: "Priority" },
  { value: "channel", label: "Channel" },
  { value: "category", label: "Category" },
  { value: "sentiment", label: "Sentiment" },
  { value: "language", label: "Language" },
];

const OPERATOR_OPTIONS = [
  { value: "equals", label: "Equals" },
  { value: "not_equals", label: "Not equals" },
  { value: "contains", label: "Contains" },
  { value: "greater_than", label: "Greater than" },
  { value: "less_than", label: "Less than" },
];

interface ConditionBuilderProps {
  value: ConditionGroup;
  onChange: (group: ConditionGroup) => void;
  className?: string;
}

function generateId(): string {
  return `cond_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
}

export function ConditionBuilder({ value, onChange, className }: ConditionBuilderProps) {
  const { conditions, logic } = value;

  const updateCondition = useCallback(
    (condId: string, partial: Partial<Condition>) => {
      const next = conditions.map((c) => (c.id === condId ? { ...c, ...partial } : c));
      onChange({ conditions: next, logic });
    },
    [conditions, logic, onChange],
  );

  const addCondition = useCallback(() => {
    const newCondition: Condition = {
      id: generateId(),
      field: "status",
      operator: "equals",
      value: "",
    };
    onChange({ conditions: [...conditions, newCondition], logic });
  }, [conditions, logic, onChange]);

  const removeCondition = useCallback(
    (condId: string) => {
      onChange({ conditions: conditions.filter((c) => c.id !== condId), logic });
    },
    [conditions, logic, onChange],
  );

  const toggleLogic = useCallback(() => {
    onChange({ conditions, logic: logic === "AND" ? "OR" : "AND" });
  }, [conditions, logic, onChange]);

  return (
    <div className={cn("flex flex-col gap-3", className)}>
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-semibold text-linkedin-gray-90">Conditions</h3>
        <button
          type="button"
          onClick={toggleLogic}
          className="rounded-full border border-linkedin-gray-30 px-3 py-1 text-xs font-semibold text-linkedin-gray-70 transition-colors hover:bg-linkedin-gray-05"
        >
          {logic}
        </button>
      </div>

      <div className="flex flex-col gap-2">
        {conditions.map((condition, index) => (
          <div key={condition.id} className="flex flex-col gap-2">
            {index > 0 && (
              <span className="self-center text-xs font-medium text-linkedin-gray-50">
                {logic}
              </span>
            )}
            <div className="flex items-end gap-2 rounded-lg border border-linkedin-gray-20 bg-linkedin-white p-3">
              <Select
                label={index === 0 ? "Field" : undefined}
                options={FIELD_OPTIONS}
                value={condition.field}
                onChange={(e) => updateCondition(condition.id, { field: e.target.value })}
                className="flex-1"
              />
              <Select
                label={index === 0 ? "Operator" : undefined}
                options={OPERATOR_OPTIONS}
                value={condition.operator}
                onChange={(e) => updateCondition(condition.id, { operator: e.target.value })}
                className="flex-1"
              />
              <Input
                label={index === 0 ? "Value" : undefined}
                placeholder="Enter value"
                value={condition.value}
                onChange={(e) => updateCondition(condition.id, { value: e.target.value })}
                className="flex-1"
              />
              <button
                type="button"
                onClick={() => removeCondition(condition.id)}
                className="mb-0.5 rounded p-2 text-linkedin-gray-50 transition-colors hover:bg-red-50 hover:text-linkedin-red"
                aria-label="Remove condition"
              >
                <Trash2 className="h-4 w-4" />
              </button>
            </div>
          </div>
        ))}
      </div>

      <Button
        type="button"
        variant="secondary"
        size="sm"
        iconLeft={<Plus className="h-3.5 w-3.5" />}
        onClick={addCondition}
      >
        Add condition
      </Button>
    </div>
  );
}
