"use client";

import React from "react";
import { cn } from "@/lib/utils/cn";
import {
  Send,
  UserPlus,
  ArrowRightCircle,
  AlertTriangle,
  Bell,
  ArrowUp,
  CheckCircle,
  Tag,
} from "lucide-react";

interface ActionOption {
  id: string;
  label: string;
  description: string;
  icon: React.ReactNode;
}

const ACTION_OPTIONS: ActionOption[] = [
  {
    id: "send_reply",
    label: "Send Auto-Reply",
    description: "Send an automated reply to the customer",
    icon: <Send className="h-5 w-5" />,
  },
  {
    id: "assign_agent",
    label: "Assign to Agent",
    description: "Assign the ticket to a specific agent or team",
    icon: <UserPlus className="h-5 w-5" />,
  },
  {
    id: "change_status",
    label: "Change Status",
    description: "Update the ticket status",
    icon: <ArrowRightCircle className="h-5 w-5" />,
  },
  {
    id: "change_priority",
    label: "Change Priority",
    description: "Update the ticket priority level",
    icon: <AlertTriangle className="h-5 w-5" />,
  },
  {
    id: "send_notification",
    label: "Send Notification",
    description: "Notify agents or supervisors",
    icon: <Bell className="h-5 w-5" />,
  },
  {
    id: "escalate",
    label: "Escalate",
    description: "Escalate to a senior agent or team lead",
    icon: <ArrowUp className="h-5 w-5" />,
  },
  {
    id: "close_ticket",
    label: "Close Ticket",
    description: "Automatically close the ticket",
    icon: <CheckCircle className="h-5 w-5" />,
  },
  {
    id: "add_tag",
    label: "Add Tag",
    description: "Apply a tag to the ticket for categorization",
    icon: <Tag className="h-5 w-5" />,
  },
];

interface ActionSelectorProps {
  selectedId: string | null;
  onSelect: (actionId: string) => void;
  className?: string;
}

export function ActionSelector({ selectedId, onSelect, className }: ActionSelectorProps) {
  return (
    <div className={cn("flex flex-col gap-2", className)}>
      <h3 className="text-sm font-semibold text-linkedin-gray-90">Select an action</h3>
      <div className="flex flex-col gap-1">
        {ACTION_OPTIONS.map((option) => (
          <button
            key={option.id}
            type="button"
            onClick={() => onSelect(option.id)}
            className={cn(
              "flex items-center gap-3 rounded-lg px-3 py-3 text-left transition-colors",
              selectedId === option.id
                ? "bg-linkedin-blue-bg border border-linkedin-blue"
                : "border border-transparent hover:bg-linkedin-gray-05",
            )}
          >
            <div
              className={cn(
                "flex h-10 w-10 shrink-0 items-center justify-center rounded-lg",
                selectedId === option.id
                  ? "bg-linkedin-blue text-linkedin-white"
                  : "bg-blue-100 text-blue-700",
              )}
            >
              {option.icon}
            </div>
            <div className="flex-1">
              <p className="text-sm font-medium text-linkedin-gray-90">{option.label}</p>
              <p className="text-xs text-linkedin-gray-50">{option.description}</p>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}
