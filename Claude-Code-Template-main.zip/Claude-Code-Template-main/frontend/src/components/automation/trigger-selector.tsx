"use client";

import React from "react";
import { cn } from "@/lib/utils/cn";
import { Plus, RefreshCw, Clock, Search, Moon, TrendingDown } from "lucide-react";

interface TriggerOption {
  id: string;
  label: string;
  description: string;
  icon: React.ReactNode;
}

const TRIGGER_OPTIONS: TriggerOption[] = [
  {
    id: "new_ticket",
    label: "New Ticket Created",
    description: "Triggers when a new ticket is created",
    icon: <Plus className="h-5 w-5" />,
  },
  {
    id: "ticket_updated",
    label: "Ticket Updated",
    description: "Triggers when a ticket status or priority changes",
    icon: <RefreshCw className="h-5 w-5" />,
  },
  {
    id: "sla_approaching",
    label: "SLA Approaching",
    description: "Triggers when a ticket is nearing SLA breach",
    icon: <Clock className="h-5 w-5" />,
  },
  {
    id: "keyword_match",
    label: "Keyword Match",
    description: "Triggers when a message contains specific keywords",
    icon: <Search className="h-5 w-5" />,
  },
  {
    id: "off_hours",
    label: "Off-Hours Message",
    description: "Triggers when a message arrives outside business hours",
    icon: <Moon className="h-5 w-5" />,
  },
  {
    id: "sentiment_drop",
    label: "Sentiment Drop",
    description: "Triggers when customer sentiment becomes negative",
    icon: <TrendingDown className="h-5 w-5" />,
  },
];

interface TriggerSelectorProps {
  selectedId: string | null;
  onSelect: (triggerId: string) => void;
  className?: string;
}

export function TriggerSelector({ selectedId, onSelect, className }: TriggerSelectorProps) {
  return (
    <div className={cn("flex flex-col gap-2", className)}>
      <h3 className="text-sm font-semibold text-linkedin-gray-90">Select a trigger</h3>
      <div className="flex flex-col gap-1">
        {TRIGGER_OPTIONS.map((option) => (
          <button
            key={option.id}
            type="button"
            onClick={() => onSelect(option.id)}
            className={cn(
              "flex items-center gap-3 rounded-lg px-3 py-3 text-left transition-colors",
              selectedId === option.id
                ? "bg-linkedin-blue-bg border border-linkedin-blue"
                : "border border-transparent hover:bg-linkedin-gray-05",
            )}
          >
            <div
              className={cn(
                "flex h-10 w-10 shrink-0 items-center justify-center rounded-lg",
                selectedId === option.id
                  ? "bg-linkedin-blue text-linkedin-white"
                  : "bg-green-100 text-green-700",
              )}
            >
              {option.icon}
            </div>
            <div className="flex-1">
              <p className="text-sm font-medium text-linkedin-gray-90">{option.label}</p>
              <p className="text-xs text-linkedin-gray-50">{option.description}</p>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}
