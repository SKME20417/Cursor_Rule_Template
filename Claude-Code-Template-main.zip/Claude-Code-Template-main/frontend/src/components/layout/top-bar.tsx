"use client";

import { useState } from "react";
import { Menu, Search, Command } from "lucide-react";
import { cn } from "@/lib/utils/cn";
import { Breadcrumbs } from "@/components/layout/breadcrumbs";
import { ConnectionStatus, type ConnectionState } from "@/components/shared/connection-status";
import { NotificationBell, type Notification } from "@/components/shared/notification-bell";
import { OnlineStatus, type AgentStatus } from "@/components/shared/online-status";
import { KeyboardShortcuts } from "@/components/shared/keyboard-shortcuts";
import { User } from "lucide-react";

interface TopBarProps {
  onSidebarToggle?: () => void;
  connectionStatus?: ConnectionState;
  agentStatus?: AgentStatus;
  onAgentStatusChange?: (status: AgentStatus) => void;
  notifications?: Notification[];
  unreadCount?: number;
  onSearch?: () => void;
  className?: string;
}

export function TopBar({
  onSidebarToggle,
  connectionStatus = "connected",
  agentStatus = "online",
  onAgentStatusChange,
  notifications = [],
  unreadCount = 0,
  onSearch,
  className,
}: TopBarProps) {
  const [searchFocused, setSearchFocused] = useState(false);

  const handleSearchClick = () => {
    onSearch?.();
  };

  return (
    <>
      <KeyboardShortcuts onSearch={onSearch} />
      <header
        className={cn(
          "sticky top-0 z-30 flex h-14 items-center gap-4 bg-linkedin-white border-b border-linkedin-gray-20 px-4",
          className
        )}
      >
        {/* Left: Sidebar toggle + Breadcrumbs */}
        <div className="flex items-center gap-3 min-w-0">
          {onSidebarToggle && (
            <button
              onClick={onSidebarToggle}
              className="p-1.5 rounded-md hover:bg-linkedin-gray-10 transition-colors text-linkedin-gray-70 md:hidden"
              aria-label="Toggle sidebar"
            >
              <Menu className="h-5 w-5" />
            </button>
          )}
          <Breadcrumbs className="hidden sm:flex" />
        </div>

        {/* Center: Search */}
        <div className="flex-1 flex justify-center max-w-md mx-auto">
          <button
            onClick={handleSearchClick}
            className={cn(
              "flex items-center gap-2 w-full max-w-sm px-3 py-1.5 rounded-md text-sm border transition-colors",
              searchFocused
                ? "border-linkedin-blue ring-1 ring-linkedin-blue"
                : "border-linkedin-gray-20 hover:border-linkedin-gray-30 bg-linkedin-gray-10"
            )}
          >
            <Search className="h-4 w-4 text-linkedin-gray-50" />
            <span className="text-linkedin-gray-50 flex-1 text-left">
              Search...
            </span>
            <kbd className="hidden sm:inline-flex items-center gap-0.5 rounded border border-linkedin-gray-20 bg-linkedin-white px-1.5 py-0.5 text-2xs text-linkedin-gray-50">
              <Command className="h-3 w-3" />K
            </kbd>
          </button>
        </div>

        {/* Right: Status indicators + User */}
        <div className="flex items-center gap-1 shrink-0">
          <ConnectionStatus status={connectionStatus} className="mr-1" />
          <NotificationBell
            notifications={notifications}
            unreadCount={unreadCount}
          />
          <OnlineStatus
            status={agentStatus}
            onStatusChange={onAgentStatusChange}
          />
          <div className="ml-1 h-8 w-8 rounded-full bg-linkedin-blue-bg flex items-center justify-center">
            <User className="h-4 w-4 text-linkedin-blue" />
          </div>
        </div>
      </header>
    </>
  );
}
