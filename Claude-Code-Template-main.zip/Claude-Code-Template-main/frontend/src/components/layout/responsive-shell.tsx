"use client";

import { useState, type ReactNode } from "react";
import { cn } from "@/lib/utils/cn";
import { Sidebar, MobileSidebar, type SidebarItem } from "@/components/layout/sidebar";
import { TopBar } from "@/components/layout/top-bar";
import type { ConnectionState } from "@/components/shared/connection-status";
import type { AgentStatus } from "@/components/shared/online-status";
import type { Notification } from "@/components/shared/notification-bell";

interface ResponsiveShellProps {
  sidebarItems: SidebarItem[];
  sidebarSections?: { label: string; items: SidebarItem[] }[];
  connectionStatus?: ConnectionState;
  agentStatus?: AgentStatus;
  onAgentStatusChange?: (status: AgentStatus) => void;
  notifications?: Notification[];
  unreadCount?: number;
  onSearch?: () => void;
  children: ReactNode;
  className?: string;
}

export function ResponsiveShell({
  sidebarItems,
  sidebarSections,
  connectionStatus = "connected",
  agentStatus = "online",
  onAgentStatusChange,
  notifications = [],
  unreadCount = 0,
  onSearch,
  children,
  className,
}: ResponsiveShellProps) {
  const [collapsed, setCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <div className={cn("flex h-screen overflow-hidden bg-linkedin-gray-10", className)}>
      {/* Desktop Sidebar */}
      <div className="hidden md:flex">
        <Sidebar
          items={sidebarItems}
          sections={sidebarSections}
          collapsed={collapsed}
          onToggle={() => setCollapsed(!collapsed)}
        />
      </div>

      {/* Mobile Sidebar Overlay */}
      <MobileSidebar
        items={sidebarItems}
        sections={sidebarSections}
        open={mobileOpen}
        onClose={() => setMobileOpen(false)}
      />

      {/* Main Content Area */}
      <div className="flex flex-1 flex-col min-w-0">
        <TopBar
          onSidebarToggle={() => setMobileOpen(true)}
          connectionStatus={connectionStatus}
          agentStatus={agentStatus}
          onAgentStatusChange={onAgentStatusChange}
          notifications={notifications}
          unreadCount={unreadCount}
          onSearch={onSearch}
        />
        <main className="flex-1 overflow-y-auto p-4 sm:p-6">{children}</main>
      </div>
    </div>
  );
}
