"use client";

import { useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  Menu,
  X,
  Home,
  MessageCircle,
  Ticket,
  BookOpen,
  User,
  LogOut,
  Settings,
} from "lucide-react";
import { cn } from "@/lib/utils/cn";
import { NotificationBell } from "@/components/shared/notification-bell";
import { LanguageSwitcher } from "@/components/shared/language-switcher";

interface HeaderProps {
  className?: string;
}

const navLinks = [
  { label: "Home", href: "/", icon: Home },
  { label: "Chat", href: "/chat", icon: MessageCircle },
  { label: "Tickets", href: "/tickets", icon: Ticket },
  { label: "Knowledge Base", href: "/knowledge-base", icon: BookOpen },
];

export function Header({ className }: HeaderProps) {
  const pathname = usePathname();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);

  return (
    <header
      className={cn(
        "sticky top-0 z-40 w-full bg-linkedin-white shadow-card",
        className
      )}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex h-14 items-center justify-between">
          {/* Left: Logo + Nav */}
          <div className="flex items-center gap-8">
            <Link href="/" className="flex items-center gap-2 shrink-0">
              <div className="h-8 w-8 rounded-md bg-linkedin-blue flex items-center justify-center">
                <span className="text-sm font-bold text-white">AI</span>
              </div>
              <span className="text-base font-semibold text-linkedin-black hidden sm:inline">
                Support Copilot
              </span>
            </Link>

            <nav className="hidden md:flex items-center gap-1">
              {navLinks.map((link) => {
                const isActive =
                  link.href === "/"
                    ? pathname === "/"
                    : pathname.startsWith(link.href);
                return (
                  <Link
                    key={link.href}
                    href={link.href}
                    className={cn(
                      "flex items-center gap-1.5 px-3 py-2 rounded-md text-sm font-medium transition-colors",
                      isActive
                        ? "text-linkedin-blue bg-linkedin-blue-bg"
                        : "text-linkedin-gray-70 hover:bg-linkedin-gray-10 hover:text-linkedin-black"
                    )}
                  >
                    <link.icon className="h-4 w-4" />
                    {link.label}
                  </Link>
                );
              })}
            </nav>
          </div>

          {/* Right: Actions */}
          <div className="flex items-center gap-1">
            <LanguageSwitcher />
            <NotificationBell />

            {/* User Avatar Dropdown */}
            <div className="relative">
              <button
                onClick={() => setProfileOpen(!profileOpen)}
                className="ml-1 flex h-8 w-8 items-center justify-center rounded-full bg-linkedin-blue-bg text-linkedin-blue hover:ring-2 hover:ring-linkedin-blue-light transition"
                aria-label="User menu"
              >
                <User className="h-4 w-4" />
              </button>
              {profileOpen && (
                <>
                  <div
                    className="fixed inset-0 z-40"
                    onClick={() => setProfileOpen(false)}
                  />
                  <div className="absolute right-0 top-full mt-2 w-48 rounded-card bg-linkedin-white shadow-dropdown z-50 border border-linkedin-gray-20 py-1">
                    <Link
                      href="/profile"
                      onClick={() => setProfileOpen(false)}
                      className="flex items-center gap-2 px-4 py-2 text-sm text-linkedin-black hover:bg-linkedin-gray-10 transition-colors"
                    >
                      <User className="h-4 w-4" />
                      Profile
                    </Link>
                    <Link
                      href="/settings"
                      onClick={() => setProfileOpen(false)}
                      className="flex items-center gap-2 px-4 py-2 text-sm text-linkedin-black hover:bg-linkedin-gray-10 transition-colors"
                    >
                      <Settings className="h-4 w-4" />
                      Settings
                    </Link>
                    <hr className="my-1 border-linkedin-gray-20" />
                    <button className="flex w-full items-center gap-2 px-4 py-2 text-sm text-linkedin-red hover:bg-linkedin-gray-10 transition-colors">
                      <LogOut className="h-4 w-4" />
                      Sign out
                    </button>
                  </div>
                </>
              )}
            </div>

            {/* Mobile Hamburger */}
            <button
              onClick={() => setMobileOpen(true)}
              className="ml-2 p-2 rounded-md md:hidden hover:bg-linkedin-gray-10 transition-colors"
              aria-label="Open menu"
            >
              <Menu className="h-5 w-5 text-linkedin-gray-70" />
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Slide-over Nav */}
      {mobileOpen && (
        <div className="fixed inset-0 z-50 md:hidden">
          <div
            className="fixed inset-0 bg-black/40"
            onClick={() => setMobileOpen(false)}
          />
          <div className="fixed right-0 top-0 h-full w-72 bg-linkedin-white shadow-modal animate-slide-in">
            <div className="flex items-center justify-between px-4 py-4 border-b border-linkedin-gray-20">
              <span className="text-base font-semibold text-linkedin-black">
                Menu
              </span>
              <button
                onClick={() => setMobileOpen(false)}
                className="p-1 rounded-md hover:bg-linkedin-gray-10"
                aria-label="Close menu"
              >
                <X className="h-5 w-5 text-linkedin-gray-70" />
              </button>
            </div>
            <nav className="px-2 py-3 space-y-1">
              {navLinks.map((link) => {
                const isActive =
                  link.href === "/"
                    ? pathname === "/"
                    : pathname.startsWith(link.href);
                return (
                  <Link
                    key={link.href}
                    href={link.href}
                    onClick={() => setMobileOpen(false)}
                    className={cn(
                      "sidebar-link",
                      isActive && "sidebar-link-active"
                    )}
                  >
                    <link.icon className="h-5 w-5" />
                    {link.label}
                  </Link>
                );
              })}
            </nav>
          </div>
        </div>
      )}
    </header>
  );
}
