import Link from "next/link";
import { cn } from "@/lib/utils/cn";

interface FooterProps {
  className?: string;
}

const footerLinks = [
  { label: "Help", href: "/help" },
  { label: "Privacy", href: "/privacy" },
  { label: "Terms", href: "/terms" },
  { label: "Contact", href: "/contact" },
];

export function Footer({ className }: FooterProps) {
  return (
    <footer
      className={cn(
        "w-full bg-linkedin-gray-10 border-t border-linkedin-gray-20",
        className
      )}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
          <nav className="flex items-center gap-6">
            {footerLinks.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className="text-sm text-linkedin-gray-70 hover:text-linkedin-blue hover:underline transition-colors"
              >
                {link.label}
              </Link>
            ))}
          </nav>
          <p className="text-xs text-linkedin-gray-50">
            &copy; {new Date().getFullYear()} AI Support Copilot. All rights
            reserved.
          </p>
        </div>
      </div>
    </footer>
  );
}
