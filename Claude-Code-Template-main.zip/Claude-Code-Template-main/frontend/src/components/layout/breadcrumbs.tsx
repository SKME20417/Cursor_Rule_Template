"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { ChevronRight } from "lucide-react";
import { cn } from "@/lib/utils/cn";

interface BreadcrumbsProps {
  className?: string;
  /** Optional overrides for segment labels. Key = segment, value = display label */
  labelMap?: Record<string, string>;
}

function formatSegment(segment: string, labelMap?: Record<string, string>): string {
  if (labelMap?.[segment]) return labelMap[segment];
  // Strip route group parentheses
  const clean = segment.replace(/^\(|\)$/g, "");
  // Convert kebab-case to Title Case
  return clean
    .split("-")
    .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
    .join(" ");
}

export function Breadcrumbs({ className, labelMap }: BreadcrumbsProps) {
  const pathname = usePathname();
  const segments = pathname
    .split("/")
    .filter(Boolean)
    // Filter out route group segments like (admin), (agent)
    .filter((s) => !s.startsWith("("));

  if (segments.length === 0) return null;

  return (
    <nav aria-label="Breadcrumb" className={cn("flex items-center gap-1 text-sm", className)}>
      <Link
        href="/"
        className="text-linkedin-gray-50 hover:text-linkedin-blue transition-colors"
      >
        Home
      </Link>
      {segments.map((segment, index) => {
        const href = "/" + segments.slice(0, index + 1).join("/");
        const isLast = index === segments.length - 1;

        return (
          <span key={href} className="flex items-center gap-1">
            <ChevronRight className="h-3.5 w-3.5 text-linkedin-gray-30" />
            {isLast ? (
              <span className="text-linkedin-black font-medium">
                {formatSegment(segment, labelMap)}
              </span>
            ) : (
              <Link
                href={href}
                className="text-linkedin-gray-50 hover:text-linkedin-blue transition-colors"
              >
                {formatSegment(segment, labelMap)}
              </Link>
            )}
          </span>
        );
      })}
    </nav>
  );
}
