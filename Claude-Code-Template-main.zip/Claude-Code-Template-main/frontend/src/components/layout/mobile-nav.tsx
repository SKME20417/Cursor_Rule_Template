"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { type LucideIcon } from "lucide-react";
import { cn } from "@/lib/utils/cn";

export interface MobileNavItem {
  label: string;
  href: string;
  icon: LucideIcon;
}

interface MobileNavProps {
  items: MobileNavItem[];
  className?: string;
}

export function MobileNav({ items, className }: MobileNavProps) {
  const pathname = usePathname();

  return (
    <nav
      className={cn(
        "fixed bottom-0 left-0 right-0 z-40 bg-linkedin-white border-t border-linkedin-gray-20 md:hidden",
        className
      )}
    >
      <div className="flex items-center justify-around h-14">
        {items.map((item) => {
          const isActive =
            item.href === "/"
              ? pathname === "/"
              : pathname.startsWith(item.href);
          const Icon = item.icon;

          return (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                "flex flex-col items-center justify-center gap-0.5 px-3 py-1.5 min-w-0 transition-colors",
                isActive
                  ? "text-linkedin-blue"
                  : "text-linkedin-gray-50 hover:text-linkedin-gray-70"
              )}
            >
              <Icon className="h-5 w-5" />
              <span className="text-2xs font-medium truncate">{item.label}</span>
            </Link>
          );
        })}
      </div>
      {/* Safe area padding for iOS */}
      <div className="h-[env(safe-area-inset-bottom)]" />
    </nav>
  );
}
