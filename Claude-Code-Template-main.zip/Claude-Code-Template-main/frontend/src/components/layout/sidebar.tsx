"use client";

import { useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  ChevronDown,
  ChevronRight,
  PanelLeftClose,
  PanelLeft,
  LogOut,
  User,
  X,
  type LucideIcon,
} from "lucide-react";
import { cn } from "@/lib/utils/cn";

export interface SidebarItem {
  label: string;
  href: string;
  icon: LucideIcon;
  badge?: string | number;
  children?: SidebarItem[];
}

interface SidebarProps {
  items: SidebarItem[];
  collapsed: boolean;
  onToggle: () => void;
  className?: string;
  /** Section headers - maps section label to item indices */
  sections?: { label: string; items: SidebarItem[] }[];
}

function SidebarLink({
  item,
  collapsed,
  depth = 0,
}: {
  item: SidebarItem;
  collapsed: boolean;
  depth?: number;
}) {
  const pathname = usePathname();
  const isActive = pathname === item.href || pathname.startsWith(item.href + "/");
  const [expanded, setExpanded] = useState(isActive);
  const hasChildren = item.children && item.children.length > 0;
  const Icon = item.icon;

  return (
    <div>
      <div className="relative">
        <Link
          href={hasChildren ? "#" : item.href}
          onClick={
            hasChildren
              ? (e) => {
                  e.preventDefault();
                  setExpanded(!expanded);
                }
              : undefined
          }
          title={collapsed ? item.label : undefined}
          className={cn(
            "sidebar-link group",
            isActive && !hasChildren && "sidebar-link-active",
            depth > 0 && "pl-10",
            collapsed && "justify-center px-2"
          )}
        >
          <Icon className="h-5 w-5 shrink-0" />
          {!collapsed && (
            <>
              <span className="flex-1 truncate">{item.label}</span>
              {item.badge !== undefined && (
                <span className="badge bg-linkedin-red text-white text-2xs">
                  {item.badge}
                </span>
              )}
              {hasChildren && (
                <span className="text-linkedin-gray-50">
                  {expanded ? (
                    <ChevronDown className="h-4 w-4" />
                  ) : (
                    <ChevronRight className="h-4 w-4" />
                  )}
                </span>
              )}
            </>
          )}
        </Link>
      </div>

      {hasChildren && expanded && !collapsed && (
        <div className="mt-0.5 space-y-0.5">
          {item.children!.map((child) => (
            <SidebarLink key={child.href} item={child} collapsed={false} depth={depth + 1} />
          ))}
        </div>
      )}
    </div>
  );
}

export function Sidebar({
  items,
  collapsed,
  onToggle,
  className,
  sections,
}: SidebarProps) {
  const renderItems = (list: SidebarItem[]) =>
    list.map((item) => (
      <SidebarLink key={item.href} item={item} collapsed={collapsed} />
    ));

  return (
    <aside
      className={cn(
        "flex flex-col h-full bg-linkedin-white border-r border-linkedin-gray-20 transition-all duration-200",
        collapsed ? "w-16" : "w-60",
        className
      )}
    >
      {/* Logo + Toggle */}
      <div className="flex items-center h-14 px-3 border-b border-linkedin-gray-20 shrink-0">
        {!collapsed && (
          <Link href="/" className="flex items-center gap-2 flex-1 min-w-0">
            <div className="h-8 w-8 rounded-md bg-linkedin-blue flex items-center justify-center shrink-0">
              <span className="text-sm font-bold text-white">AI</span>
            </div>
            <span className="text-sm font-semibold text-linkedin-black truncate">
              Support Copilot
            </span>
          </Link>
        )}
        <button
          onClick={onToggle}
          className={cn(
            "p-1.5 rounded-md hover:bg-linkedin-gray-10 transition-colors text-linkedin-gray-70",
            collapsed && "mx-auto"
          )}
          aria-label={collapsed ? "Expand sidebar" : "Collapse sidebar"}
        >
          {collapsed ? (
            <PanelLeft className="h-5 w-5" />
          ) : (
            <PanelLeftClose className="h-5 w-5" />
          )}
        </button>
      </div>

      {/* Navigation */}
      <nav className="flex-1 overflow-y-auto py-3 px-2 space-y-1 scrollbar-hide">
        {sections
          ? sections.map((section) => (
              <div key={section.label} className="mb-4">
                {!collapsed && (
                  <p className="px-4 pb-1.5 pt-3 text-2xs font-semibold uppercase tracking-wider text-linkedin-gray-50">
                    {section.label}
                  </p>
                )}
                <div className="space-y-0.5">{renderItems(section.items)}</div>
              </div>
            ))
          : renderItems(items)}
      </nav>

      {/* User Profile Card */}
      <div className="shrink-0 border-t border-linkedin-gray-20 p-3">
        {collapsed ? (
          <div className="flex flex-col items-center gap-2">
            <div className="h-8 w-8 rounded-full bg-linkedin-blue-bg flex items-center justify-center">
              <User className="h-4 w-4 text-linkedin-blue" />
            </div>
            <button
              className="p-1 rounded-md hover:bg-linkedin-gray-10 text-linkedin-gray-50"
              aria-label="Sign out"
            >
              <LogOut className="h-4 w-4" />
            </button>
          </div>
        ) : (
          <div className="flex items-center gap-3">
            <div className="h-9 w-9 rounded-full bg-linkedin-blue-bg flex items-center justify-center shrink-0">
              <User className="h-4 w-4 text-linkedin-blue" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-linkedin-black truncate">
                Agent User
              </p>
              <p className="text-2xs text-linkedin-gray-50 truncate">
                agent@company.com
              </p>
            </div>
            <button
              className="p-1.5 rounded-md hover:bg-linkedin-gray-10 text-linkedin-gray-50 transition-colors"
              aria-label="Sign out"
            >
              <LogOut className="h-4 w-4" />
            </button>
          </div>
        )}
      </div>
    </aside>
  );
}

/** Mobile overlay version of the sidebar */
export function MobileSidebar({
  items,
  sections,
  open,
  onClose,
}: {
  items: SidebarItem[];
  sections?: { label: string; items: SidebarItem[] }[];
  open: boolean;
  onClose: () => void;
}) {
  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 md:hidden">
      <div className="fixed inset-0 bg-black/40" onClick={onClose} />
      <div className="fixed left-0 top-0 h-full w-64 animate-slide-in">
        <div className="relative h-full">
          <button
            onClick={onClose}
            className="absolute right-2 top-3 p-1.5 rounded-md hover:bg-linkedin-gray-10 z-10"
            aria-label="Close sidebar"
          >
            <X className="h-4 w-4 text-linkedin-gray-70" />
          </button>
          <Sidebar
            items={items}
            sections={sections}
            collapsed={false}
            onToggle={onClose}
          />
        </div>
      </div>
    </div>
  );
}
