"use client";

import React, { useEffect, useRef, useState } from "react";
import { cn } from "@/lib/utils/cn";
import { MessageBubble } from "./message-bubble";
import { Loader2 } from "lucide-react";

interface MessageSender {
  id: string;
  name: string;
  avatar?: string;
  role: "customer" | "agent" | "system" | "ai";
}

interface Message {
  id: string;
  content: string;
  sender: MessageSender;
  timestamp: string;
  type: "text" | "image" | "file" | "system";
  channel?: string;
  metadata?: Record<string, unknown>;
}

interface MessageListProps {
  messages: Message[];
  onLoadMore?: () => void;
  hasMore?: boolean;
  loadingMore?: boolean;
  className?: string;
}

function formatDateSeparator(timestamp: string): string {
  const date = new Date(timestamp);
  const now = new Date();
  const diffDays = Math.floor(
    (now.getTime() - date.getTime()) / (1000 * 60 * 60 * 24),
  );

  if (diffDays === 0) return "Today";
  if (diffDays === 1) return "Yesterday";
  return date.toLocaleDateString(undefined, {
    weekday: "long",
    month: "short",
    day: "numeric",
  });
}

function getDateKey(timestamp: string): string {
  return new Date(timestamp).toDateString();
}

export function MessageList({
  messages,
  onLoadMore,
  hasMore = false,
  loadingMore = false,
  className,
}: MessageListProps) {
  const bottomRef = useRef<HTMLDivElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [autoScroll, setAutoScroll] = useState(true);

  // Auto-scroll to bottom on new messages
  useEffect(() => {
    if (autoScroll && bottomRef.current) {
      bottomRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [messages.length, autoScroll]);

  function handleScroll() {
    const el = containerRef.current;
    if (!el) return;
    const atBottom = el.scrollHeight - el.scrollTop - el.clientHeight < 80;
    setAutoScroll(atBottom);
  }

  // Group messages by date
  const groups: Array<{ date: string; label: string; items: Message[] }> = [];
  let currentDateKey = "";

  for (const msg of messages) {
    const key = getDateKey(msg.timestamp);
    if (key !== currentDateKey) {
      currentDateKey = key;
      groups.push({
        date: key,
        label: formatDateSeparator(msg.timestamp),
        items: [],
      });
    }
    groups[groups.length - 1].items.push(msg);
  }

  return (
    <div
      ref={containerRef}
      onScroll={handleScroll}
      className={cn(
        "flex flex-1 flex-col overflow-y-auto scroll-smooth",
        className,
      )}
    >
      {/* Load more */}
      {hasMore && (
        <div className="flex justify-center py-3">
          <button
            type="button"
            onClick={onLoadMore}
            disabled={loadingMore}
            className="inline-flex items-center gap-1.5 rounded-full px-4 py-1.5 text-xs font-medium text-linkedin-blue transition-colors hover:bg-linkedin-blue-bg disabled:opacity-50"
          >
            {loadingMore ? (
              <>
                <Loader2 className="h-3 w-3 animate-spin" />
                Loading...
              </>
            ) : (
              "Load earlier messages"
            )}
          </button>
        </div>
      )}

      {/* Message groups */}
      {groups.map((group) => (
        <div key={group.date}>
          {/* Date separator */}
          <div className="flex items-center gap-3 px-4 py-3">
            <div className="h-px flex-1 bg-linkedin-gray-20" />
            <span className="text-xs font-medium text-linkedin-gray-50">
              {group.label}
            </span>
            <div className="h-px flex-1 bg-linkedin-gray-20" />
          </div>

          {/* Messages */}
          {group.items.map((msg) => (
            <MessageBubble key={msg.id} {...msg} />
          ))}
        </div>
      ))}

      <div ref={bottomRef} />
    </div>
  );
}
