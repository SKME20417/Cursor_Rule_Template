"use client";

import React from "react";
import { cn } from "@/lib/utils/cn";
import {
  MessageSquare,
  Mail,
  Phone,
  Globe,
  Instagram,
  Facebook,
} from "lucide-react";

interface ChannelBadgeProps {
  channel: string;
  className?: string;
}

const CHANNEL_CONFIG: Record<
  string,
  { icon: React.ElementType; label: string; color: string }
> = {
  whatsapp: {
    icon: MessageSquare,
    label: "WhatsApp",
    color: "bg-green-50 text-green-700",
  },
  email: {
    icon: Mail,
    label: "Email",
    color: "bg-blue-50 text-blue-700",
  },
  phone: {
    icon: Phone,
    label: "Phone",
    color: "bg-purple-50 text-purple-700",
  },
  web: {
    icon: Globe,
    label: "Web Chat",
    color: "bg-linkedin-blue-bg text-linkedin-blue",
  },
  instagram: {
    icon: Instagram,
    label: "Instagram",
    color: "bg-pink-50 text-pink-700",
  },
  facebook: {
    icon: Facebook,
    label: "Facebook",
    color: "bg-blue-50 text-blue-800",
  },
  chat: {
    icon: MessageSquare,
    label: "Chat",
    color: "bg-linkedin-blue-bg text-linkedin-blue",
  },
};

export function ChannelBadge({ channel, className }: ChannelBadgeProps) {
  const config = CHANNEL_CONFIG[channel.toLowerCase()] ?? {
    icon: MessageSquare,
    label: channel,
    color: "bg-linkedin-gray-20 text-linkedin-gray-70",
  };
  const Icon = config.icon;

  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-xs font-medium",
        config.color,
        className,
      )}
    >
      <Icon className="h-3 w-3" aria-hidden="true" />
      {config.label}
    </span>
  );
}
