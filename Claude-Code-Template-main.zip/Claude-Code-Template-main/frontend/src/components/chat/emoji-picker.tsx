"use client";

import React, { useState } from "react";
import { cn } from "@/lib/utils/cn";

interface EmojiPickerProps {
  onSelect: (emoji: string) => void;
  className?: string;
}

const EMOJI_CATEGORIES: Record<string, string[]> = {
  "Smileys": [
    "\u{1F600}", "\u{1F603}", "\u{1F604}", "\u{1F601}", "\u{1F606}", "\u{1F605}",
    "\u{1F602}", "\u{1F923}", "\u{1F60A}", "\u{1F607}", "\u{1F642}", "\u{1F643}",
    "\u{1F609}", "\u{1F60C}", "\u{1F60D}", "\u{1F618}", "\u{1F617}", "\u{1F619}",
    "\u{1F61A}", "\u{1F60B}", "\u{1F61C}", "\u{1F61D}", "\u{1F61B}", "\u{1F911}",
  ],
  "Gestures": [
    "\u{1F44D}", "\u{1F44E}", "\u{1F44A}", "\u{270C}\u{FE0F}", "\u{1F44B}", "\u{1F44F}",
    "\u{1F64F}", "\u{1F4AA}", "\u{1F91D}", "\u{261D}\u{FE0F}", "\u{1F446}", "\u{1F447}",
  ],
  "Objects": [
    "\u{2764}\u{FE0F}", "\u{1F4A1}", "\u{1F525}", "\u{2B50}", "\u{1F389}", "\u{1F381}",
    "\u{1F4E7}", "\u{1F4CE}", "\u{1F4C4}", "\u{1F4DD}", "\u{2705}", "\u{274C}",
  ],
};

const CATEGORY_NAMES = Object.keys(EMOJI_CATEGORIES);

export function EmojiPicker({ onSelect, className }: EmojiPickerProps) {
  const [activeCategory, setActiveCategory] = useState(CATEGORY_NAMES[0]);

  return (
    <div
      className={cn(
        "w-64 rounded-lg border border-linkedin-gray-20 bg-linkedin-white shadow-lg",
        className,
      )}
    >
      {/* Category tabs */}
      <div className="flex border-b border-linkedin-gray-20">
        {CATEGORY_NAMES.map((cat) => (
          <button
            key={cat}
            type="button"
            onClick={() => setActiveCategory(cat)}
            className={cn(
              "flex-1 px-2 py-2 text-xs font-medium transition-colors",
              activeCategory === cat
                ? "border-b-2 border-linkedin-blue text-linkedin-blue"
                : "text-linkedin-gray-50 hover:text-linkedin-gray-70",
            )}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Emoji grid */}
      <div className="grid grid-cols-8 gap-0.5 p-2">
        {EMOJI_CATEGORIES[activeCategory].map((emoji) => (
          <button
            key={emoji}
            type="button"
            onClick={() => onSelect(emoji)}
            className="flex h-8 w-8 items-center justify-center rounded text-lg transition-colors hover:bg-linkedin-gray-10"
            aria-label={`Insert emoji ${emoji}`}
          >
            {emoji}
          </button>
        ))}
      </div>
    </div>
  );
}
