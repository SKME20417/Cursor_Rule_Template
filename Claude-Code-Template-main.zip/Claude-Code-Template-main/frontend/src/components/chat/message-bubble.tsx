"use client";

import React from "react";
import { cn } from "@/lib/utils/cn";
import { AiResponseBadge } from "./ai-response-badge";
import { ChannelBadge } from "./channel-badge";
import { FileAttachment } from "./file-attachment";

interface MessageSender {
  id: string;
  name: string;
  avatar?: string;
  role: "customer" | "agent" | "system" | "ai";
}

interface MessageBubbleProps {
  id: string;
  content: string;
  sender: MessageSender;
  timestamp: string;
  type: "text" | "image" | "file" | "system";
  channel?: string;
  metadata?: Record<string, unknown>;
  className?: string;
}

function formatTime(timestamp: string): string {
  const date = new Date(timestamp);
  return date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
}

function getInitials(name: string): string {
  const parts = name.trim().split(/\s+/);
  if (parts.length === 1) return parts[0][0]?.toUpperCase() ?? "?";
  return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
}

export function MessageBubble({
  content,
  sender,
  timestamp,
  type,
  channel,
  metadata,
  className,
}: MessageBubbleProps) {
  // System messages: centered
  if (sender.role === "system" || type === "system") {
    return (
      <div className={cn("flex justify-center px-4 py-2", className)}>
        <span className="text-xs text-linkedin-gray-50 italic">{content}</span>
      </div>
    );
  }

  const isAgent = sender.role === "agent";
  const isAi = sender.role === "ai";

  return (
    <div
      className={cn(
        "flex gap-2 px-4 py-1.5",
        isAgent ? "flex-row-reverse" : "flex-row",
        className,
      )}
    >
      {/* Avatar */}
      <div className="shrink-0 pt-1">
        {sender.avatar ? (
          <img
            src={sender.avatar}
            alt={sender.name}
            className="h-8 w-8 rounded-full object-cover"
          />
        ) : (
          <span
            className={cn(
              "flex h-8 w-8 items-center justify-center rounded-full text-xs font-semibold",
              isAi
                ? "bg-purple-100 text-purple-700"
                : isAgent
                  ? "bg-linkedin-blue-bg text-linkedin-blue"
                  : "bg-linkedin-gray-20 text-linkedin-gray-70",
            )}
          >
            {isAi ? "AI" : getInitials(sender.name)}
          </span>
        )}
      </div>

      {/* Bubble */}
      <div
        className={cn(
          "flex max-w-[70%] flex-col gap-1",
          isAgent ? "items-end" : "items-start",
        )}
      >
        {/* Name + channel */}
        <div
          className={cn(
            "flex items-center gap-2 text-xs text-linkedin-gray-50",
            isAgent && "flex-row-reverse",
          )}
        >
          <span className="font-medium text-linkedin-gray-70">
            {sender.name}
          </span>
          {channel && <ChannelBadge channel={channel} />}
          {isAi && <AiResponseBadge />}
        </div>

        {/* Content */}
        <div
          className={cn(
            "rounded-2xl px-4 py-2.5 text-sm leading-relaxed",
            isAgent
              ? "rounded-tr-md bg-linkedin-blue text-white"
              : isAi
                ? "rounded-tl-md bg-blue-50 text-linkedin-gray-90"
                : "rounded-tl-md bg-linkedin-gray-10 text-linkedin-gray-90",
          )}
        >
          {type === "text" && <p className="whitespace-pre-wrap">{content}</p>}
          {type === "image" && (
            <div className="flex flex-col gap-2">
              <img
                src={content}
                alt="Shared image"
                className="max-h-64 rounded-lg object-contain"
              />
            </div>
          )}
          {type === "file" && (
            <FileAttachment
              name={(metadata?.fileName as string) ?? "File"}
              size={(metadata?.fileSize as string) ?? "Unknown"}
              type={(metadata?.fileType as string) ?? "file"}
              url={content}
              thumbnailUrl={metadata?.thumbnailUrl as string | undefined}
            />
          )}
        </div>

        {/* Timestamp */}
        <span className="text-[10px] text-linkedin-gray-50">
          {formatTime(timestamp)}
        </span>
      </div>
    </div>
  );
}
