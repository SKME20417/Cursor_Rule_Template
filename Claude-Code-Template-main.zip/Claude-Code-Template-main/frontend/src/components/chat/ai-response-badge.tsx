"use client";

import React from "react";
import { cn } from "@/lib/utils/cn";
import { Sparkles } from "lucide-react";

interface AiResponseBadgeProps {
  sourceLabel?: string;
  sourceHref?: string;
  className?: string;
}

export function AiResponseBadge({
  sourceLabel,
  sourceHref,
  className,
}: AiResponseBadgeProps) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 rounded-full bg-purple-50 px-2 py-0.5 text-xs font-medium text-purple-700",
        className,
      )}
    >
      <Sparkles className="h-3 w-3" aria-hidden="true" />
      AI Generated
      {sourceLabel && sourceHref && (
        <>
          <span className="mx-0.5 text-purple-400">&middot;</span>
          <a
            href={sourceHref}
            target="_blank"
            rel="noopener noreferrer"
            className="underline hover:text-purple-900 transition-colors"
          >
            {sourceLabel}
          </a>
        </>
      )}
    </span>
  );
}
