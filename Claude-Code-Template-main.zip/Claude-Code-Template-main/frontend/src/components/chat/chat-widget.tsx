"use client";

import React, { useState, useCallback } from "react";
import { cn } from "@/lib/utils/cn";
import { MessageSquare, Minus, X } from "lucide-react";
import { MessageList } from "./message-list";
import { MessageInput } from "./message-input";

interface MessageSender {
  id: string;
  name: string;
  avatar?: string;
  role: "customer" | "agent" | "system" | "ai";
}

interface Message {
  id: string;
  content: string;
  sender: MessageSender;
  timestamp: string;
  type: "text" | "image" | "file" | "system";
  channel?: string;
  metadata?: Record<string, unknown>;
}

interface ChatWidgetProps {
  className?: string;
}

const INITIAL_MESSAGES: Message[] = [
  {
    id: "w1",
    content: "Hi! How can I help you today? I'm an AI assistant and can answer most questions instantly.",
    sender: { id: "ai1", name: "AI Support", role: "ai" },
    timestamp: new Date().toISOString(),
    type: "text",
  },
];

export function ChatWidget({ className }: ChatWidgetProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  const [messages, setMessages] = useState<Message[]>(INITIAL_MESSAGES);

  const handleSend = useCallback((content: string) => {
    const customerMsg: Message = {
      id: `cw-${Date.now()}`,
      content,
      sender: { id: "customer", name: "You", role: "customer" },
      timestamp: new Date().toISOString(),
      type: "text",
    };
    setMessages((prev) => [...prev, customerMsg]);

    // Simulate AI response
    setTimeout(() => {
      const aiMsg: Message = {
        id: `cw-ai-${Date.now()}`,
        content:
          "Thanks for reaching out! Let me look into that for you. One moment please.",
        sender: { id: "ai1", name: "AI Support", role: "ai" },
        timestamp: new Date().toISOString(),
        type: "text",
      };
      setMessages((prev) => [...prev, aiMsg]);
    }, 1500);
  }, []);

  if (!isOpen) {
    return (
      <button
        type="button"
        onClick={() => setIsOpen(true)}
        className={cn(
          "fixed bottom-6 right-6 z-50 flex h-14 w-14 items-center justify-center rounded-full bg-linkedin-blue shadow-lg transition-transform hover:scale-105 hover:bg-linkedin-blue-hover",
          className,
        )}
        aria-label="Open chat"
      >
        <MessageSquare className="h-6 w-6 text-white" />
      </button>
    );
  }

  return (
    <div
      className={cn(
        "fixed bottom-6 right-6 z-50 flex w-[400px] flex-col overflow-hidden rounded-xl border border-linkedin-gray-20 bg-linkedin-white shadow-xl",
        isMinimized ? "h-[56px]" : "h-[600px]",
        "max-h-[calc(100vh-48px)] max-w-[calc(100vw-48px)]",
        className,
      )}
    >
      {/* Header */}
      <div className="flex items-center justify-between bg-linkedin-blue px-4 py-3">
        <div className="flex items-center gap-2">
          <div className="flex h-8 w-8 items-center justify-center rounded-full bg-white/20">
            <MessageSquare className="h-4 w-4 text-white" />
          </div>
          <div>
            <p className="text-sm font-semibold text-white">AI Support</p>
            <p className="text-xs text-white/70">Online</p>
          </div>
        </div>
        <div className="flex items-center gap-1">
          <button
            type="button"
            onClick={() => setIsMinimized((m) => !m)}
            className="flex h-7 w-7 items-center justify-center rounded-full text-white/70 transition-colors hover:bg-white/20 hover:text-white"
            aria-label={isMinimized ? "Expand" : "Minimize"}
          >
            <Minus className="h-4 w-4" />
          </button>
          <button
            type="button"
            onClick={() => {
              setIsOpen(false);
              setIsMinimized(false);
            }}
            className="flex h-7 w-7 items-center justify-center rounded-full text-white/70 transition-colors hover:bg-white/20 hover:text-white"
            aria-label="Close chat"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
      </div>

      {/* Body */}
      {!isMinimized && (
        <>
          <MessageList messages={messages} className="flex-1" />
          <MessageInput
            onSend={handleSend}
            placeholder="Type your message..."
          />
          {/* Footer */}
          <div className="border-t border-linkedin-gray-20 bg-linkedin-gray-10 py-1.5 text-center">
            <span className="text-[10px] text-linkedin-gray-50">
              Powered by AI Support
            </span>
          </div>
        </>
      )}
    </div>
  );
}
