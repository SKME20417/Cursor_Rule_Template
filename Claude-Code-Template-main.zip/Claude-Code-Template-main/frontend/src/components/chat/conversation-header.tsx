"use client";

import React from "react";
import { cn } from "@/lib/utils/cn";
import { ChannelBadge } from "./channel-badge";
import {
  UserPlus,
  ArrowRightLeft,
  XCircle,
  Video,
  Phone,
  Eye,
} from "lucide-react";

interface ConversationHeaderProps {
  customerName: string;
  customerAvatar?: string;
  channel: string;
  status: "active" | "waiting" | "resolved";
  onAssign?: () => void;
  onTransfer?: () => void;
  onClose?: () => void;
  onVideoCall?: () => void;
  onVoiceCall?: () => void;
  onViewContext?: () => void;
  className?: string;
}

const STATUS_STYLES: Record<string, { label: string; className: string }> = {
  active: {
    label: "Active",
    className: "bg-green-50 text-linkedin-green",
  },
  waiting: {
    label: "Waiting",
    className: "bg-orange-50 text-linkedin-orange",
  },
  resolved: {
    label: "Resolved",
    className: "bg-linkedin-gray-20 text-linkedin-gray-70",
  },
};

function getInitials(name: string): string {
  const parts = name.trim().split(/\s+/);
  if (parts.length === 1) return parts[0][0]?.toUpperCase() ?? "?";
  return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
}

export function ConversationHeader({
  customerName,
  customerAvatar,
  channel,
  status,
  onAssign,
  onTransfer,
  onClose,
  onVideoCall,
  onVoiceCall,
  onViewContext,
  className,
}: ConversationHeaderProps) {
  const statusConfig = STATUS_STYLES[status];

  return (
    <div
      className={cn(
        "flex items-center justify-between border-b border-linkedin-gray-20 bg-linkedin-white px-4 py-3",
        className,
      )}
    >
      {/* Left: customer info */}
      <div className="flex items-center gap-3">
        {customerAvatar ? (
          <img
            src={customerAvatar}
            alt={customerName}
            className="h-10 w-10 rounded-full object-cover"
          />
        ) : (
          <span className="flex h-10 w-10 items-center justify-center rounded-full bg-linkedin-blue-bg text-sm font-semibold text-linkedin-blue">
            {getInitials(customerName)}
          </span>
        )}
        <div className="flex flex-col">
          <span className="text-sm font-semibold text-linkedin-gray-90">
            {customerName}
          </span>
          <div className="flex items-center gap-2">
            <ChannelBadge channel={channel} />
            <span
              className={cn(
                "inline-flex items-center rounded-full px-2 py-0.5 text-xs font-medium",
                statusConfig.className,
              )}
            >
              {statusConfig.label}
            </span>
          </div>
        </div>
      </div>

      {/* Right: actions */}
      <div className="flex items-center gap-1">
        {[
          { icon: Phone, label: "Voice call", action: onVoiceCall },
          { icon: Video, label: "Video call", action: onVideoCall },
          { icon: Eye, label: "View context", action: onViewContext },
          { icon: UserPlus, label: "Assign", action: onAssign },
          { icon: ArrowRightLeft, label: "Transfer", action: onTransfer },
          { icon: XCircle, label: "Close", action: onClose },
        ].map(({ icon: Icon, label, action }) =>
          action ? (
            <button
              key={label}
              type="button"
              onClick={action}
              className="flex h-8 w-8 items-center justify-center rounded-full text-linkedin-gray-50 transition-colors hover:bg-linkedin-gray-10 hover:text-linkedin-blue"
              aria-label={label}
              title={label}
            >
              <Icon className="h-4 w-4" />
            </button>
          ) : null,
        )}
      </div>
    </div>
  );
}
