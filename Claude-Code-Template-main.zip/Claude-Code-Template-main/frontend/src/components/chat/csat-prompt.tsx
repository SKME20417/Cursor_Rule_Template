"use client";

import React, { useState } from "react";
import { cn } from "@/lib/utils/cn";
import { Star } from "lucide-react";

interface CsatPromptProps {
  onSubmit: (rating: number, comment?: string) => void;
  onDismiss?: () => void;
  className?: string;
}

export function CsatPrompt({ onSubmit, onDismiss, className }: CsatPromptProps) {
  const [rating, setRating] = useState(0);
  const [hoveredStar, setHoveredStar] = useState(0);
  const [comment, setComment] = useState("");
  const [submitted, setSubmitted] = useState(false);

  function handleSubmit() {
    if (rating === 0) return;
    onSubmit(rating, comment.trim() || undefined);
    setSubmitted(true);
  }

  if (submitted) {
    return (
      <div
        className={cn(
          "rounded-lg border border-linkedin-gray-20 bg-linkedin-white p-6 text-center",
          className,
        )}
      >
        <p className="text-sm font-medium text-linkedin-gray-90">
          Thank you for your feedback!
        </p>
        <p className="mt-1 text-xs text-linkedin-gray-50">
          Your input helps us improve our service.
        </p>
      </div>
    );
  }

  return (
    <div
      className={cn(
        "rounded-lg border border-linkedin-gray-20 bg-linkedin-white p-6",
        className,
      )}
    >
      <p className="text-center text-sm font-semibold text-linkedin-gray-90">
        How was your experience?
      </p>

      {/* Star rating */}
      <div className="mt-4 flex justify-center gap-1">
        {[1, 2, 3, 4, 5].map((star) => (
          <button
            key={star}
            type="button"
            onClick={() => setRating(star)}
            onMouseEnter={() => setHoveredStar(star)}
            onMouseLeave={() => setHoveredStar(0)}
            className="p-1 transition-transform hover:scale-110"
            aria-label={`Rate ${star} out of 5`}
          >
            <Star
              className={cn(
                "h-7 w-7 transition-colors",
                (hoveredStar || rating) >= star
                  ? "fill-yellow-400 text-yellow-400"
                  : "text-linkedin-gray-30",
              )}
            />
          </button>
        ))}
      </div>

      {/* Comment */}
      {rating > 0 && (
        <textarea
          value={comment}
          onChange={(e) => setComment(e.target.value)}
          placeholder="Any additional comments? (optional)"
          rows={3}
          className="mt-4 w-full resize-none rounded-lg border border-linkedin-gray-20 bg-linkedin-gray-10 px-3 py-2 text-sm text-linkedin-gray-90 placeholder:text-linkedin-gray-50 focus:border-linkedin-blue focus:outline-none focus:ring-1 focus:ring-linkedin-blue"
        />
      )}

      {/* Actions */}
      <div className="mt-4 flex items-center justify-center gap-3">
        {onDismiss && (
          <button
            type="button"
            onClick={onDismiss}
            className="rounded-full px-4 py-2 text-sm font-medium text-linkedin-gray-50 transition-colors hover:bg-linkedin-gray-10"
          >
            Skip
          </button>
        )}
        <button
          type="button"
          onClick={handleSubmit}
          disabled={rating === 0}
          className="rounded-full bg-linkedin-blue px-6 py-2 text-sm font-semibold text-white transition-colors hover:bg-linkedin-blue-hover disabled:cursor-not-allowed disabled:opacity-50"
        >
          Submit
        </button>
      </div>
    </div>
  );
}
