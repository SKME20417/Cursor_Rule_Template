"use client";

import React, { useState, useMemo } from "react";
import { cn } from "@/lib/utils/cn";
import { Search } from "lucide-react";
import { ConversationItem } from "./conversation-item";

interface Conversation {
  id: string;
  customerName: string;
  customerAvatar?: string;
  lastMessage: string;
  timestamp: string;
  channel: string;
  unreadCount: number;
  priority: "low" | "medium" | "high" | "urgent";
  sentiment: "positive" | "neutral" | "negative";
  assignedTo?: string;
  isAiHandled?: boolean;
}

interface ConversationListProps {
  conversations: Conversation[];
  activeId?: string;
  onSelect: (id: string) => void;
  className?: string;
}

type FilterTab = "all" | "mine" | "unassigned" | "ai";

const FILTER_TABS: { key: FilterTab; label: string }[] = [
  { key: "all", label: "All" },
  { key: "mine", label: "Mine" },
  { key: "unassigned", label: "Unassigned" },
  { key: "ai", label: "AI" },
];

export function ConversationList({
  conversations,
  activeId,
  onSelect,
  className,
}: ConversationListProps) {
  const [search, setSearch] = useState("");
  const [activeTab, setActiveTab] = useState<FilterTab>("all");

  const filtered = useMemo(() => {
    let result = conversations;

    // Filter by tab
    if (activeTab === "mine") {
      result = result.filter((c) => c.assignedTo === "current-agent");
    } else if (activeTab === "unassigned") {
      result = result.filter((c) => !c.assignedTo);
    } else if (activeTab === "ai") {
      result = result.filter((c) => c.isAiHandled);
    }

    // Filter by search
    if (search.trim()) {
      const q = search.toLowerCase();
      result = result.filter(
        (c) =>
          c.customerName.toLowerCase().includes(q) ||
          c.lastMessage.toLowerCase().includes(q),
      );
    }

    return result;
  }, [conversations, activeTab, search]);

  return (
    <div
      className={cn(
        "flex h-full flex-col border-r border-linkedin-gray-20 bg-linkedin-white",
        className,
      )}
    >
      {/* Search */}
      <div className="border-b border-linkedin-gray-20 p-3">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-linkedin-gray-50" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search conversations..."
            className="w-full rounded-lg border border-linkedin-gray-20 bg-linkedin-gray-10 py-2 pl-9 pr-3 text-sm text-linkedin-gray-90 placeholder:text-linkedin-gray-50 focus:border-linkedin-blue focus:outline-none focus:ring-1 focus:ring-linkedin-blue"
          />
        </div>
      </div>

      {/* Filter tabs */}
      <div className="flex border-b border-linkedin-gray-20">
        {FILTER_TABS.map((tab) => (
          <button
            key={tab.key}
            type="button"
            onClick={() => setActiveTab(tab.key)}
            className={cn(
              "flex-1 py-2.5 text-xs font-medium transition-colors",
              activeTab === tab.key
                ? "border-b-2 border-linkedin-blue text-linkedin-blue"
                : "text-linkedin-gray-50 hover:text-linkedin-gray-70",
            )}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Conversation list */}
      <div className="flex-1 overflow-y-auto">
        {filtered.length === 0 ? (
          <div className="flex flex-col items-center justify-center gap-2 px-4 py-12">
            <p className="text-sm text-linkedin-gray-50">No conversations found</p>
          </div>
        ) : (
          filtered.map((conv) => (
            <ConversationItem
              key={conv.id}
              {...conv}
              isActive={conv.id === activeId}
              onClick={() => onSelect(conv.id)}
            />
          ))
        )}
      </div>
    </div>
  );
}
