"use client";

import React from "react";
import { cn } from "@/lib/utils/cn";
import {
  FileText,
  Image as ImageIcon,
  File,
  Download,
  FileSpreadsheet,
  FileCode,
} from "lucide-react";

interface FileAttachmentProps {
  name: string;
  size: string;
  type: string;
  url?: string;
  thumbnailUrl?: string;
  className?: string;
}

function getFileIcon(type: string): React.ElementType {
  const lower = type.toLowerCase();
  if (lower.includes("pdf")) return FileText;
  if (lower.includes("image") || lower.includes("png") || lower.includes("jpg") || lower.includes("jpeg"))
    return ImageIcon;
  if (lower.includes("spreadsheet") || lower.includes("csv") || lower.includes("xlsx"))
    return FileSpreadsheet;
  if (lower.includes("code") || lower.includes("json") || lower.includes("xml"))
    return FileCode;
  return File;
}

export function FileAttachment({
  name,
  size,
  type,
  url,
  thumbnailUrl,
  className,
}: FileAttachmentProps) {
  const Icon = getFileIcon(type);
  const isImage =
    type.toLowerCase().includes("image") ||
    type.toLowerCase().includes("png") ||
    type.toLowerCase().includes("jpg") ||
    type.toLowerCase().includes("jpeg");

  return (
    <div
      className={cn(
        "flex flex-col gap-2 rounded-lg border border-linkedin-gray-20 bg-linkedin-white p-3",
        className,
      )}
    >
      {isImage && thumbnailUrl && (
        <div className="overflow-hidden rounded-md">
          <img
            src={thumbnailUrl}
            alt={name}
            className="h-32 w-full object-cover"
          />
        </div>
      )}
      <div className="flex items-center gap-3">
        <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-linkedin-blue-bg">
          <Icon className="h-5 w-5 text-linkedin-blue" aria-hidden="true" />
        </div>
        <div className="flex min-w-0 flex-1 flex-col">
          <span className="truncate text-sm font-medium text-linkedin-gray-90">
            {name}
          </span>
          <span className="text-xs text-linkedin-gray-50">{size}</span>
        </div>
        {url && (
          <a
            href={url}
            download={name}
            className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full text-linkedin-gray-50 transition-colors hover:bg-linkedin-gray-10 hover:text-linkedin-blue"
            aria-label={`Download ${name}`}
          >
            <Download className="h-4 w-4" />
          </a>
        )}
      </div>
    </div>
  );
}
