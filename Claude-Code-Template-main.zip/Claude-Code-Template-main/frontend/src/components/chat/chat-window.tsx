"use client";

import React, { useState } from "react";
import { cn } from "@/lib/utils/cn";
import { ConversationHeader } from "./conversation-header";
import { MessageList } from "./message-list";
import { MessageInput } from "./message-input";
import { TypingIndicator } from "./typing-indicator";

interface MessageSender {
  id: string;
  name: string;
  avatar?: string;
  role: "customer" | "agent" | "system" | "ai";
}

interface Message {
  id: string;
  content: string;
  sender: MessageSender;
  timestamp: string;
  type: "text" | "image" | "file" | "system";
  channel?: string;
  metadata?: Record<string, unknown>;
}

interface ChatWindowProps {
  conversationId: string;
  className?: string;
}

// ----- Mock data -----
const MOCK_MESSAGES: Message[] = [
  {
    id: "1",
    content: "Hi, I'm having trouble with my subscription renewal. It charged me twice.",
    sender: { id: "c1", name: "Sarah Johnson", role: "customer" },
    timestamp: new Date(Date.now() - 3600000 * 2).toISOString(),
    type: "text",
    channel: "web",
  },
  {
    id: "2",
    content: "I can see a potential duplicate charge on your account. Let me look into the billing details for you.",
    sender: { id: "ai1", name: "AI Assistant", role: "ai" },
    timestamp: new Date(Date.now() - 3600000 * 1.9).toISOString(),
    type: "text",
    channel: "web",
  },
  {
    id: "3",
    content: "Hi Sarah! I've reviewed your account. You're right -- there was a duplicate charge on March 7th. I'm processing a refund of $29.99 right now.",
    sender: { id: "a1", name: "Mike Chen", role: "agent" },
    timestamp: new Date(Date.now() - 3600000).toISOString(),
    type: "text",
    channel: "web",
  },
  {
    id: "4",
    content: "Thank you so much! How long will the refund take?",
    sender: { id: "c1", name: "Sarah Johnson", role: "customer" },
    timestamp: new Date(Date.now() - 1800000).toISOString(),
    type: "text",
    channel: "web",
  },
  {
    id: "5",
    content: "Refund initiated for order #ORD-20260307-4821.",
    sender: { id: "sys", name: "System", role: "system" },
    timestamp: new Date(Date.now() - 1700000).toISOString(),
    type: "system",
  },
  {
    id: "6",
    content: "The refund will appear on your card within 3-5 business days. Is there anything else I can help you with?",
    sender: { id: "a1", name: "Mike Chen", role: "agent" },
    timestamp: new Date(Date.now() - 900000).toISOString(),
    type: "text",
    channel: "web",
  },
];

export function ChatWindow({ conversationId, className }: ChatWindowProps) {
  const [messages, setMessages] = useState<Message[]>(MOCK_MESSAGES);
  const [isTyping, setIsTyping] = useState(false);

  function handleSend(content: string) {
    const newMsg: Message = {
      id: `msg-${Date.now()}`,
      content,
      sender: { id: "a1", name: "Mike Chen", role: "agent" },
      timestamp: new Date().toISOString(),
      type: "text",
      channel: "web",
    };
    setMessages((prev) => [...prev, newMsg]);
  }

  function handleTyping() {
    setIsTyping(true);
    setTimeout(() => setIsTyping(false), 2000);
  }

  return (
    <div
      className={cn(
        "flex h-full flex-col bg-linkedin-white",
        className,
      )}
      data-conversation-id={conversationId}
    >
      <ConversationHeader
        customerName="Sarah Johnson"
        channel="web"
        status="active"
        onAssign={() => {}}
        onTransfer={() => {}}
        onClose={() => {}}
        onVideoCall={() => {}}
        onVoiceCall={() => {}}
        onViewContext={() => {}}
      />
      <MessageList
        messages={messages}
        hasMore
        onLoadMore={() => {}}
      />
      {isTyping && <TypingIndicator name="Sarah" />}
      <MessageInput
        onSend={handleSend}
        onTyping={handleTyping}
        placeholder="Type your reply..."
      />
    </div>
  );
}
