"use client";

import React from "react";
import { cn } from "@/lib/utils/cn";

interface TypingIndicatorProps {
  name?: string;
  className?: string;
}

export function TypingIndicator({ name, className }: TypingIndicatorProps) {
  return (
    <div
      className={cn(
        "flex items-center gap-2 px-4 py-2 text-xs text-linkedin-gray-50",
        className,
      )}
      aria-live="polite"
    >
      <span className="inline-flex items-center gap-0.5">
        <span className="h-1.5 w-1.5 rounded-full bg-linkedin-gray-50 animate-bounce [animation-delay:0ms]" />
        <span className="h-1.5 w-1.5 rounded-full bg-linkedin-gray-50 animate-bounce [animation-delay:150ms]" />
        <span className="h-1.5 w-1.5 rounded-full bg-linkedin-gray-50 animate-bounce [animation-delay:300ms]" />
      </span>
      {name ? `${name} is typing...` : "Typing..."}
    </div>
  );
}
