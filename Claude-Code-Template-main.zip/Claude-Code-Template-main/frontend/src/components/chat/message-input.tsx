"use client";

import React, { useCallback, useRef, useState } from "react";
import { cn } from "@/lib/utils/cn";
import { Smile, Paperclip, Send } from "lucide-react";
import { EmojiPicker } from "./emoji-picker";

interface MessageInputProps {
  onSend: (content: string, attachments?: File[]) => void;
  onTyping?: () => void;
  disabled?: boolean;
  placeholder?: string;
  className?: string;
}

export function MessageInput({
  onSend,
  onTyping,
  disabled = false,
  placeholder = "Type a message...",
  className,
}: MessageInputProps) {
  const [text, setText] = useState("");
  const [showEmoji, setShowEmoji] = useState(false);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const typingTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const adjustHeight = useCallback(() => {
    const el = textareaRef.current;
    if (!el) return;
    el.style.height = "auto";
    el.style.height = `${Math.min(el.scrollHeight, 120)}px`;
  }, []);

  function handleChange(e: React.ChangeEvent<HTMLTextAreaElement>) {
    setText(e.target.value);
    adjustHeight();

    // Debounced typing indicator
    if (onTyping) {
      if (typingTimeoutRef.current) clearTimeout(typingTimeoutRef.current);
      onTyping();
      typingTimeoutRef.current = setTimeout(() => {
        typingTimeoutRef.current = null;
      }, 1000);
    }
  }

  function handleSend() {
    const trimmed = text.trim();
    if (!trimmed || disabled) return;
    onSend(trimmed);
    setText("");
    if (textareaRef.current) {
      textareaRef.current.style.height = "auto";
    }
    setShowEmoji(false);
  }

  function handleKeyDown(e: React.KeyboardEvent<HTMLTextAreaElement>) {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  }

  function handleEmojiSelect(emoji: string) {
    setText((prev) => prev + emoji);
    textareaRef.current?.focus();
  }

  function handleFileClick() {
    fileInputRef.current?.click();
  }

  function handleFileChange(e: React.ChangeEvent<HTMLInputElement>) {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    onSend("", Array.from(files));
    e.target.value = "";
  }

  return (
    <div className={cn("relative border-t border-linkedin-gray-20 bg-linkedin-white", className)}>
      {/* Emoji picker popover */}
      {showEmoji && (
        <div className="absolute bottom-full left-2 z-10 mb-2">
          <EmojiPicker
            onSelect={handleEmojiSelect}
          />
        </div>
      )}

      <div className="flex items-end gap-2 p-3">
        {/* Emoji toggle */}
        <button
          type="button"
          onClick={() => setShowEmoji((s) => !s)}
          disabled={disabled}
          className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full text-linkedin-gray-50 transition-colors hover:bg-linkedin-gray-10 hover:text-linkedin-blue disabled:opacity-50"
          aria-label="Toggle emoji picker"
        >
          <Smile className="h-5 w-5" />
        </button>

        {/* File attachment */}
        <button
          type="button"
          onClick={handleFileClick}
          disabled={disabled}
          className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full text-linkedin-gray-50 transition-colors hover:bg-linkedin-gray-10 hover:text-linkedin-blue disabled:opacity-50"
          aria-label="Attach file"
        >
          <Paperclip className="h-5 w-5" />
        </button>
        <input
          ref={fileInputRef}
          type="file"
          multiple
          onChange={handleFileChange}
          className="hidden"
          aria-hidden="true"
        />

        {/* Textarea */}
        <textarea
          ref={textareaRef}
          value={text}
          onChange={handleChange}
          onKeyDown={handleKeyDown}
          placeholder={placeholder}
          disabled={disabled}
          rows={1}
          className="max-h-[120px] min-h-[36px] flex-1 resize-none rounded-2xl border border-linkedin-gray-20 bg-linkedin-gray-10 px-4 py-2 text-sm text-linkedin-gray-90 placeholder:text-linkedin-gray-50 focus:border-linkedin-blue focus:outline-none focus:ring-1 focus:ring-linkedin-blue disabled:cursor-not-allowed disabled:opacity-50"
        />

        {/* Send */}
        <button
          type="button"
          onClick={handleSend}
          disabled={disabled || !text.trim()}
          className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-linkedin-blue text-white transition-colors hover:bg-linkedin-blue-hover disabled:cursor-not-allowed disabled:opacity-50"
          aria-label="Send message"
        >
          <Send className="h-4 w-4" />
        </button>
      </div>
    </div>
  );
}
