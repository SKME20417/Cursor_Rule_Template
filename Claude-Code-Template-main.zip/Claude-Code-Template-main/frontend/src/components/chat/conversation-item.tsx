"use client";

import React from "react";
import { cn } from "@/lib/utils/cn";
import { ChannelBadge } from "./channel-badge";

interface ConversationItemProps {
  id: string;
  customerName: string;
  customerAvatar?: string;
  lastMessage: string;
  timestamp: string;
  channel: string;
  unreadCount: number;
  priority: "low" | "medium" | "high" | "urgent";
  sentiment: "positive" | "neutral" | "negative";
  isActive?: boolean;
  onClick?: () => void;
  className?: string;
}

const PRIORITY_COLORS: Record<string, string> = {
  low: "bg-linkedin-gray-50",
  medium: "bg-linkedin-blue",
  high: "bg-linkedin-orange",
  urgent: "bg-linkedin-red",
};

const SENTIMENT_COLORS: Record<string, string> = {
  positive: "bg-linkedin-green",
  neutral: "bg-linkedin-gray-50",
  negative: "bg-linkedin-red",
};

function formatRelativeTime(timestamp: string): string {
  const diff = Date.now() - new Date(timestamp).getTime();
  const minutes = Math.floor(diff / 60000);
  if (minutes < 1) return "Just now";
  if (minutes < 60) return `${minutes}m`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours}h`;
  const days = Math.floor(hours / 24);
  return `${days}d`;
}

function getInitials(name: string): string {
  const parts = name.trim().split(/\s+/);
  if (parts.length === 1) return parts[0][0]?.toUpperCase() ?? "?";
  return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
}

export function ConversationItem({
  customerName,
  customerAvatar,
  lastMessage,
  timestamp,
  channel,
  unreadCount,
  priority,
  sentiment,
  isActive = false,
  onClick,
  className,
}: ConversationItemProps) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "flex w-full items-start gap-3 px-4 py-3 text-left transition-colors",
        isActive
          ? "bg-linkedin-blue-bg border-l-2 border-linkedin-blue"
          : "hover:bg-linkedin-gray-10 border-l-2 border-transparent",
        className,
      )}
    >
      {/* Avatar with priority dot */}
      <div className="relative shrink-0">
        {customerAvatar ? (
          <img
            src={customerAvatar}
            alt={customerName}
            className="h-10 w-10 rounded-full object-cover"
          />
        ) : (
          <span className="flex h-10 w-10 items-center justify-center rounded-full bg-linkedin-blue-bg text-sm font-semibold text-linkedin-blue">
            {getInitials(customerName)}
          </span>
        )}
        {/* Priority dot */}
        <span
          className={cn(
            "absolute -right-0.5 -top-0.5 h-3 w-3 rounded-full border-2 border-linkedin-white",
            PRIORITY_COLORS[priority],
          )}
          title={`${priority} priority`}
        />
      </div>

      {/* Content */}
      <div className="flex min-w-0 flex-1 flex-col gap-0.5">
        <div className="flex items-center justify-between">
          <span
            className={cn(
              "truncate text-sm",
              unreadCount > 0
                ? "font-semibold text-linkedin-gray-90"
                : "font-medium text-linkedin-gray-70",
            )}
          >
            {customerName}
          </span>
          <span className="shrink-0 text-xs text-linkedin-gray-50">
            {formatRelativeTime(timestamp)}
          </span>
        </div>

        <div className="flex items-center gap-2">
          <p
            className={cn(
              "flex-1 truncate text-xs",
              unreadCount > 0
                ? "font-medium text-linkedin-gray-70"
                : "text-linkedin-gray-50",
            )}
          >
            {lastMessage}
          </p>
          {unreadCount > 0 && (
            <span className="flex h-5 min-w-[20px] shrink-0 items-center justify-center rounded-full bg-linkedin-blue px-1.5 text-[10px] font-bold text-white">
              {unreadCount > 99 ? "99+" : unreadCount}
            </span>
          )}
        </div>

        {/* Channel + sentiment bar */}
        <div className="flex items-center gap-2 pt-0.5">
          <ChannelBadge channel={channel} />
          <div className="flex items-center gap-1">
            <div
              className={cn(
                "h-1.5 w-8 rounded-full",
                SENTIMENT_COLORS[sentiment],
              )}
              title={`Sentiment: ${sentiment}`}
            />
          </div>
        </div>
      </div>
    </button>
  );
}
