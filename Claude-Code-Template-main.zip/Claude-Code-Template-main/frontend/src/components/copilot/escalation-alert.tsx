"use client";

import React from "react";
import { cn } from "@/lib/utils/cn";
import { AlertTriangle, ArrowUpCircle, X } from "lucide-react";

interface EscalationAlertProps {
  reason: string;
  onEscalate: () => void;
  onDismiss: () => void;
  className?: string;
}

export function EscalationAlert({
  reason,
  onEscalate,
  onDismiss,
  className,
}: EscalationAlertProps) {
  return (
    <div
      className={cn(
        "relative overflow-hidden rounded-lg border border-linkedin-orange/30 bg-orange-50",
        className,
      )}
      role="alert"
    >
      {/* Pulsing attention bar */}
      <div className="absolute left-0 top-0 h-full w-1 animate-pulse bg-linkedin-orange" />

      <div className="flex flex-col gap-3 p-4 pl-5">
        <div className="flex items-start gap-2">
          <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-linkedin-orange" />
          <div className="flex-1">
            <p className="text-sm font-semibold text-linkedin-orange">
              Escalation Recommended
            </p>
            <p className="mt-0.5 text-xs text-linkedin-gray-70">{reason}</p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={onEscalate}
            className="inline-flex items-center gap-1.5 rounded-full bg-linkedin-orange px-4 py-1.5 text-xs font-semibold text-white transition-colors hover:bg-orange-700"
          >
            <ArrowUpCircle className="h-3.5 w-3.5" />
            Escalate Now
          </button>
          <button
            type="button"
            onClick={onDismiss}
            className="inline-flex items-center gap-1 rounded-full px-3 py-1.5 text-xs font-medium text-linkedin-gray-50 transition-colors hover:bg-orange-100 hover:text-linkedin-gray-70"
          >
            <X className="h-3 w-3" />
            Dismiss
          </button>
        </div>
      </div>
    </div>
  );
}
