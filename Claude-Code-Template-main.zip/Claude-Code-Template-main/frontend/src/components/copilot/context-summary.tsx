"use client";

import React from "react";
import { cn } from "@/lib/utils/cn";
import { FileText, Lightbulb, TrendingUp, RefreshCw, Loader2 } from "lucide-react";
import { SentimentIndicator } from "./sentiment-indicator";

interface ContextSummaryProps {
  summary: string;
  keyPoints: string[];
  suggestedNextSteps: string[];
  sentiment: "positive" | "neutral" | "negative";
  sentimentScore?: number;
  loading?: boolean;
  onRefresh?: () => void;
  className?: string;
}

export function ContextSummary({
  summary,
  keyPoints,
  suggestedNextSteps,
  sentiment,
  sentimentScore,
  loading = false,
  onRefresh,
  className,
}: ContextSummaryProps) {
  if (loading) {
    return (
      <div className={cn("flex flex-col gap-4 p-1", className)}>
        <div className="skeleton h-4 w-full rounded" />
        <div className="skeleton h-4 w-3/4 rounded" />
        <div className="skeleton h-4 w-1/2 rounded" />
        <div className="skeleton mt-2 h-20 w-full rounded" />
      </div>
    );
  }

  return (
    <div className={cn("flex flex-col gap-4", className)}>
      {/* Header with refresh */}
      <div className="flex items-center justify-between">
        <SentimentIndicator sentiment={sentiment} score={sentimentScore} />
        {onRefresh && (
          <button
            type="button"
            onClick={onRefresh}
            className="inline-flex items-center gap-1 text-xs text-linkedin-blue hover:text-linkedin-blue-hover"
          >
            <RefreshCw className="h-3 w-3" />
            Refresh
          </button>
        )}
      </div>

      {/* Issue summary */}
      <div className="flex gap-2">
        <FileText className="mt-0.5 h-4 w-4 shrink-0 text-linkedin-blue" />
        <div>
          <p className="text-xs font-semibold text-linkedin-gray-90">
            Issue Summary
          </p>
          <p className="mt-0.5 text-xs leading-relaxed text-linkedin-gray-70">
            {summary}
          </p>
        </div>
      </div>

      {/* Key points */}
      {keyPoints.length > 0 && (
        <div className="flex gap-2">
          <TrendingUp className="mt-0.5 h-4 w-4 shrink-0 text-linkedin-blue" />
          <div>
            <p className="text-xs font-semibold text-linkedin-gray-90">
              Key Points
            </p>
            <ul className="mt-1 flex flex-col gap-1">
              {keyPoints.map((point, i) => (
                <li
                  key={i}
                  className="flex items-start gap-1.5 text-xs text-linkedin-gray-70"
                >
                  <span className="mt-1 h-1.5 w-1.5 shrink-0 rounded-full bg-linkedin-blue" />
                  {point}
                </li>
              ))}
            </ul>
          </div>
        </div>
      )}

      {/* Suggested next steps */}
      {suggestedNextSteps.length > 0 && (
        <div className="flex gap-2">
          <Lightbulb className="mt-0.5 h-4 w-4 shrink-0 text-yellow-500" />
          <div>
            <p className="text-xs font-semibold text-linkedin-gray-90">
              Suggested Next Steps
            </p>
            <ul className="mt-1 flex flex-col gap-1">
              {suggestedNextSteps.map((step, i) => (
                <li
                  key={i}
                  className="flex items-start gap-1.5 text-xs text-linkedin-gray-70"
                >
                  <span className="mt-1 h-1.5 w-1.5 shrink-0 rounded-full bg-yellow-400" />
                  {step}
                </li>
              ))}
            </ul>
          </div>
        </div>
      )}
    </div>
  );
}
