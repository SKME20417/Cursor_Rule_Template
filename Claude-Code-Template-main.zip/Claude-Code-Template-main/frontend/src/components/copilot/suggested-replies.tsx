"use client";

import React from "react";
import { cn } from "@/lib/utils/cn";
import { Pencil, Send, Loader2 } from "lucide-react";
import { CopilotFeedback } from "./copilot-feedback";

interface SuggestedReply {
  id: string;
  content: string;
  confidence: number;
}

interface SuggestedRepliesProps {
  suggestions: SuggestedReply[];
  loading?: boolean;
  onUseReply: (content: string) => void;
  onEditReply: (content: string) => void;
  onFeedback: (suggestionId: string, rating: "up" | "down", comment?: string) => void;
  className?: string;
}

function SkeletonCard() {
  return (
    <div className="rounded-lg border border-linkedin-gray-20 p-3">
      <div className="skeleton h-4 w-3/4 rounded" />
      <div className="skeleton mt-2 h-4 w-full rounded" />
      <div className="skeleton mt-2 h-4 w-1/2 rounded" />
      <div className="mt-3 flex gap-2">
        <div className="skeleton h-7 w-20 rounded-full" />
        <div className="skeleton h-7 w-20 rounded-full" />
      </div>
    </div>
  );
}

export function SuggestedReplies({
  suggestions,
  loading = false,
  onUseReply,
  onEditReply,
  onFeedback,
  className,
}: SuggestedRepliesProps) {
  if (loading) {
    return (
      <div className={cn("flex flex-col gap-3", className)}>
        <SkeletonCard />
        <SkeletonCard />
      </div>
    );
  }

  if (suggestions.length === 0) {
    return (
      <div className={cn("py-6 text-center text-xs text-linkedin-gray-50", className)}>
        No suggestions available yet.
      </div>
    );
  }

  return (
    <div className={cn("flex flex-col gap-3", className)}>
      {suggestions.map((suggestion) => (
        <div
          key={suggestion.id}
          className="rounded-lg border border-linkedin-gray-20 bg-linkedin-white p-3 transition-shadow hover:shadow-sm"
        >
          {/* Confidence badge */}
          <div className="mb-2 flex items-center justify-between">
            <span
              className={cn(
                "rounded-full px-2 py-0.5 text-[10px] font-semibold",
                suggestion.confidence >= 0.8
                  ? "bg-green-50 text-linkedin-green"
                  : suggestion.confidence >= 0.5
                    ? "bg-yellow-50 text-yellow-700"
                    : "bg-linkedin-gray-10 text-linkedin-gray-50",
              )}
            >
              {Math.round(suggestion.confidence * 100)}% match
            </span>
          </div>

          {/* Content */}
          <p className="text-sm leading-relaxed text-linkedin-gray-70">
            {suggestion.content}
          </p>

          {/* Actions + Feedback */}
          <div className="mt-3 flex items-center justify-between">
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => onUseReply(suggestion.content)}
                className="inline-flex items-center gap-1 rounded-full bg-linkedin-blue px-3 py-1 text-xs font-medium text-white transition-colors hover:bg-linkedin-blue-hover"
              >
                <Send className="h-3 w-3" />
                Use
              </button>
              <button
                type="button"
                onClick={() => onEditReply(suggestion.content)}
                className="inline-flex items-center gap-1 rounded-full border border-linkedin-gray-20 px-3 py-1 text-xs font-medium text-linkedin-gray-70 transition-colors hover:bg-linkedin-gray-10"
              >
                <Pencil className="h-3 w-3" />
                Edit & Use
              </button>
            </div>
            <CopilotFeedback
              suggestionId={suggestion.id}
              onFeedback={onFeedback}
            />
          </div>
        </div>
      ))}
    </div>
  );
}
