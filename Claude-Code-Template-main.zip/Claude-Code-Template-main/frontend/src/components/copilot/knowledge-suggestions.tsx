"use client";

import React from "react";
import { cn } from "@/lib/utils/cn";
import { FileText, Link2, ExternalLink, RefreshCw } from "lucide-react";

interface KnowledgeArticle {
  id: string;
  title: string;
  snippet: string;
  relevanceScore: number;
  url: string;
}

interface KnowledgeSuggestionsProps {
  articles: KnowledgeArticle[];
  loading?: boolean;
  onInsertLink: (article: KnowledgeArticle) => void;
  onRefresh?: () => void;
  className?: string;
}

export function KnowledgeSuggestions({
  articles,
  loading = false,
  onInsertLink,
  onRefresh,
  className,
}: KnowledgeSuggestionsProps) {
  if (loading) {
    return (
      <div className={cn("flex flex-col gap-3", className)}>
        {[1, 2, 3].map((i) => (
          <div key={i} className="rounded-lg border border-linkedin-gray-20 p-3">
            <div className="skeleton h-4 w-3/4 rounded" />
            <div className="skeleton mt-2 h-3 w-full rounded" />
            <div className="skeleton mt-1 h-3 w-2/3 rounded" />
          </div>
        ))}
      </div>
    );
  }

  return (
    <div className={cn("flex flex-col gap-2", className)}>
      {/* Refresh */}
      {onRefresh && (
        <div className="flex justify-end">
          <button
            type="button"
            onClick={onRefresh}
            className="inline-flex items-center gap-1 text-xs text-linkedin-blue transition-colors hover:text-linkedin-blue-hover"
          >
            <RefreshCw className="h-3 w-3" />
            Refresh
          </button>
        </div>
      )}

      {articles.length === 0 ? (
        <p className="py-6 text-center text-xs text-linkedin-gray-50">
          No relevant articles found.
        </p>
      ) : (
        articles.map((article) => (
          <div
            key={article.id}
            className="rounded-lg border border-linkedin-gray-20 bg-linkedin-white p-3 transition-shadow hover:shadow-sm"
          >
            <div className="flex items-start gap-2">
              <FileText className="mt-0.5 h-4 w-4 shrink-0 text-linkedin-blue" />
              <div className="flex-1">
                <p className="text-sm font-medium text-linkedin-gray-90">
                  {article.title}
                </p>
                <p className="mt-0.5 text-xs leading-relaxed text-linkedin-gray-50">
                  {article.snippet}
                </p>
                <div className="mt-2 flex items-center gap-3">
                  <span className="text-[10px] font-medium text-linkedin-gray-50">
                    {Math.round(article.relevanceScore * 100)}% relevant
                  </span>
                  <button
                    type="button"
                    onClick={() => onInsertLink(article)}
                    className="inline-flex items-center gap-1 text-xs font-medium text-linkedin-blue transition-colors hover:text-linkedin-blue-hover"
                  >
                    <Link2 className="h-3 w-3" />
                    Insert link
                  </button>
                  <a
                    href={article.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1 text-xs font-medium text-linkedin-gray-50 transition-colors hover:text-linkedin-blue"
                  >
                    <ExternalLink className="h-3 w-3" />
                    View full
                  </a>
                </div>
              </div>
            </div>
          </div>
        ))
      )}
    </div>
  );
}
