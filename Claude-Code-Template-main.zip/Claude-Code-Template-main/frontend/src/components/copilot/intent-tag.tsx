"use client";

import React from "react";
import { cn } from "@/lib/utils/cn";
import { Tag } from "lucide-react";

interface IntentTagProps {
  intent: string;
  confidence: number;
  className?: string;
}

export function IntentTag({ intent, confidence, className }: IntentTagProps) {
  const pct = Math.round(confidence * 100);

  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border border-linkedin-gray-20 bg-linkedin-white px-2.5 py-1 text-xs font-medium text-linkedin-gray-70",
        className,
      )}
    >
      <Tag className="h-3 w-3 text-linkedin-blue" aria-hidden="true" />
      {intent}
      <span className="rounded-full bg-linkedin-blue-bg px-1.5 py-0.5 text-[10px] font-semibold text-linkedin-blue">
        {pct}%
      </span>
    </span>
  );
}
