"use client";

import React, { useState } from "react";
import { cn } from "@/lib/utils/cn";
import { PanelRightClose, PanelRightOpen } from "lucide-react";
import { SuggestedReplies } from "./suggested-replies";
import { KnowledgeSuggestions } from "./knowledge-suggestions";
import { ContextSummary } from "./context-summary";
import { EscalationAlert } from "./escalation-alert";
import { IntentTag } from "./intent-tag";

interface CopilotPanelProps {
  className?: string;
}

type Tab = "suggestions" | "knowledge" | "summary";

const TABS: { key: Tab; label: string }[] = [
  { key: "suggestions", label: "Suggestions" },
  { key: "knowledge", label: "Knowledge" },
  { key: "summary", label: "Summary" },
];

// ----- Mock data -----
const MOCK_SUGGESTIONS = [
  {
    id: "s1",
    content:
      "The refund typically takes 3-5 business days to appear on your statement. You'll receive a confirmation email once it's processed. Is there anything else I can help with?",
    confidence: 0.92,
  },
  {
    id: "s2",
    content:
      "I understand the frustration with duplicate charges. The refund of $29.99 has been initiated and should reflect in your account within 3-5 business days.",
    confidence: 0.85,
  },
  {
    id: "s3",
    content:
      "Great question! Refunds are processed within 1 business day on our end, but your bank may take an additional 2-4 days to reflect the credit.",
    confidence: 0.71,
  },
];

const MOCK_ARTICLES = [
  {
    id: "kb1",
    title: "Refund Policy & Processing Times",
    snippet:
      "Refunds are initiated within 24 hours and typically appear on the customer's statement within 3-5 business days...",
    relevanceScore: 0.94,
    url: "/kb/refund-policy",
  },
  {
    id: "kb2",
    title: "Handling Duplicate Charges",
    snippet:
      "If a customer reports a duplicate charge, verify the transaction IDs and initiate a refund through the billing dashboard...",
    relevanceScore: 0.88,
    url: "/kb/duplicate-charges",
  },
];

export function CopilotPanel({ className }: CopilotPanelProps) {
  const [collapsed, setCollapsed] = useState(false);
  const [activeTab, setActiveTab] = useState<Tab>("suggestions");
  const [showEscalation, setShowEscalation] = useState(true);

  if (collapsed) {
    return (
      <div className={cn("flex flex-col items-center border-l border-linkedin-gray-20 bg-linkedin-white py-3", className)}>
        <button
          type="button"
          onClick={() => setCollapsed(false)}
          className="flex h-8 w-8 items-center justify-center rounded-full text-linkedin-gray-50 transition-colors hover:bg-linkedin-gray-10 hover:text-linkedin-blue"
          aria-label="Expand copilot panel"
        >
          <PanelRightOpen className="h-4 w-4" />
        </button>
      </div>
    );
  }

  return (
    <div
      className={cn(
        "flex h-full w-80 flex-col border-l border-linkedin-gray-20 bg-linkedin-white",
        "max-lg:fixed max-lg:inset-y-0 max-lg:right-0 max-lg:z-40 max-lg:w-full max-lg:max-w-sm max-lg:shadow-xl",
        className,
      )}
    >
      {/* Header */}
      <div className="flex items-center justify-between border-b border-linkedin-gray-20 px-4 py-3">
        <h2 className="text-sm font-semibold text-linkedin-gray-90">
          AI Copilot
        </h2>
        <button
          type="button"
          onClick={() => setCollapsed(true)}
          className="flex h-7 w-7 items-center justify-center rounded-full text-linkedin-gray-50 transition-colors hover:bg-linkedin-gray-10 hover:text-linkedin-blue"
          aria-label="Collapse copilot panel"
        >
          <PanelRightClose className="h-4 w-4" />
        </button>
      </div>

      {/* Intents */}
      <div className="flex flex-wrap gap-1.5 border-b border-linkedin-gray-20 px-4 py-2.5">
        <IntentTag intent="Billing Issue" confidence={0.91} />
        <IntentTag intent="Refund Request" confidence={0.87} />
      </div>

      {/* Escalation alert */}
      {showEscalation && (
        <div className="border-b border-linkedin-gray-20 px-4 py-3">
          <EscalationAlert
            reason="Customer has been waiting over 10 minutes and sentiment is declining. Consider escalating to a senior agent."
            onEscalate={() => setShowEscalation(false)}
            onDismiss={() => setShowEscalation(false)}
          />
        </div>
      )}

      {/* Tabs */}
      <div className="flex border-b border-linkedin-gray-20">
        {TABS.map((tab) => (
          <button
            key={tab.key}
            type="button"
            onClick={() => setActiveTab(tab.key)}
            className={cn(
              "flex-1 py-2.5 text-xs font-medium transition-colors",
              activeTab === tab.key
                ? "border-b-2 border-linkedin-blue text-linkedin-blue"
                : "text-linkedin-gray-50 hover:text-linkedin-gray-70",
            )}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Tab content */}
      <div className="flex-1 overflow-y-auto p-4">
        {activeTab === "suggestions" && (
          <SuggestedReplies
            suggestions={MOCK_SUGGESTIONS}
            onUseReply={() => {}}
            onEditReply={() => {}}
            onFeedback={() => {}}
          />
        )}

        {activeTab === "knowledge" && (
          <KnowledgeSuggestions
            articles={MOCK_ARTICLES}
            onInsertLink={() => {}}
            onRefresh={() => {}}
          />
        )}

        {activeTab === "summary" && (
          <ContextSummary
            summary="Customer Sarah Johnson is reporting a duplicate subscription charge of $29.99 on March 7th. A refund has been initiated by agent Mike Chen."
            keyPoints={[
              "Duplicate charge of $29.99 confirmed",
              "Refund initiated via billing system",
              "Customer asking about refund timeline",
            ]}
            suggestedNextSteps={[
              "Confirm 3-5 business day refund timeline",
              "Offer to set up billing alerts",
              "Follow up after 5 days if not resolved",
            ]}
            sentiment="neutral"
            sentimentScore={0.45}
            onRefresh={() => {}}
          />
        )}
      </div>
    </div>
  );
}
