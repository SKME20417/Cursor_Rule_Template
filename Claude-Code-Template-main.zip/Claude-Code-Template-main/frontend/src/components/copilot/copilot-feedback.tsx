"use client";

import React, { useState } from "react";
import { cn } from "@/lib/utils/cn";
import { ThumbsUp, ThumbsDown } from "lucide-react";

interface CopilotFeedbackProps {
  suggestionId: string;
  onFeedback: (
    suggestionId: string,
    rating: "up" | "down",
    comment?: string,
  ) => void;
  className?: string;
}

export function CopilotFeedback({
  suggestionId,
  onFeedback,
  className,
}: CopilotFeedbackProps) {
  const [selected, setSelected] = useState<"up" | "down" | null>(null);
  const [showComment, setShowComment] = useState(false);
  const [comment, setComment] = useState("");

  function handleRate(rating: "up" | "down") {
    setSelected(rating);
    if (rating === "down") {
      setShowComment(true);
    } else {
      onFeedback(suggestionId, rating);
    }
  }

  function handleSubmitComment() {
    if (selected) {
      onFeedback(suggestionId, selected, comment.trim() || undefined);
      setShowComment(false);
    }
  }

  return (
    <div className={cn("flex flex-col gap-2", className)}>
      <div className="flex items-center gap-1">
        <button
          type="button"
          onClick={() => handleRate("up")}
          disabled={selected !== null}
          className={cn(
            "flex h-7 w-7 items-center justify-center rounded-full transition-colors",
            selected === "up"
              ? "bg-green-50 text-linkedin-green"
              : "text-linkedin-gray-50 hover:bg-linkedin-gray-10 hover:text-linkedin-green",
            selected !== null && selected !== "up" && "opacity-30",
          )}
          aria-label="Thumbs up"
        >
          <ThumbsUp className="h-3.5 w-3.5" />
        </button>
        <button
          type="button"
          onClick={() => handleRate("down")}
          disabled={selected !== null}
          className={cn(
            "flex h-7 w-7 items-center justify-center rounded-full transition-colors",
            selected === "down"
              ? "bg-red-50 text-linkedin-red"
              : "text-linkedin-gray-50 hover:bg-linkedin-gray-10 hover:text-linkedin-red",
            selected !== null && selected !== "down" && "opacity-30",
          )}
          aria-label="Thumbs down"
        >
          <ThumbsDown className="h-3.5 w-3.5" />
        </button>
      </div>

      {showComment && (
        <div className="flex flex-col gap-1.5">
          <textarea
            value={comment}
            onChange={(e) => setComment(e.target.value)}
            placeholder="What could be improved?"
            rows={2}
            className="w-full resize-none rounded-lg border border-linkedin-gray-20 bg-linkedin-gray-10 px-3 py-2 text-xs text-linkedin-gray-90 placeholder:text-linkedin-gray-50 focus:border-linkedin-blue focus:outline-none focus:ring-1 focus:ring-linkedin-blue"
          />
          <button
            type="button"
            onClick={handleSubmitComment}
            className="self-end rounded-full bg-linkedin-blue px-3 py-1 text-xs font-medium text-white transition-colors hover:bg-linkedin-blue-hover"
          >
            Submit
          </button>
        </div>
      )}
    </div>
  );
}
