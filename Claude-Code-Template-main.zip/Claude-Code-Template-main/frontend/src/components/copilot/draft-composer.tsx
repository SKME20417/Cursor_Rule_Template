"use client";

import React, { useState } from "react";
import { cn } from "@/lib/utils/cn";
import { RefreshCw, Send, Loader2 } from "lucide-react";

interface DraftComposerProps {
  draft: string;
  loading?: boolean;
  onUseDraft: (content: string) => void;
  onRegenerate: (tone: string) => void;
  className?: string;
}

type Tone = "professional" | "friendly" | "empathetic";

const TONES: { key: Tone; label: string }[] = [
  { key: "professional", label: "Professional" },
  { key: "friendly", label: "Friendly" },
  { key: "empathetic", label: "Empathetic" },
];

export function DraftComposer({
  draft,
  loading = false,
  onUseDraft,
  onRegenerate,
  className,
}: DraftComposerProps) {
  const [editedDraft, setEditedDraft] = useState(draft);
  const [tone, setTone] = useState<Tone>("professional");

  // Sync when draft changes externally
  React.useEffect(() => {
    setEditedDraft(draft);
  }, [draft]);

  return (
    <div className={cn("flex flex-col gap-3", className)}>
      {/* Tone selector */}
      <div className="flex items-center gap-1">
        <span className="text-xs font-medium text-linkedin-gray-50">Tone:</span>
        {TONES.map((t) => (
          <button
            key={t.key}
            type="button"
            onClick={() => setTone(t.key)}
            className={cn(
              "rounded-full px-2.5 py-1 text-xs font-medium transition-colors",
              tone === t.key
                ? "bg-linkedin-blue text-white"
                : "bg-linkedin-gray-10 text-linkedin-gray-50 hover:bg-linkedin-gray-20",
            )}
          >
            {t.label}
          </button>
        ))}
      </div>

      {/* Draft textarea */}
      <div className="relative">
        {loading && (
          <div className="absolute inset-0 z-10 flex items-center justify-center rounded-lg bg-linkedin-white/80">
            <Loader2 className="h-5 w-5 animate-spin text-linkedin-blue" />
          </div>
        )}
        <textarea
          value={editedDraft}
          onChange={(e) => setEditedDraft(e.target.value)}
          rows={6}
          disabled={loading}
          className="w-full resize-none rounded-lg border border-linkedin-gray-20 bg-linkedin-white px-3 py-2.5 text-sm leading-relaxed text-linkedin-gray-90 placeholder:text-linkedin-gray-50 focus:border-linkedin-blue focus:outline-none focus:ring-1 focus:ring-linkedin-blue disabled:opacity-50"
          placeholder="AI-generated draft will appear here..."
        />
      </div>

      {/* Actions */}
      <div className="flex items-center gap-2">
        <button
          type="button"
          onClick={() => onRegenerate(tone)}
          disabled={loading}
          className="inline-flex items-center gap-1.5 rounded-full border border-linkedin-gray-20 px-3 py-1.5 text-xs font-medium text-linkedin-gray-70 transition-colors hover:bg-linkedin-gray-10 disabled:opacity-50"
        >
          <RefreshCw className="h-3 w-3" />
          Regenerate
        </button>
        <button
          type="button"
          onClick={() => onUseDraft(editedDraft)}
          disabled={loading || !editedDraft.trim()}
          className="inline-flex items-center gap-1.5 rounded-full bg-linkedin-blue px-4 py-1.5 text-xs font-semibold text-white transition-colors hover:bg-linkedin-blue-hover disabled:opacity-50"
        >
          <Send className="h-3 w-3" />
          Use Draft
        </button>
      </div>
    </div>
  );
}
