"use client";

import React from "react";
import { cn } from "@/lib/utils/cn";
import { SmilePlus, Meh, Frown } from "lucide-react";

interface SentimentIndicatorProps {
  sentiment: "positive" | "neutral" | "negative";
  score?: number;
  className?: string;
}

const SENTIMENT_CONFIG: Record<
  string,
  { icon: React.ElementType; color: string; bg: string; label: string }
> = {
  positive: {
    icon: SmilePlus,
    color: "text-linkedin-green",
    bg: "bg-green-50",
    label: "Positive",
  },
  neutral: {
    icon: Meh,
    color: "text-linkedin-gray-50",
    bg: "bg-linkedin-gray-10",
    label: "Neutral",
  },
  negative: {
    icon: Frown,
    color: "text-linkedin-red",
    bg: "bg-red-50",
    label: "Negative",
  },
};

export function SentimentIndicator({
  sentiment,
  score,
  className,
}: SentimentIndicatorProps) {
  const config = SENTIMENT_CONFIG[sentiment];
  const Icon = config.icon;

  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-medium",
        config.bg,
        config.color,
        className,
      )}
      title={
        score !== undefined
          ? `${config.label} (${Math.round(score * 100)}%)`
          : config.label
      }
    >
      <Icon className="h-3.5 w-3.5" aria-hidden="true" />
      {config.label}
      {score !== undefined && (
        <span className="opacity-70">{Math.round(score * 100)}%</span>
      )}
    </span>
  );
}
