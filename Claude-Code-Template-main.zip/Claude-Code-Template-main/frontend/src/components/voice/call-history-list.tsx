"use client";

import React, { useState } from "react";
import { cn } from "@/lib/utils/cn";
import {
  PhoneIncoming,
  PhoneOutgoing,
  ChevronUp,
  ChevronDown,
  Filter,
} from "lucide-react";

interface CallHistoryEntry {
  id: string;
  date: string;
  customerName: string;
  agentName: string;
  duration: string;
  type: "inbound" | "outbound";
  quality: 1 | 2 | 3 | 4 | 5;
  outcome: string;
}

interface CallHistoryListProps {
  calls: CallHistoryEntry[];
  onSelectCall?: (callId: string) => void;
  className?: string;
}

type SortField = "date" | "customerName" | "agentName" | "duration" | "quality";
type SortDirection = "asc" | "desc";

function CallHistoryList({
  calls,
  onSelectCall,
  className,
}: CallHistoryListProps) {
  const [sortField, setSortField] = useState<SortField>("date");
  const [sortDirection, setSortDirection] = useState<SortDirection>("desc");
  const [filterType, setFilterType] = useState<"all" | "inbound" | "outbound">("all");
  const [filterAgent, setFilterAgent] = useState("");
  const [showFilters, setShowFilters] = useState(false);

  const toggleSort = (field: SortField) => {
    if (sortField === field) {
      setSortDirection((d) => (d === "asc" ? "desc" : "asc"));
    } else {
      setSortField(field);
      setSortDirection("asc");
    }
  };

  const SortIcon = ({ field }: { field: SortField }) => {
    if (sortField !== field) return null;
    return sortDirection === "asc" ? (
      <ChevronUp className="h-3 w-3" />
    ) : (
      <ChevronDown className="h-3 w-3" />
    );
  };

  const filtered = calls
    .filter((c) => filterType === "all" || c.type === filterType)
    .filter(
      (c) =>
        !filterAgent ||
        c.agentName.toLowerCase().includes(filterAgent.toLowerCase()),
    );

  const sorted = [...filtered].sort((a, b) => {
    const dir = sortDirection === "asc" ? 1 : -1;
    const aVal = a[sortField];
    const bVal = b[sortField];
    if (typeof aVal === "number" && typeof bVal === "number") {
      return (aVal - bVal) * dir;
    }
    return String(aVal).localeCompare(String(bVal)) * dir;
  });

  const qualityColor = (q: number) => {
    if (q >= 4) return "text-linkedin-green";
    if (q >= 3) return "text-linkedin-orange";
    return "text-linkedin-red";
  };

  const agents = Array.from(new Set(calls.map((c) => c.agentName)));

  return (
    <div
      className={cn(
        "rounded-lg border border-linkedin-gray-20 bg-linkedin-white",
        className,
      )}
    >
      <div className="flex items-center justify-between border-b border-linkedin-gray-20 px-4 py-3">
        <h3 className="text-sm font-semibold text-linkedin-gray-90">
          Call History
        </h3>
        <button
          type="button"
          onClick={() => setShowFilters((p) => !p)}
          className={cn(
            "flex items-center gap-1 rounded-full px-2.5 py-1 text-xs font-medium transition-colors",
            showFilters
              ? "bg-linkedin-blue-bg text-linkedin-blue"
              : "text-linkedin-gray-50 hover:bg-linkedin-gray-10",
          )}
        >
          <Filter className="h-3.5 w-3.5" />
          Filters
        </button>
      </div>

      {showFilters && (
        <div className="flex flex-wrap items-center gap-3 border-b border-linkedin-gray-20 px-4 py-2">
          <div className="flex items-center gap-1.5">
            <label className="text-xs text-linkedin-gray-50">Type:</label>
            <select
              value={filterType}
              onChange={(e) => setFilterType(e.target.value as "all" | "inbound" | "outbound")}
              className="rounded border border-linkedin-gray-30 bg-linkedin-white px-2 py-1 text-xs text-linkedin-gray-90 focus:border-linkedin-blue focus:outline-none"
            >
              <option value="all">All</option>
              <option value="inbound">Inbound</option>
              <option value="outbound">Outbound</option>
            </select>
          </div>
          <div className="flex items-center gap-1.5">
            <label className="text-xs text-linkedin-gray-50">Agent:</label>
            <select
              value={filterAgent}
              onChange={(e) => setFilterAgent(e.target.value)}
              className="rounded border border-linkedin-gray-30 bg-linkedin-white px-2 py-1 text-xs text-linkedin-gray-90 focus:border-linkedin-blue focus:outline-none"
            >
              <option value="">All</option>
              {agents.map((a) => (
                <option key={a} value={a}>
                  {a}
                </option>
              ))}
            </select>
          </div>
        </div>
      )}

      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-linkedin-gray-20 text-left">
              {(
                [
                  ["date", "Date"],
                  ["customerName", "Customer"],
                  ["agentName", "Agent"],
                  ["duration", "Duration"],
                ] as [SortField, string][]
              ).map(([field, label]) => (
                <th
                  key={field}
                  className="cursor-pointer px-4 py-2 text-xs font-semibold text-linkedin-gray-50 hover:text-linkedin-gray-90 transition-colors"
                  onClick={() => toggleSort(field)}
                >
                  <span className="inline-flex items-center gap-1">
                    {label}
                    <SortIcon field={field} />
                  </span>
                </th>
              ))}
              <th className="px-4 py-2 text-xs font-semibold text-linkedin-gray-50">
                Type
              </th>
              <th
                className="cursor-pointer px-4 py-2 text-xs font-semibold text-linkedin-gray-50 hover:text-linkedin-gray-90 transition-colors"
                onClick={() => toggleSort("quality")}
              >
                <span className="inline-flex items-center gap-1">
                  Quality
                  <SortIcon field="quality" />
                </span>
              </th>
              <th className="px-4 py-2 text-xs font-semibold text-linkedin-gray-50">
                Outcome
              </th>
            </tr>
          </thead>
          <tbody className="divide-y divide-linkedin-gray-20">
            {sorted.length === 0 ? (
              <tr>
                <td
                  colSpan={7}
                  className="px-4 py-8 text-center text-sm text-linkedin-gray-50"
                >
                  No calls found
                </td>
              </tr>
            ) : (
              sorted.map((call) => (
                <tr
                  key={call.id}
                  onClick={() => onSelectCall?.(call.id)}
                  className="cursor-pointer hover:bg-linkedin-gray-10 transition-colors"
                >
                  <td className="px-4 py-2.5 text-linkedin-gray-70 whitespace-nowrap">
                    {call.date}
                  </td>
                  <td className="px-4 py-2.5 font-medium text-linkedin-gray-90">
                    {call.customerName}
                  </td>
                  <td className="px-4 py-2.5 text-linkedin-gray-70">
                    {call.agentName}
                  </td>
                  <td className="px-4 py-2.5 font-mono text-linkedin-gray-70 tabular-nums">
                    {call.duration}
                  </td>
                  <td className="px-4 py-2.5">
                    {call.type === "inbound" ? (
                      <span className="inline-flex items-center gap-1 text-linkedin-green">
                        <PhoneIncoming className="h-3.5 w-3.5" />
                        <span className="text-xs">In</span>
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 text-linkedin-blue">
                        <PhoneOutgoing className="h-3.5 w-3.5" />
                        <span className="text-xs">Out</span>
                      </span>
                    )}
                  </td>
                  <td className={cn("px-4 py-2.5 font-semibold", qualityColor(call.quality))}>
                    {call.quality}/5
                  </td>
                  <td className="px-4 py-2.5 text-linkedin-gray-70">
                    {call.outcome}
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

CallHistoryList.displayName = "CallHistoryList";

export { CallHistoryList };
export type { CallHistoryEntry };
