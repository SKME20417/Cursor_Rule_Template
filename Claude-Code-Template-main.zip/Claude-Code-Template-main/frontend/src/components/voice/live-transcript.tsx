"use client";

import React, { useRef, useEffect, useState, useCallback } from "react";
import { cn } from "@/lib/utils/cn";
import { ArrowDown, Search } from "lucide-react";

interface TranscriptSegment {
  id: string;
  speaker: "customer" | "agent";
  speakerName: string;
  text: string;
  timestamp: string;
  keywords?: string[];
}

interface LiveTranscriptProps {
  segments: TranscriptSegment[];
  highlightKeywords?: string[];
  className?: string;
}

function highlightText(
  text: string,
  keywords: string[],
  searchQuery: string,
): React.ReactNode {
  if (keywords.length === 0 && !searchQuery) return text;

  const allTerms = [...keywords];
  if (searchQuery) allTerms.push(searchQuery);

  const escaped = allTerms.map((t) => t.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"));
  const pattern = new RegExp(`(${escaped.join("|")})`, "gi");
  const parts = text.split(pattern);

  return parts.map((part, i) => {
    if (pattern.test(part)) {
      return (
        <mark
          key={i}
          className="rounded bg-yellow-200 px-0.5 text-linkedin-gray-90"
        >
          {part}
        </mark>
      );
    }
    return part;
  });
}

function LiveTranscript({
  segments,
  highlightKeywords = [],
  className,
}: LiveTranscriptProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const [autoScroll, setAutoScroll] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [showSearch, setShowSearch] = useState(false);

  const scrollToBottom = useCallback(() => {
    if (containerRef.current) {
      containerRef.current.scrollTop = containerRef.current.scrollHeight;
    }
  }, []);

  useEffect(() => {
    if (autoScroll) scrollToBottom();
  }, [segments, autoScroll, scrollToBottom]);

  const handleScroll = () => {
    if (!containerRef.current) return;
    const { scrollTop, scrollHeight, clientHeight } = containerRef.current;
    const atBottom = scrollHeight - scrollTop - clientHeight < 40;
    setAutoScroll(atBottom);
  };

  return (
    <div
      className={cn(
        "flex flex-col rounded-lg border border-linkedin-gray-20 bg-linkedin-white",
        className,
      )}
    >
      <div className="flex items-center justify-between border-b border-linkedin-gray-20 px-4 py-2">
        <h3 className="text-sm font-semibold text-linkedin-gray-90">
          Live Transcript
        </h3>
        <button
          type="button"
          onClick={() => setShowSearch((p) => !p)}
          aria-label="Search transcript"
          className="rounded p-1 text-linkedin-gray-50 hover:bg-linkedin-gray-10 hover:text-linkedin-gray-90 transition-colors"
        >
          <Search className="h-4 w-4" />
        </button>
      </div>

      {showSearch && (
        <div className="border-b border-linkedin-gray-20 px-4 py-2">
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search transcript..."
            className="w-full rounded-md border border-linkedin-gray-30 bg-linkedin-white px-3 py-1.5 text-sm text-linkedin-gray-90 placeholder:text-linkedin-gray-50 focus:border-linkedin-blue focus:outline-none focus:ring-1 focus:ring-linkedin-blue"
          />
        </div>
      )}

      <div
        ref={containerRef}
        onScroll={handleScroll}
        className="relative flex-1 overflow-y-auto px-4 py-3 space-y-3"
        style={{ maxHeight: 400 }}
      >
        {segments.length === 0 && (
          <p className="text-center text-sm text-linkedin-gray-50 py-8">
            Waiting for conversation to begin...
          </p>
        )}
        {segments.map((seg) => (
          <div key={seg.id} className="flex flex-col gap-1">
            <div className="flex items-center gap-2">
              <span
                className={cn(
                  "text-xs font-semibold",
                  seg.speaker === "customer"
                    ? "text-linkedin-gray-70"
                    : "text-linkedin-blue",
                )}
              >
                {seg.speakerName}
              </span>
              <span className="text-xs text-linkedin-gray-50">
                {seg.timestamp}
              </span>
            </div>
            <div
              className={cn(
                "rounded-lg px-3 py-2 text-sm leading-relaxed",
                seg.speaker === "customer"
                  ? "bg-linkedin-gray-10 text-linkedin-gray-90"
                  : "bg-linkedin-blue-bg text-linkedin-gray-90",
              )}
            >
              {highlightText(
                seg.text,
                [...highlightKeywords, ...(seg.keywords ?? [])],
                searchQuery,
              )}
            </div>
          </div>
        ))}
      </div>

      {!autoScroll && (
        <div className="flex justify-center pb-2">
          <button
            type="button"
            onClick={() => {
              scrollToBottom();
              setAutoScroll(true);
            }}
            className="flex items-center gap-1 rounded-full bg-linkedin-blue px-3 py-1 text-xs font-medium text-linkedin-white shadow-sm hover:bg-linkedin-blue-hover transition-colors"
          >
            <ArrowDown className="h-3 w-3" />
            Scroll to bottom
          </button>
        </div>
      )}
    </div>
  );
}

LiveTranscript.displayName = "LiveTranscript";

export { LiveTranscript };
export type { TranscriptSegment };
