"use client";

import React from "react";
import { cn } from "@/lib/utils/cn";
import { Bot, ArrowRightLeft } from "lucide-react";

interface VoiceBotStatusProps {
  isActive: boolean;
  confidenceScore: number;
  onTransferToAgent?: () => void;
  className?: string;
}

function VoiceBotStatus({
  isActive,
  confidenceScore,
  onTransferToAgent,
  className,
}: VoiceBotStatusProps) {
  if (!isActive) return null;

  const confidenceColor =
    confidenceScore >= 0.8
      ? "text-linkedin-green"
      : confidenceScore >= 0.5
        ? "text-linkedin-orange"
        : "text-linkedin-red";

  return (
    <div
      className={cn(
        "rounded-lg border border-linkedin-gray-20 bg-linkedin-white p-4",
        className,
      )}
    >
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-full bg-linkedin-blue-bg">
            <Bot className="h-5 w-5 text-linkedin-blue" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-sm font-semibold text-linkedin-gray-90">
                AI is responding
              </span>
              {/* Animated waves */}
              <div className="flex items-center gap-0.5">
                {[0, 1, 2, 3].map((i) => (
                  <span
                    key={i}
                    className="inline-block w-0.5 rounded-full bg-linkedin-blue"
                    style={{
                      height: "12px",
                      animation: `wave 1.2s ease-in-out ${i * 0.15}s infinite`,
                    }}
                  />
                ))}
              </div>
            </div>
            <div className="flex items-center gap-2 mt-1">
              <span className="text-xs text-linkedin-gray-50">Confidence:</span>
              <span className={cn("text-xs font-semibold", confidenceColor)}>
                {Math.round(confidenceScore * 100)}%
              </span>
            </div>
          </div>
        </div>

        <button
          type="button"
          onClick={onTransferToAgent}
          className="flex items-center gap-1.5 rounded-full border border-linkedin-blue px-3 py-1.5 text-xs font-semibold text-linkedin-blue transition-colors hover:bg-linkedin-blue-bg"
        >
          <ArrowRightLeft className="h-3.5 w-3.5" />
          Transfer to agent
        </button>
      </div>

      <style jsx>{`
        @keyframes wave {
          0%, 100% { transform: scaleY(0.4); }
          50% { transform: scaleY(1); }
        }
      `}</style>
    </div>
  );
}

VoiceBotStatus.displayName = "VoiceBotStatus";

export { VoiceBotStatus };
