"use client";

import React from "react";
import { cn } from "@/lib/utils/cn";
import { Headphones, MessageSquare, PhoneIncoming, Clock } from "lucide-react";

interface ActiveCall {
  id: string;
  agentName: string;
  customerName: string;
  duration: string;
  sentiment: "positive" | "neutral" | "negative";
  quality: 1 | 2 | 3 | 4 | 5;
}

interface CallMonitorPanelProps {
  activeCalls: ActiveCall[];
  onListen?: (callId: string) => void;
  onWhisper?: (callId: string) => void;
  onBarge?: (callId: string) => void;
  className?: string;
}

const sentimentConfig: Record<string, { label: string; color: string; dot: string }> = {
  positive: { label: "Positive", color: "text-linkedin-green", dot: "bg-linkedin-green" },
  neutral: { label: "Neutral", color: "text-linkedin-gray-50", dot: "bg-linkedin-gray-50" },
  negative: { label: "Negative", color: "text-linkedin-red", dot: "bg-linkedin-red" },
};

function CallMonitorPanel({
  activeCalls,
  onListen,
  onWhisper,
  onBarge,
  className,
}: CallMonitorPanelProps) {
  return (
    <div
      className={cn(
        "rounded-lg border border-linkedin-gray-20 bg-linkedin-white",
        className,
      )}
    >
      <div className="border-b border-linkedin-gray-20 px-4 py-3">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-semibold text-linkedin-gray-90">
            Active Calls
          </h3>
          <span className="rounded-full bg-linkedin-blue-bg px-2 py-0.5 text-xs font-semibold text-linkedin-blue">
            {activeCalls.length}
          </span>
        </div>
      </div>

      {activeCalls.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-8 text-center">
          <PhoneIncoming className="h-8 w-8 text-linkedin-gray-30 mb-2" />
          <p className="text-sm text-linkedin-gray-50">No active calls</p>
        </div>
      ) : (
        <div className="divide-y divide-linkedin-gray-20">
          {activeCalls.map((call) => {
            const sentiment = sentimentConfig[call.sentiment];
            return (
              <div
                key={call.id}
                className="flex items-center justify-between px-4 py-3 hover:bg-linkedin-gray-10 transition-colors"
              >
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-semibold text-linkedin-gray-90 truncate">
                      {call.agentName}
                    </span>
                    <span className="text-xs text-linkedin-gray-50">with</span>
                    <span className="text-sm text-linkedin-gray-70 truncate">
                      {call.customerName}
                    </span>
                  </div>
                  <div className="flex items-center gap-3 mt-1">
                    <span className="flex items-center gap-1 text-xs text-linkedin-gray-50">
                      <Clock className="h-3 w-3" />
                      {call.duration}
                    </span>
                    <span className="flex items-center gap-1 text-xs">
                      <span className={cn("h-1.5 w-1.5 rounded-full", sentiment.dot)} />
                      <span className={sentiment.color}>{sentiment.label}</span>
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-1 ml-3">
                  <button
                    type="button"
                    onClick={() => onListen?.(call.id)}
                    title="Listen"
                    className="flex h-8 w-8 items-center justify-center rounded-full text-linkedin-gray-50 hover:bg-linkedin-gray-10 hover:text-linkedin-blue transition-colors"
                  >
                    <Headphones className="h-4 w-4" />
                  </button>
                  <button
                    type="button"
                    onClick={() => onWhisper?.(call.id)}
                    title="Whisper (agent hears)"
                    className="flex h-8 w-8 items-center justify-center rounded-full text-linkedin-gray-50 hover:bg-linkedin-gray-10 hover:text-linkedin-orange transition-colors"
                  >
                    <MessageSquare className="h-4 w-4" />
                  </button>
                  <button
                    type="button"
                    onClick={() => onBarge?.(call.id)}
                    title="Barge (join call)"
                    className="flex h-8 w-8 items-center justify-center rounded-full text-linkedin-gray-50 hover:bg-linkedin-gray-10 hover:text-linkedin-red transition-colors"
                  >
                    <PhoneIncoming className="h-4 w-4" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

CallMonitorPanel.displayName = "CallMonitorPanel";

export { CallMonitorPanel };
export type { ActiveCall };
