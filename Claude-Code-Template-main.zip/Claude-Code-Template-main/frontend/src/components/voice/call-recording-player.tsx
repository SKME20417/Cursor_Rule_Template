"use client";

import React, { useState, useRef, useEffect, useCallback } from "react";
import { cn } from "@/lib/utils/cn";
import { Play, Pause } from "lucide-react";

interface RecordingSegment {
  id: string;
  speaker: string;
  text: string;
  startTime: number;
  endTime: number;
}

interface CallRecordingPlayerProps {
  audioSrc: string;
  duration: number;
  segments?: RecordingSegment[];
  className?: string;
}

const SPEED_OPTIONS = [0.5, 1, 1.5, 2] as const;

function formatTime(seconds: number): string {
  const mins = Math.floor(seconds / 60);
  const secs = Math.floor(seconds % 60);
  return `${String(mins).padStart(2, "0")}:${String(secs).padStart(2, "0")}`;
}

function CallRecordingPlayer({
  audioSrc,
  duration,
  segments = [],
  className,
}: CallRecordingPlayerProps) {
  const audioRef = useRef<HTMLAudioElement>(null);
  const [playing, setPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [speed, setSpeed] = useState<number>(1);
  const [waveformBars] = useState(() =>
    Array.from({ length: 60 }, () => Math.random() * 0.8 + 0.2),
  );

  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;

    const onTimeUpdate = () => setCurrentTime(audio.currentTime);
    const onEnded = () => setPlaying(false);

    audio.addEventListener("timeupdate", onTimeUpdate);
    audio.addEventListener("ended", onEnded);
    return () => {
      audio.removeEventListener("timeupdate", onTimeUpdate);
      audio.removeEventListener("ended", onEnded);
    };
  }, []);

  const togglePlay = useCallback(() => {
    const audio = audioRef.current;
    if (!audio) return;
    if (playing) {
      audio.pause();
    } else {
      audio.play();
    }
    setPlaying((p) => !p);
  }, [playing]);

  const handleSeek = (e: React.MouseEvent<HTMLDivElement>) => {
    const audio = audioRef.current;
    if (!audio) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const pct = (e.clientX - rect.left) / rect.width;
    const newTime = pct * duration;
    audio.currentTime = newTime;
    setCurrentTime(newTime);
  };

  const cycleSpeed = () => {
    const idx = SPEED_OPTIONS.indexOf(speed as (typeof SPEED_OPTIONS)[number]);
    const next = SPEED_OPTIONS[(idx + 1) % SPEED_OPTIONS.length];
    setSpeed(next);
    if (audioRef.current) audioRef.current.playbackRate = next;
  };

  const activeSegment = segments.find(
    (s) => currentTime >= s.startTime && currentTime <= s.endTime,
  );

  const progress = duration > 0 ? (currentTime / duration) * 100 : 0;

  return (
    <div
      className={cn(
        "rounded-lg border border-linkedin-gray-20 bg-linkedin-white p-4",
        className,
      )}
    >
      <audio ref={audioRef} src={audioSrc} preload="metadata" />

      {/* Waveform visualization */}
      <div
        className="relative mb-3 flex h-16 cursor-pointer items-end gap-px"
        onClick={handleSeek}
        role="slider"
        aria-label="Audio seek"
        aria-valuenow={Math.round(currentTime)}
        aria-valuemin={0}
        aria-valuemax={duration}
        tabIndex={0}
      >
        {waveformBars.map((height, i) => {
          const barPct = (i / waveformBars.length) * 100;
          const isPlayed = barPct <= progress;
          return (
            <div
              key={i}
              className={cn(
                "flex-1 rounded-sm transition-colors",
                isPlayed ? "bg-linkedin-blue" : "bg-linkedin-gray-20",
              )}
              style={{ height: `${height * 100}%` }}
            />
          );
        })}
      </div>

      {/* Controls */}
      <div className="flex items-center gap-3">
        <button
          type="button"
          onClick={togglePlay}
          aria-label={playing ? "Pause" : "Play"}
          className="flex h-10 w-10 items-center justify-center rounded-full bg-linkedin-blue text-linkedin-white transition-colors hover:bg-linkedin-blue-hover"
        >
          {playing ? (
            <Pause className="h-5 w-5" />
          ) : (
            <Play className="h-5 w-5 ml-0.5" />
          )}
        </button>

        <span className="min-w-[80px] text-sm font-mono tabular-nums text-linkedin-gray-70">
          {formatTime(currentTime)} / {formatTime(duration)}
        </span>

        <button
          type="button"
          onClick={cycleSpeed}
          aria-label={`Playback speed: ${speed}x`}
          className="rounded-full border border-linkedin-gray-30 px-2.5 py-0.5 text-xs font-semibold text-linkedin-gray-70 transition-colors hover:bg-linkedin-gray-10"
        >
          {speed}x
        </button>
      </div>

      {/* Active transcript segment */}
      {activeSegment && (
        <div className="mt-3 rounded-md bg-linkedin-blue-bg px-3 py-2">
          <span className="text-xs font-semibold text-linkedin-blue">
            {activeSegment.speaker}
          </span>
          <p className="text-sm text-linkedin-gray-90 leading-relaxed">
            {activeSegment.text}
          </p>
        </div>
      )}
    </div>
  );
}

CallRecordingPlayer.displayName = "CallRecordingPlayer";

export { CallRecordingPlayer };
export type { RecordingSegment };
