"use client";

import React, { useState } from "react";
import { cn } from "@/lib/utils/cn";
import {
  Mic,
  MicOff,
  Pause,
  Play,
  PhoneForwarded,
  PhoneOff,
  Grid3X3,
  Circle,
} from "lucide-react";

interface CallControlsProps {
  onMuteToggle?: (muted: boolean) => void;
  onHoldToggle?: (held: boolean) => void;
  onTransfer?: () => void;
  onEndCall?: () => void;
  onKeypadToggle?: () => void;
  onRecordToggle?: (recording: boolean) => void;
  className?: string;
}

function CallControls({
  onMuteToggle,
  onHoldToggle,
  onTransfer,
  onEndCall,
  onKeypadToggle,
  onRecordToggle,
  className,
}: CallControlsProps) {
  const [muted, setMuted] = useState(false);
  const [held, setHeld] = useState(false);
  const [recording, setRecording] = useState(false);

  const handleMute = () => {
    const next = !muted;
    setMuted(next);
    onMuteToggle?.(next);
  };

  const handleHold = () => {
    const next = !held;
    setHeld(next);
    onHoldToggle?.(next);
  };

  const handleRecord = () => {
    const next = !recording;
    setRecording(next);
    onRecordToggle?.(next);
  };

  return (
    <div
      className={cn(
        "inline-flex items-center gap-2 rounded-full bg-linkedin-gray-90 px-4 py-3 shadow-lg",
        className,
      )}
    >
      <button
        type="button"
        onClick={handleMute}
        aria-label={muted ? "Unmute microphone" : "Mute microphone"}
        className={cn(
          "flex h-10 w-10 items-center justify-center rounded-full transition-colors",
          muted
            ? "bg-linkedin-red text-linkedin-white"
            : "bg-linkedin-gray-70 text-linkedin-white hover:bg-linkedin-gray-50",
        )}
      >
        {muted ? <MicOff className="h-5 w-5" /> : <Mic className="h-5 w-5" />}
      </button>

      <button
        type="button"
        onClick={handleHold}
        aria-label={held ? "Resume call" : "Hold call"}
        className={cn(
          "flex h-10 w-10 items-center justify-center rounded-full transition-colors",
          held
            ? "bg-yellow-500 text-linkedin-white"
            : "bg-linkedin-gray-70 text-linkedin-white hover:bg-linkedin-gray-50",
        )}
      >
        {held ? <Play className="h-5 w-5" /> : <Pause className="h-5 w-5" />}
      </button>

      <button
        type="button"
        onClick={onTransfer}
        aria-label="Transfer call"
        className="flex h-10 w-10 items-center justify-center rounded-full bg-linkedin-gray-70 text-linkedin-white transition-colors hover:bg-linkedin-gray-50"
      >
        <PhoneForwarded className="h-5 w-5" />
      </button>

      <button
        type="button"
        onClick={onKeypadToggle}
        aria-label="Toggle keypad"
        className="flex h-10 w-10 items-center justify-center rounded-full bg-linkedin-gray-70 text-linkedin-white transition-colors hover:bg-linkedin-gray-50"
      >
        <Grid3X3 className="h-5 w-5" />
      </button>

      <button
        type="button"
        onClick={handleRecord}
        aria-label={recording ? "Stop recording" : "Start recording"}
        className={cn(
          "flex h-10 w-10 items-center justify-center rounded-full transition-colors",
          recording
            ? "bg-linkedin-red text-linkedin-white animate-pulse"
            : "bg-linkedin-gray-70 text-linkedin-white hover:bg-linkedin-gray-50",
        )}
      >
        <Circle className="h-5 w-5" />
      </button>

      <button
        type="button"
        onClick={onEndCall}
        aria-label="End call"
        className="flex h-10 w-10 items-center justify-center rounded-full bg-linkedin-red text-linkedin-white transition-colors hover:bg-red-700"
      >
        <PhoneOff className="h-5 w-5" />
      </button>
    </div>
  );
}

CallControls.displayName = "CallControls";

export { CallControls };
