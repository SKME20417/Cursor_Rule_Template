"use client";

import React, { useState, useEffect } from "react";
import { cn } from "@/lib/utils/cn";
import { Mic, MicOff, Pause, PhoneOff, ChevronDown } from "lucide-react";

interface CallStatusBarProps {
  callerName: string;
  startTime: Date;
  quality: "good" | "fair" | "poor";
  isMuted?: boolean;
  isHeld?: boolean;
  onMuteToggle?: () => void;
  onHoldToggle?: () => void;
  onEndCall?: () => void;
  onExpand?: () => void;
  className?: string;
}

function formatDuration(seconds: number): string {
  const hrs = Math.floor(seconds / 3600);
  const mins = Math.floor((seconds % 3600) / 60);
  const secs = seconds % 60;
  const parts: string[] = [];
  if (hrs > 0) parts.push(String(hrs).padStart(2, "0"));
  parts.push(String(mins).padStart(2, "0"));
  parts.push(String(secs).padStart(2, "0"));
  return parts.join(":");
}

function CallStatusBar({
  callerName,
  startTime,
  quality,
  isMuted = false,
  isHeld = false,
  onMuteToggle,
  onHoldToggle,
  onEndCall,
  onExpand,
  className,
}: CallStatusBarProps) {
  const [elapsed, setElapsed] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setElapsed(Math.floor((Date.now() - startTime.getTime()) / 1000));
    }, 1000);
    return () => clearInterval(interval);
  }, [startTime]);

  const qualityColors: Record<string, string> = {
    good: "bg-green-400",
    fair: "bg-yellow-400",
    poor: "bg-linkedin-red",
  };

  return (
    <div
      className={cn(
        "fixed top-0 left-0 right-0 z-50 flex items-center justify-between px-4 py-2 bg-gradient-to-r from-green-600 to-green-500 text-linkedin-white shadow-md",
        className,
      )}
    >
      <button
        type="button"
        onClick={onExpand}
        className="flex items-center gap-3 hover:opacity-90 transition-opacity"
      >
        <div className="flex items-center gap-2">
          <span className="relative flex h-2.5 w-2.5">
            <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-white opacity-75" />
            <span className="relative inline-flex h-2.5 w-2.5 rounded-full bg-white" />
          </span>
          <span className="font-semibold text-sm">{callerName}</span>
        </div>
        <span className="font-mono text-sm tabular-nums">
          {formatDuration(elapsed)}
        </span>
        <span
          className={cn("h-2 w-2 rounded-full", qualityColors[quality])}
          title={`Call quality: ${quality}`}
        />
        <ChevronDown className="h-4 w-4" />
      </button>

      <div className="flex items-center gap-1.5">
        <button
          type="button"
          onClick={onMuteToggle}
          aria-label={isMuted ? "Unmute" : "Mute"}
          className={cn(
            "flex h-8 w-8 items-center justify-center rounded-full transition-colors",
            isMuted ? "bg-red-700" : "bg-white/20 hover:bg-white/30",
          )}
        >
          {isMuted ? (
            <MicOff className="h-4 w-4" />
          ) : (
            <Mic className="h-4 w-4" />
          )}
        </button>
        <button
          type="button"
          onClick={onHoldToggle}
          aria-label={isHeld ? "Resume" : "Hold"}
          className={cn(
            "flex h-8 w-8 items-center justify-center rounded-full transition-colors",
            isHeld ? "bg-yellow-600" : "bg-white/20 hover:bg-white/30",
          )}
        >
          <Pause className="h-4 w-4" />
        </button>
        <button
          type="button"
          onClick={onEndCall}
          aria-label="End call"
          className="flex h-8 w-8 items-center justify-center rounded-full bg-red-700 transition-colors hover:bg-red-800"
        >
          <PhoneOff className="h-4 w-4" />
        </button>
      </div>
    </div>
  );
}

CallStatusBar.displayName = "CallStatusBar";

export { CallStatusBar };
