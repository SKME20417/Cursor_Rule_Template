"use client";

import React, { useState } from "react";
import { cn } from "@/lib/utils/cn";
import { MicOff, Pin } from "lucide-react";

interface VideoParticipant {
  id: string;
  name: string;
  videoEnabled: boolean;
  audioEnabled: boolean;
  isSpeaking?: boolean;
}

interface VideoGridProps {
  participants: VideoParticipant[];
  className?: string;
}

function getGridClass(count: number): string {
  if (count === 1) return "grid-cols-1";
  if (count === 2) return "grid-cols-2";
  if (count <= 4) return "grid-cols-2 grid-rows-2";
  if (count <= 6) return "grid-cols-3 grid-rows-2";
  return "grid-cols-3 grid-rows-3";
}

function VideoGrid({ participants, className }: VideoGridProps) {
  const [pinnedId, setPinnedId] = useState<string | null>(null);

  const pinnedParticipant = pinnedId
    ? participants.find((p) => p.id === pinnedId)
    : null;

  if (pinnedParticipant) {
    const others = participants.filter((p) => p.id !== pinnedId);
    return (
      <div className={cn("flex h-full gap-2", className)}>
        <div className="flex-1 min-w-0">
          <VideoTile
            participant={pinnedParticipant}
            isPinned
            onTogglePin={() => setPinnedId(null)}
          />
        </div>
        {others.length > 0 && (
          <div className="flex w-40 flex-col gap-2 overflow-y-auto">
            {others.map((p) => (
              <VideoTile
                key={p.id}
                participant={p}
                isPinned={false}
                onTogglePin={() => setPinnedId(p.id)}
              />
            ))}
          </div>
        )}
      </div>
    );
  }

  return (
    <div
      className={cn(
        "grid h-full gap-2",
        getGridClass(participants.length),
        className,
      )}
    >
      {participants.map((p) => (
        <VideoTile
          key={p.id}
          participant={p}
          isPinned={false}
          onTogglePin={() => setPinnedId(p.id)}
        />
      ))}
    </div>
  );
}

function VideoTile({
  participant,
  isPinned,
  onTogglePin,
}: {
  participant: VideoParticipant;
  isPinned: boolean;
  onTogglePin: () => void;
}) {
  const initials = participant.name
    .split(" ")
    .map((n) => n[0])
    .join("")
    .toUpperCase()
    .slice(0, 2);

  return (
    <div
      className={cn(
        "group relative flex items-center justify-center overflow-hidden rounded-lg bg-linkedin-gray-70",
        participant.isSpeaking && "ring-2 ring-linkedin-blue",
        isPinned ? "h-full" : "min-h-[120px]",
      )}
    >
      {participant.videoEnabled ? (
        <div className="absolute inset-0 bg-linkedin-gray-70">
          {/* Placeholder for actual video element */}
          <div className="flex h-full items-center justify-center">
            <span className="text-4xl font-bold text-linkedin-white/30">
              {initials}
            </span>
          </div>
        </div>
      ) : (
        <div className="flex h-16 w-16 items-center justify-center rounded-full bg-linkedin-gray-50">
          <span className="text-lg font-bold text-linkedin-white">
            {initials}
          </span>
        </div>
      )}

      {/* Name label */}
      <div className="absolute bottom-2 left-2 flex items-center gap-1.5 rounded bg-black/50 px-2 py-0.5">
        <span className="text-xs font-medium text-linkedin-white">
          {participant.name}
        </span>
        {!participant.audioEnabled && (
          <MicOff className="h-3 w-3 text-linkedin-red" />
        )}
      </div>

      {/* Pin button */}
      <button
        type="button"
        onClick={onTogglePin}
        aria-label={isPinned ? "Unpin" : "Pin"}
        className={cn(
          "absolute top-2 right-2 flex h-7 w-7 items-center justify-center rounded-full transition-opacity",
          isPinned
            ? "bg-linkedin-blue text-linkedin-white opacity-100"
            : "bg-black/50 text-linkedin-white opacity-0 group-hover:opacity-100",
        )}
      >
        <Pin className="h-3.5 w-3.5" />
      </button>
    </div>
  );
}

VideoGrid.displayName = "VideoGrid";

export { VideoGrid };
