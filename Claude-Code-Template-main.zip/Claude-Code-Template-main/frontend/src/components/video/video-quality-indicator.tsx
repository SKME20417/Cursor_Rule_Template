"use client";

import React, { useState } from "react";
import { cn } from "@/lib/utils/cn";

interface VideoQualityIndicatorProps {
  level: 1 | 2 | 3 | 4 | 5;
  latencyMs?: number;
  packetLossPercent?: number;
  resolution?: string;
  className?: string;
}

function getQualityMeta(level: number) {
  if (level >= 4) return { label: "Good", color: "bg-linkedin-green" };
  if (level >= 3) return { label: "Fair", color: "bg-yellow-400" };
  return { label: "Poor", color: "bg-linkedin-red" };
}

function VideoQualityIndicator({
  level,
  latencyMs,
  packetLossPercent,
  resolution,
  className,
}: VideoQualityIndicatorProps) {
  const [showTooltip, setShowTooltip] = useState(false);
  const { label, color } = getQualityMeta(level);

  return (
    <div
      className={cn("relative inline-flex", className)}
      onMouseEnter={() => setShowTooltip(true)}
      onMouseLeave={() => setShowTooltip(false)}
      onFocus={() => setShowTooltip(true)}
      onBlur={() => setShowTooltip(false)}
      tabIndex={0}
      role="status"
      aria-label={`Video quality: ${label}`}
    >
      <div className="flex items-end gap-0.5">
        {[1, 2, 3, 4, 5].map((bar) => (
          <div
            key={bar}
            className={cn(
              "w-1 rounded-sm transition-colors",
              bar <= level ? color : "bg-linkedin-gray-20",
            )}
            style={{ height: `${bar * 3 + 4}px` }}
          />
        ))}
      </div>

      {showTooltip && (
        <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 z-50 whitespace-nowrap rounded-md bg-linkedin-gray-90 px-3 py-2 text-xs text-linkedin-white shadow-lg">
          <p className="font-semibold mb-1">Video Quality: {label}</p>
          {latencyMs !== undefined && <p>Latency: {latencyMs}ms</p>}
          {packetLossPercent !== undefined && (
            <p>Packet loss: {packetLossPercent}%</p>
          )}
          {resolution && <p>Resolution: {resolution}</p>}
        </div>
      )}
    </div>
  );
}

VideoQualityIndicator.displayName = "VideoQualityIndicator";

export { VideoQualityIndicator };
