"use client";

import React from "react";
import { cn } from "@/lib/utils/cn";
import { Monitor } from "lucide-react";

interface ScreenShareViewerProps {
  sharerName: string;
  children?: React.ReactNode;
  className?: string;
}

function ScreenShareViewer({
  sharerName,
  children,
  className,
}: ScreenShareViewerProps) {
  return (
    <div
      className={cn(
        "relative flex flex-col items-center justify-center rounded-lg bg-black",
        className,
      )}
    >
      <div className="absolute top-3 left-3 z-10 flex items-center gap-2 rounded-full bg-black/60 px-3 py-1.5 backdrop-blur-sm">
        <Monitor className="h-3.5 w-3.5 text-linkedin-green" />
        <span className="text-xs font-medium text-linkedin-white">
          {sharerName} is sharing their screen
        </span>
      </div>

      <div className="flex h-full w-full items-center justify-center overflow-hidden">
        {children ?? (
          <div className="flex flex-col items-center gap-3 text-linkedin-gray-50">
            <Monitor className="h-12 w-12" />
            <p className="text-sm">Screen share content will appear here</p>
          </div>
        )}
      </div>
    </div>
  );
}

ScreenShareViewer.displayName = "ScreenShareViewer";

export { ScreenShareViewer };
