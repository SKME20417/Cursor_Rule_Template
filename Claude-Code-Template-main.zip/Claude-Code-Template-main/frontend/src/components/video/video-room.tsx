"use client";

import React, { useState } from "react";
import { cn } from "@/lib/utils/cn";
import { MessageSquare, X } from "lucide-react";
import { VideoGrid } from "./video-grid";
import { VideoControls } from "./video-controls";

interface Participant {
  id: string;
  name: string;
  videoEnabled: boolean;
  audioEnabled: boolean;
  isScreenSharing?: boolean;
  isSpeaking?: boolean;
}

interface VideoRoomProps {
  participants: Participant[];
  localParticipantId: string;
  isFullScreen?: boolean;
  onLeave?: () => void;
  chatPanel?: React.ReactNode;
  screenShareContent?: React.ReactNode;
  className?: string;
}

function VideoRoom({
  participants,
  localParticipantId,
  isFullScreen = false,
  onLeave,
  chatPanel,
  screenShareContent,
  className,
}: VideoRoomProps) {
  const [showChat, setShowChat] = useState(false);
  const [cameraOn, setCameraOn] = useState(true);
  const [micOn, setMicOn] = useState(true);
  const [isSharing, setIsSharing] = useState(false);
  const [isRecording, setIsRecording] = useState(false);

  const screenSharer = participants.find((p) => p.isScreenSharing);

  return (
    <div
      className={cn(
        "relative flex flex-col bg-linkedin-gray-90",
        isFullScreen ? "fixed inset-0 z-50" : "h-[600px] rounded-lg overflow-hidden",
        className,
      )}
    >
      {/* Main content area */}
      <div className="flex flex-1 min-h-0">
        <div className="flex flex-1 flex-col min-w-0">
          {screenSharer && screenShareContent ? (
            <div className="flex-1 flex flex-col min-h-0">
              <div className="flex items-center gap-2 bg-black/40 px-3 py-1.5">
                <span className="text-xs text-linkedin-white">
                  {screenSharer.name} is sharing their screen
                </span>
              </div>
              <div className="flex-1 flex items-center justify-center p-2">
                {screenShareContent}
              </div>
              {/* Participant strip */}
              <div className="flex gap-1 overflow-x-auto p-2">
                {participants.map((p) => (
                  <div
                    key={p.id}
                    className="relative h-24 w-32 flex-shrink-0 rounded bg-linkedin-gray-70 flex items-center justify-center"
                  >
                    <span className="text-xs text-linkedin-white font-medium">
                      {p.name}
                    </span>
                    {!p.audioEnabled && (
                      <span className="absolute bottom-1 right-1 rounded-full bg-linkedin-red p-0.5">
                        <span className="block h-2 w-2" />
                      </span>
                    )}
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <div className="flex-1 p-2">
              <VideoGrid participants={participants} />
            </div>
          )}

          {/* Controls */}
          <div className="flex justify-center pb-4 pt-2">
            <VideoControls
              cameraOn={cameraOn}
              micOn={micOn}
              isScreenSharing={isSharing}
              isRecording={isRecording}
              isChatOpen={showChat}
              onToggleCamera={() => setCameraOn((p) => !p)}
              onToggleMic={() => setMicOn((p) => !p)}
              onToggleScreenShare={() => setIsSharing((p) => !p)}
              onToggleChat={() => setShowChat((p) => !p)}
              onToggleRecord={() => setIsRecording((p) => !p)}
              onEndCall={onLeave}
            />
          </div>
        </div>

        {/* Chat sidebar */}
        {showChat && (
          <div className="w-80 flex-shrink-0 border-l border-linkedin-gray-70 bg-linkedin-white flex flex-col">
            <div className="flex items-center justify-between border-b border-linkedin-gray-20 px-3 py-2">
              <span className="text-sm font-semibold text-linkedin-gray-90">Chat</span>
              <button
                type="button"
                onClick={() => setShowChat(false)}
                className="rounded p-1 text-linkedin-gray-50 hover:bg-linkedin-gray-10"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
            <div className="flex-1 overflow-y-auto">
              {chatPanel ?? (
                <p className="p-4 text-sm text-linkedin-gray-50 text-center">
                  No messages yet
                </p>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

VideoRoom.displayName = "VideoRoom";

export { VideoRoom };
export type { Participant };
