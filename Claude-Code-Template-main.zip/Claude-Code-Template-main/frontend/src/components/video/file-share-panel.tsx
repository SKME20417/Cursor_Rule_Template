"use client";

import React, { useState, useCallback } from "react";
import { cn } from "@/lib/utils/cn";
import {
  Upload,
  Download,
  FileText,
  FileImage,
  FileArchive,
  File,
  X,
} from "lucide-react";

interface SharedFile {
  id: string;
  name: string;
  size: string;
  type: "document" | "image" | "archive" | "other";
  sharedBy: string;
  timestamp: string;
}

interface FileSharePanelProps {
  files: SharedFile[];
  onUpload?: (files: FileList) => void;
  onDownload?: (fileId: string) => void;
  className?: string;
}

const fileIcons: Record<string, React.ReactNode> = {
  document: <FileText className="h-5 w-5 text-linkedin-blue" />,
  image: <FileImage className="h-5 w-5 text-linkedin-green" />,
  archive: <FileArchive className="h-5 w-5 text-linkedin-orange" />,
  other: <File className="h-5 w-5 text-linkedin-gray-50" />,
};

function FileSharePanel({
  files,
  onUpload,
  onDownload,
  className,
}: FileSharePanelProps) {
  const [isDragging, setIsDragging] = useState(false);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback(() => {
    setIsDragging(false);
  }, []);

  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault();
      setIsDragging(false);
      if (e.dataTransfer.files.length > 0) {
        onUpload?.(e.dataTransfer.files);
      }
    },
    [onUpload],
  );

  return (
    <div
      className={cn(
        "rounded-lg border border-linkedin-gray-20 bg-linkedin-white",
        className,
      )}
    >
      <div className="border-b border-linkedin-gray-20 px-4 py-3">
        <h3 className="text-sm font-semibold text-linkedin-gray-90">
          Shared Files
        </h3>
      </div>

      {/* Drop zone */}
      <div
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        className={cn(
          "m-3 flex flex-col items-center gap-2 rounded-lg border-2 border-dashed px-4 py-6 transition-colors",
          isDragging
            ? "border-linkedin-blue bg-linkedin-blue-bg"
            : "border-linkedin-gray-30",
        )}
      >
        <Upload className="h-6 w-6 text-linkedin-gray-50" />
        <p className="text-sm text-linkedin-gray-50">
          Drag and drop files here
        </p>
        <label className="cursor-pointer rounded-full bg-linkedin-blue px-3 py-1 text-xs font-semibold text-linkedin-white hover:bg-linkedin-blue-hover transition-colors">
          Browse files
          <input
            type="file"
            className="hidden"
            multiple
            onChange={(e) => {
              if (e.target.files && e.target.files.length > 0) {
                onUpload?.(e.target.files);
              }
            }}
          />
        </label>
      </div>

      {/* File list */}
      {files.length > 0 && (
        <div className="divide-y divide-linkedin-gray-20 border-t border-linkedin-gray-20">
          {files.map((file) => (
            <div
              key={file.id}
              className="flex items-center gap-3 px-4 py-2.5 hover:bg-linkedin-gray-10 transition-colors"
            >
              {fileIcons[file.type]}
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-linkedin-gray-90 truncate">
                  {file.name}
                </p>
                <p className="text-xs text-linkedin-gray-50">
                  {file.size} &middot; {file.sharedBy} &middot; {file.timestamp}
                </p>
              </div>
              <button
                type="button"
                onClick={() => onDownload?.(file.id)}
                aria-label={`Download ${file.name}`}
                className="flex h-8 w-8 items-center justify-center rounded-full text-linkedin-gray-50 hover:bg-linkedin-gray-10 hover:text-linkedin-blue transition-colors"
              >
                <Download className="h-4 w-4" />
              </button>
            </div>
          ))}
        </div>
      )}

      {files.length === 0 && (
        <p className="px-4 pb-4 text-center text-sm text-linkedin-gray-50">
          No files shared yet
        </p>
      )}
    </div>
  );
}

FileSharePanel.displayName = "FileSharePanel";

export { FileSharePanel };
export type { SharedFile };
