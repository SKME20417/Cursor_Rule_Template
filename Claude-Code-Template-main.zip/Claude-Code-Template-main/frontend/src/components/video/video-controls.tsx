"use client";

import React, { useState } from "react";
import { cn } from "@/lib/utils/cn";
import {
  Video,
  VideoOff,
  Mic,
  MicOff,
  Monitor,
  MonitorOff,
  MessageSquare,
  Share2,
  PhoneOff,
  MoreHorizontal,
  Settings,
  LayoutGrid,
  Circle,
} from "lucide-react";

interface VideoControlsProps {
  cameraOn: boolean;
  micOn: boolean;
  isScreenSharing: boolean;
  isRecording?: boolean;
  isChatOpen?: boolean;
  onToggleCamera: () => void;
  onToggleMic: () => void;
  onToggleScreenShare: () => void;
  onToggleChat?: () => void;
  onToggleRecord?: () => void;
  onFileShare?: () => void;
  onEndCall?: () => void;
  onSettings?: () => void;
  onChangeLayout?: () => void;
  className?: string;
}

function VideoControls({
  cameraOn,
  micOn,
  isScreenSharing,
  isRecording = false,
  isChatOpen = false,
  onToggleCamera,
  onToggleMic,
  onToggleScreenShare,
  onToggleChat,
  onToggleRecord,
  onFileShare,
  onEndCall,
  onSettings,
  onChangeLayout,
  className,
}: VideoControlsProps) {
  const [showMore, setShowMore] = useState(false);

  return (
    <div
      className={cn(
        "relative inline-flex items-center gap-2 rounded-full bg-black/60 px-4 py-3 backdrop-blur-sm",
        className,
      )}
    >
      <button
        type="button"
        onClick={onToggleCamera}
        aria-label={cameraOn ? "Turn off camera" : "Turn on camera"}
        className={cn(
          "flex h-10 w-10 items-center justify-center rounded-full transition-colors",
          cameraOn
            ? "bg-linkedin-gray-70 text-linkedin-white hover:bg-linkedin-gray-50"
            : "bg-linkedin-red text-linkedin-white",
        )}
      >
        {cameraOn ? (
          <Video className="h-5 w-5" />
        ) : (
          <VideoOff className="h-5 w-5" />
        )}
      </button>

      <button
        type="button"
        onClick={onToggleMic}
        aria-label={micOn ? "Mute microphone" : "Unmute microphone"}
        className={cn(
          "flex h-10 w-10 items-center justify-center rounded-full transition-colors",
          micOn
            ? "bg-linkedin-gray-70 text-linkedin-white hover:bg-linkedin-gray-50"
            : "bg-linkedin-red text-linkedin-white",
        )}
      >
        {micOn ? (
          <Mic className="h-5 w-5" />
        ) : (
          <MicOff className="h-5 w-5" />
        )}
      </button>

      <button
        type="button"
        onClick={onToggleScreenShare}
        aria-label={isScreenSharing ? "Stop sharing" : "Share screen"}
        className={cn(
          "flex h-10 w-10 items-center justify-center rounded-full transition-colors",
          isScreenSharing
            ? "bg-linkedin-blue text-linkedin-white"
            : "bg-linkedin-gray-70 text-linkedin-white hover:bg-linkedin-gray-50",
        )}
      >
        {isScreenSharing ? (
          <MonitorOff className="h-5 w-5" />
        ) : (
          <Monitor className="h-5 w-5" />
        )}
      </button>

      <button
        type="button"
        onClick={onToggleChat}
        aria-label="Toggle chat"
        className={cn(
          "flex h-10 w-10 items-center justify-center rounded-full transition-colors",
          isChatOpen
            ? "bg-linkedin-blue text-linkedin-white"
            : "bg-linkedin-gray-70 text-linkedin-white hover:bg-linkedin-gray-50",
        )}
      >
        <MessageSquare className="h-5 w-5" />
      </button>

      <button
        type="button"
        onClick={onFileShare}
        aria-label="Share file"
        className="flex h-10 w-10 items-center justify-center rounded-full bg-linkedin-gray-70 text-linkedin-white transition-colors hover:bg-linkedin-gray-50"
      >
        <Share2 className="h-5 w-5" />
      </button>

      <button
        type="button"
        onClick={onEndCall}
        aria-label="End call"
        className="flex h-10 w-10 items-center justify-center rounded-full bg-linkedin-red text-linkedin-white transition-colors hover:bg-red-700"
      >
        <PhoneOff className="h-5 w-5" />
      </button>

      {/* More menu */}
      <div className="relative">
        <button
          type="button"
          onClick={() => setShowMore((p) => !p)}
          aria-label="More options"
          className="flex h-10 w-10 items-center justify-center rounded-full bg-linkedin-gray-70 text-linkedin-white transition-colors hover:bg-linkedin-gray-50"
        >
          <MoreHorizontal className="h-5 w-5" />
        </button>

        {showMore && (
          <div className="absolute bottom-full mb-2 right-0 min-w-[160px] rounded-lg border border-linkedin-gray-20 bg-linkedin-white py-1 shadow-lg">
            <button
              type="button"
              onClick={() => {
                onSettings?.();
                setShowMore(false);
              }}
              className="flex w-full items-center gap-2 px-3 py-2 text-sm text-linkedin-gray-70 hover:bg-linkedin-gray-10"
            >
              <Settings className="h-4 w-4" />
              Settings
            </button>
            <button
              type="button"
              onClick={() => {
                onChangeLayout?.();
                setShowMore(false);
              }}
              className="flex w-full items-center gap-2 px-3 py-2 text-sm text-linkedin-gray-70 hover:bg-linkedin-gray-10"
            >
              <LayoutGrid className="h-4 w-4" />
              Change layout
            </button>
            <button
              type="button"
              onClick={() => {
                onToggleRecord?.();
                setShowMore(false);
              }}
              className={cn(
                "flex w-full items-center gap-2 px-3 py-2 text-sm hover:bg-linkedin-gray-10",
                isRecording ? "text-linkedin-red" : "text-linkedin-gray-70",
              )}
            >
              <Circle className="h-4 w-4" />
              {isRecording ? "Stop recording" : "Record"}
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

VideoControls.displayName = "VideoControls";

export { VideoControls };
