"use client";

import React from "react";
import { cn } from "@/lib/utils/cn";
import { Tooltip } from "@/components/ui/tooltip";
import { Brain } from "lucide-react";

interface IntentBadgeProps {
  intent: string;
  confidence: number;
  details?: {
    topIntents?: { name: string; score: number }[];
    modelVersion?: string;
  };
  className?: string;
}

export function IntentBadge({
  intent,
  confidence,
  details,
  className,
}: IntentBadgeProps) {
  const pct = Math.round(confidence * 100);

  const tooltipContent = details ? (
    <div className="space-y-1 text-xs">
      <p className="font-semibold">Intent Classification</p>
      {details.topIntents?.map((item) => (
        <p key={item.name}>
          {item.name}: {Math.round(item.score * 100)}%
        </p>
      ))}
      {details.modelVersion && (
        <p className="text-linkedin-gray-50">Model: {details.modelVersion}</p>
      )}
    </div>
  ) : (
    `${intent} (${pct}% confidence)`
  );

  return (
    <Tooltip content={tooltipContent}>
      <span
        className={cn(
          "inline-flex items-center gap-1.5 rounded-full bg-linkedin-blue-bg px-2.5 py-0.5 text-xs font-medium text-linkedin-blue",
          className,
        )}
      >
        <Brain className="h-3 w-3" aria-hidden="true" />
        {intent}
        <span className="text-[10px] font-normal opacity-70">{pct}%</span>
      </span>
    </Tooltip>
  );
}
