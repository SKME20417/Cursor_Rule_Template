"use client";

import React from "react";
import { cn } from "@/lib/utils/cn";

interface SentimentMeterProps {
  value: number; // -1 to +1
  className?: string;
}

function getSentimentLabel(value: number): string {
  if (value >= 0.5) return "Very Positive";
  if (value >= 0.15) return "Positive";
  if (value > -0.15) return "Neutral";
  if (value > -0.5) return "Negative";
  return "Very Negative";
}

function getSentimentColor(value: number): string {
  if (value >= 0.5) return "text-linkedin-green";
  if (value >= 0.15) return "text-green-500";
  if (value > -0.15) return "text-linkedin-gray-50";
  if (value > -0.5) return "text-linkedin-orange";
  return "text-linkedin-red";
}

export function SentimentMeter({ value, className }: SentimentMeterProps) {
  const clamped = Math.max(-1, Math.min(1, value));
  // Map -1..+1 to 0..100 for positioning
  const position = ((clamped + 1) / 2) * 100;
  const label = getSentimentLabel(clamped);
  const color = getSentimentColor(clamped);

  return (
    <div className={cn("inline-flex flex-col items-center gap-1", className)}>
      {/* Label */}
      <span className={cn("text-xs font-medium", color)}>{label}</span>

      {/* Meter bar */}
      <div className="relative h-2 w-32 overflow-hidden rounded-full">
        {/* Gradient background */}
        <div
          className="absolute inset-0 rounded-full"
          style={{
            background:
              "linear-gradient(to right, #ef4444, #f97316, #eab308, #22c55e, #16a34a)",
          }}
        />

        {/* Needle / marker */}
        <div
          className="absolute top-1/2 h-3.5 w-1.5 -translate-y-1/2 rounded-full bg-linkedin-white border-2 border-linkedin-gray-90 shadow-sm transition-all duration-300"
          style={{ left: `calc(${position}% - 3px)` }}
          role="img"
          aria-label={`Sentiment: ${label} (${clamped.toFixed(2)})`}
        />
      </div>

      {/* Scale labels */}
      <div className="flex w-32 justify-between text-[9px] text-linkedin-gray-50">
        <span>-1</span>
        <span>0</span>
        <span>+1</span>
      </div>
    </div>
  );
}
