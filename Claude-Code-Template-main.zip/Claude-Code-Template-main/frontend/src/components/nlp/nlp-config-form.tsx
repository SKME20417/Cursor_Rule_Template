"use client";

import React, { useState } from "react";
import { cn } from "@/lib/utils/cn";
import { RotateCcw, Save, Play } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Toggle } from "@/components/ui/toggle";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";

interface ClassifierConfig {
  key: string;
  label: string;
  enabled: boolean;
  threshold: number;
}

interface NlpConfigFormProps {
  classifiers: ClassifierConfig[];
  modelVersions: string[];
  selectedModelVersion: string;
  onSave: (config: {
    classifiers: ClassifierConfig[];
    modelVersion: string;
  }) => void;
  onTestSample?: (text: string) => void;
  loading?: boolean;
  className?: string;
}

const DEFAULT_CLASSIFIERS: ClassifierConfig[] = [
  { key: "intent", label: "Intent Detection", enabled: true, threshold: 0.7 },
  { key: "sentiment", label: "Sentiment Analysis", enabled: true, threshold: 0.6 },
  { key: "urgency", label: "Urgency Detection", enabled: true, threshold: 0.65 },
  { key: "language", label: "Language Detection", enabled: true, threshold: 0.8 },
  { key: "escalation", label: "Escalation Risk", enabled: true, threshold: 0.75 },
];

export function NlpConfigForm({
  classifiers: initialClassifiers,
  modelVersions,
  selectedModelVersion: initialModelVersion,
  onSave,
  onTestSample,
  loading = false,
  className,
}: NlpConfigFormProps) {
  const [classifiers, setClassifiers] = useState(initialClassifiers);
  const [modelVersion, setModelVersion] = useState(initialModelVersion);
  const [testText, setTestText] = useState("");

  function updateClassifier(key: string, updates: Partial<ClassifierConfig>) {
    setClassifiers((prev) =>
      prev.map((c) => (c.key === key ? { ...c, ...updates } : c)),
    );
  }

  function handleReset() {
    setClassifiers(DEFAULT_CLASSIFIERS);
    setModelVersion(modelVersions[0] ?? "");
  }

  function handleSave() {
    onSave({ classifiers, modelVersion });
  }

  return (
    <div className={cn("space-y-6", className)}>
      {/* Model version */}
      <Select
        label="Model Version"
        options={modelVersions.map((v) => ({ value: v, label: v }))}
        value={modelVersion}
        onChange={(e) => setModelVersion(e.target.value)}
      />

      {/* Classifier configs */}
      <div className="space-y-4">
        <h3 className="text-sm font-semibold text-linkedin-gray-90">
          Classifiers
        </h3>

        {classifiers.map((cls) => (
          <div
            key={cls.key}
            className={cn(
              "rounded-lg border border-linkedin-gray-20 p-4 transition-opacity",
              !cls.enabled && "opacity-50",
            )}
          >
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium text-linkedin-gray-90">
                {cls.label}
              </span>
              <Toggle
                checked={cls.enabled}
                onChange={(checked) =>
                  updateClassifier(cls.key, { enabled: checked })
                }
              />
            </div>

            {cls.enabled && (
              <div className="mt-3">
                <div className="flex items-center justify-between mb-1">
                  <label className="text-xs text-linkedin-gray-50">
                    Confidence Threshold
                  </label>
                  <span className="text-xs font-mono text-linkedin-gray-70">
                    {Math.round(cls.threshold * 100)}%
                  </span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={Math.round(cls.threshold * 100)}
                  onChange={(e) =>
                    updateClassifier(cls.key, {
                      threshold: Number(e.target.value) / 100,
                    })
                  }
                  className="w-full h-1.5 rounded-full appearance-none cursor-pointer bg-linkedin-gray-20 accent-linkedin-blue"
                />
                <div className="flex justify-between text-[9px] text-linkedin-gray-50 mt-0.5">
                  <span>0%</span>
                  <span>50%</span>
                  <span>100%</span>
                </div>
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Test with sample */}
      {onTestSample && (
        <div>
          <h3 className="mb-2 text-sm font-semibold text-linkedin-gray-90">
            Test with Sample
          </h3>
          <div className="flex gap-2">
            <div className="flex-1">
              <Input
                placeholder="Enter sample text to classify..."
                value={testText}
                onChange={(e) => setTestText(e.target.value)}
              />
            </div>
            <Button
              variant="secondary"
              onClick={() => onTestSample(testText)}
              disabled={!testText.trim()}
              iconLeft={<Play className="h-4 w-4" />}
            >
              Test
            </Button>
          </div>
        </div>
      )}

      {/* Actions */}
      <div className="flex items-center justify-end gap-3 border-t border-linkedin-gray-20 pt-4">
        <Button
          variant="ghost"
          onClick={handleReset}
          iconLeft={<RotateCcw className="h-4 w-4" />}
        >
          Reset
        </Button>
        <Button
          onClick={handleSave}
          loading={loading}
          iconLeft={<Save className="h-4 w-4" />}
        >
          Save Configuration
        </Button>
      </div>
    </div>
  );
}
