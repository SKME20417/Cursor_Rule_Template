"use client";

import React from "react";
import { cn } from "@/lib/utils/cn";
import { AlertTriangle, ArrowUp, Minus, ArrowDown } from "lucide-react";

interface UrgencyIndicatorProps {
  level: "low" | "medium" | "high" | "critical";
  className?: string;
}

const URGENCY_CONFIG: Record<
  string,
  { icon: React.ElementType; label: string; bgColor: string; textColor: string; pulse: boolean }
> = {
  low: {
    icon: ArrowDown,
    label: "Low",
    bgColor: "bg-green-50",
    textColor: "text-linkedin-green",
    pulse: false,
  },
  medium: {
    icon: Minus,
    label: "Medium",
    bgColor: "bg-yellow-50",
    textColor: "text-yellow-700",
    pulse: false,
  },
  high: {
    icon: ArrowUp,
    label: "High",
    bgColor: "bg-orange-50",
    textColor: "text-linkedin-orange",
    pulse: false,
  },
  critical: {
    icon: AlertTriangle,
    label: "Critical",
    bgColor: "bg-red-50",
    textColor: "text-linkedin-red",
    pulse: true,
  },
};

export function UrgencyIndicator({ level, className }: UrgencyIndicatorProps) {
  const config = URGENCY_CONFIG[level] ?? URGENCY_CONFIG.medium;
  const Icon = config.icon;

  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-xs font-medium",
        config.bgColor,
        config.textColor,
        config.pulse && "animate-pulse",
        className,
      )}
    >
      <Icon className="h-3 w-3" aria-hidden="true" />
      {config.label}
    </span>
  );
}
