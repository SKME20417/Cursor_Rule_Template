"use client";

import React, { useState } from "react";
import { cn } from "@/lib/utils/cn";
import { ChevronDown, ChevronRight, Bug } from "lucide-react";
import { Badge } from "@/components/ui/badge";

interface ClassificationResult {
  classifier: string;
  value: string;
  confidence: number;
}

interface ClassificationDebugProps {
  classifications: ClassificationResult[];
  modelVersion?: string;
  messageId?: string;
  className?: string;
}

function getConfidenceColor(score: number): string {
  if (score >= 0.8) return "text-linkedin-green";
  if (score >= 0.5) return "text-yellow-700";
  return "text-linkedin-red";
}

function getConfidenceBg(score: number): string {
  if (score >= 0.8) return "bg-green-50";
  if (score >= 0.5) return "bg-yellow-50";
  return "bg-red-50";
}

export function ClassificationDebug({
  classifications,
  modelVersion,
  messageId,
  className,
}: ClassificationDebugProps) {
  const [expanded, setExpanded] = useState(false);

  return (
    <div
      className={cn(
        "rounded-lg border border-linkedin-gray-20 bg-linkedin-white",
        className,
      )}
    >
      <button
        type="button"
        onClick={() => setExpanded(!expanded)}
        className="flex w-full items-center gap-2 px-4 py-3 text-sm font-medium text-linkedin-gray-70 hover:text-linkedin-gray-90 transition-colors"
      >
        {expanded ? (
          <ChevronDown className="h-4 w-4" />
        ) : (
          <ChevronRight className="h-4 w-4" />
        )}
        <Bug className="h-4 w-4" />
        NLP Debug
        {modelVersion && (
          <Badge variant="default" size="sm" className="ml-auto">
            {modelVersion}
          </Badge>
        )}
      </button>

      {expanded && (
        <div className="border-t border-linkedin-gray-20 px-4 py-3">
          {messageId && (
            <p className="mb-3 text-xs text-linkedin-gray-50">
              Message ID:{" "}
              <span className="font-mono">{messageId}</span>
            </p>
          )}

          <table className="w-full text-left">
            <thead>
              <tr className="border-b border-linkedin-gray-20">
                <th className="pb-2 text-xs font-medium uppercase tracking-wide text-linkedin-gray-50">
                  Classifier
                </th>
                <th className="pb-2 text-xs font-medium uppercase tracking-wide text-linkedin-gray-50">
                  Value
                </th>
                <th className="pb-2 text-xs font-medium uppercase tracking-wide text-linkedin-gray-50 text-right">
                  Confidence
                </th>
              </tr>
            </thead>
            <tbody>
              {classifications.map((cls) => (
                <tr
                  key={cls.classifier}
                  className="border-b border-linkedin-gray-20 last:border-b-0"
                >
                  <td className="py-2 text-sm text-linkedin-gray-70">
                    {cls.classifier}
                  </td>
                  <td className="py-2 text-sm font-medium text-linkedin-gray-90">
                    {cls.value}
                  </td>
                  <td className="py-2 text-right">
                    <span
                      className={cn(
                        "inline-flex items-center rounded-full px-2 py-0.5 text-xs font-medium",
                        getConfidenceBg(cls.confidence),
                        getConfidenceColor(cls.confidence),
                      )}
                    >
                      {Math.round(cls.confidence * 100)}%
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>

          {modelVersion && (
            <p className="mt-3 text-xs text-linkedin-gray-50">
              Model version: {modelVersion}
            </p>
          )}
        </div>
      )}
    </div>
  );
}
