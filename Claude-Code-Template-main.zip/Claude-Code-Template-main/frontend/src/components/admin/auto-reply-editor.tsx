"use client";

import React, { useState } from "react";
import { cn } from "@/lib/utils/cn";
import { Plus, Pencil, Trash2, Eye, MessageSquare } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Toggle } from "@/components/ui/toggle";
import { Card, CardBody } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Modal } from "@/components/ui/modal";
import { ConfirmDialog } from "@/components/ui/confirm-dialog";
import { EmptyState } from "@/components/ui/empty-state";

/* ------------------------------------------------------------------ */
/* Types                                                               */
/* ------------------------------------------------------------------ */

interface AutoReplyTemplate {
  id: string;
  name: string;
  triggerType: string;
  triggerValue: string;
  responseTemplate: string;
  enabled: boolean;
}

interface AutoReplyEditorProps {
  templates: AutoReplyTemplate[];
  onSave?: (template: AutoReplyTemplate) => void;
  onDelete?: (templateId: string) => void;
  onToggle?: (templateId: string, enabled: boolean) => void;
  className?: string;
}

/* ------------------------------------------------------------------ */
/* Constants                                                           */
/* ------------------------------------------------------------------ */

const triggerOptions = [
  { value: "new_ticket", label: "New Ticket" },
  { value: "keyword_match", label: "Keyword Match" },
  { value: "off_hours", label: "Off Hours" },
  { value: "queue_full", label: "Queue Full" },
];

const variablesList = [
  "{{customer_name}}",
  "{{ticket_id}}",
  "{{agent_name}}",
  "{{company_name}}",
  "{{estimated_wait}}",
];

/* ------------------------------------------------------------------ */
/* Component                                                           */
/* ------------------------------------------------------------------ */

export function AutoReplyEditor({
  templates,
  onSave,
  onDelete,
  onToggle,
  className,
}: AutoReplyEditorProps) {
  const [editing, setEditing] = useState<AutoReplyTemplate | null>(null);
  const [creating, setCreating] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<AutoReplyTemplate | null>(null);
  const [previewing, setPreviewing] = useState<AutoReplyTemplate | null>(null);

  const [formName, setFormName] = useState("");
  const [formTriggerType, setFormTriggerType] = useState("new_ticket");
  const [formTriggerValue, setFormTriggerValue] = useState("");
  const [formTemplate, setFormTemplate] = useState("");

  const openCreate = () => {
    setFormName("");
    setFormTriggerType("new_ticket");
    setFormTriggerValue("");
    setFormTemplate("");
    setCreating(true);
    setEditing(null);
  };

  const openEdit = (tpl: AutoReplyTemplate) => {
    setFormName(tpl.name);
    setFormTriggerType(tpl.triggerType);
    setFormTriggerValue(tpl.triggerValue);
    setFormTemplate(tpl.responseTemplate);
    setEditing(tpl);
    setCreating(false);
  };

  const handleSave = () => {
    const tpl: AutoReplyTemplate = {
      id: editing?.id ?? crypto.randomUUID(),
      name: formName,
      triggerType: formTriggerType,
      triggerValue: formTriggerValue,
      responseTemplate: formTemplate,
      enabled: editing?.enabled ?? true,
    };
    onSave?.(tpl);
    setCreating(false);
    setEditing(null);
  };

  const handleDelete = () => {
    if (deleteTarget) {
      onDelete?.(deleteTarget.id);
      setDeleteTarget(null);
    }
  };

  const renderPreview = (template: string): string => {
    return template
      .replace("{{customer_name}}", "John Doe")
      .replace("{{ticket_id}}", "TKT-1234")
      .replace("{{agent_name}}", "Jane Smith")
      .replace("{{company_name}}", "Acme Inc")
      .replace("{{estimated_wait}}", "5 minutes");
  };

  const isFormOpen = creating || editing !== null;

  return (
    <div className={cn("flex flex-col gap-4", className)}>
      <div className="flex items-center justify-end">
        <Button iconLeft={<Plus className="h-4 w-4" />} onClick={openCreate}>
          Add Template
        </Button>
      </div>

      {templates.length === 0 ? (
        <EmptyState
          icon={<MessageSquare className="h-7 w-7" />}
          title="No auto-reply templates"
          description="Create templates to automatically respond to incoming messages."
          action={
            <Button iconLeft={<Plus className="h-4 w-4" />} onClick={openCreate}>
              Add Template
            </Button>
          }
        />
      ) : (
        <div className="flex flex-col gap-3">
          {templates.map((tpl) => (
            <Card key={tpl.id} padding="none">
              <CardBody>
                <div className="flex items-center gap-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <h3 className="font-medium text-linkedin-gray-90">
                        {tpl.name}
                      </h3>
                      <Badge
                        variant={tpl.enabled ? "success" : "default"}
                        size="sm"
                      >
                        {tpl.enabled ? "Active" : "Inactive"}
                      </Badge>
                    </div>
                    <p className="mt-1 text-xs text-linkedin-gray-50">
                      Trigger:{" "}
                      {triggerOptions.find((o) => o.value === tpl.triggerType)
                        ?.label ?? tpl.triggerType}
                      {tpl.triggerValue && ` - ${tpl.triggerValue}`}
                    </p>
                  </div>

                  <Toggle
                    checked={tpl.enabled}
                    onChange={(v) => onToggle?.(tpl.id, v)}
                  />

                  <div className="flex items-center gap-1">
                    <Button
                      variant="ghost"
                      size="sm"
                      iconLeft={<Eye className="h-3.5 w-3.5" />}
                      onClick={() => setPreviewing(tpl)}
                    >
                      Preview
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      iconLeft={<Pencil className="h-3.5 w-3.5" />}
                      onClick={() => openEdit(tpl)}
                    >
                      Edit
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      iconLeft={<Trash2 className="h-3.5 w-3.5" />}
                      onClick={() => setDeleteTarget(tpl)}
                    >
                      Delete
                    </Button>
                  </div>
                </div>
              </CardBody>
            </Card>
          ))}
        </div>
      )}

      {/* Create/Edit Modal */}
      <Modal
        open={isFormOpen}
        onClose={() => {
          setCreating(false);
          setEditing(null);
        }}
        title={editing ? "Edit Auto-Reply" : "Create Auto-Reply"}
        size="lg"
        footer={
          <>
            <Button
              variant="ghost"
              onClick={() => {
                setCreating(false);
                setEditing(null);
              }}
            >
              Cancel
            </Button>
            <Button onClick={handleSave}>Save</Button>
          </>
        }
      >
        <div className="flex flex-col gap-4">
          <Input
            label="Template Name"
            value={formName}
            onChange={(e) => setFormName(e.target.value)}
            placeholder="e.g. New Ticket Welcome"
          />
          <Select
            label="Trigger Type"
            options={triggerOptions}
            value={formTriggerType}
            onChange={(e) => setFormTriggerType(e.target.value)}
          />
          <Input
            label="Trigger Value (optional)"
            value={formTriggerValue}
            onChange={(e) => setFormTriggerValue(e.target.value)}
            placeholder="e.g. keyword to match, hours range"
          />
          <Textarea
            label="Response Template"
            value={formTemplate}
            onChange={(e) => setFormTemplate(e.target.value)}
            placeholder="Hello {{customer_name}}, thanks for reaching out..."
            rows={6}
          />
          <div>
            <p className="text-xs font-medium text-linkedin-gray-50 mb-1">
              Available variables:
            </p>
            <div className="flex flex-wrap gap-1">
              {variablesList.map((v) => (
                <button
                  key={v}
                  type="button"
                  onClick={() => setFormTemplate((prev) => prev + v)}
                  className="rounded bg-linkedin-gray-10 px-2 py-0.5 text-xs text-linkedin-gray-70 hover:bg-linkedin-gray-20"
                >
                  {v}
                </button>
              ))}
            </div>
          </div>
        </div>
      </Modal>

      {/* Preview Modal */}
      <Modal
        open={previewing !== null}
        onClose={() => setPreviewing(null)}
        title="Template Preview"
      >
        <div className="rounded-lg bg-linkedin-gray-10 p-4">
          <p className="text-sm text-linkedin-gray-90 whitespace-pre-wrap">
            {previewing ? renderPreview(previewing.responseTemplate) : ""}
          </p>
        </div>
      </Modal>

      <ConfirmDialog
        open={deleteTarget !== null}
        onClose={() => setDeleteTarget(null)}
        onConfirm={handleDelete}
        title="Delete Template"
        message={`Are you sure you want to delete "${deleteTarget?.name}"?`}
        danger
        confirmLabel="Delete"
      />
    </div>
  );
}
