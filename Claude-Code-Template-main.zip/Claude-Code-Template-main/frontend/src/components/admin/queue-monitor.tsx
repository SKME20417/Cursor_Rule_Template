"use client";

import React, { useState, useEffect } from "react";
import { cn } from "@/lib/utils/cn";
import { RefreshCw, AlertTriangle } from "lucide-react";
import { Card, CardBody, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

/* ------------------------------------------------------------------ */
/* Types                                                               */
/* ------------------------------------------------------------------ */

interface QueueData {
  name: string;
  depth: number;
  maxDepth: number;
  consumerLag: number;
  alertThreshold: number;
}

interface QueueMonitorProps {
  queues: QueueData[];
  autoRefreshMs?: number;
  onRefresh?: () => void;
  className?: string;
}

/* ------------------------------------------------------------------ */
/* Component                                                           */
/* ------------------------------------------------------------------ */

export function QueueMonitor({
  queues,
  autoRefreshMs = 5000,
  onRefresh,
  className,
}: QueueMonitorProps) {
  const [lastRefresh, setLastRefresh] = useState(new Date());

  useEffect(() => {
    const interval = setInterval(() => {
      onRefresh?.();
      setLastRefresh(new Date());
    }, autoRefreshMs);
    return () => clearInterval(interval);
  }, [autoRefreshMs, onRefresh]);

  const maxDepth = Math.max(...queues.map((q) => q.maxDepth), 1);

  return (
    <Card className={className} padding="none">
      <CardHeader>
        <div className="flex items-center justify-between">
          <h3 className="font-semibold text-linkedin-gray-90">
            Queue Monitor
          </h3>
          <div className="flex items-center gap-2 text-xs text-linkedin-gray-50">
            <RefreshCw className="h-3 w-3 animate-spin" />
            Auto-refresh every {autoRefreshMs / 1000}s
          </div>
        </div>
      </CardHeader>
      <CardBody>
        <div className="flex flex-col gap-4">
          {/* Bar Chart */}
          <div className="flex items-end gap-3" style={{ minHeight: 200 }}>
            {queues.map((queue) => {
              const heightPct = (queue.depth / maxDepth) * 100;
              const thresholdPct = (queue.alertThreshold / maxDepth) * 100;
              const isAlert = queue.depth >= queue.alertThreshold;

              return (
                <div
                  key={queue.name}
                  className="flex flex-1 flex-col items-center gap-1"
                >
                  <span className="text-xs font-medium text-linkedin-gray-90 tabular-nums">
                    {queue.depth}
                  </span>
                  <div
                    className="relative w-full max-w-[60px]"
                    style={{ height: 160 }}
                  >
                    {/* Alert threshold line */}
                    <div
                      className="absolute left-0 right-0 border-t-2 border-dashed border-linkedin-red"
                      style={{ bottom: `${thresholdPct}%` }}
                    />
                    {/* Bar */}
                    <div
                      className={cn(
                        "absolute bottom-0 left-0 right-0 rounded-t-md transition-all duration-500",
                        isAlert ? "bg-linkedin-red" : "bg-linkedin-blue",
                      )}
                      style={{ height: `${heightPct}%` }}
                    />
                  </div>
                  <span className="text-xs text-linkedin-gray-50 text-center truncate w-full">
                    {queue.name}
                  </span>
                </div>
              );
            })}
          </div>

          {/* Consumer Lag Table */}
          <div>
            <h4 className="mb-2 text-sm font-medium text-linkedin-gray-70">
              Consumer Lag
            </h4>
            <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
              {queues.map((queue) => {
                const isAlert = queue.depth >= queue.alertThreshold;
                return (
                  <div
                    key={queue.name}
                    className="flex items-center justify-between rounded-lg border border-linkedin-gray-20 px-3 py-2"
                  >
                    <div className="flex items-center gap-2">
                      {isAlert && (
                        <AlertTriangle className="h-3.5 w-3.5 text-linkedin-red" />
                      )}
                      <span className="text-sm text-linkedin-gray-90">
                        {queue.name}
                      </span>
                    </div>
                    <Badge
                      variant={isAlert ? "danger" : "default"}
                      size="sm"
                    >
                      {queue.consumerLag} lag
                    </Badge>
                  </div>
                );
              })}
            </div>
          </div>

          <p className="text-xs text-linkedin-gray-50">
            Last refreshed: {lastRefresh.toLocaleTimeString()}
          </p>
        </div>
      </CardBody>
    </Card>
  );
}
