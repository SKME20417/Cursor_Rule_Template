"use client";

import React, { useState } from "react";
import { cn } from "@/lib/utils/cn";
import { Plus, Pencil, Trash2, Zap, Webhook } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Toggle } from "@/components/ui/toggle";
import { Badge } from "@/components/ui/badge";
import { Modal } from "@/components/ui/modal";
import { ConfirmDialog } from "@/components/ui/confirm-dialog";
import { EmptyState } from "@/components/ui/empty-state";
import { DataTable, type DataTableColumn } from "@/components/ui/data-table";

/* ------------------------------------------------------------------ */
/* Types                                                               */
/* ------------------------------------------------------------------ */

interface WebhookConfig {
  id: string;
  url: string;
  events: string[];
  secret: string;
  enabled: boolean;
  lastTriggered: string | null;
}

interface WebhookManagerProps {
  webhooks: WebhookConfig[];
  onSave?: (webhook: WebhookConfig) => void;
  onDelete?: (webhookId: string) => void;
  onToggle?: (webhookId: string, enabled: boolean) => void;
  onTest?: (webhookId: string) => void;
  className?: string;
}

/* ------------------------------------------------------------------ */
/* Constants                                                           */
/* ------------------------------------------------------------------ */

const availableEvents = [
  "ticket.created",
  "ticket.updated",
  "ticket.resolved",
  "conversation.started",
  "conversation.ended",
  "agent.assigned",
  "sla.breached",
  "customer.created",
];

/* ------------------------------------------------------------------ */
/* Component                                                           */
/* ------------------------------------------------------------------ */

export function WebhookManager({
  webhooks,
  onSave,
  onDelete,
  onToggle,
  onTest,
  className,
}: WebhookManagerProps) {
  const [editing, setEditing] = useState<WebhookConfig | null>(null);
  const [creating, setCreating] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<WebhookConfig | null>(null);

  const [formUrl, setFormUrl] = useState("");
  const [formEvents, setFormEvents] = useState<string[]>([]);
  const [formSecret, setFormSecret] = useState("");

  const openCreate = () => {
    setFormUrl("");
    setFormEvents([]);
    setFormSecret("");
    setCreating(true);
    setEditing(null);
  };

  const openEdit = (wh: WebhookConfig) => {
    setFormUrl(wh.url);
    setFormEvents(wh.events);
    setFormSecret(wh.secret);
    setEditing(wh);
    setCreating(false);
  };

  const handleSave = () => {
    const wh: WebhookConfig = {
      id: editing?.id ?? crypto.randomUUID(),
      url: formUrl,
      events: formEvents,
      secret: formSecret,
      enabled: editing?.enabled ?? true,
      lastTriggered: editing?.lastTriggered ?? null,
    };
    onSave?.(wh);
    setCreating(false);
    setEditing(null);
  };

  const handleDelete = () => {
    if (deleteTarget) {
      onDelete?.(deleteTarget.id);
      setDeleteTarget(null);
    }
  };

  const toggleEvent = (event: string) => {
    setFormEvents((prev) =>
      prev.includes(event)
        ? prev.filter((e) => e !== event)
        : [...prev, event],
    );
  };

  const isFormOpen = creating || editing !== null;

  const columns: DataTableColumn<WebhookConfig>[] = [
    {
      key: "url",
      header: "URL",
      render: (row) => (
        <span className="font-mono text-xs break-all">{row.url}</span>
      ),
    },
    {
      key: "events",
      header: "Events",
      render: (row) => (
        <div className="flex flex-wrap gap-1">
          {row.events.slice(0, 2).map((e) => (
            <Badge key={e} variant="primary" size="sm">
              {e}
            </Badge>
          ))}
          {row.events.length > 2 && (
            <Badge variant="default" size="sm">
              +{row.events.length - 2}
            </Badge>
          )}
        </div>
      ),
    },
    {
      key: "enabled",
      header: "Status",
      render: (row) => (
        <Toggle
          checked={row.enabled}
          onChange={(v) => onToggle?.(row.id, v)}
        />
      ),
    },
    {
      key: "lastTriggered",
      header: "Last Triggered",
      render: (row) => (
        <span className="text-linkedin-gray-50">
          {row.lastTriggered ?? "Never"}
        </span>
      ),
    },
    {
      key: "actions",
      header: "Actions",
      render: (row) => (
        <div className="flex items-center gap-1">
          {onTest && (
            <Button
              variant="ghost"
              size="sm"
              iconLeft={<Zap className="h-3.5 w-3.5" />}
              onClick={() => onTest(row.id)}
            >
              Test
            </Button>
          )}
          <Button
            variant="ghost"
            size="sm"
            iconLeft={<Pencil className="h-3.5 w-3.5" />}
            onClick={() => openEdit(row)}
          >
            Edit
          </Button>
          <Button
            variant="ghost"
            size="sm"
            iconLeft={<Trash2 className="h-3.5 w-3.5" />}
            onClick={() => setDeleteTarget(row)}
          >
            Delete
          </Button>
        </div>
      ),
    },
  ];

  return (
    <div className={cn("flex flex-col gap-4", className)}>
      <div className="flex items-center justify-end">
        <Button iconLeft={<Plus className="h-4 w-4" />} onClick={openCreate}>
          Add Webhook
        </Button>
      </div>

      {webhooks.length === 0 ? (
        <EmptyState
          icon={<Webhook className="h-7 w-7" />}
          title="No webhooks"
          description="Add a webhook to receive real-time event notifications."
          action={
            <Button iconLeft={<Plus className="h-4 w-4" />} onClick={openCreate}>
              Add Webhook
            </Button>
          }
        />
      ) : (
        <DataTable
          columns={columns}
          data={webhooks}
          rowKey={(row) => row.id}
        />
      )}

      <Modal
        open={isFormOpen}
        onClose={() => {
          setCreating(false);
          setEditing(null);
        }}
        title={editing ? "Edit Webhook" : "Add Webhook"}
        footer={
          <>
            <Button
              variant="ghost"
              onClick={() => {
                setCreating(false);
                setEditing(null);
              }}
            >
              Cancel
            </Button>
            <Button onClick={handleSave}>Save</Button>
          </>
        }
      >
        <div className="flex flex-col gap-4">
          <Input
            label="Webhook URL"
            type="url"
            value={formUrl}
            onChange={(e) => setFormUrl(e.target.value)}
            placeholder="https://your-server.com/webhook"
          />
          <Input
            label="Secret"
            type="password"
            value={formSecret}
            onChange={(e) => setFormSecret(e.target.value)}
            placeholder="Webhook signing secret"
          />
          <div className="flex flex-col gap-1">
            <label className="text-sm font-medium text-linkedin-gray-90">
              Events
            </label>
            <div className="grid grid-cols-2 gap-2">
              {availableEvents.map((event) => (
                <label
                  key={event}
                  className="flex cursor-pointer items-center gap-1.5 text-sm"
                >
                  <input
                    type="checkbox"
                    checked={formEvents.includes(event)}
                    onChange={() => toggleEvent(event)}
                    className="accent-linkedin-blue"
                  />
                  {event}
                </label>
              ))}
            </div>
          </div>
        </div>
      </Modal>

      <ConfirmDialog
        open={deleteTarget !== null}
        onClose={() => setDeleteTarget(null)}
        onConfirm={handleDelete}
        title="Delete Webhook"
        message={`Are you sure you want to delete this webhook?`}
        danger
        confirmLabel="Delete"
      />
    </div>
  );
}
