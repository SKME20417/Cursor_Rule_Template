"use client";

import React, { useState } from "react";
import { cn } from "@/lib/utils/cn";
import { Upload, Save, MessageSquare } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { FileUpload } from "@/components/ui/file-upload";
import { Card, CardBody, CardHeader, CardFooter } from "@/components/ui/card";

/* ------------------------------------------------------------------ */
/* Types                                                               */
/* ------------------------------------------------------------------ */

interface BrandingConfigProps {
  initialCompanyName?: string;
  initialPrimaryColor?: string;
  initialLogoUrl?: string;
  initialFaviconUrl?: string;
  onSave?: (config: {
    companyName: string;
    primaryColor: string;
    logoFile?: File;
    faviconFile?: File;
  }) => void;
  loading?: boolean;
  className?: string;
}

/* ------------------------------------------------------------------ */
/* Component                                                           */
/* ------------------------------------------------------------------ */

export function BrandingConfig({
  initialCompanyName = "",
  initialPrimaryColor = "#0a66c2",
  initialLogoUrl,
  initialFaviconUrl,
  onSave,
  loading = false,
  className,
}: BrandingConfigProps) {
  const [companyName, setCompanyName] = useState(initialCompanyName);
  const [primaryColor, setPrimaryColor] = useState(initialPrimaryColor);
  const [logoFile, setLogoFile] = useState<File | undefined>();
  const [faviconFile, setFaviconFile] = useState<File | undefined>();

  const handleSave = () => {
    onSave?.({ companyName, primaryColor, logoFile, faviconFile });
  };

  return (
    <div className={cn("grid gap-6 lg:grid-cols-2", className)}>
      {/* Settings */}
      <Card padding="none">
        <CardHeader>
          <h3 className="font-semibold text-linkedin-gray-90">
            Brand Settings
          </h3>
        </CardHeader>
        <CardBody>
          <div className="flex flex-col gap-5">
            <Input
              label="Company Name"
              value={companyName}
              onChange={(e) => setCompanyName(e.target.value)}
              placeholder="Your Company"
            />

            <div className="flex flex-col gap-1">
              <label className="text-sm font-medium text-linkedin-gray-90">
                Primary Color
              </label>
              <div className="flex items-center gap-3">
                <input
                  type="color"
                  value={primaryColor}
                  onChange={(e) => setPrimaryColor(e.target.value)}
                  className="h-10 w-10 cursor-pointer rounded border border-linkedin-gray-30"
                />
                <Input
                  value={primaryColor}
                  onChange={(e) => setPrimaryColor(e.target.value)}
                  placeholder="#0a66c2"
                  className="max-w-32"
                />
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <label className="text-sm font-medium text-linkedin-gray-90">
                Logo
              </label>
              {initialLogoUrl && !logoFile && (
                <div className="mb-2 flex items-center gap-2">
                  <img
                    src={initialLogoUrl}
                    alt="Current logo"
                    className="h-10 rounded"
                  />
                  <span className="text-xs text-linkedin-gray-50">
                    Current logo
                  </span>
                </div>
              )}
              <FileUpload
                accept="image/*"
                maxSizeMB={5}
                onFiles={(files) => setLogoFile(files[0])}
              />
            </div>

            <div className="flex flex-col gap-1">
              <label className="text-sm font-medium text-linkedin-gray-90">
                Favicon
              </label>
              {initialFaviconUrl && !faviconFile && (
                <div className="mb-2 flex items-center gap-2">
                  <img
                    src={initialFaviconUrl}
                    alt="Current favicon"
                    className="h-6 rounded"
                  />
                  <span className="text-xs text-linkedin-gray-50">
                    Current favicon
                  </span>
                </div>
              )}
              <FileUpload
                accept="image/x-icon,image/png,image/svg+xml"
                maxSizeMB={1}
                onFiles={(files) => setFaviconFile(files[0])}
              />
            </div>
          </div>
        </CardBody>
        <CardFooter>
          <div className="flex justify-end">
            <Button
              onClick={handleSave}
              loading={loading}
              iconLeft={<Save className="h-4 w-4" />}
            >
              Save Branding
            </Button>
          </div>
        </CardFooter>
      </Card>

      {/* Preview */}
      <Card padding="none">
        <CardHeader>
          <h3 className="font-semibold text-linkedin-gray-90">
            Chat Widget Preview
          </h3>
        </CardHeader>
        <CardBody>
          <div className="flex justify-center">
            <div className="w-72 rounded-xl border border-linkedin-gray-20 shadow-card overflow-hidden">
              {/* Widget Header */}
              <div
                className="flex items-center gap-2 px-4 py-3 text-white"
                style={{ backgroundColor: primaryColor }}
              >
                {logoFile ? (
                  <img
                    src={URL.createObjectURL(logoFile)}
                    alt="Logo preview"
                    className="h-6 rounded"
                  />
                ) : (
                  <MessageSquare className="h-5 w-5" />
                )}
                <span className="font-semibold text-sm">
                  {companyName || "Company"}
                </span>
              </div>

              {/* Widget Body */}
              <div className="bg-linkedin-gray-10 p-4 min-h-[200px]">
                <div className="rounded-lg bg-linkedin-white p-3 text-sm text-linkedin-gray-70 shadow-sm">
                  Hi there! How can we help you today?
                </div>
              </div>

              {/* Widget Input */}
              <div className="border-t border-linkedin-gray-20 px-4 py-3">
                <div className="rounded-full border border-linkedin-gray-30 px-3 py-2 text-xs text-linkedin-gray-50">
                  Type a message...
                </div>
              </div>
            </div>
          </div>
        </CardBody>
      </Card>
    </div>
  );
}
