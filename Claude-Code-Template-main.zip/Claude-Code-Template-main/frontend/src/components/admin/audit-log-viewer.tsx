"use client";

import React, { useState } from "react";
import { cn } from "@/lib/utils/cn";
import { Download, ChevronDown, ChevronRight, Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import { SearchInput } from "@/components/ui/search-input";
import { Select } from "@/components/ui/select";
import { DatePicker } from "@/components/ui/date-picker";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { EmptyState } from "@/components/ui/empty-state";

/* ------------------------------------------------------------------ */
/* Types                                                               */
/* ------------------------------------------------------------------ */

interface AuditLogEntry {
  id: string;
  timestamp: string;
  user: string;
  action: string;
  resource: string;
  details: string;
  ip: string;
}

interface AuditLogViewerProps {
  entries: AuditLogEntry[];
  loading?: boolean;
  onExport?: () => void;
  className?: string;
}

/* ------------------------------------------------------------------ */
/* Constants                                                           */
/* ------------------------------------------------------------------ */

const actionOptions = [
  { value: "", label: "All Actions" },
  { value: "create", label: "Create" },
  { value: "update", label: "Update" },
  { value: "delete", label: "Delete" },
  { value: "login", label: "Login" },
  { value: "logout", label: "Logout" },
  { value: "export", label: "Export" },
];

const actionVariant: Record<string, "primary" | "success" | "warning" | "danger" | "default"> = {
  create: "success",
  update: "primary",
  delete: "danger",
  login: "info" as "primary",
  logout: "default",
  export: "warning",
};

/* ------------------------------------------------------------------ */
/* Component                                                           */
/* ------------------------------------------------------------------ */

export function AuditLogViewer({
  entries,
  loading = false,
  onExport,
  className,
}: AuditLogViewerProps) {
  const [search, setSearch] = useState("");
  const [actionFilter, setActionFilter] = useState("");
  const [dateFrom, setDateFrom] = useState("");
  const [dateTo, setDateTo] = useState("");
  const [expandedId, setExpandedId] = useState<string | null>(null);

  const filtered = entries.filter((entry) => {
    if (search) {
      const q = search.toLowerCase();
      if (
        !entry.user.toLowerCase().includes(q) &&
        !entry.resource.toLowerCase().includes(q) &&
        !entry.details.toLowerCase().includes(q)
      ) {
        return false;
      }
    }
    if (actionFilter && entry.action !== actionFilter) return false;
    if (dateFrom && entry.timestamp < dateFrom) return false;
    if (dateTo && entry.timestamp > dateTo + "T23:59:59") return false;
    return true;
  });

  return (
    <div className={cn("flex flex-col gap-4", className)}>
      {/* Filters */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex flex-1 flex-col gap-2 sm:flex-row sm:items-center">
          <SearchInput
            value={search}
            onChange={setSearch}
            placeholder="Search logs..."
            className="sm:max-w-xs"
          />
          <Select
            options={actionOptions}
            value={actionFilter}
            onChange={(e) => setActionFilter(e.target.value)}
          />
          <DatePicker
            value={dateFrom}
            onChange={(e) => setDateFrom(e.target.value)}
            placeholder="From"
          />
          <DatePicker
            value={dateTo}
            onChange={(e) => setDateTo(e.target.value)}
            placeholder="To"
          />
        </div>
        {onExport && (
          <Button
            variant="secondary"
            iconLeft={<Download className="h-4 w-4" />}
            onClick={onExport}
          >
            Export
          </Button>
        )}
      </div>

      {/* Table */}
      <div className="overflow-x-auto rounded-lg border border-linkedin-gray-20 bg-linkedin-white">
        <table className="w-full text-left text-sm">
          <thead>
            <tr className="border-b border-linkedin-gray-20 bg-linkedin-gray-10">
              <th className="w-8 px-3 py-3" />
              <th className="px-4 py-3 font-semibold text-linkedin-gray-70">
                Timestamp
              </th>
              <th className="px-4 py-3 font-semibold text-linkedin-gray-70">
                User
              </th>
              <th className="px-4 py-3 font-semibold text-linkedin-gray-70">
                Action
              </th>
              <th className="px-4 py-3 font-semibold text-linkedin-gray-70">
                Resource
              </th>
              <th className="px-4 py-3 font-semibold text-linkedin-gray-70">
                IP
              </th>
            </tr>
          </thead>
          <tbody>
            {loading
              ? Array.from({ length: 5 }).map((_, i) => (
                  <tr
                    key={`skel-${i}`}
                    className="border-b border-linkedin-gray-20"
                  >
                    {Array.from({ length: 6 }).map((_, j) => (
                      <td key={j} className="px-4 py-3">
                        <Skeleton shape="text" />
                      </td>
                    ))}
                  </tr>
                ))
              : filtered.length === 0
                ? (
                  <tr>
                    <td colSpan={6}>
                      <EmptyState
                        title="No audit log entries"
                        description="No entries match your filters."
                      />
                    </td>
                  </tr>
                )
                : filtered.map((entry) => (
                    <React.Fragment key={entry.id}>
                      <tr
                        className="border-b border-linkedin-gray-20 cursor-pointer hover:bg-linkedin-gray-10 transition-colors"
                        onClick={() =>
                          setExpandedId(
                            expandedId === entry.id ? null : entry.id,
                          )
                        }
                      >
                        <td className="px-3 py-3">
                          {expandedId === entry.id ? (
                            <ChevronDown className="h-4 w-4 text-linkedin-gray-50" />
                          ) : (
                            <ChevronRight className="h-4 w-4 text-linkedin-gray-50" />
                          )}
                        </td>
                        <td className="px-4 py-3 whitespace-nowrap text-linkedin-gray-70 tabular-nums">
                          {entry.timestamp}
                        </td>
                        <td className="px-4 py-3 font-medium text-linkedin-gray-90">
                          {entry.user}
                        </td>
                        <td className="px-4 py-3">
                          <Badge
                            variant={
                              actionVariant[entry.action] ?? "default"
                            }
                            size="sm"
                          >
                            {entry.action}
                          </Badge>
                        </td>
                        <td className="px-4 py-3 text-linkedin-gray-90">
                          {entry.resource}
                        </td>
                        <td className="px-4 py-3 font-mono text-xs text-linkedin-gray-50">
                          {entry.ip}
                        </td>
                      </tr>
                      {expandedId === entry.id && (
                        <tr className="border-b border-linkedin-gray-20 bg-linkedin-gray-10">
                          <td colSpan={6} className="px-8 py-3">
                            <p className="text-sm text-linkedin-gray-70">
                              <span className="font-medium">Details:</span>{" "}
                              {entry.details}
                            </p>
                          </td>
                        </tr>
                      )}
                    </React.Fragment>
                  ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
