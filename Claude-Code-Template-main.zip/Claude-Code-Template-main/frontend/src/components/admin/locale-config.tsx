"use client";

import React, { useState } from "react";
import { cn } from "@/lib/utils/cn";
import { Save, Globe } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Select } from "@/components/ui/select";
import { Card, CardBody, CardHeader, CardFooter } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";

/* ------------------------------------------------------------------ */
/* Types                                                               */
/* ------------------------------------------------------------------ */

interface LocaleConfigProps {
  initialLanguages?: string[];
  initialDefaultLang?: string;
  initialTimezone?: string;
  initialDateFormat?: string;
  onSave?: (config: {
    languages: string[];
    defaultLang: string;
    timezone: string;
    dateFormat: string;
  }) => void;
  loading?: boolean;
  className?: string;
}

/* ------------------------------------------------------------------ */
/* Constants                                                           */
/* ------------------------------------------------------------------ */

const allLanguages = [
  { code: "en", label: "English" },
  { code: "es", label: "Spanish" },
  { code: "fr", label: "French" },
  { code: "de", label: "German" },
  { code: "pt", label: "Portuguese" },
  { code: "ja", label: "Japanese" },
  { code: "zh", label: "Chinese" },
  { code: "ko", label: "Korean" },
  { code: "ar", label: "Arabic" },
  { code: "hi", label: "Hindi" },
  { code: "it", label: "Italian" },
  { code: "nl", label: "Dutch" },
];

const timezoneOptions = [
  { value: "UTC", label: "UTC" },
  { value: "America/New_York", label: "Eastern (US)" },
  { value: "America/Chicago", label: "Central (US)" },
  { value: "America/Denver", label: "Mountain (US)" },
  { value: "America/Los_Angeles", label: "Pacific (US)" },
  { value: "Europe/London", label: "London" },
  { value: "Europe/Paris", label: "Paris" },
  { value: "Europe/Berlin", label: "Berlin" },
  { value: "Asia/Tokyo", label: "Tokyo" },
  { value: "Asia/Shanghai", label: "Shanghai" },
  { value: "Asia/Kolkata", label: "India" },
  { value: "Australia/Sydney", label: "Sydney" },
];

const dateFormatOptions = [
  { value: "MM/DD/YYYY", label: "MM/DD/YYYY" },
  { value: "DD/MM/YYYY", label: "DD/MM/YYYY" },
  { value: "YYYY-MM-DD", label: "YYYY-MM-DD (ISO)" },
  { value: "DD.MM.YYYY", label: "DD.MM.YYYY" },
];

/* ------------------------------------------------------------------ */
/* Component                                                           */
/* ------------------------------------------------------------------ */

export function LocaleConfig({
  initialLanguages = ["en"],
  initialDefaultLang = "en",
  initialTimezone = "UTC",
  initialDateFormat = "MM/DD/YYYY",
  onSave,
  loading = false,
  className,
}: LocaleConfigProps) {
  const [languages, setLanguages] = useState<string[]>(initialLanguages);
  const [defaultLang, setDefaultLang] = useState(initialDefaultLang);
  const [timezone, setTimezone] = useState(initialTimezone);
  const [dateFormat, setDateFormat] = useState(initialDateFormat);

  const toggleLanguage = (code: string) => {
    setLanguages((prev) => {
      if (prev.includes(code)) {
        const next = prev.filter((l) => l !== code);
        if (defaultLang === code && next.length > 0) {
          setDefaultLang(next[0]);
        }
        return next;
      }
      return [...prev, code];
    });
  };

  const handleSave = () => {
    onSave?.({ languages, defaultLang, timezone, dateFormat });
  };

  const defaultLangOptions = languages.map((code) => ({
    value: code,
    label: allLanguages.find((l) => l.code === code)?.label ?? code,
  }));

  return (
    <Card className={className} padding="none">
      <CardHeader>
        <div className="flex items-center gap-2">
          <Globe className="h-5 w-5 text-linkedin-blue" />
          <h3 className="font-semibold text-linkedin-gray-90">
            Localization Settings
          </h3>
        </div>
      </CardHeader>
      <CardBody>
        <div className="flex flex-col gap-5">
          {/* Supported Languages */}
          <div className="flex flex-col gap-2">
            <label className="text-sm font-medium text-linkedin-gray-90">
              Supported Languages
            </label>
            <div className="grid grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-4">
              {allLanguages.map((lang) => (
                <Checkbox
                  key={lang.code}
                  label={lang.label}
                  checked={languages.includes(lang.code)}
                  onChange={() => toggleLanguage(lang.code)}
                />
              ))}
            </div>
          </div>

          {/* Default Language */}
          <Select
            label="Default Language"
            options={defaultLangOptions}
            value={defaultLang}
            onChange={(e) => setDefaultLang(e.target.value)}
          />

          {/* Timezone */}
          <Select
            label="Timezone"
            options={timezoneOptions}
            value={timezone}
            onChange={(e) => setTimezone(e.target.value)}
          />

          {/* Date Format */}
          <Select
            label="Date Format"
            options={dateFormatOptions}
            value={dateFormat}
            onChange={(e) => setDateFormat(e.target.value)}
          />
        </div>
      </CardBody>
      <CardFooter>
        <div className="flex justify-end">
          <Button
            onClick={handleSave}
            loading={loading}
            iconLeft={<Save className="h-4 w-4" />}
          >
            Save Settings
          </Button>
        </div>
      </CardFooter>
    </Card>
  );
}
