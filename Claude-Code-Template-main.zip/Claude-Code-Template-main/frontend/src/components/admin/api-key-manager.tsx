"use client";

import React, { useState } from "react";
import { cn } from "@/lib/utils/cn";
import { Plus, Copy, Trash2, Key, Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import { Card, CardBody, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Modal } from "@/components/ui/modal";
import { ConfirmDialog } from "@/components/ui/confirm-dialog";
import { EmptyState } from "@/components/ui/empty-state";
import { DataTable, type DataTableColumn } from "@/components/ui/data-table";

/* ------------------------------------------------------------------ */
/* Types                                                               */
/* ------------------------------------------------------------------ */

interface ApiKey {
  id: string;
  prefix: string;
  name: string;
  permissions: string[];
  createdAt: string;
  lastUsed: string | null;
}

interface ApiKeyManagerProps {
  keys: ApiKey[];
  onCreate?: (name: string, permissions: string[]) => string | null;
  onRevoke?: (keyId: string) => void;
  className?: string;
}

/* ------------------------------------------------------------------ */
/* Constants                                                           */
/* ------------------------------------------------------------------ */

const permissionOptions = [
  { value: "read", label: "Read" },
  { value: "write", label: "Write" },
  { value: "admin", label: "Admin" },
  { value: "webhooks", label: "Webhooks" },
];

/* ------------------------------------------------------------------ */
/* Component                                                           */
/* ------------------------------------------------------------------ */

export function ApiKeyManager({
  keys,
  onCreate,
  onRevoke,
  className,
}: ApiKeyManagerProps) {
  const [creating, setCreating] = useState(false);
  const [revokeTarget, setRevokeTarget] = useState<ApiKey | null>(null);
  const [newKeyName, setNewKeyName] = useState("");
  const [newKeyPerms, setNewKeyPerms] = useState<string[]>(["read"]);
  const [generatedKey, setGeneratedKey] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  const handleCreate = () => {
    const key = onCreate?.(newKeyName, newKeyPerms);
    if (key) {
      setGeneratedKey(key);
    } else {
      setGeneratedKey(`sk_live_${crypto.randomUUID().replace(/-/g, "")}`);
    }
  };

  const handleCopy = () => {
    if (generatedKey) {
      navigator.clipboard.writeText(generatedKey);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleRevoke = () => {
    if (revokeTarget) {
      onRevoke?.(revokeTarget.id);
      setRevokeTarget(null);
    }
  };

  const closeCreate = () => {
    setCreating(false);
    setGeneratedKey(null);
    setNewKeyName("");
    setNewKeyPerms(["read"]);
    setCopied(false);
  };

  const togglePerm = (perm: string) => {
    setNewKeyPerms((prev) =>
      prev.includes(perm)
        ? prev.filter((p) => p !== perm)
        : [...prev, perm],
    );
  };

  const columns: DataTableColumn<ApiKey>[] = [
    {
      key: "prefix",
      header: "Key",
      render: (row) => (
        <code className="rounded bg-linkedin-gray-10 px-2 py-0.5 text-xs font-mono">
          {row.prefix}...
        </code>
      ),
    },
    { key: "name", header: "Name" },
    {
      key: "permissions",
      header: "Permissions",
      render: (row) => (
        <div className="flex flex-wrap gap-1">
          {row.permissions.map((p) => (
            <Badge key={p} variant="primary" size="sm">
              {p}
            </Badge>
          ))}
        </div>
      ),
    },
    { key: "createdAt", header: "Created" },
    {
      key: "lastUsed",
      header: "Last Used",
      render: (row) => (
        <span className="text-linkedin-gray-50">
          {row.lastUsed ?? "Never"}
        </span>
      ),
    },
    {
      key: "actions",
      header: "Actions",
      render: (row) => (
        <Button
          variant="ghost"
          size="sm"
          iconLeft={<Trash2 className="h-3.5 w-3.5" />}
          onClick={() => setRevokeTarget(row)}
        >
          Revoke
        </Button>
      ),
    },
  ];

  return (
    <div className={cn("flex flex-col gap-4", className)}>
      <div className="flex items-center justify-end">
        <Button
          iconLeft={<Plus className="h-4 w-4" />}
          onClick={() => setCreating(true)}
        >
          Create API Key
        </Button>
      </div>

      {keys.length === 0 ? (
        <EmptyState
          icon={<Key className="h-7 w-7" />}
          title="No API keys"
          description="Create an API key to access the platform programmatically."
          action={
            <Button
              iconLeft={<Plus className="h-4 w-4" />}
              onClick={() => setCreating(true)}
            >
              Create API Key
            </Button>
          }
        />
      ) : (
        <DataTable
          columns={columns}
          data={keys}
          rowKey={(row) => row.id}
        />
      )}

      {/* Create Modal */}
      <Modal
        open={creating}
        onClose={closeCreate}
        title={generatedKey ? "API Key Created" : "Create API Key"}
        footer={
          generatedKey ? (
            <Button onClick={closeCreate}>Done</Button>
          ) : (
            <>
              <Button variant="ghost" onClick={closeCreate}>
                Cancel
              </Button>
              <Button onClick={handleCreate}>Create</Button>
            </>
          )
        }
      >
        {generatedKey ? (
          <div className="flex flex-col gap-3">
            <p className="text-sm text-linkedin-gray-70">
              Copy this key now. You will not be able to see it again.
            </p>
            <div className="flex items-center gap-2">
              <code className="flex-1 rounded-lg border border-linkedin-gray-20 bg-linkedin-gray-10 px-3 py-2 text-sm font-mono break-all">
                {generatedKey}
              </code>
              <Button
                variant="secondary"
                size="sm"
                iconLeft={
                  copied ? (
                    <Check className="h-3.5 w-3.5" />
                  ) : (
                    <Copy className="h-3.5 w-3.5" />
                  )
                }
                onClick={handleCopy}
              >
                {copied ? "Copied" : "Copy"}
              </Button>
            </div>
          </div>
        ) : (
          <div className="flex flex-col gap-4">
            <Input
              label="Key Name"
              value={newKeyName}
              onChange={(e) => setNewKeyName(e.target.value)}
              placeholder="e.g. Production API Key"
            />
            <div className="flex flex-col gap-1">
              <label className="text-sm font-medium text-linkedin-gray-90">
                Permissions
              </label>
              <div className="flex flex-wrap gap-2">
                {permissionOptions.map((opt) => (
                  <label
                    key={opt.value}
                    className="flex cursor-pointer items-center gap-1.5 text-sm"
                  >
                    <input
                      type="checkbox"
                      checked={newKeyPerms.includes(opt.value)}
                      onChange={() => togglePerm(opt.value)}
                      className="accent-linkedin-blue"
                    />
                    {opt.label}
                  </label>
                ))}
              </div>
            </div>
          </div>
        )}
      </Modal>

      <ConfirmDialog
        open={revokeTarget !== null}
        onClose={() => setRevokeTarget(null)}
        onConfirm={handleRevoke}
        title="Revoke API Key"
        message={`Are you sure you want to revoke "${revokeTarget?.name}"? This action is irreversible.`}
        danger
        confirmLabel="Revoke"
      />
    </div>
  );
}
