"use client";

import React from "react";
import { cn } from "@/lib/utils/cn";
import { Activity, Clock } from "lucide-react";
import { Card, CardBody } from "@/components/ui/card";

/* ------------------------------------------------------------------ */
/* Types                                                               */
/* ------------------------------------------------------------------ */

interface SystemHealthCardProps {
  serviceName: string;
  status: "healthy" | "degraded" | "down";
  uptimePct: number;
  responseTimeMs: number;
  lastCheck: string;
  onClick?: () => void;
  className?: string;
}

/* ------------------------------------------------------------------ */
/* Constants                                                           */
/* ------------------------------------------------------------------ */

const statusConfig: Record<
  string,
  { label: string; color: string; bgColor: string; dotColor: string }
> = {
  healthy: {
    label: "Healthy",
    color: "text-linkedin-green",
    bgColor: "bg-green-50",
    dotColor: "bg-linkedin-green",
  },
  degraded: {
    label: "Degraded",
    color: "text-linkedin-orange",
    bgColor: "bg-orange-50",
    dotColor: "bg-linkedin-orange",
  },
  down: {
    label: "Down",
    color: "text-linkedin-red",
    bgColor: "bg-red-50",
    dotColor: "bg-linkedin-red",
  },
};

/* ------------------------------------------------------------------ */
/* Component                                                           */
/* ------------------------------------------------------------------ */

export function SystemHealthCard({
  serviceName,
  status,
  uptimePct,
  responseTimeMs,
  lastCheck,
  onClick,
  className,
}: SystemHealthCardProps) {
  const cfg = statusConfig[status];

  return (
    <Card
      hover={!!onClick}
      className={cn(onClick && "cursor-pointer", className)}
      onClick={onClick}
    >
      <CardBody>
        <div className="flex items-start justify-between">
          <div>
            <h3 className="font-semibold text-linkedin-gray-90">
              {serviceName}
            </h3>
            <div className="mt-1 flex items-center gap-1.5">
              <span
                className={cn("h-2 w-2 rounded-full", cfg.dotColor)}
                aria-hidden="true"
              />
              <span className={cn("text-sm font-medium", cfg.color)}>
                {cfg.label}
              </span>
            </div>
          </div>
          <div
            className={cn(
              "flex h-10 w-10 items-center justify-center rounded-lg",
              cfg.bgColor,
            )}
          >
            <Activity className={cn("h-5 w-5", cfg.color)} />
          </div>
        </div>

        <div className="mt-4 grid grid-cols-2 gap-3">
          <div>
            <p className="text-xs text-linkedin-gray-50">Uptime</p>
            <p className="text-lg font-semibold text-linkedin-gray-90 tabular-nums">
              {uptimePct.toFixed(2)}%
            </p>
          </div>
          <div>
            <p className="text-xs text-linkedin-gray-50">Response Time</p>
            <p className="text-lg font-semibold text-linkedin-gray-90 tabular-nums">
              {responseTimeMs}ms
            </p>
          </div>
        </div>

        <div className="mt-3 flex items-center gap-1 text-xs text-linkedin-gray-50">
          <Clock className="h-3 w-3" />
          Last check: {lastCheck}
        </div>
      </CardBody>
    </Card>
  );
}
