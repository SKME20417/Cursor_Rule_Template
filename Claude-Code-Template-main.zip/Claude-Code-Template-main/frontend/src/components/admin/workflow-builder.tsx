"use client";

import React, { useState, useCallback } from "react";
import { cn } from "@/lib/utils/cn";
import {
  Plus,
  Zap,
  GitBranch,
  Play,
  Clock,
  Trash2,
  Save,
  Power,
  Settings,
  X,
  ArrowDown,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardBody, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Toggle } from "@/components/ui/toggle";

/* ------------------------------------------------------------------ */
/* Types                                                               */
/* ------------------------------------------------------------------ */

type NodeType = "trigger" | "condition" | "action" | "delay";

interface WorkflowNode {
  id: string;
  type: NodeType;
  label: string;
  config: Record<string, string>;
  x: number;
  y: number;
}

interface WorkflowEdge {
  id: string;
  from: string;
  to: string;
  label?: string;
}

interface Workflow {
  id: string;
  name: string;
  nodes: WorkflowNode[];
  edges: WorkflowEdge[];
  active: boolean;
}

interface WorkflowBuilderProps {
  workflow?: Workflow;
  onSave?: (workflow: Workflow) => void;
  className?: string;
}

/* ------------------------------------------------------------------ */
/* Constants                                                           */
/* ------------------------------------------------------------------ */

const nodeTypeConfig: Record<
  NodeType,
  { icon: React.ReactNode; color: string; bgColor: string }
> = {
  trigger: {
    icon: <Zap className="h-4 w-4" />,
    color: "text-linkedin-blue",
    bgColor: "bg-linkedin-blue-bg border-linkedin-blue",
  },
  condition: {
    icon: <GitBranch className="h-4 w-4" />,
    color: "text-linkedin-orange",
    bgColor: "bg-orange-50 border-linkedin-orange",
  },
  action: {
    icon: <Play className="h-4 w-4" />,
    color: "text-linkedin-green",
    bgColor: "bg-green-50 border-linkedin-green",
  },
  delay: {
    icon: <Clock className="h-4 w-4" />,
    color: "text-purple-600",
    bgColor: "bg-purple-50 border-purple-400",
  },
};

const nodeTypeOptions = [
  { value: "trigger", label: "Trigger" },
  { value: "condition", label: "Condition" },
  { value: "action", label: "Action" },
  { value: "delay", label: "Delay" },
];

/* ------------------------------------------------------------------ */
/* Component                                                           */
/* ------------------------------------------------------------------ */

export function WorkflowBuilder({
  workflow: initial,
  onSave,
  className,
}: WorkflowBuilderProps) {
  const [name, setName] = useState(initial?.name ?? "Untitled Workflow");
  const [nodes, setNodes] = useState<WorkflowNode[]>(initial?.nodes ?? []);
  const [edges, setEdges] = useState<WorkflowEdge[]>(initial?.edges ?? []);
  const [active, setActive] = useState(initial?.active ?? false);
  const [selectedNode, setSelectedNode] = useState<WorkflowNode | null>(null);
  const [configLabel, setConfigLabel] = useState("");
  const [configValue, setConfigValue] = useState("");

  const addNode = (type: NodeType) => {
    const newNode: WorkflowNode = {
      id: crypto.randomUUID(),
      type,
      label: `${type.charAt(0).toUpperCase() + type.slice(1)} ${nodes.length + 1}`,
      config: {},
      x: 0,
      y: nodes.length * 120,
    };
    setNodes((prev) => {
      const updated = [...prev, newNode];
      // Auto-connect to previous node
      if (prev.length > 0) {
        const lastNode = prev[prev.length - 1];
        setEdges((e) => [
          ...e,
          {
            id: crypto.randomUUID(),
            from: lastNode.id,
            to: newNode.id,
          },
        ]);
      }
      return updated;
    });
  };

  const removeNode = (nodeId: string) => {
    setNodes((prev) => prev.filter((n) => n.id !== nodeId));
    setEdges((prev) =>
      prev.filter((e) => e.from !== nodeId && e.to !== nodeId),
    );
    if (selectedNode?.id === nodeId) setSelectedNode(null);
  };

  const openConfig = (node: WorkflowNode) => {
    setSelectedNode(node);
    setConfigLabel(node.label);
    setConfigValue(node.config.value ?? "");
  };

  const saveNodeConfig = () => {
    if (!selectedNode) return;
    setNodes((prev) =>
      prev.map((n) =>
        n.id === selectedNode.id
          ? { ...n, label: configLabel, config: { ...n.config, value: configValue } }
          : n,
      ),
    );
    setSelectedNode(null);
  };

  const handleSave = () => {
    onSave?.({
      id: initial?.id ?? crypto.randomUUID(),
      name,
      nodes,
      edges,
      active,
    });
  };

  return (
    <div className={cn("flex flex-col gap-4", className)}>
      {/* Header */}
      <div className="flex items-center gap-4">
        <Input
          value={name}
          onChange={(e) => setName(e.target.value)}
          className="max-w-sm text-lg font-semibold"
        />
        <Toggle
          checked={active}
          onChange={setActive}
          label={active ? "Active" : "Inactive"}
        />
        <div className="ml-auto">
          <Button
            iconLeft={<Save className="h-4 w-4" />}
            onClick={handleSave}
          >
            Save Workflow
          </Button>
        </div>
      </div>

      <div className="flex gap-4">
        {/* Sidebar - Node palette */}
        <Card className="w-48 shrink-0" padding="none">
          <CardHeader>
            <span className="text-sm font-semibold">Add Nodes</span>
          </CardHeader>
          <CardBody>
            <div className="flex flex-col gap-2">
              {(Object.keys(nodeTypeConfig) as NodeType[]).map((type) => {
                const cfg = nodeTypeConfig[type];
                return (
                  <button
                    key={type}
                    type="button"
                    onClick={() => addNode(type)}
                    className={cn(
                      "flex items-center gap-2 rounded-lg border px-3 py-2 text-sm font-medium transition-colors hover:shadow-sm",
                      cfg.bgColor,
                      cfg.color,
                    )}
                  >
                    {cfg.icon}
                    <span className="capitalize">{type}</span>
                  </button>
                );
              })}
            </div>
          </CardBody>
        </Card>

        {/* Canvas */}
        <Card className="flex-1 min-h-[400px]" padding="none">
          <CardBody>
            {nodes.length === 0 ? (
              <div className="flex h-full min-h-[350px] items-center justify-center text-sm text-linkedin-gray-50">
                Add nodes from the sidebar to build your workflow
              </div>
            ) : (
              <div className="flex flex-col items-center gap-2 py-4">
                {nodes.map((node, idx) => {
                  const cfg = nodeTypeConfig[node.type];
                  return (
                    <React.Fragment key={node.id}>
                      {idx > 0 && (
                        <ArrowDown className="h-5 w-5 text-linkedin-gray-30" />
                      )}
                      <div
                        className={cn(
                          "relative flex w-64 items-center gap-2 rounded-lg border-2 px-4 py-3 cursor-pointer transition-shadow hover:shadow-md",
                          cfg.bgColor,
                        )}
                        onClick={() => openConfig(node)}
                      >
                        <span className={cfg.color}>{cfg.icon}</span>
                        <div className="flex-1">
                          <p
                            className={cn(
                              "text-sm font-medium",
                              cfg.color,
                            )}
                          >
                            {node.label}
                          </p>
                          <p className="text-xs text-linkedin-gray-50 capitalize">
                            {node.type}
                          </p>
                        </div>
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            removeNode(node.id);
                          }}
                          className="rounded-full p-1 text-linkedin-gray-50 hover:bg-black/10 transition-colors"
                          aria-label="Remove node"
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </button>
                      </div>
                    </React.Fragment>
                  );
                })}
              </div>
            )}
          </CardBody>
        </Card>

        {/* Config Panel */}
        {selectedNode && (
          <Card className="w-72 shrink-0" padding="none">
            <CardHeader>
              <div className="flex items-center justify-between">
                <span className="text-sm font-semibold">Configure Node</span>
                <button
                  type="button"
                  onClick={() => setSelectedNode(null)}
                  className="rounded-full p-1 text-linkedin-gray-50 hover:bg-linkedin-gray-10"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>
            </CardHeader>
            <CardBody>
              <div className="flex flex-col gap-3">
                <Input
                  label="Label"
                  value={configLabel}
                  onChange={(e) => setConfigLabel(e.target.value)}
                />
                <Textarea
                  label="Configuration"
                  value={configValue}
                  onChange={(e) => setConfigValue(e.target.value)}
                  placeholder="Enter node configuration..."
                  rows={4}
                />
                <Button onClick={saveNodeConfig} size="sm">
                  Apply
                </Button>
              </div>
            </CardBody>
          </Card>
        )}
      </div>
    </div>
  );
}
