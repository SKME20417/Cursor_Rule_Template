"use client";

import React from "react";
import { cn } from "@/lib/utils/cn";
import { Settings, CheckCircle, XCircle, AlertTriangle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardBody } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

/* ------------------------------------------------------------------ */
/* Types                                                               */
/* ------------------------------------------------------------------ */

interface IntegrationCardProps {
  name: string;
  icon?: React.ReactNode;
  status: "connected" | "disconnected" | "error";
  lastSync?: string;
  onConfigure?: () => void;
  className?: string;
}

/* ------------------------------------------------------------------ */
/* Constants                                                           */
/* ------------------------------------------------------------------ */

const statusConfig: Record<
  string,
  {
    label: string;
    variant: "success" | "default" | "danger";
    icon: React.ReactNode;
    dotColor: string;
  }
> = {
  connected: {
    label: "Connected",
    variant: "success",
    icon: <CheckCircle className="h-4 w-4" />,
    dotColor: "bg-linkedin-green",
  },
  disconnected: {
    label: "Disconnected",
    variant: "default",
    icon: <XCircle className="h-4 w-4" />,
    dotColor: "bg-linkedin-gray-50",
  },
  error: {
    label: "Error",
    variant: "danger",
    icon: <AlertTriangle className="h-4 w-4" />,
    dotColor: "bg-linkedin-red",
  },
};

/* ------------------------------------------------------------------ */
/* Component                                                           */
/* ------------------------------------------------------------------ */

export function IntegrationCard({
  name,
  icon,
  status,
  lastSync,
  onConfigure,
  className,
}: IntegrationCardProps) {
  const cfg = statusConfig[status];

  return (
    <Card hover className={className}>
      <CardBody>
        <div className="flex items-start gap-3">
          {/* Icon / Logo */}
          <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-linkedin-gray-10 text-linkedin-gray-70">
            {icon ?? <Settings className="h-5 w-5" />}
          </div>

          <div className="flex-1">
            <div className="flex items-center gap-2">
              <h3 className="font-semibold text-linkedin-gray-90">{name}</h3>
              <span
                className={cn("h-2 w-2 rounded-full", cfg.dotColor)}
                aria-hidden="true"
              />
            </div>

            <div className="mt-1 flex items-center gap-2">
              <Badge variant={cfg.variant} size="sm">
                {cfg.label}
              </Badge>
            </div>

            {lastSync && (
              <p className="mt-2 text-xs text-linkedin-gray-50">
                Last sync: {lastSync}
              </p>
            )}
          </div>
        </div>

        {onConfigure && (
          <div className="mt-3 border-t border-linkedin-gray-20 pt-3">
            <Button
              variant="secondary"
              size="sm"
              iconLeft={<Settings className="h-3.5 w-3.5" />}
              onClick={onConfigure}
            >
              Configure
            </Button>
          </div>
        )}
      </CardBody>
    </Card>
  );
}
