"use client";

import React, { useState } from "react";
import { cn } from "@/lib/utils/cn";
import { Plus, Pencil, Trash2, Users } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardBody, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Modal } from "@/components/ui/modal";
import { ConfirmDialog } from "@/components/ui/confirm-dialog";
import { EmptyState } from "@/components/ui/empty-state";

/* ------------------------------------------------------------------ */
/* Types                                                               */
/* ------------------------------------------------------------------ */

interface TeamMember {
  id: string;
  name: string;
}

interface Team {
  id: string;
  name: string;
  description: string;
  leadId: string;
  leadName: string;
  members: TeamMember[];
}

interface TeamManagerProps {
  teams: Team[];
  availableAgents: TeamMember[];
  onSave?: (team: Omit<Team, "leadName">) => void;
  onDelete?: (teamId: string) => void;
  className?: string;
}

/* ------------------------------------------------------------------ */
/* Component                                                           */
/* ------------------------------------------------------------------ */

export function TeamManager({
  teams,
  availableAgents,
  onSave,
  onDelete,
  className,
}: TeamManagerProps) {
  const [editing, setEditing] = useState<Team | null>(null);
  const [creating, setCreating] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<Team | null>(null);

  const [formName, setFormName] = useState("");
  const [formDesc, setFormDesc] = useState("");
  const [formLead, setFormLead] = useState("");
  const [formMembers, setFormMembers] = useState<string[]>([]);

  const openCreate = () => {
    setFormName("");
    setFormDesc("");
    setFormLead("");
    setFormMembers([]);
    setCreating(true);
    setEditing(null);
  };

  const openEdit = (team: Team) => {
    setFormName(team.name);
    setFormDesc(team.description);
    setFormLead(team.leadId);
    setFormMembers(team.members.map((m) => m.id));
    setEditing(team);
    setCreating(false);
  };

  const handleSave = () => {
    const teamData: Omit<Team, "leadName"> = {
      id: editing?.id ?? crypto.randomUUID(),
      name: formName,
      description: formDesc,
      leadId: formLead,
      members: formMembers.map((id) => ({
        id,
        name: availableAgents.find((a) => a.id === id)?.name ?? id,
      })),
    };
    onSave?.(teamData);
    setCreating(false);
    setEditing(null);
  };

  const handleDelete = () => {
    if (deleteTarget) {
      onDelete?.(deleteTarget.id);
      setDeleteTarget(null);
    }
  };

  const isFormOpen = creating || editing !== null;

  const agentOptions = availableAgents.map((a) => ({
    value: a.id,
    label: a.name,
  }));

  const toggleMember = (id: string) => {
    setFormMembers((prev) =>
      prev.includes(id) ? prev.filter((m) => m !== id) : [...prev, id],
    );
  };

  return (
    <div className={cn("flex flex-col gap-4", className)}>
      <div className="flex items-center justify-end">
        <Button iconLeft={<Plus className="h-4 w-4" />} onClick={openCreate}>
          Add Team
        </Button>
      </div>

      {teams.length === 0 ? (
        <EmptyState
          icon={<Users className="h-7 w-7" />}
          title="No teams yet"
          description="Create your first team to organize agents."
          action={
            <Button
              iconLeft={<Plus className="h-4 w-4" />}
              onClick={openCreate}
            >
              Add Team
            </Button>
          }
        />
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {teams.map((team) => (
            <Card key={team.id} hover>
              <CardBody>
                <div className="flex items-start justify-between">
                  <div>
                    <h3 className="font-semibold text-linkedin-gray-90">
                      {team.name}
                    </h3>
                    <p className="mt-1 text-xs text-linkedin-gray-50">
                      {team.description}
                    </p>
                  </div>
                  <Badge variant="primary">{team.members.length} members</Badge>
                </div>

                <div className="mt-3 text-sm text-linkedin-gray-70">
                  <span className="font-medium">Lead:</span> {team.leadName}
                </div>

                <div className="mt-3 flex items-center gap-2">
                  <Button
                    variant="ghost"
                    size="sm"
                    iconLeft={<Pencil className="h-3.5 w-3.5" />}
                    onClick={() => openEdit(team)}
                  >
                    Edit
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    iconLeft={<Trash2 className="h-3.5 w-3.5" />}
                    onClick={() => setDeleteTarget(team)}
                  >
                    Delete
                  </Button>
                </div>
              </CardBody>
            </Card>
          ))}
        </div>
      )}

      {/* Create/Edit Modal */}
      <Modal
        open={isFormOpen}
        onClose={() => {
          setCreating(false);
          setEditing(null);
        }}
        title={editing ? "Edit Team" : "Create Team"}
        footer={
          <>
            <Button
              variant="ghost"
              onClick={() => {
                setCreating(false);
                setEditing(null);
              }}
            >
              Cancel
            </Button>
            <Button onClick={handleSave}>Save</Button>
          </>
        }
      >
        <div className="flex flex-col gap-4">
          <Input
            label="Team Name"
            value={formName}
            onChange={(e) => setFormName(e.target.value)}
            placeholder="e.g. Billing Support"
          />
          <Textarea
            label="Description"
            value={formDesc}
            onChange={(e) => setFormDesc(e.target.value)}
            placeholder="What this team handles..."
            rows={3}
          />
          <Select
            label="Team Lead"
            options={[{ value: "", label: "Select lead..." }, ...agentOptions]}
            value={formLead}
            onChange={(e) => setFormLead(e.target.value)}
          />
          <div className="flex flex-col gap-1">
            <label className="text-sm font-medium text-linkedin-gray-90">
              Members
            </label>
            <div className="max-h-40 overflow-y-auto rounded-lg border border-linkedin-gray-20">
              {availableAgents.map((agent) => (
                <label
                  key={agent.id}
                  className="flex cursor-pointer items-center gap-2 px-3 py-2 hover:bg-linkedin-gray-10"
                >
                  <input
                    type="checkbox"
                    checked={formMembers.includes(agent.id)}
                    onChange={() => toggleMember(agent.id)}
                    className="accent-linkedin-blue"
                  />
                  <span className="text-sm text-linkedin-gray-90">
                    {agent.name}
                  </span>
                </label>
              ))}
            </div>
          </div>
        </div>
      </Modal>

      {/* Delete Confirmation */}
      <ConfirmDialog
        open={deleteTarget !== null}
        onClose={() => setDeleteTarget(null)}
        onConfirm={handleDelete}
        title="Delete Team"
        message={`Are you sure you want to delete "${deleteTarget?.name}"? This action cannot be undone.`}
        danger
        confirmLabel="Delete"
      />
    </div>
  );
}
