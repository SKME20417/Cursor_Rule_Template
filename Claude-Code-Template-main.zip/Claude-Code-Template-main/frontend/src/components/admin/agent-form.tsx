"use client";

import React, { useState } from "react";
import { cn } from "@/lib/utils/cn";
import { Save, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import { Toggle } from "@/components/ui/toggle";
import { Tag } from "@/components/ui/tag";
import { Card, CardBody } from "@/components/ui/card";

/* ------------------------------------------------------------------ */
/* Types                                                               */
/* ------------------------------------------------------------------ */

interface AgentFormData {
  name: string;
  email: string;
  role: string;
  team: string;
  skills: string[];
  maxConcurrent: number;
  shiftStart: string;
  shiftEnd: string;
  active: boolean;
}

interface AgentFormProps {
  initialData?: Partial<AgentFormData>;
  onSave?: (data: AgentFormData) => void;
  onCancel?: () => void;
  loading?: boolean;
  className?: string;
}

/* ------------------------------------------------------------------ */
/* Constants                                                           */
/* ------------------------------------------------------------------ */

const roleOptions = [
  { value: "agent", label: "Agent" },
  { value: "supervisor", label: "Supervisor" },
];

const teamOptions = [
  { value: "Billing", label: "Billing" },
  { value: "Technical", label: "Technical" },
  { value: "Sales", label: "Sales" },
  { value: "General", label: "General" },
];

const availableSkills = [
  "Billing",
  "Refunds",
  "Technical",
  "Onboarding",
  "API",
  "Enterprise",
  "Security",
  "Compliance",
  "Sales",
  "Spanish",
  "French",
  "German",
];

const defaultFormData: AgentFormData = {
  name: "",
  email: "",
  role: "agent",
  team: "General",
  skills: [],
  maxConcurrent: 5,
  shiftStart: "09:00",
  shiftEnd: "17:00",
  active: true,
};

/* ------------------------------------------------------------------ */
/* Component                                                           */
/* ------------------------------------------------------------------ */

export function AgentForm({
  initialData,
  onSave,
  onCancel,
  loading = false,
  className,
}: AgentFormProps) {
  const [form, setForm] = useState<AgentFormData>({
    ...defaultFormData,
    ...initialData,
  });
  const [skillInput, setSkillInput] = useState("");

  const update = <K extends keyof AgentFormData>(
    key: K,
    value: AgentFormData[K],
  ) => setForm((prev) => ({ ...prev, [key]: value }));

  const addSkill = (skill: string) => {
    const trimmed = skill.trim();
    if (trimmed && !form.skills.includes(trimmed)) {
      update("skills", [...form.skills, trimmed]);
    }
    setSkillInput("");
  };

  const removeSkill = (skill: string) => {
    update(
      "skills",
      form.skills.filter((s) => s !== skill),
    );
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave?.(form);
  };

  const filteredSkills = availableSkills.filter(
    (s) =>
      !form.skills.includes(s) &&
      s.toLowerCase().includes(skillInput.toLowerCase()),
  );

  return (
    <Card className={className} padding="none">
      <CardBody>
        <form onSubmit={handleSubmit} className="flex flex-col gap-5">
          {/* Basic info */}
          <div className="grid gap-4 sm:grid-cols-2">
            <Input
              label="Full Name"
              value={form.name}
              onChange={(e) => update("name", e.target.value)}
              placeholder="Jane Smith"
              required
            />
            <Input
              label="Email"
              type="email"
              value={form.email}
              onChange={(e) => update("email", e.target.value)}
              placeholder="jane@company.com"
              required
            />
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            <Select
              label="Role"
              options={roleOptions}
              value={form.role}
              onChange={(e) => update("role", e.target.value)}
            />
            <Select
              label="Team"
              options={teamOptions}
              value={form.team}
              onChange={(e) => update("team", e.target.value)}
            />
          </div>

          {/* Skills multi-select */}
          <div className="flex flex-col gap-1">
            <label className="text-sm font-medium text-linkedin-gray-90">
              Skills
            </label>
            <div className="flex flex-wrap gap-1.5">
              {form.skills.map((skill) => (
                <Tag
                  key={skill}
                  variant="primary"
                  onRemove={() => removeSkill(skill)}
                >
                  {skill}
                </Tag>
              ))}
            </div>
            <div className="relative mt-1">
              <Input
                value={skillInput}
                onChange={(e) => setSkillInput(e.target.value)}
                placeholder="Add skills..."
                onKeyDown={(e) => {
                  if (e.key === "Enter") {
                    e.preventDefault();
                    addSkill(skillInput);
                  }
                }}
              />
              {skillInput && filteredSkills.length > 0 && (
                <div className="absolute z-10 mt-1 w-full rounded-lg border border-linkedin-gray-20 bg-linkedin-white shadow-card">
                  {filteredSkills.slice(0, 6).map((skill) => (
                    <button
                      key={skill}
                      type="button"
                      onClick={() => addSkill(skill)}
                      className="block w-full px-3 py-2 text-left text-sm text-linkedin-gray-90 hover:bg-linkedin-gray-10"
                    >
                      {skill}
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Concurrency */}
          <div className="grid gap-4 sm:grid-cols-2">
            <Input
              label="Max Concurrent Conversations"
              type="number"
              min={1}
              max={20}
              value={String(form.maxConcurrent)}
              onChange={(e) =>
                update("maxConcurrent", parseInt(e.target.value, 10) || 1)
              }
            />
          </div>

          {/* Schedule */}
          <div className="grid gap-4 sm:grid-cols-2">
            <Input
              label="Shift Start"
              type="time"
              value={form.shiftStart}
              onChange={(e) => update("shiftStart", e.target.value)}
            />
            <Input
              label="Shift End"
              type="time"
              value={form.shiftEnd}
              onChange={(e) => update("shiftEnd", e.target.value)}
            />
          </div>

          {/* Active toggle */}
          <Toggle
            checked={form.active}
            onChange={(v) => update("active", v)}
            label="Active"
          />

          {/* Actions */}
          <div className="flex items-center justify-end gap-2 border-t border-linkedin-gray-20 pt-4">
            {onCancel && (
              <Button variant="ghost" onClick={onCancel} type="button">
                Cancel
              </Button>
            )}
            <Button
              type="submit"
              loading={loading}
              iconLeft={<Save className="h-4 w-4" />}
            >
              Save Agent
            </Button>
          </div>
        </form>
      </CardBody>
    </Card>
  );
}
