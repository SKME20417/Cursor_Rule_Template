"use client";

import React, { useState } from "react";
import { cn } from "@/lib/utils/cn";
import {
  Plus,
  Pencil,
  Trash2,
  GripVertical,
  Play,
  ArrowRight,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import { Card, CardBody, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Modal } from "@/components/ui/modal";
import { ConfirmDialog } from "@/components/ui/confirm-dialog";
import { EmptyState } from "@/components/ui/empty-state";

/* ------------------------------------------------------------------ */
/* Types                                                               */
/* ------------------------------------------------------------------ */

interface RoutingRule {
  id: string;
  name: string;
  priority: number;
  conditionType: string;
  conditionValue: string;
  actionType: string;
  actionTarget: string;
  enabled: boolean;
}

interface RoutingRuleEditorProps {
  rules: RoutingRule[];
  onSave?: (rule: RoutingRule) => void;
  onDelete?: (ruleId: string) => void;
  onReorder?: (rules: RoutingRule[]) => void;
  onTest?: (rule: RoutingRule) => void;
  className?: string;
}

/* ------------------------------------------------------------------ */
/* Constants                                                           */
/* ------------------------------------------------------------------ */

const conditionTypes = [
  { value: "category", label: "Category" },
  { value: "priority", label: "Priority" },
  { value: "channel", label: "Channel" },
  { value: "language", label: "Language" },
];

const actionTypes = [
  { value: "assign_team", label: "Assign to Team" },
  { value: "assign_agent", label: "Assign to Agent" },
  { value: "round_robin", label: "Round Robin" },
];

/* ------------------------------------------------------------------ */
/* Component                                                           */
/* ------------------------------------------------------------------ */

export function RoutingRuleEditor({
  rules: initialRules,
  onSave,
  onDelete,
  onReorder,
  onTest,
  className,
}: RoutingRuleEditorProps) {
  const [rules, setRules] = useState(initialRules);
  const [editing, setEditing] = useState<RoutingRule | null>(null);
  const [creating, setCreating] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<RoutingRule | null>(null);
  const [dragIdx, setDragIdx] = useState<number | null>(null);

  const [formName, setFormName] = useState("");
  const [formCondType, setFormCondType] = useState("category");
  const [formCondVal, setFormCondVal] = useState("");
  const [formActType, setFormActType] = useState("assign_team");
  const [formActTarget, setFormActTarget] = useState("");

  const openCreate = () => {
    setFormName("");
    setFormCondType("category");
    setFormCondVal("");
    setFormActType("assign_team");
    setFormActTarget("");
    setCreating(true);
    setEditing(null);
  };

  const openEdit = (rule: RoutingRule) => {
    setFormName(rule.name);
    setFormCondType(rule.conditionType);
    setFormCondVal(rule.conditionValue);
    setFormActType(rule.actionType);
    setFormActTarget(rule.actionTarget);
    setEditing(rule);
    setCreating(false);
  };

  const handleSave = () => {
    const rule: RoutingRule = {
      id: editing?.id ?? crypto.randomUUID(),
      name: formName,
      priority: editing?.priority ?? rules.length + 1,
      conditionType: formCondType,
      conditionValue: formCondVal,
      actionType: formActType,
      actionTarget: formActTarget,
      enabled: editing?.enabled ?? true,
    };
    onSave?.(rule);
    setCreating(false);
    setEditing(null);
  };

  const handleDelete = () => {
    if (deleteTarget) {
      onDelete?.(deleteTarget.id);
      setRules((prev) => prev.filter((r) => r.id !== deleteTarget.id));
      setDeleteTarget(null);
    }
  };

  const moveRule = (fromIdx: number, toIdx: number) => {
    const reordered = [...rules];
    const [moved] = reordered.splice(fromIdx, 1);
    reordered.splice(toIdx, 0, moved);
    const updated = reordered.map((r, i) => ({ ...r, priority: i + 1 }));
    setRules(updated);
    onReorder?.(updated);
  };

  const isFormOpen = creating || editing !== null;

  return (
    <div className={cn("flex flex-col gap-4", className)}>
      <div className="flex items-center justify-end">
        <Button iconLeft={<Plus className="h-4 w-4" />} onClick={openCreate}>
          Add Rule
        </Button>
      </div>

      {rules.length === 0 ? (
        <EmptyState
          title="No routing rules"
          description="Create routing rules to automatically assign tickets."
          action={
            <Button
              iconLeft={<Plus className="h-4 w-4" />}
              onClick={openCreate}
            >
              Add Rule
            </Button>
          }
        />
      ) : (
        <div className="flex flex-col gap-2">
          {rules
            .sort((a, b) => a.priority - b.priority)
            .map((rule, idx) => (
              <Card key={rule.id} padding="none">
                <CardBody>
                  <div className="flex items-center gap-3">
                    <button
                      type="button"
                      className="cursor-grab text-linkedin-gray-50 hover:text-linkedin-gray-90"
                      draggable
                      onDragStart={() => setDragIdx(idx)}
                      onDragOver={(e) => e.preventDefault()}
                      onDrop={() => {
                        if (dragIdx !== null) moveRule(dragIdx, idx);
                        setDragIdx(null);
                      }}
                      aria-label="Drag to reorder"
                    >
                      <GripVertical className="h-4 w-4" />
                    </button>

                    <Badge variant="default">#{rule.priority}</Badge>

                    <div className="flex-1">
                      <p className="font-medium text-linkedin-gray-90">
                        {rule.name}
                      </p>
                      <p className="mt-0.5 flex items-center gap-1 text-xs text-linkedin-gray-50">
                        <span className="capitalize">{rule.conditionType}</span>
                        : {rule.conditionValue}
                        <ArrowRight className="h-3 w-3" />
                        <span className="capitalize">
                          {rule.actionType.replace("_", " ")}
                        </span>
                        : {rule.actionTarget}
                      </p>
                    </div>

                    <Badge
                      variant={rule.enabled ? "success" : "default"}
                    >
                      {rule.enabled ? "Active" : "Inactive"}
                    </Badge>

                    <div className="flex items-center gap-1">
                      {onTest && (
                        <Button
                          variant="ghost"
                          size="sm"
                          iconLeft={<Play className="h-3.5 w-3.5" />}
                          onClick={() => onTest(rule)}
                        >
                          Test
                        </Button>
                      )}
                      <Button
                        variant="ghost"
                        size="sm"
                        iconLeft={<Pencil className="h-3.5 w-3.5" />}
                        onClick={() => openEdit(rule)}
                      >
                        Edit
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        iconLeft={<Trash2 className="h-3.5 w-3.5" />}
                        onClick={() => setDeleteTarget(rule)}
                      >
                        Delete
                      </Button>
                    </div>
                  </div>
                </CardBody>
              </Card>
            ))}
        </div>
      )}

      {/* Create/Edit Modal */}
      <Modal
        open={isFormOpen}
        onClose={() => {
          setCreating(false);
          setEditing(null);
        }}
        title={editing ? "Edit Routing Rule" : "Create Routing Rule"}
        footer={
          <>
            <Button
              variant="ghost"
              onClick={() => {
                setCreating(false);
                setEditing(null);
              }}
            >
              Cancel
            </Button>
            <Button onClick={handleSave}>Save</Button>
          </>
        }
      >
        <div className="flex flex-col gap-4">
          <Input
            label="Rule Name"
            value={formName}
            onChange={(e) => setFormName(e.target.value)}
            placeholder="e.g. Route billing to Billing team"
          />
          <Select
            label="Condition Type"
            options={conditionTypes}
            value={formCondType}
            onChange={(e) => setFormCondType(e.target.value)}
          />
          <Input
            label="Condition Value"
            value={formCondVal}
            onChange={(e) => setFormCondVal(e.target.value)}
            placeholder="e.g. billing, high, email"
          />
          <Select
            label="Action Type"
            options={actionTypes}
            value={formActType}
            onChange={(e) => setFormActType(e.target.value)}
          />
          <Input
            label="Action Target"
            value={formActTarget}
            onChange={(e) => setFormActTarget(e.target.value)}
            placeholder="e.g. Billing Team"
          />
        </div>
      </Modal>

      <ConfirmDialog
        open={deleteTarget !== null}
        onClose={() => setDeleteTarget(null)}
        onConfirm={handleDelete}
        title="Delete Rule"
        message={`Are you sure you want to delete "${deleteTarget?.name}"?`}
        danger
        confirmLabel="Delete"
      />
    </div>
  );
}
