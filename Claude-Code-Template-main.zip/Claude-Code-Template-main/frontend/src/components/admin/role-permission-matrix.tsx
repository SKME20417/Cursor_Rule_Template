"use client";

import React, { useState } from "react";
import { cn } from "@/lib/utils/cn";
import { Save } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Select } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Card, CardBody, CardHeader, CardFooter } from "@/components/ui/card";

/* ------------------------------------------------------------------ */
/* Types                                                               */
/* ------------------------------------------------------------------ */

type Action = "view" | "create" | "edit" | "delete";

interface Permission {
  resource: string;
  actions: Record<Action, boolean>;
}

interface RolePermissionMatrixProps {
  roles: string[];
  permissions: Record<string, Permission[]>;
  onSave?: (role: string, permissions: Permission[]) => void;
  loading?: boolean;
  className?: string;
}

/* ------------------------------------------------------------------ */
/* Constants                                                           */
/* ------------------------------------------------------------------ */

const actions: Action[] = ["view", "create", "edit", "delete"];

const actionLabels: Record<Action, string> = {
  view: "View",
  create: "Create",
  edit: "Edit",
  delete: "Delete",
};

/* ------------------------------------------------------------------ */
/* Component                                                           */
/* ------------------------------------------------------------------ */

export function RolePermissionMatrix({
  roles,
  permissions,
  onSave,
  loading = false,
  className,
}: RolePermissionMatrixProps) {
  const [selectedRole, setSelectedRole] = useState(roles[0] ?? "");
  const [localPerms, setLocalPerms] = useState<Record<string, Permission[]>>(
    () => structuredClone(permissions),
  );

  const currentPerms = localPerms[selectedRole] ?? [];

  const toggle = (resourceIdx: number, action: Action) => {
    setLocalPerms((prev) => {
      const copy = structuredClone(prev);
      const perms = copy[selectedRole];
      if (perms && perms[resourceIdx]) {
        perms[resourceIdx].actions[action] = !perms[resourceIdx].actions[action];
      }
      return copy;
    });
  };

  const handleSave = () => {
    onSave?.(selectedRole, localPerms[selectedRole] ?? []);
  };

  const roleOptions = roles.map((r) => ({
    value: r,
    label: r.charAt(0).toUpperCase() + r.slice(1),
  }));

  return (
    <Card className={className} padding="none">
      <CardHeader>
        <div className="flex items-center justify-between">
          <h3 className="font-semibold text-linkedin-gray-90">
            Role Permissions
          </h3>
          <Select
            options={roleOptions}
            value={selectedRole}
            onChange={(e) => setSelectedRole(e.target.value)}
            className="w-48"
          />
        </div>
      </CardHeader>
      <CardBody className="p-0">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead>
              <tr className="border-b border-linkedin-gray-20 bg-linkedin-gray-10">
                <th className="px-4 py-3 font-semibold text-linkedin-gray-70">
                  Resource
                </th>
                {actions.map((action) => (
                  <th
                    key={action}
                    className="px-4 py-3 text-center font-semibold text-linkedin-gray-70"
                  >
                    {actionLabels[action]}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {currentPerms.map((perm, idx) => (
                <tr
                  key={perm.resource}
                  className="border-b border-linkedin-gray-20 hover:bg-linkedin-gray-10 transition-colors"
                >
                  <td className="px-4 py-3 font-medium text-linkedin-gray-90 capitalize">
                    {perm.resource}
                  </td>
                  {actions.map((action) => (
                    <td key={action} className="px-4 py-3 text-center">
                      <Checkbox
                        checked={perm.actions[action]}
                        onChange={() => toggle(idx, action)}
                        aria-label={`${perm.resource} ${action}`}
                      />
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </CardBody>
      <CardFooter>
        <div className="flex justify-end">
          <Button
            onClick={handleSave}
            loading={loading}
            iconLeft={<Save className="h-4 w-4" />}
          >
            Save Changes
          </Button>
        </div>
      </CardFooter>
    </Card>
  );
}
