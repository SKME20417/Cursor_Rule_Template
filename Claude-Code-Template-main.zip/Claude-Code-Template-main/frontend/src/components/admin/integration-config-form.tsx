"use client";

import React, { useState } from "react";
import { cn } from "@/lib/utils/cn";
import { Save, Zap, Eye, EyeOff } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import { Toggle } from "@/components/ui/toggle";
import { Card, CardBody, CardHeader, CardFooter } from "@/components/ui/card";

/* ------------------------------------------------------------------ */
/* Types                                                               */
/* ------------------------------------------------------------------ */

interface FieldMapping {
  source: string;
  target: string;
}

interface IntegrationConfigFormProps {
  name: string;
  initialApiKey?: string;
  initialApiSecret?: string;
  initialEndpoint?: string;
  initialSyncDirection?: string;
  initialFieldMappings?: FieldMapping[];
  initialEnabled?: boolean;
  onSave?: (config: {
    apiKey: string;
    apiSecret: string;
    endpoint: string;
    syncDirection: string;
    fieldMappings: FieldMapping[];
    enabled: boolean;
  }) => void;
  onTestConnection?: () => void;
  testLoading?: boolean;
  testResult?: "success" | "error" | null;
  loading?: boolean;
  className?: string;
}

/* ------------------------------------------------------------------ */
/* Constants                                                           */
/* ------------------------------------------------------------------ */

const syncOptions = [
  { value: "inbound", label: "Inbound Only" },
  { value: "outbound", label: "Outbound Only" },
  { value: "bidirectional", label: "Bidirectional" },
];

/* ------------------------------------------------------------------ */
/* Component                                                           */
/* ------------------------------------------------------------------ */

export function IntegrationConfigForm({
  name,
  initialApiKey = "",
  initialApiSecret = "",
  initialEndpoint = "",
  initialSyncDirection = "bidirectional",
  initialFieldMappings = [],
  initialEnabled = false,
  onSave,
  onTestConnection,
  testLoading = false,
  testResult = null,
  loading = false,
  className,
}: IntegrationConfigFormProps) {
  const [apiKey, setApiKey] = useState(initialApiKey);
  const [apiSecret, setApiSecret] = useState(initialApiSecret);
  const [endpoint, setEndpoint] = useState(initialEndpoint);
  const [syncDirection, setSyncDirection] = useState(initialSyncDirection);
  const [fieldMappings, setFieldMappings] =
    useState<FieldMapping[]>(initialFieldMappings);
  const [enabled, setEnabled] = useState(initialEnabled);
  const [showSecret, setShowSecret] = useState(false);
  const [showKey, setShowKey] = useState(false);

  const addMapping = () => {
    setFieldMappings((prev) => [...prev, { source: "", target: "" }]);
  };

  const updateMapping = (
    idx: number,
    field: keyof FieldMapping,
    value: string,
  ) => {
    setFieldMappings((prev) =>
      prev.map((m, i) => (i === idx ? { ...m, [field]: value } : m)),
    );
  };

  const removeMapping = (idx: number) => {
    setFieldMappings((prev) => prev.filter((_, i) => i !== idx));
  };

  const handleSave = () => {
    onSave?.({
      apiKey,
      apiSecret,
      endpoint,
      syncDirection,
      fieldMappings,
      enabled,
    });
  };

  return (
    <Card className={className} padding="none">
      <CardHeader>
        <h3 className="font-semibold text-linkedin-gray-90">
          {name} Configuration
        </h3>
      </CardHeader>
      <CardBody>
        <div className="flex flex-col gap-4">
          <div className="relative">
            <Input
              label="API Key"
              type={showKey ? "text" : "password"}
              value={apiKey}
              onChange={(e) => setApiKey(e.target.value)}
              placeholder="Enter API key..."
              iconRight={
                <button
                  type="button"
                  onClick={() => setShowKey(!showKey)}
                  className="pointer-events-auto cursor-pointer"
                >
                  {showKey ? (
                    <EyeOff className="h-4 w-4" />
                  ) : (
                    <Eye className="h-4 w-4" />
                  )}
                </button>
              }
            />
          </div>

          <div className="relative">
            <Input
              label="API Secret"
              type={showSecret ? "text" : "password"}
              value={apiSecret}
              onChange={(e) => setApiSecret(e.target.value)}
              placeholder="Enter API secret..."
              iconRight={
                <button
                  type="button"
                  onClick={() => setShowSecret(!showSecret)}
                  className="pointer-events-auto cursor-pointer"
                >
                  {showSecret ? (
                    <EyeOff className="h-4 w-4" />
                  ) : (
                    <Eye className="h-4 w-4" />
                  )}
                </button>
              }
            />
          </div>

          <Input
            label="Endpoint URL"
            type="url"
            value={endpoint}
            onChange={(e) => setEndpoint(e.target.value)}
            placeholder="https://api.example.com/v1"
          />

          <Select
            label="Sync Direction"
            options={syncOptions}
            value={syncDirection}
            onChange={(e) => setSyncDirection(e.target.value)}
          />

          {/* Field Mappings */}
          <div className="flex flex-col gap-2">
            <div className="flex items-center justify-between">
              <label className="text-sm font-medium text-linkedin-gray-90">
                Field Mappings
              </label>
              <Button variant="ghost" size="sm" onClick={addMapping}>
                + Add Mapping
              </Button>
            </div>
            {fieldMappings.length > 0 && (
              <div className="overflow-x-auto rounded-lg border border-linkedin-gray-20">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-linkedin-gray-20 bg-linkedin-gray-10">
                      <th className="px-3 py-2 text-left font-medium text-linkedin-gray-70">
                        Source Field
                      </th>
                      <th className="px-3 py-2 text-left font-medium text-linkedin-gray-70">
                        Target Field
                      </th>
                      <th className="w-10 px-3 py-2" />
                    </tr>
                  </thead>
                  <tbody>
                    {fieldMappings.map((m, idx) => (
                      <tr
                        key={idx}
                        className="border-b border-linkedin-gray-20"
                      >
                        <td className="px-3 py-2">
                          <input
                            value={m.source}
                            onChange={(e) =>
                              updateMapping(idx, "source", e.target.value)
                            }
                            className="w-full rounded border border-linkedin-gray-30 px-2 py-1 text-sm"
                            placeholder="source_field"
                          />
                        </td>
                        <td className="px-3 py-2">
                          <input
                            value={m.target}
                            onChange={(e) =>
                              updateMapping(idx, "target", e.target.value)
                            }
                            className="w-full rounded border border-linkedin-gray-30 px-2 py-1 text-sm"
                            placeholder="target_field"
                          />
                        </td>
                        <td className="px-3 py-2">
                          <button
                            type="button"
                            onClick={() => removeMapping(idx)}
                            className="text-linkedin-gray-50 hover:text-linkedin-red text-xs"
                          >
                            Remove
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>

          {/* Test Connection */}
          <div className="flex items-center gap-3">
            <Button
              variant="secondary"
              size="sm"
              iconLeft={<Zap className="h-3.5 w-3.5" />}
              onClick={onTestConnection}
              loading={testLoading}
            >
              Test Connection
            </Button>
            {testResult === "success" && (
              <span className="text-sm text-linkedin-green font-medium">
                Connection successful
              </span>
            )}
            {testResult === "error" && (
              <span className="text-sm text-linkedin-red font-medium">
                Connection failed
              </span>
            )}
          </div>

          <Toggle
            checked={enabled}
            onChange={setEnabled}
            label="Enable Integration"
          />
        </div>
      </CardBody>
      <CardFooter>
        <div className="flex justify-end">
          <Button
            onClick={handleSave}
            loading={loading}
            iconLeft={<Save className="h-4 w-4" />}
          >
            Save Configuration
          </Button>
        </div>
      </CardFooter>
    </Card>
  );
}
