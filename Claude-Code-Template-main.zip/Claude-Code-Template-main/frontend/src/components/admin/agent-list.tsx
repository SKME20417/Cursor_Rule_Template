"use client";

import React, { useState, useMemo } from "react";
import { cn } from "@/lib/utils/cn";
import {
  Search,
  UserPlus,
  ChevronUp,
  ChevronDown,
  MoreHorizontal,
  Star,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { SearchInput } from "@/components/ui/search-input";
import { Select } from "@/components/ui/select";
import { StatusDot } from "@/components/ui/status-dot";
import { Skeleton } from "@/components/ui/skeleton";
import { EmptyState } from "@/components/ui/empty-state";

/* ------------------------------------------------------------------ */
/* Types                                                               */
/* ------------------------------------------------------------------ */

interface Agent {
  id: string;
  name: string;
  email: string;
  avatarUrl?: string;
  role: "agent" | "supervisor" | "admin";
  team: string;
  status: "online" | "away" | "offline";
  activeTickets: number;
  csat: number;
}

interface AgentListProps {
  agents: Agent[];
  loading?: boolean;
  onInvite?: () => void;
  onRowClick?: (agent: Agent) => void;
  className?: string;
}

/* ------------------------------------------------------------------ */
/* Helpers                                                             */
/* ------------------------------------------------------------------ */

type SortKey = "name" | "role" | "team" | "status" | "activeTickets" | "csat";
type SortDir = "asc" | "desc";

const roleLabel: Record<string, string> = {
  agent: "Agent",
  supervisor: "Supervisor",
  admin: "Admin",
};

const roleBadgeVariant: Record<string, "default" | "primary" | "warning"> = {
  agent: "default",
  supervisor: "primary",
  admin: "warning",
};

const teams = [
  { value: "", label: "All Teams" },
  { value: "Billing", label: "Billing" },
  { value: "Technical", label: "Technical" },
  { value: "Sales", label: "Sales" },
  { value: "General", label: "General" },
];

const roles = [
  { value: "", label: "All Roles" },
  { value: "agent", label: "Agent" },
  { value: "supervisor", label: "Supervisor" },
  { value: "admin", label: "Admin" },
];

const statuses = [
  { value: "", label: "All Statuses" },
  { value: "online", label: "Online" },
  { value: "away", label: "Away" },
  { value: "offline", label: "Offline" },
];

/* ------------------------------------------------------------------ */
/* Component                                                           */
/* ------------------------------------------------------------------ */

export function AgentList({
  agents,
  loading = false,
  onInvite,
  onRowClick,
  className,
}: AgentListProps) {
  const [search, setSearch] = useState("");
  const [teamFilter, setTeamFilter] = useState("");
  const [roleFilter, setRoleFilter] = useState("");
  const [statusFilter, setStatusFilter] = useState("");
  const [sortKey, setSortKey] = useState<SortKey>("name");
  const [sortDir, setSortDir] = useState<SortDir>("asc");

  const handleSort = (key: SortKey) => {
    if (sortKey === key) {
      setSortDir((d) => (d === "asc" ? "desc" : "asc"));
    } else {
      setSortKey(key);
      setSortDir("asc");
    }
  };

  const filtered = useMemo(() => {
    let result = agents;

    if (search) {
      const q = search.toLowerCase();
      result = result.filter(
        (a) =>
          a.name.toLowerCase().includes(q) ||
          a.email.toLowerCase().includes(q),
      );
    }
    if (teamFilter) result = result.filter((a) => a.team === teamFilter);
    if (roleFilter) result = result.filter((a) => a.role === roleFilter);
    if (statusFilter) result = result.filter((a) => a.status === statusFilter);

    result = [...result].sort((a, b) => {
      const valA = a[sortKey];
      const valB = b[sortKey];
      if (typeof valA === "number" && typeof valB === "number") {
        return sortDir === "asc" ? valA - valB : valB - valA;
      }
      const strA = String(valA).toLowerCase();
      const strB = String(valB).toLowerCase();
      return sortDir === "asc"
        ? strA.localeCompare(strB)
        : strB.localeCompare(strA);
    });

    return result;
  }, [agents, search, teamFilter, roleFilter, statusFilter, sortKey, sortDir]);

  const SortIcon = ({ col }: { col: SortKey }) => {
    if (sortKey !== col) return null;
    return sortDir === "asc" ? (
      <ChevronUp className="h-3.5 w-3.5" />
    ) : (
      <ChevronDown className="h-3.5 w-3.5" />
    );
  };

  const ThSortable = ({
    col,
    children,
    className: thClass,
  }: {
    col: SortKey;
    children: React.ReactNode;
    className?: string;
  }) => (
    <th
      className={cn(
        "cursor-pointer select-none px-4 py-3 font-semibold text-linkedin-gray-70 whitespace-nowrap hover:text-linkedin-gray-90",
        thClass,
      )}
      onClick={() => handleSort(col)}
    >
      <span className="inline-flex items-center gap-1">
        {children}
        <SortIcon col={col} />
      </span>
    </th>
  );

  return (
    <div className={cn("flex flex-col gap-4", className)}>
      {/* Toolbar */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex flex-1 flex-col gap-2 sm:flex-row sm:items-center">
          <SearchInput
            value={search}
            onChange={setSearch}
            placeholder="Search agents..."
            className="sm:max-w-xs"
          />
          <Select
            options={teams}
            value={teamFilter}
            onChange={(e) => setTeamFilter(e.target.value)}
          />
          <Select
            options={roles}
            value={roleFilter}
            onChange={(e) => setRoleFilter(e.target.value)}
          />
          <Select
            options={statuses}
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
          />
        </div>
        {onInvite && (
          <Button
            iconLeft={<UserPlus className="h-4 w-4" />}
            onClick={onInvite}
          >
            Invite Agent
          </Button>
        )}
      </div>

      {/* Table */}
      <div className="overflow-x-auto rounded-lg border border-linkedin-gray-20 bg-linkedin-white">
        <table className="w-full text-left text-sm">
          <thead>
            <tr className="border-b border-linkedin-gray-20 bg-linkedin-gray-10">
              <ThSortable col="name">Agent</ThSortable>
              <ThSortable col="role">Role</ThSortable>
              <ThSortable col="team">Team</ThSortable>
              <ThSortable col="status">Status</ThSortable>
              <ThSortable col="activeTickets">Active Tickets</ThSortable>
              <ThSortable col="csat">CSAT</ThSortable>
              <th className="px-4 py-3 font-semibold text-linkedin-gray-70">
                Actions
              </th>
            </tr>
          </thead>
          <tbody>
            {loading
              ? Array.from({ length: 5 }).map((_, i) => (
                  <tr
                    key={`skel-${i}`}
                    className="border-b border-linkedin-gray-20"
                  >
                    {Array.from({ length: 7 }).map((_, j) => (
                      <td key={j} className="px-4 py-3">
                        <Skeleton shape="text" />
                      </td>
                    ))}
                  </tr>
                ))
              : filtered.length === 0
                ? (
                  <tr>
                    <td colSpan={7}>
                      <EmptyState
                        title="No agents found"
                        description="Try adjusting your filters or search query."
                      />
                    </td>
                  </tr>
                )
                : filtered.map((agent) => (
                    <tr
                      key={agent.id}
                      onClick={() => onRowClick?.(agent)}
                      className={cn(
                        "border-b border-linkedin-gray-20 transition-colors hover:bg-linkedin-gray-10",
                        onRowClick && "cursor-pointer",
                      )}
                    >
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-3">
                          <div className="relative">
                            {agent.avatarUrl ? (
                              <img
                                src={agent.avatarUrl}
                                alt={agent.name}
                                className="h-8 w-8 rounded-full object-cover"
                              />
                            ) : (
                              <div className="flex h-8 w-8 items-center justify-center rounded-full bg-linkedin-blue-bg text-sm font-semibold text-linkedin-blue">
                                {agent.name
                                  .split(" ")
                                  .map((n) => n[0])
                                  .join("")
                                  .slice(0, 2)}
                              </div>
                            )}
                          </div>
                          <div>
                            <p className="font-medium text-linkedin-gray-90">
                              {agent.name}
                            </p>
                            <p className="text-xs text-linkedin-gray-50">
                              {agent.email}
                            </p>
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        <Badge variant={roleBadgeVariant[agent.role]}>
                          {roleLabel[agent.role]}
                        </Badge>
                      </td>
                      <td className="px-4 py-3 text-linkedin-gray-90">
                        {agent.team}
                      </td>
                      <td className="px-4 py-3">
                        <span className="inline-flex items-center gap-1.5 capitalize">
                          <StatusDot
                            status={
                              agent.status === "offline"
                                ? "offline"
                                : agent.status === "away"
                                  ? "away"
                                  : "online"
                            }
                          />
                          {agent.status}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-linkedin-gray-90 tabular-nums">
                        {agent.activeTickets}
                      </td>
                      <td className="px-4 py-3">
                        <span className="inline-flex items-center gap-1 tabular-nums">
                          <Star className="h-3.5 w-3.5 text-linkedin-orange" />
                          {agent.csat.toFixed(1)}
                        </span>
                      </td>
                      <td className="px-4 py-3">
                        <button
                          type="button"
                          className="rounded-full p-1.5 text-linkedin-gray-50 hover:bg-linkedin-gray-10 transition-colors"
                          aria-label="Agent actions"
                          onClick={(e) => e.stopPropagation()}
                        >
                          <MoreHorizontal className="h-4 w-4" />
                        </button>
                      </td>
                    </tr>
                  ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
