"use client";

import React, { useState } from "react";
import { cn } from "@/lib/utils/cn";
import { Plus, Pencil, Trash2, Clock, AlertTriangle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import { Card, CardBody } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Modal } from "@/components/ui/modal";
import { ConfirmDialog } from "@/components/ui/confirm-dialog";
import { EmptyState } from "@/components/ui/empty-state";

/* ------------------------------------------------------------------ */
/* Types                                                               */
/* ------------------------------------------------------------------ */

interface SlaPolicy {
  id: string;
  name: string;
  firstResponseMinutes: number;
  resolutionMinutes: number;
  businessHoursOnly: boolean;
  appliedTo: string[];
  warningThresholdPct: number;
}

interface SlaPolicyEditorProps {
  policies: SlaPolicy[];
  onSave?: (policy: SlaPolicy) => void;
  onDelete?: (policyId: string) => void;
  className?: string;
}

/* ------------------------------------------------------------------ */
/* Helpers                                                             */
/* ------------------------------------------------------------------ */

function formatMinutes(m: number): string {
  if (m < 60) return `${m}m`;
  const h = Math.floor(m / 60);
  const rem = m % 60;
  return rem > 0 ? `${h}h ${rem}m` : `${h}h`;
}

const appliedToOptions = [
  { value: "billing", label: "Billing" },
  { value: "technical", label: "Technical" },
  { value: "enterprise", label: "Enterprise" },
  { value: "standard", label: "Standard" },
  { value: "premium", label: "Premium" },
  { value: "urgent", label: "Urgent" },
];

/* ------------------------------------------------------------------ */
/* Component                                                           */
/* ------------------------------------------------------------------ */

export function SlaPolicyEditor({
  policies,
  onSave,
  onDelete,
  className,
}: SlaPolicyEditorProps) {
  const [editing, setEditing] = useState<SlaPolicy | null>(null);
  const [creating, setCreating] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<SlaPolicy | null>(null);

  const [formName, setFormName] = useState("");
  const [formFirstResp, setFormFirstResp] = useState(15);
  const [formResolution, setFormResolution] = useState(240);
  const [formBizHours, setFormBizHours] = useState(true);
  const [formAppliedTo, setFormAppliedTo] = useState<string[]>([]);
  const [formWarning, setFormWarning] = useState(80);

  const openCreate = () => {
    setFormName("");
    setFormFirstResp(15);
    setFormResolution(240);
    setFormBizHours(true);
    setFormAppliedTo([]);
    setFormWarning(80);
    setCreating(true);
    setEditing(null);
  };

  const openEdit = (policy: SlaPolicy) => {
    setFormName(policy.name);
    setFormFirstResp(policy.firstResponseMinutes);
    setFormResolution(policy.resolutionMinutes);
    setFormBizHours(policy.businessHoursOnly);
    setFormAppliedTo(policy.appliedTo);
    setFormWarning(policy.warningThresholdPct);
    setEditing(policy);
    setCreating(false);
  };

  const handleSave = () => {
    const policy: SlaPolicy = {
      id: editing?.id ?? crypto.randomUUID(),
      name: formName,
      firstResponseMinutes: formFirstResp,
      resolutionMinutes: formResolution,
      businessHoursOnly: formBizHours,
      appliedTo: formAppliedTo,
      warningThresholdPct: formWarning,
    };
    onSave?.(policy);
    setCreating(false);
    setEditing(null);
  };

  const handleDelete = () => {
    if (deleteTarget) {
      onDelete?.(deleteTarget.id);
      setDeleteTarget(null);
    }
  };

  const toggleAppliedTo = (value: string) => {
    setFormAppliedTo((prev) =>
      prev.includes(value)
        ? prev.filter((v) => v !== value)
        : [...prev, value],
    );
  };

  const isFormOpen = creating || editing !== null;

  return (
    <div className={cn("flex flex-col gap-4", className)}>
      <div className="flex items-center justify-end">
        <Button iconLeft={<Plus className="h-4 w-4" />} onClick={openCreate}>
          Add SLA Policy
        </Button>
      </div>

      {policies.length === 0 ? (
        <EmptyState
          icon={<Clock className="h-7 w-7" />}
          title="No SLA policies"
          description="Create SLA policies to set response and resolution targets."
          action={
            <Button
              iconLeft={<Plus className="h-4 w-4" />}
              onClick={openCreate}
            >
              Add Policy
            </Button>
          }
        />
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {policies.map((policy) => (
            <Card key={policy.id} hover>
              <CardBody>
                <h3 className="font-semibold text-linkedin-gray-90">
                  {policy.name}
                </h3>

                <div className="mt-3 space-y-2 text-sm">
                  <div className="flex items-center justify-between">
                    <span className="text-linkedin-gray-50">
                      First Response
                    </span>
                    <span className="font-medium text-linkedin-gray-90">
                      {formatMinutes(policy.firstResponseMinutes)}
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-linkedin-gray-50">Resolution</span>
                    <span className="font-medium text-linkedin-gray-90">
                      {formatMinutes(policy.resolutionMinutes)}
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-linkedin-gray-50">
                      Business Hours
                    </span>
                    <Badge
                      variant={policy.businessHoursOnly ? "primary" : "default"}
                    >
                      {policy.businessHoursOnly ? "Yes" : "No"}
                    </Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="inline-flex items-center gap-1 text-linkedin-gray-50">
                      <AlertTriangle className="h-3 w-3" />
                      Warning
                    </span>
                    <span className="font-medium text-linkedin-gray-90">
                      {policy.warningThresholdPct}%
                    </span>
                  </div>
                </div>

                <div className="mt-3 flex flex-wrap gap-1">
                  {policy.appliedTo.map((t) => (
                    <Badge key={t} variant="info" size="sm">
                      {t}
                    </Badge>
                  ))}
                </div>

                <div className="mt-3 flex items-center gap-2 border-t border-linkedin-gray-20 pt-3">
                  <Button
                    variant="ghost"
                    size="sm"
                    iconLeft={<Pencil className="h-3.5 w-3.5" />}
                    onClick={() => openEdit(policy)}
                  >
                    Edit
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    iconLeft={<Trash2 className="h-3.5 w-3.5" />}
                    onClick={() => setDeleteTarget(policy)}
                  >
                    Delete
                  </Button>
                </div>
              </CardBody>
            </Card>
          ))}
        </div>
      )}

      <Modal
        open={isFormOpen}
        onClose={() => {
          setCreating(false);
          setEditing(null);
        }}
        title={editing ? "Edit SLA Policy" : "Create SLA Policy"}
        footer={
          <>
            <Button
              variant="ghost"
              onClick={() => {
                setCreating(false);
                setEditing(null);
              }}
            >
              Cancel
            </Button>
            <Button onClick={handleSave}>Save</Button>
          </>
        }
      >
        <div className="flex flex-col gap-4">
          <Input
            label="Policy Name"
            value={formName}
            onChange={(e) => setFormName(e.target.value)}
            placeholder="e.g. Enterprise SLA"
          />
          <div className="grid gap-4 sm:grid-cols-2">
            <Input
              label="First Response (minutes)"
              type="number"
              min={1}
              value={String(formFirstResp)}
              onChange={(e) =>
                setFormFirstResp(parseInt(e.target.value, 10) || 1)
              }
            />
            <Input
              label="Resolution Target (minutes)"
              type="number"
              min={1}
              value={String(formResolution)}
              onChange={(e) =>
                setFormResolution(parseInt(e.target.value, 10) || 1)
              }
            />
          </div>
          <label className="flex items-center gap-2 text-sm">
            <input
              type="checkbox"
              checked={formBizHours}
              onChange={(e) => setFormBizHours(e.target.checked)}
              className="accent-linkedin-blue"
            />
            Business hours only
          </label>
          <Input
            label="Warning Threshold (%)"
            type="number"
            min={1}
            max={100}
            value={String(formWarning)}
            onChange={(e) =>
              setFormWarning(parseInt(e.target.value, 10) || 80)
            }
          />
          <div className="flex flex-col gap-1">
            <label className="text-sm font-medium text-linkedin-gray-90">
              Applied To
            </label>
            <div className="flex flex-wrap gap-2">
              {appliedToOptions.map((opt) => (
                <label
                  key={opt.value}
                  className="flex cursor-pointer items-center gap-1.5 text-sm"
                >
                  <input
                    type="checkbox"
                    checked={formAppliedTo.includes(opt.value)}
                    onChange={() => toggleAppliedTo(opt.value)}
                    className="accent-linkedin-blue"
                  />
                  {opt.label}
                </label>
              ))}
            </div>
          </div>
        </div>
      </Modal>

      <ConfirmDialog
        open={deleteTarget !== null}
        onClose={() => setDeleteTarget(null)}
        onConfirm={handleDelete}
        title="Delete SLA Policy"
        message={`Are you sure you want to delete "${deleteTarget?.name}"?`}
        danger
        confirmLabel="Delete"
      />
    </div>
  );
}
