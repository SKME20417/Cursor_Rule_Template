"use client";

import React, { useState } from "react";
import { cn } from "@/lib/utils/cn";
import { Plus, Pencil, Trash2, Bell, Zap } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import { Toggle } from "@/components/ui/toggle";
import { Card, CardBody } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Modal } from "@/components/ui/modal";
import { ConfirmDialog } from "@/components/ui/confirm-dialog";
import { EmptyState } from "@/components/ui/empty-state";
import { DataTable, type DataTableColumn } from "@/components/ui/data-table";

/* ------------------------------------------------------------------ */
/* Types                                                               */
/* ------------------------------------------------------------------ */

interface AlertRule {
  id: string;
  name: string;
  metric: string;
  condition: "above" | "below";
  threshold: number;
  channels: string[];
  enabled: boolean;
}

interface AlertRuleEditorProps {
  rules: AlertRule[];
  onSave?: (rule: AlertRule) => void;
  onDelete?: (ruleId: string) => void;
  onToggle?: (ruleId: string, enabled: boolean) => void;
  onTest?: (ruleId: string) => void;
  className?: string;
}

/* ------------------------------------------------------------------ */
/* Constants                                                           */
/* ------------------------------------------------------------------ */

const metricOptions = [
  { value: "response_time", label: "Response Time (ms)" },
  { value: "error_rate", label: "Error Rate (%)" },
  { value: "queue_depth", label: "Queue Depth" },
  { value: "cpu_usage", label: "CPU Usage (%)" },
  { value: "memory_usage", label: "Memory Usage (%)" },
  { value: "ticket_volume", label: "Ticket Volume" },
  { value: "sla_breach_rate", label: "SLA Breach Rate (%)" },
];

const conditionOptions = [
  { value: "above", label: "Above" },
  { value: "below", label: "Below" },
];

const channelsList = ["email", "slack", "pagerduty", "webhook", "sms"];

/* ------------------------------------------------------------------ */
/* Component                                                           */
/* ------------------------------------------------------------------ */

export function AlertRuleEditor({
  rules,
  onSave,
  onDelete,
  onToggle,
  onTest,
  className,
}: AlertRuleEditorProps) {
  const [editing, setEditing] = useState<AlertRule | null>(null);
  const [creating, setCreating] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<AlertRule | null>(null);

  const [formName, setFormName] = useState("");
  const [formMetric, setFormMetric] = useState("response_time");
  const [formCondition, setFormCondition] = useState<"above" | "below">("above");
  const [formThreshold, setFormThreshold] = useState(1000);
  const [formChannels, setFormChannels] = useState<string[]>([]);

  const openCreate = () => {
    setFormName("");
    setFormMetric("response_time");
    setFormCondition("above");
    setFormThreshold(1000);
    setFormChannels([]);
    setCreating(true);
    setEditing(null);
  };

  const openEdit = (rule: AlertRule) => {
    setFormName(rule.name);
    setFormMetric(rule.metric);
    setFormCondition(rule.condition);
    setFormThreshold(rule.threshold);
    setFormChannels(rule.channels);
    setEditing(rule);
    setCreating(false);
  };

  const handleSave = () => {
    const rule: AlertRule = {
      id: editing?.id ?? crypto.randomUUID(),
      name: formName,
      metric: formMetric,
      condition: formCondition,
      threshold: formThreshold,
      channels: formChannels,
      enabled: editing?.enabled ?? true,
    };
    onSave?.(rule);
    setCreating(false);
    setEditing(null);
  };

  const handleDelete = () => {
    if (deleteTarget) {
      onDelete?.(deleteTarget.id);
      setDeleteTarget(null);
    }
  };

  const toggleChannel = (ch: string) => {
    setFormChannels((prev) =>
      prev.includes(ch) ? prev.filter((c) => c !== ch) : [...prev, ch],
    );
  };

  const isFormOpen = creating || editing !== null;

  const columns: DataTableColumn<AlertRule>[] = [
    { key: "name", header: "Name", sortable: true },
    {
      key: "condition",
      header: "Condition",
      render: (row) => (
        <span className="text-sm">
          {metricOptions.find((m) => m.value === row.metric)?.label ?? row.metric}{" "}
          <span className="font-medium">{row.condition}</span> {row.threshold}
        </span>
      ),
    },
    {
      key: "channels",
      header: "Channels",
      render: (row) => (
        <div className="flex flex-wrap gap-1">
          {row.channels.map((ch) => (
            <Badge key={ch} variant="primary" size="sm">
              {ch}
            </Badge>
          ))}
        </div>
      ),
    },
    {
      key: "enabled",
      header: "Status",
      render: (row) => (
        <Toggle
          checked={row.enabled}
          onChange={(v) => onToggle?.(row.id, v)}
        />
      ),
    },
    {
      key: "actions",
      header: "Actions",
      render: (row) => (
        <div className="flex items-center gap-1">
          {onTest && (
            <Button
              variant="ghost"
              size="sm"
              iconLeft={<Zap className="h-3.5 w-3.5" />}
              onClick={() => onTest(row.id)}
            >
              Test
            </Button>
          )}
          <Button
            variant="ghost"
            size="sm"
            iconLeft={<Pencil className="h-3.5 w-3.5" />}
            onClick={() => openEdit(row)}
          >
            Edit
          </Button>
          <Button
            variant="ghost"
            size="sm"
            iconLeft={<Trash2 className="h-3.5 w-3.5" />}
            onClick={() => setDeleteTarget(row)}
          >
            Delete
          </Button>
        </div>
      ),
    },
  ];

  return (
    <div className={cn("flex flex-col gap-4", className)}>
      <div className="flex items-center justify-end">
        <Button iconLeft={<Plus className="h-4 w-4" />} onClick={openCreate}>
          Add Alert Rule
        </Button>
      </div>

      {rules.length === 0 ? (
        <EmptyState
          icon={<Bell className="h-7 w-7" />}
          title="No alert rules"
          description="Create alert rules to get notified about system issues."
          action={
            <Button iconLeft={<Plus className="h-4 w-4" />} onClick={openCreate}>
              Add Alert Rule
            </Button>
          }
        />
      ) : (
        <DataTable
          columns={columns}
          data={rules}
          rowKey={(row) => row.id}
        />
      )}

      <Modal
        open={isFormOpen}
        onClose={() => {
          setCreating(false);
          setEditing(null);
        }}
        title={editing ? "Edit Alert Rule" : "Create Alert Rule"}
        footer={
          <>
            <Button
              variant="ghost"
              onClick={() => {
                setCreating(false);
                setEditing(null);
              }}
            >
              Cancel
            </Button>
            <Button onClick={handleSave}>Save</Button>
          </>
        }
      >
        <div className="flex flex-col gap-4">
          <Input
            label="Rule Name"
            value={formName}
            onChange={(e) => setFormName(e.target.value)}
            placeholder="e.g. High Response Time"
          />
          <Select
            label="Metric"
            options={metricOptions}
            value={formMetric}
            onChange={(e) => setFormMetric(e.target.value)}
          />
          <div className="grid grid-cols-2 gap-4">
            <Select
              label="Condition"
              options={conditionOptions}
              value={formCondition}
              onChange={(e) =>
                setFormCondition(e.target.value as "above" | "below")
              }
            />
            <Input
              label="Threshold"
              type="number"
              value={String(formThreshold)}
              onChange={(e) =>
                setFormThreshold(parseInt(e.target.value, 10) || 0)
              }
            />
          </div>
          <div className="flex flex-col gap-1">
            <label className="text-sm font-medium text-linkedin-gray-90">
              Notification Channels
            </label>
            <div className="flex flex-wrap gap-2">
              {channelsList.map((ch) => (
                <label
                  key={ch}
                  className="flex cursor-pointer items-center gap-1.5 text-sm capitalize"
                >
                  <input
                    type="checkbox"
                    checked={formChannels.includes(ch)}
                    onChange={() => toggleChannel(ch)}
                    className="accent-linkedin-blue"
                  />
                  {ch}
                </label>
              ))}
            </div>
          </div>
        </div>
      </Modal>

      <ConfirmDialog
        open={deleteTarget !== null}
        onClose={() => setDeleteTarget(null)}
        onConfirm={handleDelete}
        title="Delete Alert Rule"
        message={`Are you sure you want to delete "${deleteTarget?.name}"?`}
        danger
        confirmLabel="Delete"
      />
    </div>
  );
}
