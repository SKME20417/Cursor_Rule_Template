"use client";

import React from "react";
import { cn } from "@/lib/utils/cn";

export interface ToggleProps {
  checked?: boolean;
  onChange?: (checked: boolean) => void;
  disabled?: boolean;
  label?: string;
  className?: string;
  id?: string;
}

const Toggle = React.forwardRef<HTMLButtonElement, ToggleProps>(
  ({ checked = false, onChange, disabled = false, label, className, id }, ref) => {
    const toggleId = id || label?.toLowerCase().replace(/\s+/g, "-");

    return (
      <label
        htmlFor={toggleId}
        className={cn(
          "inline-flex cursor-pointer items-center gap-2 select-none",
          disabled && "cursor-not-allowed opacity-50",
          className,
        )}
      >
        <button
          ref={ref}
          id={toggleId}
          type="button"
          role="switch"
          aria-checked={checked}
          disabled={disabled}
          onClick={() => onChange?.(!checked)}
          className={cn(
            "relative inline-flex h-6 w-11 shrink-0 items-center rounded-full transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-linkedin-blue focus-visible:ring-offset-2",
            checked ? "bg-linkedin-blue" : "bg-linkedin-gray-30",
          )}
        >
          <span
            className={cn(
              "pointer-events-none block h-4 w-4 rounded-full bg-linkedin-white shadow-sm transition-transform",
              checked ? "translate-x-6" : "translate-x-1",
            )}
          />
        </button>
        {label && (
          <span className="text-sm text-linkedin-gray-90">{label}</span>
        )}
      </label>
    );
  },
);

Toggle.displayName = "Toggle";

export { Toggle };
