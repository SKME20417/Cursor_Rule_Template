import React from "react";
import { cn } from "@/lib/utils/cn";
import { AlertCircle } from "lucide-react";
import { Button } from "./button";

export interface ErrorStateProps {
  icon?: React.ReactNode;
  message?: string;
  onRetry?: () => void;
  retryLabel?: string;
  className?: string;
}

function ErrorState({
  icon,
  message = "Something went wrong. Please try again.",
  onRetry,
  retryLabel = "Retry",
  className,
}: ErrorStateProps) {
  return (
    <div
      role="alert"
      className={cn(
        "flex flex-col items-center justify-center gap-3 py-12 text-center",
        className,
      )}
    >
      <div className="flex h-14 w-14 items-center justify-center rounded-full bg-red-50 text-linkedin-red">
        {icon || <AlertCircle className="h-7 w-7" />}
      </div>
      <p className="max-w-sm text-sm text-linkedin-gray-70">{message}</p>
      {onRetry && (
        <Button variant="secondary" size="sm" onClick={onRetry}>
          {retryLabel}
        </Button>
      )}
    </div>
  );
}

ErrorState.displayName = "ErrorState";

export { ErrorState };
