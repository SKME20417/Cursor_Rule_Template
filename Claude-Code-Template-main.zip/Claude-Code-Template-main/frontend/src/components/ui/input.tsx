"use client";

import React from "react";
import { cn } from "@/lib/utils/cn";
import { Search } from "lucide-react";

export interface InputProps
  extends Omit<React.InputHTMLAttributes<HTMLInputElement>, "size"> {
  label?: string;
  error?: string;
  helperText?: string;
  iconLeft?: React.ReactNode;
  iconRight?: React.ReactNode;
  variant?: "default" | "search";
}

const Input = React.forwardRef<HTMLInputElement, InputProps>(
  (
    {
      label,
      error,
      helperText,
      iconLeft,
      iconRight,
      variant = "default",
      className,
      id,
      ...props
    },
    ref,
  ) => {
    const inputId = id || label?.toLowerCase().replace(/\s+/g, "-");
    const isSearch = variant === "search";
    const leftIcon = isSearch ? <Search className="h-4 w-4" /> : iconLeft;

    return (
      <div className="flex flex-col gap-1">
        {label && (
          <label
            htmlFor={inputId}
            className="text-sm font-medium text-linkedin-gray-90"
          >
            {label}
          </label>
        )}
        <div className="relative">
          {leftIcon && (
            <span className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-linkedin-gray-50">
              {leftIcon}
            </span>
          )}
          <input
            ref={ref}
            id={inputId}
            aria-invalid={!!error}
            aria-describedby={
              error
                ? `${inputId}-error`
                : helperText
                  ? `${inputId}-helper`
                  : undefined
            }
            className={cn(
              "w-full rounded-lg border bg-linkedin-white px-3 py-2 text-sm text-linkedin-gray-90 placeholder:text-linkedin-gray-50 transition-colors",
              "focus:border-linkedin-blue focus:outline-none focus:ring-1 focus:ring-linkedin-blue",
              error
                ? "border-linkedin-red"
                : "border-linkedin-gray-30",
              leftIcon && "pl-9",
              iconRight && "pr-9",
              className,
            )}
            {...props}
          />
          {iconRight && (
            <span className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-linkedin-gray-50">
              {iconRight}
            </span>
          )}
        </div>
        {error && (
          <p
            id={`${inputId}-error`}
            className="text-xs text-linkedin-red"
            role="alert"
          >
            {error}
          </p>
        )}
        {!error && helperText && (
          <p
            id={`${inputId}-helper`}
            className="text-xs text-linkedin-gray-50"
          >
            {helperText}
          </p>
        )}
      </div>
    );
  },
);

Input.displayName = "Input";

export { Input };
