"use client";

import React, { useState, useEffect, useRef, useCallback } from "react";
import { cn } from "@/lib/utils/cn";
import { Search, X, Loader2 } from "lucide-react";

export interface SearchInputProps
  extends Omit<React.InputHTMLAttributes<HTMLInputElement>, "onChange"> {
  value?: string;
  onChange?: (value: string) => void;
  debounceMs?: number;
  loading?: boolean;
}

const SearchInput = React.forwardRef<HTMLInputElement, SearchInputProps>(
  (
    {
      value: controlledValue,
      onChange,
      debounceMs = 300,
      loading = false,
      className,
      placeholder = "Search...",
      ...props
    },
    ref,
  ) => {
    const [internalValue, setInternalValue] = useState(controlledValue ?? "");
    const timerRef = useRef<ReturnType<typeof setTimeout>>();

    // Sync controlled value
    useEffect(() => {
      if (controlledValue !== undefined) setInternalValue(controlledValue);
    }, [controlledValue]);

    const handleChange = useCallback(
      (e: React.ChangeEvent<HTMLInputElement>) => {
        const val = e.target.value;
        setInternalValue(val);
        if (timerRef.current) clearTimeout(timerRef.current);
        timerRef.current = setTimeout(() => onChange?.(val), debounceMs);
      },
      [onChange, debounceMs],
    );

    const clear = () => {
      setInternalValue("");
      onChange?.("");
    };

    // Cleanup on unmount
    useEffect(() => () => {
      if (timerRef.current) clearTimeout(timerRef.current);
    }, []);

    return (
      <div className="relative">
        <Search
          className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-linkedin-gray-50"
          aria-hidden="true"
        />
        <input
          ref={ref}
          type="search"
          value={internalValue}
          onChange={handleChange}
          placeholder={placeholder}
          className={cn(
            "w-full rounded-lg border border-linkedin-gray-30 bg-linkedin-white py-2 pl-9 pr-9 text-sm text-linkedin-gray-90 placeholder:text-linkedin-gray-50 transition-colors",
            "focus:border-linkedin-blue focus:outline-none focus:ring-1 focus:ring-linkedin-blue",
            className,
          )}
          {...props}
        />
        <span className="absolute right-3 top-1/2 -translate-y-1/2">
          {loading ? (
            <Loader2 className="h-4 w-4 animate-spin text-linkedin-gray-50" aria-hidden="true" />
          ) : internalValue ? (
            <button
              type="button"
              onClick={clear}
              className="text-linkedin-gray-50 hover:text-linkedin-gray-90 transition-colors"
              aria-label="Clear search"
            >
              <X className="h-4 w-4" />
            </button>
          ) : null}
        </span>
      </div>
    );
  },
);

SearchInput.displayName = "SearchInput";

export { SearchInput };
