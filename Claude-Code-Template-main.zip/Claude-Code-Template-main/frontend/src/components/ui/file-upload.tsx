"use client";

import React, { useState, useRef, useCallback } from "react";
import { cn } from "@/lib/utils/cn";
import { Upload, X, FileText } from "lucide-react";
import { ProgressBar } from "./progress-bar";

export interface FileUploadProps {
  accept?: string;
  maxSizeMB?: number;
  multiple?: boolean;
  onFiles?: (files: File[]) => void;
  progress?: number;
  error?: string;
  disabled?: boolean;
  className?: string;
}

function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

function FileUpload({
  accept,
  maxSizeMB = 10,
  multiple = false,
  onFiles,
  progress,
  error: externalError,
  disabled = false,
  className,
}: FileUploadProps) {
  const [dragging, setDragging] = useState(false);
  const [files, setFiles] = useState<File[]>([]);
  const [error, setError] = useState<string | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const validate = useCallback(
    (fileList: File[]): File[] => {
      const maxBytes = maxSizeMB * 1024 * 1024;
      const acceptedTypes = accept
        ? accept.split(",").map((t) => t.trim().toLowerCase())
        : null;

      const valid: File[] = [];
      for (const f of fileList) {
        if (f.size > maxBytes) {
          setError(`${f.name} exceeds ${maxSizeMB}MB limit`);
          continue;
        }
        if (acceptedTypes) {
          const ext = `.${f.name.split(".").pop()?.toLowerCase()}`;
          const mimeMatch = acceptedTypes.some(
            (t) => t === f.type || t === ext || (t.endsWith("/*") && f.type.startsWith(t.replace("/*", "/"))),
          );
          if (!mimeMatch) {
            setError(`${f.name} is not an accepted file type`);
            continue;
          }
        }
        valid.push(f);
      }
      return valid;
    },
    [accept, maxSizeMB],
  );

  const handleFiles = useCallback(
    (fileList: FileList | null) => {
      if (!fileList) return;
      setError(null);
      const arr = Array.from(fileList);
      const valid = validate(arr);
      if (valid.length === 0) return;
      setFiles(multiple ? (prev) => [...prev, ...valid] : valid);
      onFiles?.(valid);
    },
    [validate, multiple, onFiles],
  );

  const removeFile = (index: number) => {
    setFiles((prev) => prev.filter((_, i) => i !== index));
  };

  const displayError = externalError || error;

  return (
    <div className={cn("flex flex-col gap-2", className)}>
      <div
        role="button"
        tabIndex={0}
        onClick={() => !disabled && inputRef.current?.click()}
        onKeyDown={(e) => {
          if (e.key === "Enter" || e.key === " ") {
            e.preventDefault();
            inputRef.current?.click();
          }
        }}
        onDragOver={(e) => {
          e.preventDefault();
          if (!disabled) setDragging(true);
        }}
        onDragLeave={() => setDragging(false)}
        onDrop={(e) => {
          e.preventDefault();
          setDragging(false);
          if (!disabled) handleFiles(e.dataTransfer.files);
        }}
        className={cn(
          "flex flex-col items-center justify-center gap-2 rounded-lg border-2 border-dashed p-6 text-center transition-colors cursor-pointer",
          dragging
            ? "border-linkedin-blue bg-linkedin-blue-bg"
            : "border-linkedin-gray-30 hover:border-linkedin-blue hover:bg-linkedin-gray-10",
          disabled && "cursor-not-allowed opacity-50",
        )}
      >
        <Upload className="h-8 w-8 text-linkedin-gray-50" aria-hidden="true" />
        <p className="text-sm text-linkedin-gray-70">
          <span className="font-medium text-linkedin-blue">Click to upload</span> or drag
          and drop
        </p>
        <p className="text-xs text-linkedin-gray-50">
          {accept ? `Accepted: ${accept}` : "Any file type"} &middot; Max {maxSizeMB}MB
        </p>
      </div>

      <input
        ref={inputRef}
        type="file"
        accept={accept}
        multiple={multiple}
        className="sr-only"
        onChange={(e) => handleFiles(e.target.files)}
        disabled={disabled}
      />

      {displayError && (
        <p className="text-xs text-linkedin-red" role="alert">
          {displayError}
        </p>
      )}

      {progress !== undefined && progress > 0 && progress < 100 && (
        <ProgressBar value={progress} showLabel />
      )}

      {files.length > 0 && (
        <ul className="flex flex-col gap-1">
          {files.map((f, idx) => (
            <li
              key={`${f.name}-${idx}`}
              className="flex items-center gap-2 rounded-md border border-linkedin-gray-20 px-3 py-2 text-sm"
            >
              <FileText className="h-4 w-4 shrink-0 text-linkedin-gray-50" aria-hidden="true" />
              <span className="flex-1 truncate text-linkedin-gray-90">{f.name}</span>
              <span className="text-xs text-linkedin-gray-50">{formatBytes(f.size)}</span>
              <button
                type="button"
                onClick={() => removeFile(idx)}
                className="rounded-full p-0.5 text-linkedin-gray-50 hover:bg-linkedin-gray-10 transition-colors"
                aria-label={`Remove ${f.name}`}
              >
                <X className="h-3.5 w-3.5" />
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

FileUpload.displayName = "FileUpload";

export { FileUpload };
