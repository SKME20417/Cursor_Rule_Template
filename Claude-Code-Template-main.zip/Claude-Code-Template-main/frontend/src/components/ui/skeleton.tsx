import React from "react";
import { cn } from "@/lib/utils/cn";

export interface SkeletonProps extends React.HTMLAttributes<HTMLDivElement> {
  shape?: "text" | "circle" | "rect" | "card";
  width?: string | number;
  height?: string | number;
}

const shapeStyles: Record<string, string> = {
  text: "h-4 w-full rounded",
  circle: "h-10 w-10 rounded-full",
  rect: "h-24 w-full rounded-lg",
  card: "h-40 w-full rounded-lg",
};

function Skeleton({ shape = "text", width, height, className, style, ...props }: SkeletonProps) {
  return (
    <div
      aria-hidden="true"
      className={cn(
        "animate-pulse bg-linkedin-gray-20",
        shapeStyles[shape],
        className,
      )}
      style={{
        ...(width !== undefined ? { width: typeof width === "number" ? `${width}px` : width } : {}),
        ...(height !== undefined ? { height: typeof height === "number" ? `${height}px` : height } : {}),
        ...style,
      }}
      {...props}
    />
  );
}

Skeleton.displayName = "Skeleton";

export { Skeleton };
