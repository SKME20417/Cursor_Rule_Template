"use client";

import React from "react";
import { cn } from "@/lib/utils/cn";

export interface TabItem {
  key: string;
  label: React.ReactNode;
  icon?: React.ReactNode;
  disabled?: boolean;
}

export interface TabsProps {
  items: TabItem[];
  activeKey: string;
  onChange: (key: string) => void;
  className?: string;
}

function Tabs({ items, activeKey, onChange, className }: TabsProps) {
  return (
    <div
      role="tablist"
      className={cn(
        "flex border-b border-linkedin-gray-20",
        className,
      )}
    >
      {items.map((tab) => {
        const isActive = tab.key === activeKey;
        return (
          <button
            key={tab.key}
            type="button"
            role="tab"
            aria-selected={isActive}
            disabled={tab.disabled}
            onClick={() => onChange(tab.key)}
            className={cn(
              "relative flex items-center gap-1.5 px-4 py-2.5 text-sm font-medium transition-colors whitespace-nowrap",
              isActive
                ? "text-linkedin-blue"
                : "text-linkedin-gray-50 hover:text-linkedin-gray-90",
              tab.disabled && "cursor-not-allowed opacity-50",
            )}
          >
            {tab.icon}
            {tab.label}
            {isActive && (
              <span className="absolute inset-x-0 -bottom-px h-0.5 bg-linkedin-blue rounded-full" />
            )}
          </button>
        );
      })}
    </div>
  );
}

Tabs.displayName = "Tabs";

export { Tabs };
