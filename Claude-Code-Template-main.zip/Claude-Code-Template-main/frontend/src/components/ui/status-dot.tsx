import React from "react";
import { cn } from "@/lib/utils/cn";

export interface StatusDotProps extends React.HTMLAttributes<HTMLSpanElement> {
  status: "online" | "offline" | "away" | "busy";
  size?: "sm" | "md" | "lg";
}

const statusColors: Record<string, string> = {
  online: "bg-linkedin-green",
  offline: "bg-linkedin-gray-50",
  away: "bg-linkedin-orange",
  busy: "bg-linkedin-red",
};

const sizeStyles: Record<string, string> = {
  sm: "h-2 w-2",
  md: "h-2.5 w-2.5",
  lg: "h-3 w-3",
};

const StatusDot = React.forwardRef<HTMLSpanElement, StatusDotProps>(
  ({ status, size = "md", className, ...props }, ref) => (
    <span
      ref={ref}
      role="status"
      aria-label={status}
      className={cn(
        "inline-block shrink-0 rounded-full",
        statusColors[status],
        sizeStyles[size],
        className,
      )}
      {...props}
    />
  ),
);

StatusDot.displayName = "StatusDot";

export { StatusDot };
