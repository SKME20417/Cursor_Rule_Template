"use client";

import React, { useState, useCallback } from "react";
import { cn } from "@/lib/utils/cn";
import { ChevronUp, ChevronDown } from "lucide-react";
import { Skeleton } from "./skeleton";
import { Checkbox } from "./checkbox";

/* ------------------------------------------------------------------ */
/* Types                                                               */
/* ------------------------------------------------------------------ */

export interface DataTableColumn<T> {
  key: string;
  header: string;
  sortable?: boolean;
  width?: string;
  render?: (row: T, index: number) => React.ReactNode;
}

export interface DataTableProps<T> {
  columns: DataTableColumn<T>[];
  data: T[];
  rowKey: (row: T) => string;
  loading?: boolean;
  loadingRows?: number;
  selectable?: boolean;
  selectedKeys?: Set<string>;
  onSelectionChange?: (keys: Set<string>) => void;
  sortColumn?: string;
  sortDirection?: "asc" | "desc";
  onSort?: (column: string, direction: "asc" | "desc") => void;
  emptyMessage?: string;
  className?: string;
}

/* ------------------------------------------------------------------ */
/* Component                                                           */
/* ------------------------------------------------------------------ */

function DataTable<T>({
  columns,
  data,
  rowKey,
  loading = false,
  loadingRows = 5,
  selectable = false,
  selectedKeys,
  onSelectionChange,
  sortColumn,
  sortDirection,
  onSort,
  emptyMessage = "No data available",
  className,
}: DataTableProps<T>) {
  const allKeys = data.map(rowKey);
  const allSelected = allKeys.length > 0 && selectedKeys?.size === allKeys.length;

  const toggleAll = useCallback(() => {
    if (!onSelectionChange) return;
    onSelectionChange(allSelected ? new Set() : new Set(allKeys));
  }, [allKeys, allSelected, onSelectionChange]);

  const toggleRow = useCallback(
    (key: string) => {
      if (!onSelectionChange || !selectedKeys) return;
      const next = new Set(selectedKeys);
      if (next.has(key)) next.delete(key);
      else next.add(key);
      onSelectionChange(next);
    },
    [selectedKeys, onSelectionChange],
  );

  const handleSort = (col: DataTableColumn<T>) => {
    if (!col.sortable || !onSort) return;
    const dir =
      sortColumn === col.key && sortDirection === "asc" ? "desc" : "asc";
    onSort(col.key, dir);
  };

  return (
    <div
      className={cn(
        "overflow-x-auto rounded-lg border border-linkedin-gray-20 bg-linkedin-white",
        className,
      )}
    >
      <table className="w-full text-left text-sm">
        <thead>
          <tr className="border-b border-linkedin-gray-20 bg-linkedin-gray-10">
            {selectable && (
              <th className="w-10 px-3 py-3">
                <Checkbox
                  checked={allSelected}
                  onChange={toggleAll}
                  aria-label="Select all rows"
                />
              </th>
            )}
            {columns.map((col) => (
              <th
                key={col.key}
                className={cn(
                  "px-4 py-3 font-semibold text-linkedin-gray-70 whitespace-nowrap",
                  col.sortable && "cursor-pointer select-none hover:text-linkedin-gray-90",
                )}
                style={col.width ? { width: col.width } : undefined}
                onClick={() => handleSort(col)}
                aria-sort={
                  sortColumn === col.key
                    ? sortDirection === "asc"
                      ? "ascending"
                      : "descending"
                    : undefined
                }
              >
                <span className="inline-flex items-center gap-1">
                  {col.header}
                  {col.sortable && sortColumn === col.key && (
                    sortDirection === "asc" ? (
                      <ChevronUp className="h-3.5 w-3.5" />
                    ) : (
                      <ChevronDown className="h-3.5 w-3.5" />
                    )
                  )}
                </span>
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {loading
            ? Array.from({ length: loadingRows }).map((_, i) => (
                <tr key={`skeleton-${i}`} className="border-b border-linkedin-gray-20">
                  {selectable && (
                    <td className="px-3 py-3">
                      <Skeleton shape="rect" width={16} height={16} />
                    </td>
                  )}
                  {columns.map((col) => (
                    <td key={col.key} className="px-4 py-3">
                      <Skeleton shape="text" />
                    </td>
                  ))}
                </tr>
              ))
            : data.length === 0
              ? (
                <tr>
                  <td
                    colSpan={columns.length + (selectable ? 1 : 0)}
                    className="px-4 py-8 text-center text-sm text-linkedin-gray-50"
                  >
                    {emptyMessage}
                  </td>
                </tr>
              )
              : data.map((row, idx) => {
                  const key = rowKey(row);
                  const isSelected = selectedKeys?.has(key) ?? false;
                  return (
                    <tr
                      key={key}
                      className={cn(
                        "border-b border-linkedin-gray-20 transition-colors hover:bg-linkedin-gray-10",
                        isSelected && "bg-linkedin-blue-bg",
                      )}
                    >
                      {selectable && (
                        <td className="px-3 py-3">
                          <Checkbox
                            checked={isSelected}
                            onChange={() => toggleRow(key)}
                            aria-label={`Select row ${idx + 1}`}
                          />
                        </td>
                      )}
                      {columns.map((col) => (
                        <td key={col.key} className="px-4 py-3 text-linkedin-gray-90">
                          {col.render
                            ? col.render(row, idx)
                            : (row as Record<string, unknown>)[col.key] as React.ReactNode}
                        </td>
                      ))}
                    </tr>
                  );
                })}
        </tbody>
      </table>
    </div>
  );
}

DataTable.displayName = "DataTable";

export { DataTable };
