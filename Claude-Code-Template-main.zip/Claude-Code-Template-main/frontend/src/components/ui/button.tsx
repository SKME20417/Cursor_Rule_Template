"use client";

import React from "react";
import { cn } from "@/lib/utils/cn";
import { Loader2 } from "lucide-react";

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: "primary" | "secondary" | "ghost" | "danger";
  size?: "sm" | "md" | "lg";
  loading?: boolean;
  iconLeft?: React.ReactNode;
  iconRight?: React.ReactNode;
}

const variantStyles: Record<string, string> = {
  primary:
    "bg-linkedin-blue text-linkedin-white hover:bg-linkedin-blue-hover focus-visible:ring-linkedin-blue",
  secondary:
    "border border-linkedin-blue text-linkedin-blue bg-transparent hover:bg-linkedin-blue-bg focus-visible:ring-linkedin-blue",
  ghost:
    "bg-transparent text-linkedin-gray-70 hover:bg-linkedin-gray-10 focus-visible:ring-linkedin-gray-30",
  danger:
    "bg-linkedin-red text-linkedin-white hover:bg-red-700 focus-visible:ring-linkedin-red",
};

const sizeStyles: Record<string, string> = {
  sm: "px-3 py-1 text-xs gap-1",
  md: "px-4 py-2 text-sm gap-1.5",
  lg: "px-6 py-3 text-base gap-2",
};

const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  (
    {
      variant = "primary",
      size = "md",
      loading = false,
      disabled,
      iconLeft,
      iconRight,
      className,
      children,
      ...props
    },
    ref,
  ) => {
    const isDisabled = disabled || loading;

    return (
      <button
        ref={ref}
        disabled={isDisabled}
        aria-busy={loading}
        className={cn(
          "inline-flex items-center justify-center rounded-full font-semibold transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2",
          variantStyles[variant],
          sizeStyles[size],
          isDisabled && "cursor-not-allowed opacity-50",
          className,
        )}
        {...props}
      >
        {loading ? (
          <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />
        ) : (
          iconLeft
        )}
        {children}
        {!loading && iconRight}
      </button>
    );
  },
);

Button.displayName = "Button";

export { Button };
