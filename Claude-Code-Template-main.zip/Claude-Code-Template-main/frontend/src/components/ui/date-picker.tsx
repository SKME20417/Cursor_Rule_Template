"use client";

import React from "react";
import { cn } from "@/lib/utils/cn";
import { Calendar } from "lucide-react";

export interface DatePickerProps
  extends Omit<React.InputHTMLAttributes<HTMLInputElement>, "type"> {
  label?: string;
  error?: string;
}

const DatePicker = React.forwardRef<HTMLInputElement, DatePickerProps>(
  ({ label, error, className, id, ...props }, ref) => {
    const inputId = id || label?.toLowerCase().replace(/\s+/g, "-");

    return (
      <div className="flex flex-col gap-1">
        {label && (
          <label
            htmlFor={inputId}
            className="text-sm font-medium text-linkedin-gray-90"
          >
            {label}
          </label>
        )}
        <div className="relative">
          <Calendar
            className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-linkedin-gray-50"
            aria-hidden="true"
          />
          <input
            ref={ref}
            id={inputId}
            type="date"
            aria-invalid={!!error}
            aria-describedby={error ? `${inputId}-error` : undefined}
            className={cn(
              "w-full rounded-lg border bg-linkedin-white py-2 pl-9 pr-3 text-sm text-linkedin-gray-90 transition-colors",
              "focus:border-linkedin-blue focus:outline-none focus:ring-1 focus:ring-linkedin-blue",
              error ? "border-linkedin-red" : "border-linkedin-gray-30",
              className,
            )}
            {...props}
          />
        </div>
        {error && (
          <p
            id={`${inputId}-error`}
            className="text-xs text-linkedin-red"
            role="alert"
          >
            {error}
          </p>
        )}
      </div>
    );
  },
);

DatePicker.displayName = "DatePicker";

export { DatePicker };
