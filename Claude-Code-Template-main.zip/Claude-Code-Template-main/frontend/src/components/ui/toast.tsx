"use client";

import React, { useEffect, useState, useCallback } from "react";
import { cn } from "@/lib/utils/cn";
import { X, CheckCircle, AlertCircle, AlertTriangle, Info } from "lucide-react";

export interface ToastProps {
  variant?: "success" | "error" | "warning" | "info";
  message: string;
  description?: string;
  duration?: number;
  onClose?: () => void;
  className?: string;
}

const variantConfig: Record<
  string,
  { icon: React.ElementType; bg: string; border: string; iconColor: string }
> = {
  success: {
    icon: CheckCircle,
    bg: "bg-green-50",
    border: "border-linkedin-green",
    iconColor: "text-linkedin-green",
  },
  error: {
    icon: AlertCircle,
    bg: "bg-red-50",
    border: "border-linkedin-red",
    iconColor: "text-linkedin-red",
  },
  warning: {
    icon: AlertTriangle,
    bg: "bg-orange-50",
    border: "border-linkedin-orange",
    iconColor: "text-linkedin-orange",
  },
  info: {
    icon: Info,
    bg: "bg-blue-50",
    border: "border-linkedin-blue",
    iconColor: "text-linkedin-blue",
  },
};

function Toast({
  variant = "info",
  message,
  description,
  duration = 5000,
  onClose,
  className,
}: ToastProps) {
  const [visible, setVisible] = useState(true);
  const config = variantConfig[variant];
  const Icon = config.icon;

  const dismiss = useCallback(() => {
    setVisible(false);
    onClose?.();
  }, [onClose]);

  useEffect(() => {
    if (duration <= 0) return;
    const timer = setTimeout(dismiss, duration);
    return () => clearTimeout(timer);
  }, [duration, dismiss]);

  if (!visible) return null;

  return (
    <div
      role="alert"
      aria-live="assertive"
      className={cn(
        "flex items-start gap-3 rounded-lg border-l-4 p-4 shadow-card animate-in slide-in-from-right duration-300",
        config.bg,
        config.border,
        className,
      )}
    >
      <Icon className={cn("mt-0.5 h-5 w-5 shrink-0", config.iconColor)} aria-hidden="true" />
      <div className="flex-1">
        <p className="text-sm font-medium text-linkedin-gray-90">{message}</p>
        {description && (
          <p className="mt-1 text-xs text-linkedin-gray-70">{description}</p>
        )}
      </div>
      <button
        type="button"
        onClick={dismiss}
        className="rounded-full p-0.5 text-linkedin-gray-50 hover:bg-linkedin-gray-10 transition-colors"
        aria-label="Close notification"
      >
        <X className="h-4 w-4" />
      </button>
    </div>
  );
}

Toast.displayName = "Toast";

export { Toast };
