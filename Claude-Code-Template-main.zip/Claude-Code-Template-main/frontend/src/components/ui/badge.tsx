import React from "react";
import { cn } from "@/lib/utils/cn";

export interface BadgeProps extends React.HTMLAttributes<HTMLSpanElement> {
  variant?: "default" | "primary" | "success" | "warning" | "danger" | "info";
  size?: "sm" | "md";
}

const variantStyles: Record<string, string> = {
  default: "bg-linkedin-gray-20 text-linkedin-gray-70",
  primary: "bg-linkedin-blue-bg text-linkedin-blue",
  success: "bg-green-50 text-linkedin-green",
  warning: "bg-orange-50 text-linkedin-orange",
  danger: "bg-red-50 text-linkedin-red",
  info: "bg-linkedin-blue-light text-linkedin-blue",
};

const sizeStyles: Record<string, string> = {
  sm: "px-1.5 py-0.5 text-xs",
  md: "px-2 py-0.5 text-sm",
};

const Badge = React.forwardRef<HTMLSpanElement, BadgeProps>(
  ({ variant = "default", size = "sm", className, children, ...props }, ref) => (
    <span
      ref={ref}
      className={cn(
        "inline-flex items-center rounded-full font-medium whitespace-nowrap",
        variantStyles[variant],
        sizeStyles[size],
        className,
      )}
      {...props}
    >
      {children}
    </span>
  ),
);

Badge.displayName = "Badge";

export { Badge };
