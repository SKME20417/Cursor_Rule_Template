"use client";

import React, { useState } from "react";
import { cn } from "@/lib/utils/cn";

export interface AvatarProps extends React.HTMLAttributes<HTMLDivElement> {
  src?: string;
  alt?: string;
  name?: string;
  size?: "xs" | "sm" | "md" | "lg" | "xl";
  online?: boolean;
}

const sizeMap: Record<string, { container: string; text: string; dot: string }> = {
  xs: { container: "h-6 w-6", text: "text-[10px]", dot: "h-2 w-2 border" },
  sm: { container: "h-8 w-8", text: "text-xs", dot: "h-2.5 w-2.5 border" },
  md: { container: "h-10 w-10", text: "text-sm", dot: "h-3 w-3 border-2" },
  lg: { container: "h-14 w-14", text: "text-lg", dot: "h-3.5 w-3.5 border-2" },
  xl: { container: "h-[72px] w-[72px]", text: "text-xl", dot: "h-4 w-4 border-2" },
};

function getInitials(name?: string): string {
  if (!name) return "?";
  const parts = name.trim().split(/\s+/);
  if (parts.length === 1) return parts[0][0].toUpperCase();
  return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
}

const Avatar = React.forwardRef<HTMLDivElement, AvatarProps>(
  ({ src, alt, name, size = "md", online, className, ...props }, ref) => {
    const [imgError, setImgError] = useState(false);
    const s = sizeMap[size];

    return (
      <div
        ref={ref}
        className={cn("relative inline-flex shrink-0", s.container, className)}
        {...props}
      >
        {src && !imgError ? (
          <img
            src={src}
            alt={alt || name || "Avatar"}
            onError={() => setImgError(true)}
            className={cn("rounded-full object-cover", s.container)}
          />
        ) : (
          <span
            className={cn(
              "flex items-center justify-center rounded-full bg-linkedin-blue-bg text-linkedin-blue font-semibold",
              s.container,
              s.text,
            )}
            aria-label={name || "Avatar"}
          >
            {getInitials(name)}
          </span>
        )}
        {online !== undefined && (
          <span
            className={cn(
              "absolute bottom-0 right-0 rounded-full border-linkedin-white",
              s.dot,
              online ? "bg-linkedin-green" : "bg-linkedin-gray-50",
            )}
            aria-label={online ? "Online" : "Offline"}
          />
        )}
      </div>
    );
  },
);

Avatar.displayName = "Avatar";

export { Avatar };
