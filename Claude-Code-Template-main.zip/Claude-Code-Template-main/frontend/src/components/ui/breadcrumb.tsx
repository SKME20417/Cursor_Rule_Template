import React from "react";
import { cn } from "@/lib/utils/cn";
import { ChevronRight } from "lucide-react";

export interface BreadcrumbItem {
  label: string;
  href?: string;
  onClick?: () => void;
}

export interface BreadcrumbProps {
  items: BreadcrumbItem[];
  separator?: React.ReactNode;
  className?: string;
}

function Breadcrumb({ items, separator, className }: BreadcrumbProps) {
  const sep = separator ?? (
    <ChevronRight className="h-4 w-4 text-linkedin-gray-50" aria-hidden="true" />
  );

  return (
    <nav aria-label="Breadcrumb" className={className}>
      <ol className="flex items-center gap-1.5">
        {items.map((item, idx) => {
          const isLast = idx === items.length - 1;

          return (
            <li key={idx} className="flex items-center gap-1.5">
              {item.href || item.onClick ? (
                <a
                  href={item.href || "#"}
                  onClick={(e) => {
                    if (item.onClick) {
                      e.preventDefault();
                      item.onClick();
                    }
                  }}
                  className={cn(
                    "text-sm transition-colors",
                    isLast
                      ? "font-medium text-linkedin-gray-90 pointer-events-none"
                      : "text-linkedin-blue hover:underline",
                  )}
                  aria-current={isLast ? "page" : undefined}
                >
                  {item.label}
                </a>
              ) : (
                <span
                  className={cn(
                    "text-sm",
                    isLast
                      ? "font-medium text-linkedin-gray-90"
                      : "text-linkedin-gray-50",
                  )}
                  aria-current={isLast ? "page" : undefined}
                >
                  {item.label}
                </span>
              )}
              {!isLast && sep}
            </li>
          );
        })}
      </ol>
    </nav>
  );
}

Breadcrumb.displayName = "Breadcrumb";

export { Breadcrumb };
