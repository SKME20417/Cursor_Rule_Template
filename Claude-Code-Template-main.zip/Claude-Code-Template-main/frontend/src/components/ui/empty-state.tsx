import React from "react";
import { cn } from "@/lib/utils/cn";
import { Inbox } from "lucide-react";

export interface EmptyStateProps {
  icon?: React.ReactNode;
  title: string;
  description?: string;
  action?: React.ReactNode;
  className?: string;
}

function EmptyState({
  icon,
  title,
  description,
  action,
  className,
}: EmptyStateProps) {
  return (
    <div
      className={cn(
        "flex flex-col items-center justify-center gap-3 py-12 text-center",
        className,
      )}
    >
      <div className="flex h-14 w-14 items-center justify-center rounded-full bg-linkedin-gray-10 text-linkedin-gray-50">
        {icon || <Inbox className="h-7 w-7" />}
      </div>
      <h3 className="text-base font-semibold text-linkedin-gray-90">{title}</h3>
      {description && (
        <p className="max-w-sm text-sm text-linkedin-gray-50">{description}</p>
      )}
      {action && <div className="mt-2">{action}</div>}
    </div>
  );
}

EmptyState.displayName = "EmptyState";

export { EmptyState };
