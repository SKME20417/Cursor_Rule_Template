"use client";

import React from "react";
import { cn } from "@/lib/utils/cn";
import { Check } from "lucide-react";

export interface CheckboxProps
  extends Omit<React.InputHTMLAttributes<HTMLInputElement>, "type"> {
  label?: string;
}

const Checkbox = React.forwardRef<HTMLInputElement, CheckboxProps>(
  ({ label, className, id, checked, ...props }, ref) => {
    const checkboxId = id || label?.toLowerCase().replace(/\s+/g, "-");

    return (
      <label
        htmlFor={checkboxId}
        className={cn(
          "inline-flex cursor-pointer items-center gap-2 select-none",
          props.disabled && "cursor-not-allowed opacity-50",
          className,
        )}
      >
        <span className="relative flex h-5 w-5 items-center justify-center">
          <input
            ref={ref}
            id={checkboxId}
            type="checkbox"
            checked={checked}
            className="peer sr-only"
            {...props}
          />
          <span
            className={cn(
              "flex h-5 w-5 items-center justify-center rounded border transition-colors",
              "peer-focus-visible:ring-2 peer-focus-visible:ring-linkedin-blue peer-focus-visible:ring-offset-2",
              checked
                ? "border-linkedin-blue bg-linkedin-blue"
                : "border-linkedin-gray-30 bg-linkedin-white",
            )}
          >
            {checked && (
              <Check className="h-3.5 w-3.5 text-linkedin-white" aria-hidden="true" />
            )}
          </span>
        </span>
        {label && (
          <span className="text-sm text-linkedin-gray-90">{label}</span>
        )}
      </label>
    );
  },
);

Checkbox.displayName = "Checkbox";

export { Checkbox };
