"use client";

import React, { useCallback, useEffect, useRef } from "react";
import { cn } from "@/lib/utils/cn";

export interface TextareaProps
  extends React.TextareaHTMLAttributes<HTMLTextAreaElement> {
  label?: string;
  error?: string;
  maxCharacters?: number;
  autoResize?: boolean;
}

const Textarea = React.forwardRef<HTMLTextAreaElement, TextareaProps>(
  (
    {
      label,
      error,
      maxCharacters,
      autoResize = false,
      className,
      id,
      value,
      onChange,
      ...props
    },
    ref,
  ) => {
    const textareaId = id || label?.toLowerCase().replace(/\s+/g, "-");
    const internalRef = useRef<HTMLTextAreaElement | null>(null);

    const setRefs = useCallback(
      (node: HTMLTextAreaElement | null) => {
        internalRef.current = node;
        if (typeof ref === "function") ref(node);
        else if (ref) (ref as React.MutableRefObject<HTMLTextAreaElement | null>).current = node;
      },
      [ref],
    );

    const adjustHeight = useCallback(() => {
      const el = internalRef.current;
      if (!el || !autoResize) return;
      el.style.height = "auto";
      el.style.height = `${el.scrollHeight}px`;
    }, [autoResize]);

    useEffect(() => {
      adjustHeight();
    }, [value, adjustHeight]);

    const charCount =
      typeof value === "string" ? value.length : 0;

    return (
      <div className="flex flex-col gap-1">
        {label && (
          <label
            htmlFor={textareaId}
            className="text-sm font-medium text-linkedin-gray-90"
          >
            {label}
          </label>
        )}
        <textarea
          ref={setRefs}
          id={textareaId}
          value={value}
          onChange={(e) => {
            onChange?.(e);
            adjustHeight();
          }}
          aria-invalid={!!error}
          aria-describedby={error ? `${textareaId}-error` : undefined}
          className={cn(
            "w-full rounded-lg border bg-linkedin-white px-3 py-2 text-sm text-linkedin-gray-90 placeholder:text-linkedin-gray-50 transition-colors resize-vertical",
            "focus:border-linkedin-blue focus:outline-none focus:ring-1 focus:ring-linkedin-blue",
            error ? "border-linkedin-red" : "border-linkedin-gray-30",
            autoResize && "resize-none overflow-hidden",
            className,
          )}
          {...props}
        />
        <div className="flex items-center justify-between">
          {error ? (
            <p
              id={`${textareaId}-error`}
              className="text-xs text-linkedin-red"
              role="alert"
            >
              {error}
            </p>
          ) : (
            <span />
          )}
          {maxCharacters !== undefined && (
            <span
              className={cn(
                "text-xs",
                charCount > maxCharacters
                  ? "text-linkedin-red"
                  : "text-linkedin-gray-50",
              )}
            >
              {charCount}/{maxCharacters}
            </span>
          )}
        </div>
      </div>
    );
  },
);

Textarea.displayName = "Textarea";

export { Textarea };
