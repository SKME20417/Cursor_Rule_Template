import React from "react";
import { cn } from "@/lib/utils/cn";
import { X } from "lucide-react";

export interface TagProps extends React.HTMLAttributes<HTMLSpanElement> {
  variant?: "default" | "primary" | "success" | "warning" | "danger";
  onRemove?: () => void;
}

const variantStyles: Record<string, string> = {
  default: "bg-linkedin-gray-20 text-linkedin-gray-70",
  primary: "bg-linkedin-blue-bg text-linkedin-blue",
  success: "bg-green-50 text-linkedin-green",
  warning: "bg-orange-50 text-linkedin-orange",
  danger: "bg-red-50 text-linkedin-red",
};

const Tag = React.forwardRef<HTMLSpanElement, TagProps>(
  ({ variant = "default", onRemove, className, children, ...props }, ref) => (
    <span
      ref={ref}
      className={cn(
        "inline-flex items-center gap-1 rounded-full px-2.5 py-0.5 text-xs font-medium",
        variantStyles[variant],
        className,
      )}
      {...props}
    >
      {children}
      {onRemove && (
        <button
          type="button"
          onClick={onRemove}
          className="ml-0.5 rounded-full p-0.5 transition-colors hover:bg-black/10"
          aria-label="Remove"
        >
          <X className="h-3 w-3" />
        </button>
      )}
    </span>
  ),
);

Tag.displayName = "Tag";

export { Tag };
