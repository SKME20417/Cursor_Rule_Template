import React from "react";
import { cn } from "@/lib/utils/cn";

export interface SpinnerProps extends React.HTMLAttributes<HTMLDivElement> {
  size?: "sm" | "md" | "lg";
  color?: "primary" | "white";
}

const sizeStyles: Record<string, string> = {
  sm: "h-4 w-4 border-2",
  md: "h-6 w-6 border-2",
  lg: "h-10 w-10 border-[3px]",
};

const colorStyles: Record<string, string> = {
  primary: "border-linkedin-gray-20 border-t-linkedin-blue",
  white: "border-white/30 border-t-white",
};

function Spinner({ size = "md", color = "primary", className, ...props }: SpinnerProps) {
  return (
    <div
      role="status"
      aria-label="Loading"
      className={cn(
        "inline-block animate-spin rounded-full",
        sizeStyles[size],
        colorStyles[color],
        className,
      )}
      {...props}
    >
      <span className="sr-only">Loading...</span>
    </div>
  );
}

Spinner.displayName = "Spinner";

export { Spinner };
