"use client";

import React from "react";
import { cn } from "@/lib/utils/cn";

export interface TimeRangePreset {
  key: string;
  label: string;
}

export interface TimeRangePickerProps {
  presets?: TimeRangePreset[];
  activeKey: string;
  onChange: (key: string) => void;
  customStartDate?: string;
  customEndDate?: string;
  onCustomStartChange?: (date: string) => void;
  onCustomEndChange?: (date: string) => void;
  className?: string;
}

const defaultPresets: TimeRangePreset[] = [
  { key: "today", label: "Today" },
  { key: "7d", label: "7d" },
  { key: "30d", label: "30d" },
  { key: "90d", label: "90d" },
  { key: "custom", label: "Custom" },
];

function TimeRangePicker({
  presets = defaultPresets,
  activeKey,
  onChange,
  customStartDate,
  customEndDate,
  onCustomStartChange,
  onCustomEndChange,
  className,
}: TimeRangePickerProps) {
  const isCustom = activeKey === "custom";

  return (
    <div className={cn("flex flex-wrap items-center gap-2", className)}>
      <div className="inline-flex rounded-lg border border-linkedin-gray-30 bg-linkedin-white p-0.5">
        {presets.map((preset) => (
          <button
            key={preset.key}
            type="button"
            onClick={() => onChange(preset.key)}
            className={cn(
              "rounded-md px-3 py-1.5 text-xs font-medium transition-colors",
              activeKey === preset.key
                ? "bg-linkedin-blue text-linkedin-white"
                : "text-linkedin-gray-70 hover:bg-linkedin-gray-10",
            )}
          >
            {preset.label}
          </button>
        ))}
      </div>

      {isCustom && (
        <div className="flex items-center gap-1.5">
          <input
            type="date"
            value={customStartDate ?? ""}
            onChange={(e) => onCustomStartChange?.(e.target.value)}
            className="rounded-md border border-linkedin-gray-30 bg-linkedin-white px-2 py-1.5 text-xs text-linkedin-gray-90 focus:border-linkedin-blue focus:outline-none focus:ring-1 focus:ring-linkedin-blue"
            aria-label="Start date"
          />
          <span className="text-xs text-linkedin-gray-50">to</span>
          <input
            type="date"
            value={customEndDate ?? ""}
            onChange={(e) => onCustomEndChange?.(e.target.value)}
            className="rounded-md border border-linkedin-gray-30 bg-linkedin-white px-2 py-1.5 text-xs text-linkedin-gray-90 focus:border-linkedin-blue focus:outline-none focus:ring-1 focus:ring-linkedin-blue"
            aria-label="End date"
          />
        </div>
      )}
    </div>
  );
}

TimeRangePicker.displayName = "TimeRangePicker";

export { TimeRangePicker };
