import React from "react";
import { cn } from "@/lib/utils/cn";

export interface ProgressBarProps extends React.HTMLAttributes<HTMLDivElement> {
  value: number;
  max?: number;
  showLabel?: boolean;
}

function getBarColor(pct: number): string {
  if (pct >= 75) return "bg-linkedin-green";
  if (pct >= 50) return "bg-linkedin-orange";
  return "bg-linkedin-red";
}

function ProgressBar({
  value,
  max = 100,
  showLabel = false,
  className,
  ...props
}: ProgressBarProps) {
  const pct = Math.min(100, Math.max(0, (value / max) * 100));

  return (
    <div className={cn("flex items-center gap-2", className)} {...props}>
      <div
        role="progressbar"
        aria-valuenow={value}
        aria-valuemin={0}
        aria-valuemax={max}
        className="h-2 flex-1 overflow-hidden rounded-full bg-linkedin-gray-20"
      >
        <div
          className={cn(
            "h-full rounded-full transition-all duration-300",
            getBarColor(pct),
          )}
          style={{ width: `${pct}%` }}
        />
      </div>
      {showLabel && (
        <span className="text-xs font-medium text-linkedin-gray-70 tabular-nums">
          {Math.round(pct)}%
        </span>
      )}
    </div>
  );
}

ProgressBar.displayName = "ProgressBar";

export { ProgressBar };
