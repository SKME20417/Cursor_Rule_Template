import React from "react";
import { cn } from "@/lib/utils/cn";

export interface DividerProps extends React.HTMLAttributes<HTMLDivElement> {
  label?: string;
}

const Divider = React.forwardRef<HTMLDivElement, DividerProps>(
  ({ label, className, ...props }, ref) => {
    if (label) {
      return (
        <div
          ref={ref}
          className={cn("flex items-center gap-3", className)}
          role="separator"
          {...props}
        >
          <span className="h-px flex-1 bg-linkedin-gray-20" />
          <span className="text-xs font-medium text-linkedin-gray-50">{label}</span>
          <span className="h-px flex-1 bg-linkedin-gray-20" />
        </div>
      );
    }

    return (
      <div
        ref={ref}
        className={cn("h-px w-full bg-linkedin-gray-20", className)}
        role="separator"
        {...props}
      />
    );
  },
);

Divider.displayName = "Divider";

export { Divider };
