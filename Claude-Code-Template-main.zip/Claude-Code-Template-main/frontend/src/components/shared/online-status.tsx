"use client";

import { useState, useRef, useEffect } from "react";
import { cn } from "@/lib/utils/cn";

export type AgentStatus = "online" | "away" | "offline";

interface OnlineStatusProps {
  status: AgentStatus;
  onStatusChange?: (status: AgentStatus) => void;
  className?: string;
}

const statusOptions: { value: AgentStatus; label: string; color: string }[] = [
  { value: "online", label: "Online", color: "bg-linkedin-green" },
  { value: "away", label: "Away", color: "bg-yellow-500" },
  { value: "offline", label: "Offline", color: "bg-linkedin-gray-50" },
];

export function OnlineStatus({
  status,
  onStatusChange,
  className,
}: OnlineStatusProps) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (ref.current && !ref.current.contains(e.target as Node)) {
        setOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const current = statusOptions.find((s) => s.value === status) ?? statusOptions[2];

  return (
    <div ref={ref} className={cn("relative", className)}>
      <button
        onClick={() => setOpen(!open)}
        className="flex items-center gap-2 px-3 py-1.5 rounded-full hover:bg-linkedin-gray-10 transition-colors text-sm"
        aria-label={`Status: ${current.label}`}
      >
        <span className={cn("h-2.5 w-2.5 rounded-full", current.color)} />
        <span className="text-linkedin-gray-70">{current.label}</span>
      </button>

      {open && (
        <div className="absolute right-0 top-full mt-1 w-40 rounded-card bg-linkedin-white shadow-dropdown z-50 border border-linkedin-gray-20 py-1">
          {statusOptions.map((option) => (
            <button
              key={option.value}
              onClick={() => {
                onStatusChange?.(option.value);
                setOpen(false);
              }}
              className={cn(
                "w-full flex items-center gap-2.5 px-4 py-2 text-sm hover:bg-linkedin-gray-10 transition-colors",
                option.value === status
                  ? "text-linkedin-blue font-semibold"
                  : "text-linkedin-black"
              )}
            >
              <span className={cn("h-2.5 w-2.5 rounded-full", option.color)} />
              {option.label}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
