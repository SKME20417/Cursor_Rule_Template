"use client";

import { useState, useRef, useEffect, type ReactNode } from "react";
import { Bell } from "lucide-react";
import { cn } from "@/lib/utils/cn";

export interface Notification {
  id: string;
  title: string;
  message: string;
  timestamp: string;
  read: boolean;
}

interface NotificationBellProps {
  notifications?: Notification[];
  unreadCount?: number;
  onMarkRead?: (id: string) => void;
  onMarkAllRead?: () => void;
  className?: string;
}

export function NotificationBell({
  notifications = [],
  unreadCount = 0,
  onMarkRead,
  onMarkAllRead,
  className,
}: NotificationBellProps) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (ref.current && !ref.current.contains(e.target as Node)) {
        setOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  return (
    <div ref={ref} className={cn("relative", className)}>
      <button
        onClick={() => setOpen(!open)}
        className="relative p-2 rounded-full hover:bg-linkedin-gray-10 transition-colors"
        aria-label={`Notifications${unreadCount > 0 ? `, ${unreadCount} unread` : ""}`}
      >
        <Bell className="h-5 w-5 text-linkedin-gray-70" />
        {unreadCount > 0 && (
          <span className="absolute -top-0.5 -right-0.5 flex h-4 min-w-[1rem] items-center justify-center rounded-full bg-linkedin-red px-1 text-2xs font-bold text-white">
            {unreadCount > 99 ? "99+" : unreadCount}
          </span>
        )}
      </button>

      {open && (
        <div className="absolute right-0 top-full mt-2 w-80 rounded-card bg-linkedin-white shadow-dropdown z-50 border border-linkedin-gray-20">
          <div className="flex items-center justify-between px-4 py-3 border-b border-linkedin-gray-20">
            <h3 className="text-sm font-semibold text-linkedin-black">
              Notifications
            </h3>
            {unreadCount > 0 && onMarkAllRead && (
              <button
                onClick={onMarkAllRead}
                className="text-xs text-linkedin-blue hover:underline"
              >
                Mark all read
              </button>
            )}
          </div>
          <div className="max-h-80 overflow-y-auto">
            {notifications.length === 0 ? (
              <div className="px-4 py-8 text-center text-sm text-linkedin-gray-50">
                No notifications
              </div>
            ) : (
              notifications.map((n) => (
                <button
                  key={n.id}
                  onClick={() => onMarkRead?.(n.id)}
                  className={cn(
                    "w-full text-left px-4 py-3 border-b border-linkedin-gray-20 last:border-b-0 hover:bg-linkedin-gray-10 transition-colors",
                    !n.read && "bg-linkedin-blue-bg"
                  )}
                >
                  <p className="text-sm font-medium text-linkedin-black truncate">
                    {n.title}
                  </p>
                  <p className="text-xs text-linkedin-gray-70 mt-0.5 line-clamp-2">
                    {n.message}
                  </p>
                  <p className="text-2xs text-linkedin-gray-50 mt-1">
                    {n.timestamp}
                  </p>
                </button>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  );
}
