"use client";

import { useState, useEffect, useCallback } from "react";
import { X, Command } from "lucide-react";
import { cn } from "@/lib/utils/cn";

interface Shortcut {
  keys: string[];
  description: string;
}

const defaultShortcuts: Shortcut[] = [
  { keys: ["Ctrl", "K"], description: "Open global search" },
  { keys: ["Ctrl", "/"], description: "Show keyboard shortcuts" },
  { keys: ["Ctrl", "N"], description: "New ticket" },
  { keys: ["Ctrl", "Enter"], description: "Send message" },
  { keys: ["Esc"], description: "Close modal / panel" },
  { keys: ["Ctrl", "Shift", "A"], description: "Toggle AI copilot" },
];

interface KeyboardShortcutsProps {
  shortcuts?: Shortcut[];
  onSearch?: () => void;
  className?: string;
}

export function KeyboardShortcuts({
  shortcuts = defaultShortcuts,
  onSearch,
  className,
}: KeyboardShortcutsProps) {
  const [showModal, setShowModal] = useState(false);

  const handleKeyDown = useCallback(
    (e: KeyboardEvent) => {
      const isCtrlOrMeta = e.ctrlKey || e.metaKey;

      if (isCtrlOrMeta && e.key === "k") {
        e.preventDefault();
        onSearch?.();
      }

      if (isCtrlOrMeta && e.key === "/") {
        e.preventDefault();
        setShowModal((prev) => !prev);
      }

      if (e.key === "Escape") {
        setShowModal(false);
      }
    },
    [onSearch]
  );

  useEffect(() => {
    document.addEventListener("keydown", handleKeyDown);
    return () => document.removeEventListener("keydown", handleKeyDown);
  }, [handleKeyDown]);

  if (!showModal) return null;

  return (
    <div
      className={cn(
        "fixed inset-0 z-[100] flex items-center justify-center bg-black/40",
        className
      )}
      onClick={() => setShowModal(false)}
    >
      <div
        className="w-full max-w-md rounded-card bg-linkedin-white shadow-modal animate-fade-in"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between px-5 py-4 border-b border-linkedin-gray-20">
          <h2 className="text-base font-semibold text-linkedin-black">
            Keyboard Shortcuts
          </h2>
          <button
            onClick={() => setShowModal(false)}
            className="p-1 rounded-md hover:bg-linkedin-gray-10 transition-colors"
            aria-label="Close"
          >
            <X className="h-4 w-4 text-linkedin-gray-70" />
          </button>
        </div>
        <div className="px-5 py-4 space-y-3">
          {shortcuts.map((shortcut, i) => (
            <div
              key={i}
              className="flex items-center justify-between text-sm"
            >
              <span className="text-linkedin-gray-70">
                {shortcut.description}
              </span>
              <div className="flex items-center gap-1">
                {shortcut.keys.map((key, j) => (
                  <kbd
                    key={j}
                    className="inline-flex h-6 min-w-[1.5rem] items-center justify-center rounded border border-linkedin-gray-20 bg-linkedin-gray-10 px-1.5 text-2xs font-medium text-linkedin-gray-70"
                  >
                    {key}
                  </kbd>
                ))}
              </div>
            </div>
          ))}
        </div>
        <div className="px-5 py-3 border-t border-linkedin-gray-20 text-2xs text-linkedin-gray-50 text-center">
          Press <kbd className="font-medium">Ctrl + /</kbd> to toggle this panel
        </div>
      </div>
    </div>
  );
}
