"use client";

import { useState, useRef, useEffect } from "react";
import { Globe } from "lucide-react";
import { cn } from "@/lib/utils/cn";

export interface LocaleOption {
  code: string;
  label: string;
}

const defaultLocales: LocaleOption[] = [
  { code: "en", label: "English" },
  { code: "es", label: "Espa\u00f1ol" },
  { code: "fr", label: "Fran\u00e7ais" },
  { code: "de", label: "Deutsch" },
  { code: "pt", label: "Portugu\u00eas" },
  { code: "ja", label: "\u65e5\u672c\u8a9e" },
];

interface LanguageSwitcherProps {
  locales?: LocaleOption[];
  currentLocale?: string;
  onLocaleChange?: (locale: string) => void;
  className?: string;
}

export function LanguageSwitcher({
  locales = defaultLocales,
  currentLocale = "en",
  onLocaleChange,
  className,
}: LanguageSwitcherProps) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (ref.current && !ref.current.contains(e.target as Node)) {
        setOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const selected = locales.find((l) => l.code === currentLocale);

  return (
    <div ref={ref} className={cn("relative", className)}>
      <button
        onClick={() => setOpen(!open)}
        className="flex items-center gap-1.5 px-2 py-1.5 rounded-md text-sm text-linkedin-gray-70 hover:bg-linkedin-gray-10 transition-colors"
        aria-label="Select language"
      >
        <Globe className="h-4 w-4" />
        <span className="hidden sm:inline">{selected?.label ?? currentLocale}</span>
      </button>

      {open && (
        <div className="absolute right-0 top-full mt-1 w-44 rounded-card bg-linkedin-white shadow-dropdown z-50 border border-linkedin-gray-20 py-1">
          {locales.map((locale) => (
            <button
              key={locale.code}
              onClick={() => {
                onLocaleChange?.(locale.code);
                setOpen(false);
              }}
              className={cn(
                "w-full text-left px-4 py-2 text-sm hover:bg-linkedin-gray-10 transition-colors",
                locale.code === currentLocale
                  ? "text-linkedin-blue font-semibold bg-linkedin-blue-bg"
                  : "text-linkedin-black"
              )}
            >
              {locale.label}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
