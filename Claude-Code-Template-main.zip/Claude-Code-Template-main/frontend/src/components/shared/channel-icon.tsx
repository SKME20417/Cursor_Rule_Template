import {
  MessageCircle,
  Mail,
  Smartphone,
  MessageSquare,
  Hash,
  Share2,
  Phone,
  Video,
  type LucideIcon,
} from "lucide-react";
import { cn } from "@/lib/utils/cn";

export type ChannelType =
  | "chat"
  | "email"
  | "whatsapp"
  | "sms"
  | "slack"
  | "social"
  | "voice"
  | "video";

interface ChannelIconProps {
  channel: ChannelType;
  className?: string;
  size?: number;
}

const iconMap: Record<ChannelType, LucideIcon> = {
  chat: MessageCircle,
  email: Mail,
  whatsapp: MessageSquare,
  sms: Smartphone,
  slack: Hash,
  social: Share2,
  voice: Phone,
  video: Video,
};

const colorMap: Record<ChannelType, string> = {
  chat: "text-linkedin-blue",
  email: "text-linkedin-gray-70",
  whatsapp: "text-green-600",
  sms: "text-purple-600",
  slack: "text-pink-600",
  social: "text-blue-500",
  voice: "text-linkedin-green",
  video: "text-linkedin-orange",
};

export function ChannelIcon({ channel, className, size = 16 }: ChannelIconProps) {
  const Icon = iconMap[channel];
  return (
    <Icon
      className={cn(colorMap[channel], className)}
      size={size}
      aria-label={`${channel} channel`}
    />
  );
}
