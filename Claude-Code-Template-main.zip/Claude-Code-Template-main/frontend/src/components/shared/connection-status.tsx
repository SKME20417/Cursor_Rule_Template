"use client";

import { cn } from "@/lib/utils/cn";

export type ConnectionState = "connected" | "connecting" | "disconnected";

interface ConnectionStatusProps {
  status: ConnectionState;
  className?: string;
  showLabel?: boolean;
}

const statusConfig: Record<ConnectionState, { color: string; label: string }> = {
  connected: { color: "bg-linkedin-green", label: "Connected" },
  connecting: { color: "bg-yellow-500 animate-pulse", label: "Connecting" },
  disconnected: { color: "bg-linkedin-red", label: "Disconnected" },
};

export function ConnectionStatus({
  status,
  className,
  showLabel = false,
}: ConnectionStatusProps) {
  const config = statusConfig[status];

  return (
    <div className={cn("flex items-center gap-1.5", className)}>
      <span
        className={cn("inline-block h-2.5 w-2.5 rounded-full", config.color)}
        aria-label={config.label}
      />
      {showLabel && (
        <span className="text-xs text-linkedin-gray-70">{config.label}</span>
      )}
    </div>
  );
}
