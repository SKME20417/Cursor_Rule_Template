import { cn } from "@/lib/utils/cn";

interface ConfidenceBadgeProps {
  score: number;
  className?: string;
  showPercentage?: boolean;
}

function getConfidenceLevel(score: number): {
  label: string;
  bgColor: string;
  textColor: string;
} {
  if (score >= 0.8) {
    return {
      label: "High",
      bgColor: "bg-green-100",
      textColor: "text-linkedin-green",
    };
  }
  if (score >= 0.5) {
    return {
      label: "Medium",
      bgColor: "bg-yellow-100",
      textColor: "text-yellow-700",
    };
  }
  return {
    label: "Low",
    bgColor: "bg-red-100",
    textColor: "text-linkedin-red",
  };
}

export function ConfidenceBadge({
  score,
  className,
  showPercentage = true,
}: ConfidenceBadgeProps) {
  const clamped = Math.max(0, Math.min(1, score));
  const { label, bgColor, textColor } = getConfidenceLevel(clamped);

  return (
    <span
      className={cn(
        "badge",
        bgColor,
        textColor,
        className
      )}
      title={`AI confidence: ${(clamped * 100).toFixed(0)}%`}
    >
      {showPercentage ? `${(clamped * 100).toFixed(0)}%` : label}
    </span>
  );
}
