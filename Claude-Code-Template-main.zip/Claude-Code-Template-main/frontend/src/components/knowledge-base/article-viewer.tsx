"use client";

import React, { useState } from "react";
import { cn } from "@/lib/utils/cn";
import { ThumbsUp, ThumbsDown, Printer, BookOpen, ChevronRight } from "lucide-react";

interface TocEntry {
  id: string;
  text: string;
  level: number;
}

interface RelatedArticle {
  id: string;
  title: string;
}

interface BreadcrumbItem {
  label: string;
  onClick?: () => void;
}

interface ArticleViewerProps {
  title: string;
  content: string;
  author?: string;
  authorAvatarUrl?: string;
  publishedDate?: string;
  breadcrumbs?: BreadcrumbItem[];
  tableOfContents?: TocEntry[];
  relatedArticles?: RelatedArticle[];
  onFeedback?: (helpful: boolean) => void;
  onRelatedClick?: (articleId: string) => void;
  onInsertIntoReply?: () => void;
  className?: string;
}

function ArticleViewer({
  title,
  content,
  author,
  authorAvatarUrl,
  publishedDate,
  breadcrumbs = [],
  tableOfContents = [],
  relatedArticles = [],
  onFeedback,
  onRelatedClick,
  onInsertIntoReply,
  className,
}: ArticleViewerProps) {
  const [feedbackGiven, setFeedbackGiven] = useState<boolean | null>(null);

  const handleFeedback = (helpful: boolean) => {
    setFeedbackGiven(helpful);
    onFeedback?.(helpful);
  };

  return (
    <div className={cn("flex gap-6", className)}>
      {/* Table of contents sidebar */}
      {tableOfContents.length > 0 && (
        <nav className="hidden lg:block w-56 flex-shrink-0">
          <div className="sticky top-4">
            <h4 className="text-xs font-semibold text-linkedin-gray-50 uppercase tracking-wide mb-2">
              Contents
            </h4>
            <ul className="space-y-1">
              {tableOfContents.map((entry) => (
                <li key={entry.id}>
                  <a
                    href={`#${entry.id}`}
                    className={cn(
                      "block text-sm text-linkedin-gray-50 hover:text-linkedin-blue transition-colors",
                      entry.level === 1 && "font-medium text-linkedin-gray-70",
                      entry.level === 2 && "pl-3",
                      entry.level === 3 && "pl-6",
                    )}
                  >
                    {entry.text}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </nav>
      )}

      {/* Main content */}
      <div className="flex-1 min-w-0">
        <div className="rounded-lg border border-linkedin-gray-20 bg-linkedin-white p-6 shadow-card">
          {/* Breadcrumb */}
          {breadcrumbs.length > 0 && (
            <nav className="mb-3 flex items-center gap-1 text-xs text-linkedin-gray-50">
              {breadcrumbs.map((crumb, idx) => (
                <React.Fragment key={idx}>
                  {idx > 0 && <ChevronRight className="h-3 w-3 flex-shrink-0" />}
                  {crumb.onClick ? (
                    <button
                      type="button"
                      onClick={crumb.onClick}
                      className="hover:text-linkedin-blue transition-colors"
                    >
                      {crumb.label}
                    </button>
                  ) : (
                    <span className="text-linkedin-gray-70 font-medium">{crumb.label}</span>
                  )}
                </React.Fragment>
              ))}
            </nav>
          )}

          <div className="flex items-start justify-between gap-3 mb-2">
            <h1 className="text-xl font-bold text-linkedin-gray-90">{title}</h1>
            <button
              type="button"
              onClick={() => window.print()}
              aria-label="Print article"
              className="flex-shrink-0 rounded p-1.5 text-linkedin-gray-50 hover:bg-linkedin-gray-10 hover:text-linkedin-gray-90 transition-colors"
            >
              <Printer className="h-4 w-4" />
            </button>
          </div>

          {/* Author and date */}
          {(author || publishedDate) && (
            <div className="mb-4 flex items-center gap-2 text-xs text-linkedin-gray-50">
              {authorAvatarUrl && (
                <img
                  src={authorAvatarUrl}
                  alt={author ?? "Author"}
                  className="h-6 w-6 rounded-full object-cover"
                />
              )}
              {author && <span className="font-medium text-linkedin-gray-70">{author}</span>}
              {author && publishedDate && <span>&middot;</span>}
              {publishedDate && <span>{publishedDate}</span>}
            </div>
          )}

          {/* Article content rendered as HTML */}
          <div
            className="prose prose-sm max-w-none text-linkedin-gray-70 leading-relaxed"
            dangerouslySetInnerHTML={{ __html: content }}
          />

          {/* Insert into reply */}
          {onInsertIntoReply && (
            <div className="mt-6 border-t border-linkedin-gray-20 pt-4">
              <button
                type="button"
                onClick={onInsertIntoReply}
                className="flex items-center gap-1.5 rounded-full bg-linkedin-blue px-4 py-2 text-sm font-semibold text-linkedin-white hover:bg-linkedin-blue-hover transition-colors"
              >
                <BookOpen className="h-4 w-4" />
                Insert into reply
              </button>
            </div>
          )}

          {/* Feedback */}
          <div className="mt-6 border-t border-linkedin-gray-20 pt-4">
            <p className="text-sm font-medium text-linkedin-gray-70 mb-2">
              Was this article helpful?
            </p>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => handleFeedback(true)}
                disabled={feedbackGiven !== null}
                className={cn(
                  "flex items-center gap-1 rounded-full px-3 py-1.5 text-xs font-medium transition-colors",
                  feedbackGiven === true
                    ? "bg-linkedin-green text-linkedin-white"
                    : "border border-linkedin-gray-30 text-linkedin-gray-50 hover:bg-linkedin-gray-10",
                  feedbackGiven !== null && feedbackGiven !== true && "opacity-50",
                )}
              >
                <ThumbsUp className="h-3.5 w-3.5" />
                Yes
              </button>
              <button
                type="button"
                onClick={() => handleFeedback(false)}
                disabled={feedbackGiven !== null}
                className={cn(
                  "flex items-center gap-1 rounded-full px-3 py-1.5 text-xs font-medium transition-colors",
                  feedbackGiven === false
                    ? "bg-linkedin-red text-linkedin-white"
                    : "border border-linkedin-gray-30 text-linkedin-gray-50 hover:bg-linkedin-gray-10",
                  feedbackGiven !== null && feedbackGiven !== false && "opacity-50",
                )}
              >
                <ThumbsDown className="h-3.5 w-3.5" />
                No
              </button>
            </div>
            {feedbackGiven !== null && (
              <p className="mt-2 text-xs text-linkedin-gray-50">
                Thank you for your feedback!
              </p>
            )}
          </div>
        </div>

        {/* Related articles */}
        {relatedArticles.length > 0 && (
          <div className="mt-4 rounded-lg border border-linkedin-gray-20 bg-linkedin-white p-4">
            <h3 className="text-sm font-semibold text-linkedin-gray-90 mb-3">
              Related Articles
            </h3>
            <ul className="space-y-2">
              {relatedArticles.map((article) => (
                <li key={article.id}>
                  <button
                    type="button"
                    onClick={() => onRelatedClick?.(article.id)}
                    className="text-sm text-linkedin-blue hover:underline text-left"
                  >
                    {article.title}
                  </button>
                </li>
              ))}
            </ul>
          </div>
        )}
      </div>
    </div>
  );
}

ArticleViewer.displayName = "ArticleViewer";

export { ArticleViewer };
