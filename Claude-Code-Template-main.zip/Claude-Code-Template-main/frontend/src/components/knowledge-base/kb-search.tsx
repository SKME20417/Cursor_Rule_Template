"use client";

import React, { useState, useRef, useEffect } from "react";
import { cn } from "@/lib/utils/cn";
import { Search, X, FileText, ArrowRight } from "lucide-react";

interface KbSearchResult {
  id: string;
  title: string;
  snippet: string;
  category: string;
  matchedTerms?: string[];
}

interface KbSearchProps {
  results?: KbSearchResult[];
  categories?: string[];
  onSearch?: (query: string, category?: string) => void;
  onSelectResult?: (id: string) => void;
  loading?: boolean;
  className?: string;
}

function KbSearch({
  results = [],
  categories = [],
  onSearch,
  onSelectResult,
  loading = false,
  className,
}: KbSearchProps) {
  const [query, setQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string>("");
  const [showResults, setShowResults] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setShowResults(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (query.trim()) {
      onSearch?.(query.trim(), selectedCategory || undefined);
      setShowResults(true);
    }
  };

  const handleInputChange = (value: string) => {
    setQuery(value);
    if (value.trim().length >= 2) {
      onSearch?.(value.trim(), selectedCategory || undefined);
      setShowResults(true);
    } else {
      setShowResults(false);
    }
  };

  const highlightMatch = (text: string, terms: string[] = []) => {
    if (terms.length === 0) return text;
    const escaped = terms.map((t) => t.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"));
    const pattern = new RegExp(`(${escaped.join("|")})`, "gi");
    const parts = text.split(pattern);
    return parts.map((part, i) =>
      pattern.test(part) ? (
        <mark key={i} className="bg-yellow-200 rounded px-0.5">
          {part}
        </mark>
      ) : (
        part
      ),
    );
  };

  return (
    <div ref={containerRef} className={cn("relative", className)}>
      <form onSubmit={handleSubmit}>
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-linkedin-gray-50" />
          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={(e) => handleInputChange(e.target.value)}
            onFocus={() => query.length >= 2 && setShowResults(true)}
            placeholder="Search knowledge base..."
            className="w-full rounded-lg border border-linkedin-gray-30 bg-linkedin-white py-2.5 pl-10 pr-10 text-sm text-linkedin-gray-90 placeholder:text-linkedin-gray-50 focus:border-linkedin-blue focus:outline-none focus:ring-1 focus:ring-linkedin-blue"
          />
          {query && (
            <button
              type="button"
              onClick={() => {
                setQuery("");
                setShowResults(false);
                inputRef.current?.focus();
              }}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-linkedin-gray-50 hover:text-linkedin-gray-90"
            >
              <X className="h-4 w-4" />
            </button>
          )}
        </div>

        {categories.length > 0 && (
          <div className="mt-2 flex flex-wrap gap-1">
            <button
              type="button"
              onClick={() => setSelectedCategory("")}
              className={cn(
                "rounded-full px-2.5 py-0.5 text-xs font-medium transition-colors",
                !selectedCategory
                  ? "bg-linkedin-blue text-linkedin-white"
                  : "bg-linkedin-gray-10 text-linkedin-gray-50 hover:bg-linkedin-gray-20",
              )}
            >
              All
            </button>
            {categories.map((cat) => (
              <button
                key={cat}
                type="button"
                onClick={() => setSelectedCategory(cat)}
                className={cn(
                  "rounded-full px-2.5 py-0.5 text-xs font-medium transition-colors",
                  selectedCategory === cat
                    ? "bg-linkedin-blue text-linkedin-white"
                    : "bg-linkedin-gray-10 text-linkedin-gray-50 hover:bg-linkedin-gray-20",
                )}
              >
                {cat}
              </button>
            ))}
          </div>
        )}
      </form>

      {/* Results dropdown */}
      {showResults && (
        <div className="absolute top-full left-0 right-0 z-50 mt-1 max-h-96 overflow-y-auto rounded-lg border border-linkedin-gray-20 bg-linkedin-white shadow-lg">
          {loading ? (
            <div className="p-4 space-y-3">
              {[1, 2, 3].map((i) => (
                <div key={i} className="animate-pulse space-y-1.5">
                  <div className="h-4 w-3/4 rounded bg-linkedin-gray-20" />
                  <div className="h-3 w-full rounded bg-linkedin-gray-20" />
                </div>
              ))}
            </div>
          ) : results.length === 0 ? (
            <div className="flex flex-col items-center gap-2 p-6 text-center">
              <FileText className="h-8 w-8 text-linkedin-gray-30" />
              <p className="text-sm text-linkedin-gray-50">No results found</p>
              <p className="text-xs text-linkedin-gray-50">
                Try different keywords or browse categories
              </p>
            </div>
          ) : (
            <ul className="divide-y divide-linkedin-gray-20">
              {results.map((result) => (
                <li key={result.id}>
                  <button
                    type="button"
                    onClick={() => {
                      onSelectResult?.(result.id);
                      setShowResults(false);
                    }}
                    className="flex w-full items-start gap-3 px-4 py-3 text-left hover:bg-linkedin-gray-10 transition-colors"
                  >
                    <FileText className="mt-0.5 h-4 w-4 flex-shrink-0 text-linkedin-gray-50" />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-semibold text-linkedin-gray-90">
                        {highlightMatch(result.title, result.matchedTerms)}
                      </p>
                      <p className="mt-0.5 text-xs text-linkedin-gray-50 line-clamp-2">
                        {highlightMatch(result.snippet, result.matchedTerms)}
                      </p>
                      <span className="mt-1 inline-block rounded-full bg-linkedin-gray-10 px-1.5 py-0.5 text-xs text-linkedin-gray-50">
                        {result.category}
                      </span>
                    </div>
                    <ArrowRight className="mt-0.5 h-4 w-4 flex-shrink-0 text-linkedin-gray-30" />
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>
      )}
    </div>
  );
}

KbSearch.displayName = "KbSearch";

export { KbSearch };
