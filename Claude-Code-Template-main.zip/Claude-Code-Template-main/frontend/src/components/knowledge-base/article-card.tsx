"use client";

import React from "react";
import { cn } from "@/lib/utils/cn";
import { Eye, Clock, User } from "lucide-react";

interface ArticleCardProps {
  id: string;
  title: string;
  snippet: string;
  category: string;
  author: string;
  authorAvatarUrl?: string;
  lastUpdated: string;
  viewCount: number;
  status: "draft" | "published" | "archived";
  onClick?: (id: string) => void;
  className?: string;
}

const statusConfig: Record<string, { label: string; bg: string; text: string }> = {
  draft: { label: "Draft", bg: "bg-yellow-50", text: "text-yellow-700" },
  published: { label: "Published", bg: "bg-green-50", text: "text-linkedin-green" },
  archived: { label: "Archived", bg: "bg-linkedin-gray-10", text: "text-linkedin-gray-50" },
};

function ArticleCard({
  id,
  title,
  snippet,
  category,
  author,
  authorAvatarUrl,
  lastUpdated,
  viewCount,
  status,
  onClick,
  className,
}: ArticleCardProps) {
  const statusStyle = statusConfig[status];

  return (
    <div
      role="button"
      tabIndex={0}
      onClick={() => onClick?.(id)}
      onKeyDown={(e) => {
        if (e.key === "Enter" || e.key === " ") {
          e.preventDefault();
          onClick?.(id);
        }
      }}
      className={cn(
        "group cursor-pointer rounded-lg border border-linkedin-gray-20 bg-linkedin-white p-4 shadow-card transition-shadow hover:shadow-md",
        className,
      )}
    >
      <div className="flex items-start justify-between gap-2">
        <div className="flex items-center gap-2">
          <span className="rounded-full bg-linkedin-blue-bg px-2 py-0.5 text-xs font-medium text-linkedin-blue">
            {category}
          </span>
          <span
            className={cn(
              "rounded-full px-2 py-0.5 text-xs font-medium",
              statusStyle.bg,
              statusStyle.text,
            )}
          >
            {statusStyle.label}
          </span>
        </div>
      </div>

      <h3 className="mt-2 text-sm font-semibold text-linkedin-gray-90 group-hover:text-linkedin-blue transition-colors line-clamp-2">
        {title}
      </h3>
      <p className="mt-1 text-xs text-linkedin-gray-50 line-clamp-2 leading-relaxed">
        {snippet}
      </p>

      <div className="mt-3 flex items-center gap-3 text-xs text-linkedin-gray-50">
        <span className="flex items-center gap-1">
          {authorAvatarUrl ? (
            <img
              src={authorAvatarUrl}
              alt={author}
              className="h-4 w-4 rounded-full object-cover"
            />
          ) : (
            <User className="h-3 w-3" />
          )}
          {author}
        </span>
        <span className="flex items-center gap-1">
          <Clock className="h-3 w-3" />
          {lastUpdated}
        </span>
        <span className="flex items-center gap-1">
          <Eye className="h-3 w-3" />
          {viewCount.toLocaleString()}
        </span>
      </div>
    </div>
  );
}

ArticleCard.displayName = "ArticleCard";

export { ArticleCard };
