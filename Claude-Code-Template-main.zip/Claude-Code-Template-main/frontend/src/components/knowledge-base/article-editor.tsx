"use client";

import React, { useState, useCallback } from "react";
import { cn } from "@/lib/utils/cn";
import {
  Bold,
  Italic,
  Heading2,
  Heading3,
  List,
  ListOrdered,
  Link,
  Code,
  Image,
  Eye,
  Save,
  Send,
  Check,
  X,
} from "lucide-react";

type ArticleStatus = "draft" | "published";

interface ArticleEditorProps {
  initialTitle?: string;
  initialContent?: string;
  initialCategory?: string;
  initialTags?: string[];
  initialStatus?: ArticleStatus;
  categories?: string[];
  onSaveDraft?: (data: { title: string; content: string; category: string; tags: string[]; status: ArticleStatus }) => void;
  onPublish?: (data: { title: string; content: string; category: string; tags: string[]; status: ArticleStatus }) => void;
  autoSaveStatus?: "saving" | "saved" | "error" | null;
  className?: string;
}

const TOOLBAR_BUTTONS = [
  { icon: Bold, label: "Bold", action: "bold" },
  { icon: Italic, label: "Italic", action: "italic" },
  { icon: Heading2, label: "Heading 2", action: "h2" },
  { icon: Heading3, label: "Heading 3", action: "h3" },
  { icon: List, label: "Bullet list", action: "ul" },
  { icon: ListOrdered, label: "Numbered list", action: "ol" },
  { icon: Link, label: "Link", action: "link" },
  { icon: Code, label: "Code", action: "code" },
  { icon: Image, label: "Image upload", action: "image" },
] as const;

function ArticleEditor({
  initialTitle = "",
  initialContent = "",
  initialCategory = "",
  initialTags = [],
  initialStatus = "draft",
  categories = [],
  onSaveDraft,
  onPublish,
  autoSaveStatus,
  className,
}: ArticleEditorProps) {
  const [title, setTitle] = useState(initialTitle);
  const [content, setContent] = useState(initialContent);
  const [category, setCategory] = useState(initialCategory);
  const [tags, setTags] = useState<string[]>(initialTags);
  const [tagInput, setTagInput] = useState("");
  const [showPreview, setShowPreview] = useState(false);
  const [status, setStatus] = useState<ArticleStatus>(initialStatus);

  const getData = useCallback(
    () => ({ title, content, category, tags, status }),
    [title, content, category, tags, status],
  );

  const handleAddTag = () => {
    const trimmed = tagInput.trim();
    if (trimmed && !tags.includes(trimmed)) {
      setTags((prev) => [...prev, trimmed]);
      setTagInput("");
    }
  };

  const handleRemoveTag = (tag: string) => {
    setTags((prev) => prev.filter((t) => t !== tag));
  };

  const handleTagKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      e.preventDefault();
      handleAddTag();
    }
  };

  const insertFormatting = (action: string) => {
    const prefixes: Record<string, string> = {
      bold: "**",
      italic: "_",
      h2: "## ",
      h3: "### ",
      ul: "- ",
      ol: "1. ",
      link: "[text](url)",
      code: "`",
      image: "![alt](url)",
    };
    const insertion = prefixes[action] ?? "";
    setContent((prev) => prev + insertion);
  };

  return (
    <div
      className={cn(
        "rounded-lg border border-linkedin-gray-20 bg-linkedin-white",
        className,
      )}
    >
      {/* Title */}
      <div className="border-b border-linkedin-gray-20 px-4 py-3">
        <input
          type="text"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="Article title..."
          className="w-full text-lg font-bold text-linkedin-gray-90 placeholder:text-linkedin-gray-30 focus:outline-none"
        />
      </div>

      {/* Metadata */}
      <div className="flex flex-wrap items-center gap-3 border-b border-linkedin-gray-20 px-4 py-2">
        <div className="flex items-center gap-1.5">
          <label className="text-xs text-linkedin-gray-50">Category:</label>
          <select
            value={category}
            onChange={(e) => setCategory(e.target.value)}
            className="rounded border border-linkedin-gray-30 bg-linkedin-white px-2 py-1 text-xs text-linkedin-gray-90 focus:border-linkedin-blue focus:outline-none"
          >
            <option value="">Select...</option>
            {categories.map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </select>
        </div>

        <div className="flex items-center gap-1.5">
          <label className="text-xs text-linkedin-gray-50">Status:</label>
          <select
            value={status}
            onChange={(e) => setStatus(e.target.value as ArticleStatus)}
            className="rounded border border-linkedin-gray-30 bg-linkedin-white px-2 py-1 text-xs text-linkedin-gray-90 focus:border-linkedin-blue focus:outline-none"
          >
            <option value="draft">Draft</option>
            <option value="published">Published</option>
          </select>
        </div>

        <div className="flex items-center gap-1.5">
          <label className="text-xs text-linkedin-gray-50">Tags:</label>
          <div className="flex flex-wrap items-center gap-1">
            {tags.map((tag) => (
              <span
                key={tag}
                className="inline-flex items-center gap-0.5 rounded-full bg-linkedin-blue-bg px-2 py-0.5 text-xs text-linkedin-blue"
              >
                {tag}
                <button
                  type="button"
                  onClick={() => handleRemoveTag(tag)}
                  className="hover:text-linkedin-red transition-colors"
                >
                  <X className="h-3 w-3" />
                </button>
              </span>
            ))}
            <input
              type="text"
              value={tagInput}
              onChange={(e) => setTagInput(e.target.value)}
              onKeyDown={handleTagKeyDown}
              onBlur={handleAddTag}
              placeholder="Add tag..."
              className="w-20 border-none bg-transparent text-xs text-linkedin-gray-90 placeholder:text-linkedin-gray-30 focus:outline-none"
            />
          </div>
        </div>
      </div>

      {/* Toolbar */}
      <div className="flex items-center justify-between border-b border-linkedin-gray-20 px-2 py-1">
        <div className="flex items-center gap-0.5">
          {TOOLBAR_BUTTONS.map((btn) => (
            <button
              key={btn.action}
              type="button"
              onClick={() => insertFormatting(btn.action)}
              aria-label={btn.label}
              className="flex h-7 w-7 items-center justify-center rounded text-linkedin-gray-50 hover:bg-linkedin-gray-10 hover:text-linkedin-gray-90 transition-colors"
            >
              <btn.icon className="h-4 w-4" />
            </button>
          ))}
        </div>

        <button
          type="button"
          onClick={() => setShowPreview((p) => !p)}
          className={cn(
            "flex items-center gap-1 rounded px-2 py-1 text-xs font-medium transition-colors",
            showPreview
              ? "bg-linkedin-blue-bg text-linkedin-blue"
              : "text-linkedin-gray-50 hover:bg-linkedin-gray-10",
          )}
        >
          <Eye className="h-3.5 w-3.5" />
          Preview
        </button>
      </div>

      {/* Editor / Preview */}
      <div className="min-h-[300px]">
        {showPreview ? (
          <div className="prose prose-sm max-w-none p-4 text-linkedin-gray-70">
            <div dangerouslySetInnerHTML={{ __html: content.replace(/\n/g, "<br/>") }} />
          </div>
        ) : (
          <textarea
            value={content}
            onChange={(e) => setContent(e.target.value)}
            placeholder="Write your article content here... (Markdown supported)"
            className="w-full min-h-[300px] resize-y p-4 text-sm text-linkedin-gray-90 placeholder:text-linkedin-gray-30 focus:outline-none font-mono leading-relaxed"
          />
        )}
      </div>

      {/* Footer */}
      <div className="flex items-center justify-between border-t border-linkedin-gray-20 px-4 py-3">
        <div className="text-xs text-linkedin-gray-50">
          {autoSaveStatus === "saving" && (
            <span className="flex items-center gap-1">
              <span className="h-1.5 w-1.5 rounded-full bg-yellow-400 animate-pulse" />
              Saving...
            </span>
          )}
          {autoSaveStatus === "saved" && (
            <span className="flex items-center gap-1 text-linkedin-green">
              <Check className="h-3 w-3" />
              Saved
            </span>
          )}
          {autoSaveStatus === "error" && (
            <span className="text-linkedin-red">Save failed</span>
          )}
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => onSaveDraft?.(getData())}
            className="flex items-center gap-1.5 rounded-full border border-linkedin-gray-30 px-4 py-1.5 text-sm font-semibold text-linkedin-gray-70 transition-colors hover:bg-linkedin-gray-10"
          >
            <Save className="h-4 w-4" />
            Save Draft
          </button>
          <button
            type="button"
            onClick={() => onPublish?.(getData())}
            className="flex items-center gap-1.5 rounded-full bg-linkedin-blue px-4 py-1.5 text-sm font-semibold text-linkedin-white transition-colors hover:bg-linkedin-blue-hover"
          >
            <Send className="h-4 w-4" />
            Publish
          </button>
        </div>
      </div>
    </div>
  );
}

ArticleEditor.displayName = "ArticleEditor";

export { ArticleEditor };
