"use client";

import React from "react";
import { cn } from "@/lib/utils/cn";
import { ExternalLink } from "lucide-react";

interface Source {
  id: string;
  title: string;
  url?: string;
  confidence: number;
}

interface SourceAttributionProps {
  sources: Source[];
  onSourceClick?: (sourceId: string) => void;
  className?: string;
}

function SourceAttribution({
  sources,
  onSourceClick,
  className,
}: SourceAttributionProps) {
  const displaySources = sources.slice(0, 3);

  if (displaySources.length === 0) return null;

  return (
    <div className={cn("inline-flex items-center gap-2 flex-wrap", className)}>
      <span className="text-xs font-semibold text-linkedin-gray-50">
        Sources:
      </span>
      <ul className="inline-flex items-center gap-2 flex-wrap">
        {displaySources.map((source) => {
          const confidenceColor =
            source.confidence >= 0.8
              ? "text-linkedin-green"
              : source.confidence >= 0.5
                ? "text-linkedin-orange"
                : "text-linkedin-red";

          return (
            <li key={source.id} className="inline-flex items-center gap-1.5">
              {source.url ? (
                <a
                  href={source.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  onClick={(e) => {
                    if (onSourceClick) {
                      e.preventDefault();
                      onSourceClick(source.id);
                    }
                  }}
                  className="flex items-center gap-1 text-xs text-linkedin-blue hover:underline"
                >
                  <ExternalLink className="h-3 w-3" />
                  {source.title}
                </a>
              ) : (
                <button
                  type="button"
                  onClick={() => onSourceClick?.(source.id)}
                  className="flex items-center gap-1 text-xs text-linkedin-blue hover:underline"
                >
                  <ExternalLink className="h-3 w-3" />
                  {source.title}
                </button>
              )}
              <span
                className={cn(
                  "rounded-full bg-linkedin-gray-10 px-1.5 py-0.5 text-xs font-medium tabular-nums",
                  confidenceColor,
                )}
              >
                {Math.round(source.confidence * 100)}%
              </span>
            </li>
          );
        })}
      </ul>
    </div>
  );
}

SourceAttribution.displayName = "SourceAttribution";

export { SourceAttribution };
