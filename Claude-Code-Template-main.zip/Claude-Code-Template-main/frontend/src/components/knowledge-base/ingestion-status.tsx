"use client";

import React from "react";
import { cn } from "@/lib/utils/cn";
import {
  Upload,
  Loader2,
  Scissors,
  Cpu,
  CheckCircle2,
  AlertCircle,
  RotateCcw,
  XCircle,
} from "lucide-react";

type IngestionStage =
  | "uploading"
  | "processing"
  | "chunking"
  | "embedding"
  | "complete"
  | "error";

interface IngestionDocument {
  id: string;
  name: string;
  stage: IngestionStage;
  progress: number;
  chunkCount?: number;
  errorMessage?: string;
}

interface IngestionStatusProps {
  documents: IngestionDocument[];
  onRetry?: (docId: string) => void;
  onCancel?: (docId: string) => void;
  className?: string;
}

const stageConfig: Record<
  IngestionStage,
  { label: string; icon: React.ReactNode; color: string }
> = {
  uploading: {
    label: "Uploading",
    icon: <Upload className="h-4 w-4" />,
    color: "text-linkedin-blue",
  },
  processing: {
    label: "Processing",
    icon: <Loader2 className="h-4 w-4 animate-spin" />,
    color: "text-linkedin-blue",
  },
  chunking: {
    label: "Chunking",
    icon: <Scissors className="h-4 w-4" />,
    color: "text-linkedin-orange",
  },
  embedding: {
    label: "Embedding",
    icon: <Cpu className="h-4 w-4 animate-pulse" />,
    color: "text-purple-600",
  },
  complete: {
    label: "Complete",
    icon: <CheckCircle2 className="h-4 w-4" />,
    color: "text-linkedin-green",
  },
  error: {
    label: "Error",
    icon: <AlertCircle className="h-4 w-4" />,
    color: "text-linkedin-red",
  },
};

function IngestionStatus({
  documents,
  onRetry,
  onCancel,
  className,
}: IngestionStatusProps) {
  return (
    <div
      className={cn(
        "rounded-lg border border-linkedin-gray-20 bg-linkedin-white",
        className,
      )}
    >
      <div className="border-b border-linkedin-gray-20 px-4 py-3">
        <h3 className="text-sm font-semibold text-linkedin-gray-90">
          Document Ingestion
        </h3>
      </div>

      {documents.length === 0 ? (
        <p className="px-4 py-6 text-center text-sm text-linkedin-gray-50">
          No documents being processed
        </p>
      ) : (
        <div className="divide-y divide-linkedin-gray-20">
          {documents.map((doc) => {
            const stage = stageConfig[doc.stage];
            return (
              <div key={doc.id} className="px-4 py-3">
                <div className="flex items-center justify-between mb-1.5">
                  <span className="text-sm font-medium text-linkedin-gray-90 truncate">
                    {doc.name}
                  </span>
                  <div className="flex items-center gap-1.5 flex-shrink-0 ml-2">
                    <span className={cn("flex items-center gap-1 text-xs font-medium", stage.color)}>
                      {stage.icon}
                      {stage.label}
                    </span>
                    {doc.stage === "complete" && doc.chunkCount !== undefined && (
                      <span className="rounded-full bg-linkedin-gray-10 px-1.5 py-0.5 text-xs text-linkedin-gray-50 tabular-nums">
                        {doc.chunkCount} chunks
                      </span>
                    )}
                    {doc.stage === "uploading" && onCancel && (
                      <button
                        type="button"
                        onClick={() => onCancel(doc.id)}
                        className="flex items-center gap-1 rounded-full border border-linkedin-gray-30 px-2 py-0.5 text-xs font-medium text-linkedin-gray-70 hover:bg-linkedin-gray-10 transition-colors"
                      >
                        <XCircle className="h-3 w-3" />
                        Cancel
                      </button>
                    )}
                    {doc.stage === "error" && onRetry && (
                      <button
                        type="button"
                        onClick={() => onRetry(doc.id)}
                        className="flex items-center gap-1 rounded-full bg-linkedin-red px-2 py-0.5 text-xs font-medium text-linkedin-white hover:bg-red-700 transition-colors"
                      >
                        <RotateCcw className="h-3 w-3" />
                        Retry
                      </button>
                    )}
                  </div>
                </div>

                {doc.stage !== "complete" && doc.stage !== "error" && (
                  <div className="h-1.5 w-full overflow-hidden rounded-full bg-linkedin-gray-20">
                    <div
                      className={cn(
                        "h-full rounded-full transition-all duration-500",
                        doc.stage === "embedding"
                          ? "bg-purple-500"
                          : "bg-linkedin-blue",
                      )}
                      style={{ width: `${doc.progress}%` }}
                    />
                  </div>
                )}

                {doc.stage === "error" && doc.errorMessage && (
                  <p className="mt-1 text-xs text-linkedin-red">
                    {doc.errorMessage}
                  </p>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

IngestionStatus.displayName = "IngestionStatus";

export { IngestionStatus };
export type { IngestionDocument };
