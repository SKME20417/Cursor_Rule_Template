"use client";

import React, { useState } from "react";
import { cn } from "@/lib/utils/cn";
import {
  FileText,
  FileImage,
  FileCode,
  File,
  RefreshCw,
  Trash2,
  CheckSquare,
  Square,
  Search,
  Inbox,
} from "lucide-react";

interface Document {
  id: string;
  name: string;
  type: string;
  status: "active" | "processing" | "error";
  chunks: number;
  dateUploaded: string;
  size: string;
}

interface DocumentListProps {
  documents: Document[];
  onReindex?: (docIds: string[]) => void;
  onDelete?: (docIds: string[]) => void;
  className?: string;
}

const statusConfig: Record<string, { label: string; bg: string; text: string }> = {
  active: { label: "Active", bg: "bg-green-50", text: "text-linkedin-green" },
  processing: { label: "Processing", bg: "bg-orange-50", text: "text-linkedin-orange" },
  error: { label: "Error", bg: "bg-red-50", text: "text-linkedin-red" },
};

function getTypeIcon(type: string): React.ReactNode {
  const lower = type.toLowerCase();
  if (["pdf", "doc", "docx", "txt"].includes(lower)) {
    return <FileText className="h-4 w-4 text-linkedin-blue" />;
  }
  if (["png", "jpg", "jpeg", "svg"].includes(lower)) {
    return <FileImage className="h-4 w-4 text-linkedin-orange" />;
  }
  if (["json", "csv", "xml", "html"].includes(lower)) {
    return <FileCode className="h-4 w-4 text-purple-600" />;
  }
  return <File className="h-4 w-4 text-linkedin-gray-50" />;
}

function DocumentList({
  documents,
  onReindex,
  onDelete,
  className,
}: DocumentListProps) {
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [searchFilter, setSearchFilter] = useState("");

  const filteredDocuments = documents.filter(
    (d) =>
      !searchFilter ||
      d.name.toLowerCase().includes(searchFilter.toLowerCase()) ||
      d.type.toLowerCase().includes(searchFilter.toLowerCase()),
  );

  const allSelected = filteredDocuments.length > 0 && selected.size === filteredDocuments.length;

  const toggleAll = () => {
    if (allSelected) {
      setSelected(new Set());
    } else {
      setSelected(new Set(filteredDocuments.map((d) => d.id)));
    }
  };

  const toggleOne = (id: string) => {
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
      }
      return next;
    });
  };

  const selectedIds = Array.from(selected);

  return (
    <div
      className={cn(
        "rounded-lg border border-linkedin-gray-20 bg-linkedin-white",
        className,
      )}
    >
      <div className="flex items-center justify-between border-b border-linkedin-gray-20 px-4 py-3">
        <h3 className="text-sm font-semibold text-linkedin-gray-90">
          Documents
        </h3>
        <div className="flex items-center gap-2">
          <div className="relative">
            <Search className="absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-linkedin-gray-50" />
            <input
              type="text"
              value={searchFilter}
              onChange={(e) => setSearchFilter(e.target.value)}
              placeholder="Filter documents..."
              className="w-44 rounded-md border border-linkedin-gray-30 bg-linkedin-white py-1 pl-8 pr-2 text-xs text-linkedin-gray-90 placeholder:text-linkedin-gray-40 focus:border-linkedin-blue focus:outline-none"
            />
          </div>
        </div>
        {selected.size > 0 && (
          <div className="flex items-center gap-2">
            <span className="text-xs text-linkedin-gray-50">
              {selected.size} selected
            </span>
            <button
              type="button"
              onClick={() => onReindex?.(selectedIds)}
              className="flex items-center gap-1 rounded-full border border-linkedin-gray-30 px-2.5 py-1 text-xs font-medium text-linkedin-gray-70 hover:bg-linkedin-gray-10 transition-colors"
            >
              <RefreshCw className="h-3 w-3" />
              Re-index
            </button>
            <button
              type="button"
              onClick={() => {
                onDelete?.(selectedIds);
                setSelected(new Set());
              }}
              className="flex items-center gap-1 rounded-full border border-linkedin-red px-2.5 py-1 text-xs font-medium text-linkedin-red hover:bg-red-50 transition-colors"
            >
              <Trash2 className="h-3 w-3" />
              Delete
            </button>
          </div>
        )}
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-linkedin-gray-20">
              <th className="w-10 px-4 py-2">
                <button
                  type="button"
                  onClick={toggleAll}
                  aria-label="Select all"
                  className="text-linkedin-gray-50 hover:text-linkedin-gray-90 transition-colors"
                >
                  {allSelected ? (
                    <CheckSquare className="h-4 w-4 text-linkedin-blue" />
                  ) : (
                    <Square className="h-4 w-4" />
                  )}
                </button>
              </th>
              <th className="px-4 py-2 text-left text-xs font-semibold text-linkedin-gray-50">
                Name
              </th>
              <th className="px-4 py-2 text-left text-xs font-semibold text-linkedin-gray-50">
                Type
              </th>
              <th className="px-4 py-2 text-left text-xs font-semibold text-linkedin-gray-50">
                Status
              </th>
              <th className="px-4 py-2 text-left text-xs font-semibold text-linkedin-gray-50">
                Chunks
              </th>
              <th className="px-4 py-2 text-left text-xs font-semibold text-linkedin-gray-50">
                Uploaded
              </th>
              <th className="px-4 py-2 text-left text-xs font-semibold text-linkedin-gray-50">
                Size
              </th>
              <th className="w-10 px-4 py-2" />
            </tr>
          </thead>
          <tbody className="divide-y divide-linkedin-gray-20">
            {filteredDocuments.length === 0 ? (
              <tr>
                <td
                  colSpan={8}
                  className="px-4 py-8 text-center"
                >
                  <div className="flex flex-col items-center gap-1">
                    <Inbox className="h-8 w-8 text-linkedin-gray-30" />
                    <p className="text-sm text-linkedin-gray-50">
                      {searchFilter ? "No matching documents" : "No documents uploaded"}
                    </p>
                  </div>
                </td>
              </tr>
            ) : (
              filteredDocuments.map((doc) => {
                const isChecked = selected.has(doc.id);
                const status = statusConfig[doc.status];
                return (
                  <tr
                    key={doc.id}
                    className={cn(
                      "transition-colors hover:bg-linkedin-gray-10",
                      isChecked && "bg-linkedin-blue-bg/30",
                    )}
                  >
                    <td className="px-4 py-2.5">
                      <button
                        type="button"
                        onClick={() => toggleOne(doc.id)}
                        className="text-linkedin-gray-50 hover:text-linkedin-gray-90 transition-colors"
                      >
                        {isChecked ? (
                          <CheckSquare className="h-4 w-4 text-linkedin-blue" />
                        ) : (
                          <Square className="h-4 w-4" />
                        )}
                      </button>
                    </td>
                    <td className="px-4 py-2.5">
                      <div className="flex items-center gap-2">
                        <span className="font-medium text-linkedin-gray-90 truncate">
                          {doc.name}
                        </span>
                      </div>
                    </td>
                    <td className="px-4 py-2.5">
                      <span className="flex items-center gap-1.5">
                        {getTypeIcon(doc.type)}
                        <span className="uppercase text-xs text-linkedin-gray-50">
                          {doc.type}
                        </span>
                      </span>
                    </td>
                    <td className="px-4 py-2.5">
                      <span className={cn("inline-flex items-center rounded-full px-2 py-0.5 text-xs font-medium", status.bg, status.text)}>
                        {status.label}
                      </span>
                    </td>
                    <td className="px-4 py-2.5 text-linkedin-gray-70 tabular-nums">
                      {doc.chunks}
                    </td>
                    <td className="px-4 py-2.5 text-linkedin-gray-70 whitespace-nowrap">
                      {doc.dateUploaded}
                    </td>
                    <td className="px-4 py-2.5 text-linkedin-gray-50 whitespace-nowrap">
                      {doc.size}
                    </td>
                    <td className="px-4 py-2.5">
                      <div className="flex items-center gap-1">
                        <button
                          type="button"
                          onClick={() => onReindex?.([doc.id])}
                          aria-label="Re-index"
                          className="rounded p-1 text-linkedin-gray-50 hover:bg-linkedin-gray-10 hover:text-linkedin-blue transition-colors"
                        >
                          <RefreshCw className="h-3.5 w-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={() => onDelete?.([doc.id])}
                          aria-label="Delete"
                          className="rounded p-1 text-linkedin-gray-50 hover:bg-linkedin-gray-10 hover:text-linkedin-red transition-colors"
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

DocumentList.displayName = "DocumentList";

export { DocumentList };
