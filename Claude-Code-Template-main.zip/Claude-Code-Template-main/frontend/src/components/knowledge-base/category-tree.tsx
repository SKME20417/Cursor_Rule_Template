"use client";

import React, { useState } from "react";
import { cn } from "@/lib/utils/cn";
import {
  ChevronRight,
  ChevronDown,
  Folder,
  FolderOpen,
  Plus,
  Pencil,
  Trash2,
  GripVertical,
} from "lucide-react";

interface CategoryNode {
  id: string;
  name: string;
  articleCount: number;
  children?: CategoryNode[];
}

interface CategoryTreeProps {
  categories: CategoryNode[];
  selectedId?: string;
  isAdmin?: boolean;
  onSelect?: (id: string) => void;
  onAdd?: (parentId: string | null) => void;
  onEdit?: (id: string) => void;
  onDelete?: (id: string) => void;
  className?: string;
}

function CategoryTree({
  categories,
  selectedId,
  isAdmin = false,
  onSelect,
  onAdd,
  onEdit,
  onDelete,
  className,
}: CategoryTreeProps) {
  return (
    <div
      className={cn(
        "rounded-lg border border-linkedin-gray-20 bg-linkedin-white",
        className,
      )}
    >
      <div className="flex items-center justify-between border-b border-linkedin-gray-20 px-4 py-3">
        <h3 className="text-sm font-semibold text-linkedin-gray-90">
          Categories
        </h3>
        {isAdmin && (
          <button
            type="button"
            onClick={() => onAdd?.(null)}
            aria-label="Add category"
            className="flex h-6 w-6 items-center justify-center rounded text-linkedin-gray-50 hover:bg-linkedin-gray-10 hover:text-linkedin-blue transition-colors"
          >
            <Plus className="h-4 w-4" />
          </button>
        )}
      </div>

      <div className="p-2">
        {categories.length === 0 ? (
          <p className="px-2 py-4 text-center text-sm text-linkedin-gray-50">
            No categories yet
          </p>
        ) : (
          <ul className="space-y-0.5">
            {categories.map((node) => (
              <CategoryNodeItem
                key={node.id}
                node={node}
                selectedId={selectedId}
                isAdmin={isAdmin}
                depth={0}
                onSelect={onSelect}
                onAdd={onAdd}
                onEdit={onEdit}
                onDelete={onDelete}
              />
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}

function CategoryNodeItem({
  node,
  selectedId,
  isAdmin,
  depth,
  onSelect,
  onAdd,
  onEdit,
  onDelete,
}: {
  node: CategoryNode;
  selectedId?: string;
  isAdmin: boolean;
  depth: number;
  onSelect?: (id: string) => void;
  onAdd?: (parentId: string | null) => void;
  onEdit?: (id: string) => void;
  onDelete?: (id: string) => void;
}) {
  const [expanded, setExpanded] = useState(depth < 1);
  const hasChildren = node.children && node.children.length > 0;
  const isSelected = node.id === selectedId;

  return (
    <li>
      <div
        className={cn(
          "group flex items-center gap-1 rounded-md px-2 py-1.5 transition-colors",
          isSelected
            ? "bg-linkedin-blue-bg text-linkedin-blue"
            : "text-linkedin-gray-70 hover:bg-linkedin-gray-10",
        )}
        style={{ paddingLeft: `${depth * 16 + 8}px` }}
      >
        {isAdmin && (
          <GripVertical className="h-3.5 w-3.5 flex-shrink-0 cursor-grab text-linkedin-gray-30 opacity-0 group-hover:opacity-100 transition-opacity" />
        )}

        <button
          type="button"
          onClick={() => hasChildren && setExpanded((p) => !p)}
          className="flex-shrink-0 w-4"
        >
          {hasChildren ? (
            expanded ? (
              <ChevronDown className="h-3.5 w-3.5" />
            ) : (
              <ChevronRight className="h-3.5 w-3.5" />
            )
          ) : null}
        </button>

        <button
          type="button"
          onClick={() => onSelect?.(node.id)}
          className="flex flex-1 items-center gap-1.5 min-w-0"
        >
          {expanded && hasChildren ? (
            <FolderOpen className="h-4 w-4 flex-shrink-0 text-linkedin-blue" />
          ) : (
            <Folder className="h-4 w-4 flex-shrink-0" />
          )}
          <span className="truncate text-sm">{node.name}</span>
          <span className="ml-auto flex-shrink-0 rounded-full bg-linkedin-gray-10 px-1.5 py-0.5 text-xs text-linkedin-gray-50 tabular-nums">
            {node.articleCount}
          </span>
        </button>

        {isAdmin && (
          <div className="flex items-center gap-0.5 opacity-0 group-hover:opacity-100 transition-opacity">
            <button
              type="button"
              onClick={() => onAdd?.(node.id)}
              aria-label="Add subcategory"
              className="rounded p-0.5 text-linkedin-gray-50 hover:text-linkedin-blue"
            >
              <Plus className="h-3 w-3" />
            </button>
            <button
              type="button"
              onClick={() => onEdit?.(node.id)}
              aria-label="Edit category"
              className="rounded p-0.5 text-linkedin-gray-50 hover:text-linkedin-blue"
            >
              <Pencil className="h-3 w-3" />
            </button>
            <button
              type="button"
              onClick={() => onDelete?.(node.id)}
              aria-label="Delete category"
              className="rounded p-0.5 text-linkedin-gray-50 hover:text-linkedin-red"
            >
              <Trash2 className="h-3 w-3" />
            </button>
          </div>
        )}
      </div>

      {expanded && hasChildren && (
        <ul className="space-y-0.5">
          {node.children!.map((child) => (
            <CategoryNodeItem
              key={child.id}
              node={child}
              selectedId={selectedId}
              isAdmin={isAdmin}
              depth={depth + 1}
              onSelect={onSelect}
              onAdd={onAdd}
              onEdit={onEdit}
              onDelete={onDelete}
            />
          ))}
        </ul>
      )}
    </li>
  );
}

CategoryTree.displayName = "CategoryTree";

export { CategoryTree };
export type { CategoryNode };
