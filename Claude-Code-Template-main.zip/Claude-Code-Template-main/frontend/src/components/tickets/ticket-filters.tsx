"use client";

import React, { useState } from "react";
import { cn } from "@/lib/utils/cn";
import { Filter, X, ChevronDown, ChevronUp } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";

interface TicketFiltersProps {
  filters: {
    statuses: string[];
    priorities: string[];
    assignee: string;
    channel: string;
    dateFrom: string;
    dateTo: string;
  };
  onChange: (filters: TicketFiltersProps["filters"]) => void;
  assigneeOptions?: { value: string; label: string }[];
  className?: string;
}

const STATUS_OPTIONS = [
  { value: "created", label: "Created" },
  { value: "assigned", label: "Assigned" },
  { value: "in_progress", label: "In Progress" },
  { value: "resolved", label: "Resolved" },
  { value: "closed", label: "Closed" },
];

const PRIORITY_OPTIONS = [
  { value: "critical", label: "Critical" },
  { value: "high", label: "High" },
  { value: "medium", label: "Medium" },
  { value: "low", label: "Low" },
];

const CHANNEL_OPTIONS = [
  { value: "", label: "All Channels" },
  { value: "email", label: "Email" },
  { value: "chat", label: "Chat" },
  { value: "phone", label: "Phone" },
  { value: "whatsapp", label: "WhatsApp" },
  { value: "web", label: "Web" },
];

function toggleArrayValue(arr: string[], value: string): string[] {
  return arr.includes(value)
    ? arr.filter((v) => v !== value)
    : [...arr, value];
}

export function TicketFilters({
  filters,
  onChange,
  assigneeOptions = [],
  className,
}: TicketFiltersProps) {
  const [collapsed, setCollapsed] = useState(false);

  const hasActiveFilters =
    filters.statuses.length > 0 ||
    filters.priorities.length > 0 ||
    filters.assignee !== "" ||
    filters.channel !== "" ||
    filters.dateFrom !== "" ||
    filters.dateTo !== "";

  function handleClearAll() {
    onChange({
      statuses: [],
      priorities: [],
      assignee: "",
      channel: "",
      dateFrom: "",
      dateTo: "",
    });
  }

  return (
    <div
      className={cn(
        "rounded-lg border border-linkedin-gray-20 bg-linkedin-white",
        className,
      )}
    >
      {/* Toggle header */}
      <button
        type="button"
        onClick={() => setCollapsed(!collapsed)}
        className="flex w-full items-center justify-between px-4 py-3 text-sm font-medium text-linkedin-gray-90 md:hidden"
      >
        <span className="flex items-center gap-2">
          <Filter className="h-4 w-4" />
          Filters
          {hasActiveFilters && (
            <span className="flex h-5 w-5 items-center justify-center rounded-full bg-linkedin-blue text-[10px] text-linkedin-white">
              !
            </span>
          )}
        </span>
        {collapsed ? (
          <ChevronDown className="h-4 w-4" />
        ) : (
          <ChevronUp className="h-4 w-4" />
        )}
      </button>

      {/* Filter body */}
      <div
        className={cn(
          "space-y-4 px-4 pb-4 pt-3",
          collapsed && "hidden md:block",
        )}
      >
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
          {/* Status multi-select */}
          <div>
            <p className="mb-1.5 text-xs font-medium text-linkedin-gray-70">
              Status
            </p>
            <div className="space-y-1">
              {STATUS_OPTIONS.map((opt) => (
                <Checkbox
                  key={opt.value}
                  label={opt.label}
                  checked={filters.statuses.includes(opt.value)}
                  onChange={() =>
                    onChange({
                      ...filters,
                      statuses: toggleArrayValue(filters.statuses, opt.value),
                    })
                  }
                />
              ))}
            </div>
          </div>

          {/* Priority multi-select */}
          <div>
            <p className="mb-1.5 text-xs font-medium text-linkedin-gray-70">
              Priority
            </p>
            <div className="space-y-1">
              {PRIORITY_OPTIONS.map((opt) => (
                <Checkbox
                  key={opt.value}
                  label={opt.label}
                  checked={filters.priorities.includes(opt.value)}
                  onChange={() =>
                    onChange({
                      ...filters,
                      priorities: toggleArrayValue(
                        filters.priorities,
                        opt.value,
                      ),
                    })
                  }
                />
              ))}
            </div>
          </div>

          {/* Assignee */}
          <div>
            <p className="mb-1.5 text-xs font-medium text-linkedin-gray-70">
              Assignee
            </p>
            <select
              value={filters.assignee}
              onChange={(e) =>
                onChange({ ...filters, assignee: e.target.value })
              }
              className="w-full rounded-lg border border-linkedin-gray-30 bg-linkedin-white px-3 py-2 text-sm text-linkedin-gray-90"
            >
              <option value="">All Assignees</option>
              {assigneeOptions.map((opt) => (
                <option key={opt.value} value={opt.value}>
                  {opt.label}
                </option>
              ))}
            </select>
          </div>

          {/* Channel */}
          <div>
            <p className="mb-1.5 text-xs font-medium text-linkedin-gray-70">
              Channel
            </p>
            <select
              value={filters.channel}
              onChange={(e) =>
                onChange({ ...filters, channel: e.target.value })
              }
              className="w-full rounded-lg border border-linkedin-gray-30 bg-linkedin-white px-3 py-2 text-sm text-linkedin-gray-90"
            >
              {CHANNEL_OPTIONS.map((opt) => (
                <option key={opt.value} value={opt.value}>
                  {opt.label}
                </option>
              ))}
            </select>
          </div>

          {/* Date range */}
          <div>
            <p className="mb-1.5 text-xs font-medium text-linkedin-gray-70">
              Date Range
            </p>
            <div className="space-y-1.5">
              <input
                type="date"
                value={filters.dateFrom}
                onChange={(e) =>
                  onChange({ ...filters, dateFrom: e.target.value })
                }
                className="w-full rounded-lg border border-linkedin-gray-30 bg-linkedin-white px-3 py-1.5 text-sm text-linkedin-gray-90"
                placeholder="From"
              />
              <input
                type="date"
                value={filters.dateTo}
                onChange={(e) =>
                  onChange({ ...filters, dateTo: e.target.value })
                }
                className="w-full rounded-lg border border-linkedin-gray-30 bg-linkedin-white px-3 py-1.5 text-sm text-linkedin-gray-90"
                placeholder="To"
              />
            </div>
          </div>
        </div>

        {/* Clear all */}
        {hasActiveFilters && (
          <div className="flex justify-end">
            <Button
              variant="ghost"
              size="sm"
              onClick={handleClearAll}
              iconLeft={<X className="h-3 w-3" />}
            >
              Clear all
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}
