"use client";

import React from "react";
import { cn } from "@/lib/utils/cn";
import { Clock } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Avatar } from "@/components/ui/avatar";
import { TicketStatusBadge } from "./ticket-status-badge";
import { TicketPriorityBadge } from "./ticket-priority-badge";
import { SlaIndicator } from "./sla-indicator";
import { ChannelBadge } from "@/components/chat/channel-badge";
import { formatRelativeTime } from "@/lib/utils/format-date";

interface TicketCardProps {
  ticket: {
    id: string;
    shortId: string;
    subject: string;
    status: "created" | "assigned" | "in_progress" | "resolved" | "closed";
    priority: "critical" | "high" | "medium" | "low";
    customerName: string;
    customerAvatar?: string;
    assignee?: string;
    lastActivity: string;
    slaDeadline?: string;
    channel: string;
  };
  onClick?: () => void;
  className?: string;
}

export function TicketCard({ ticket, onClick, className }: TicketCardProps) {
  return (
    <Card
      hover
      padding="none"
      className={cn("cursor-pointer", className)}
      onClick={onClick}
    >
      <div className="p-4">
        {/* Header row */}
        <div className="flex items-start justify-between gap-2">
          <div className="min-w-0 flex-1">
            <h3 className="truncate text-sm font-semibold text-linkedin-gray-90">
              {ticket.subject}
            </h3>
            <p className="mt-0.5 text-xs text-linkedin-gray-50">
              #{ticket.shortId}
            </p>
          </div>
          <TicketPriorityBadge priority={ticket.priority} />
        </div>

        {/* Customer + assignee row */}
        <div className="mt-3 flex items-center gap-3">
          <div className="flex items-center gap-2 min-w-0">
            <Avatar
              name={ticket.customerName}
              src={ticket.customerAvatar}
              size="xs"
            />
            <span className="truncate text-xs text-linkedin-gray-70">
              {ticket.customerName}
            </span>
          </div>
          {ticket.assignee && (
            <span className="text-xs text-linkedin-gray-50">
              &rarr; {ticket.assignee}
            </span>
          )}
        </div>

        {/* Footer row */}
        <div className="mt-3 flex flex-wrap items-center gap-2">
          <TicketStatusBadge status={ticket.status} />
          <ChannelBadge channel={ticket.channel} />
          {ticket.slaDeadline && (
            <SlaIndicator deadlineIso={ticket.slaDeadline} />
          )}
          <span className="ml-auto flex items-center gap-1 text-xs text-linkedin-gray-50">
            <Clock className="h-3 w-3" aria-hidden="true" />
            {formatRelativeTime(ticket.lastActivity)}
          </span>
        </div>
      </div>
    </Card>
  );
}
