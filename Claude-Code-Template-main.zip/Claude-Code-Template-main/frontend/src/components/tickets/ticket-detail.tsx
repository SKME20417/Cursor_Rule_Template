"use client";

import React, { useState } from "react";
import { cn } from "@/lib/utils/cn";
import {
  UserPlus,
  RefreshCw,
  ArrowUpDown,
  GitMerge,
  XCircle,
  Tag,
  Calendar,
  StickyNote,
  Send,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { TicketStatusBadge } from "./ticket-status-badge";
import { TicketPriorityBadge } from "./ticket-priority-badge";
import { SlaIndicator } from "./sla-indicator";
import { TicketTimeline } from "./ticket-timeline";
import { formatDate } from "@/lib/utils/format-date";

interface TimelineEvent {
  id: string;
  type:
    | "created"
    | "assigned"
    | "status_changed"
    | "message_sent"
    | "note_added"
    | "escalated"
    | "resolved";
  description: string;
  actor: string;
  timestamp: string;
}

interface TicketDetailProps {
  ticket: {
    id: string;
    shortId: string;
    subject: string;
    status: "created" | "assigned" | "in_progress" | "resolved" | "closed";
    priority: "critical" | "high" | "medium" | "low";
    assignee?: string;
    category?: string;
    tags?: string[];
    slaDeadline?: string;
    createdAt: string;
    updatedAt: string;
    timeline: TimelineEvent[];
  };
  onAssign?: () => void;
  onChangeStatus?: () => void;
  onChangePriority?: () => void;
  onMerge?: () => void;
  onClose?: () => void;
  onAddNote?: (note: string) => void;
  className?: string;
}

export function TicketDetail({
  ticket,
  onAssign,
  onChangeStatus,
  onChangePriority,
  onMerge,
  onClose,
  onAddNote,
  className,
}: TicketDetailProps) {
  const [noteText, setNoteText] = useState("");
  const [showNotes, setShowNotes] = useState(false);

  function handleSubmitNote() {
    if (!noteText.trim()) return;
    onAddNote?.(noteText.trim());
    setNoteText("");
    setShowNotes(false);
  }

  return (
    <div className={cn("flex flex-col gap-6 lg:flex-row", className)}>
      {/* Left column - conversation / timeline */}
      <div className="flex-1 min-w-0">
        {/* Header */}
        <div className="mb-4">
          <p className="text-xs font-mono text-linkedin-gray-50 mb-1">
            #{ticket.shortId}
          </p>
          <h1 className="text-xl font-semibold text-linkedin-gray-90">
            {ticket.subject}
          </h1>
          <div className="mt-2 flex flex-wrap items-center gap-2">
            <TicketStatusBadge status={ticket.status} />
            <TicketPriorityBadge priority={ticket.priority} />
            {ticket.assignee && (
              <span className="text-sm text-linkedin-gray-70">
                Assigned to{" "}
                <span className="font-medium">{ticket.assignee}</span>
              </span>
            )}
          </div>
        </div>

        {/* Action buttons */}
        <div className="mb-6 flex flex-wrap gap-2 border-b border-linkedin-gray-20 pb-4">
          <Button
            variant="secondary"
            size="sm"
            iconLeft={<UserPlus className="h-3.5 w-3.5" />}
            onClick={onAssign}
          >
            Assign
          </Button>
          <Button
            variant="secondary"
            size="sm"
            iconLeft={<RefreshCw className="h-3.5 w-3.5" />}
            onClick={onChangeStatus}
          >
            Status
          </Button>
          <Button
            variant="secondary"
            size="sm"
            iconLeft={<ArrowUpDown className="h-3.5 w-3.5" />}
            onClick={onChangePriority}
          >
            Priority
          </Button>
          <Button
            variant="secondary"
            size="sm"
            iconLeft={<GitMerge className="h-3.5 w-3.5" />}
            onClick={onMerge}
          >
            Merge
          </Button>
          <Button
            variant="danger"
            size="sm"
            iconLeft={<XCircle className="h-3.5 w-3.5" />}
            onClick={onClose}
          >
            Close
          </Button>
        </div>

        {/* Timeline */}
        <TicketTimeline events={ticket.timeline} />

        {/* Internal notes */}
        <div className="mt-6 border-t border-linkedin-gray-20 pt-4">
          <button
            type="button"
            onClick={() => setShowNotes(!showNotes)}
            className="flex items-center gap-2 text-sm font-medium text-linkedin-gray-70 hover:text-linkedin-gray-90 transition-colors"
          >
            <StickyNote className="h-4 w-4" />
            Internal Notes
          </button>

          {showNotes && (
            <div className="mt-3 space-y-3">
              <Textarea
                placeholder="Add an internal note (visible to agents only)..."
                value={noteText}
                onChange={(e) => setNoteText(e.target.value)}
                rows={3}
              />
              <div className="flex justify-end">
                <Button
                  size="sm"
                  onClick={handleSubmitNote}
                  disabled={!noteText.trim()}
                  iconLeft={<Send className="h-3.5 w-3.5" />}
                >
                  Add Note
                </Button>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Right column - metadata */}
      <aside className="w-full shrink-0 lg:w-72">
        <div className="rounded-lg border border-linkedin-gray-20 bg-linkedin-white p-4 space-y-4">
          <h3 className="text-sm font-semibold text-linkedin-gray-90">
            Details
          </h3>

          {/* Category */}
          {ticket.category && (
            <div>
              <p className="text-xs font-medium text-linkedin-gray-50 mb-1">
                Category
              </p>
              <Badge variant="info" size="md">
                {ticket.category}
              </Badge>
            </div>
          )}

          {/* Tags */}
          {ticket.tags && ticket.tags.length > 0 && (
            <div>
              <p className="text-xs font-medium text-linkedin-gray-50 mb-1">
                <Tag className="mr-1 inline h-3 w-3" />
                Tags
              </p>
              <div className="flex flex-wrap gap-1">
                {ticket.tags.map((tag) => (
                  <Badge key={tag} variant="default" size="sm">
                    {tag}
                  </Badge>
                ))}
              </div>
            </div>
          )}

          {/* SLA */}
          {ticket.slaDeadline && (
            <div>
              <p className="text-xs font-medium text-linkedin-gray-50 mb-1">
                SLA
              </p>
              <SlaIndicator deadlineIso={ticket.slaDeadline} />
            </div>
          )}

          {/* Created */}
          <div>
            <p className="text-xs font-medium text-linkedin-gray-50 mb-1">
              <Calendar className="mr-1 inline h-3 w-3" />
              Created
            </p>
            <p className="text-sm text-linkedin-gray-70">
              {formatDate(ticket.createdAt, "MMM d, yyyy h:mm a")}
            </p>
          </div>

          {/* Updated */}
          <div>
            <p className="text-xs font-medium text-linkedin-gray-50 mb-1">
              Last Updated
            </p>
            <p className="text-sm text-linkedin-gray-70">
              {formatDate(ticket.updatedAt, "MMM d, yyyy h:mm a")}
            </p>
          </div>
        </div>
      </aside>
    </div>
  );
}
