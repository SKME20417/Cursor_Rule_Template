"use client";

import React, { useState, useMemo } from "react";
import { cn } from "@/lib/utils/cn";
import { ArrowUpDown, ArrowUp, ArrowDown } from "lucide-react";
import { Checkbox } from "@/components/ui/checkbox";
import { Avatar } from "@/components/ui/avatar";
import { TicketStatusBadge } from "./ticket-status-badge";
import { TicketPriorityBadge } from "./ticket-priority-badge";
import { SlaIndicator } from "./sla-indicator";
import { TicketCard } from "./ticket-card";
import { formatDate } from "@/lib/utils/format-date";

interface TicketRow {
  id: string;
  shortId: string;
  subject: string;
  customerName: string;
  customerAvatar?: string;
  status: "created" | "assigned" | "in_progress" | "resolved" | "closed";
  priority: "critical" | "high" | "medium" | "low";
  assignee?: string;
  createdAt: string;
  slaDeadline?: string;
  lastActivity: string;
  channel: string;
}

interface TicketListProps {
  tickets: TicketRow[];
  loading?: boolean;
  selectedIds?: string[];
  onSelectionChange?: (ids: string[]) => void;
  onRowClick?: (ticketId: string) => void;
  className?: string;
}

type SortField = "shortId" | "subject" | "customerName" | "status" | "priority" | "assignee" | "createdAt" | "slaDeadline";
type SortDir = "asc" | "desc";

const PRIORITY_ORDER: Record<string, number> = {
  critical: 0,
  high: 1,
  medium: 2,
  low: 3,
};

function SkeletonRow() {
  return (
    <tr className="animate-pulse border-b border-linkedin-gray-20">
      <td className="px-3 py-3"><div className="h-5 w-5 rounded bg-linkedin-gray-20" /></td>
      <td className="px-3 py-3"><div className="h-4 w-14 rounded bg-linkedin-gray-20" /></td>
      <td className="px-3 py-3"><div className="h-4 w-40 rounded bg-linkedin-gray-20" /></td>
      <td className="px-3 py-3"><div className="h-4 w-24 rounded bg-linkedin-gray-20" /></td>
      <td className="px-3 py-3"><div className="h-5 w-20 rounded-full bg-linkedin-gray-20" /></td>
      <td className="px-3 py-3"><div className="h-5 w-16 rounded-full bg-linkedin-gray-20" /></td>
      <td className="px-3 py-3"><div className="h-4 w-20 rounded bg-linkedin-gray-20" /></td>
      <td className="px-3 py-3"><div className="h-4 w-20 rounded bg-linkedin-gray-20" /></td>
      <td className="px-3 py-3"><div className="h-5 w-16 rounded-full bg-linkedin-gray-20" /></td>
    </tr>
  );
}

export function TicketList({
  tickets,
  loading = false,
  selectedIds = [],
  onSelectionChange,
  onRowClick,
  className,
}: TicketListProps) {
  const [sortField, setSortField] = useState<SortField>("createdAt");
  const [sortDir, setSortDir] = useState<SortDir>("desc");

  function toggleSort(field: SortField) {
    if (sortField === field) {
      setSortDir((d) => (d === "asc" ? "desc" : "asc"));
    } else {
      setSortField(field);
      setSortDir("asc");
    }
  }

  const sorted = useMemo(() => {
    const copy = [...tickets];
    copy.sort((a, b) => {
      let cmp = 0;
      const fa = a[sortField] ?? "";
      const fb = b[sortField] ?? "";

      if (sortField === "priority") {
        cmp = (PRIORITY_ORDER[fa] ?? 2) - (PRIORITY_ORDER[fb] ?? 2);
      } else {
        cmp = String(fa).localeCompare(String(fb));
      }

      return sortDir === "desc" ? -cmp : cmp;
    });
    return copy;
  }, [tickets, sortField, sortDir]);

  const allSelected =
    tickets.length > 0 && selectedIds.length === tickets.length;

  function handleSelectAll() {
    if (!onSelectionChange) return;
    if (allSelected) {
      onSelectionChange([]);
    } else {
      onSelectionChange(tickets.map((t) => t.id));
    }
  }

  function handleToggleRow(id: string) {
    if (!onSelectionChange) return;
    if (selectedIds.includes(id)) {
      onSelectionChange(selectedIds.filter((s) => s !== id));
    } else {
      onSelectionChange([...selectedIds, id]);
    }
  }

  function SortHeader({
    label,
    field,
  }: {
    label: string;
    field: SortField;
  }) {
    const active = sortField === field;
    return (
      <button
        type="button"
        onClick={() => toggleSort(field)}
        className="inline-flex items-center gap-1 text-xs font-medium uppercase tracking-wide text-linkedin-gray-50 hover:text-linkedin-gray-90 transition-colors"
      >
        {label}
        {active ? (
          sortDir === "asc" ? (
            <ArrowUp className="h-3 w-3" />
          ) : (
            <ArrowDown className="h-3 w-3" />
          )
        ) : (
          <ArrowUpDown className="h-3 w-3 opacity-40" />
        )}
      </button>
    );
  }

  /* ---- Mobile card view ---- */
  const mobileView = (
    <div className="space-y-3 md:hidden">
      {loading
        ? Array.from({ length: 5 }).map((_, i) => (
            <div
              key={i}
              className="animate-pulse rounded-lg border border-linkedin-gray-20 bg-linkedin-white p-4"
            >
              <div className="h-4 w-3/4 rounded bg-linkedin-gray-20" />
              <div className="mt-2 h-3 w-1/2 rounded bg-linkedin-gray-20" />
              <div className="mt-3 flex gap-2">
                <div className="h-5 w-16 rounded-full bg-linkedin-gray-20" />
                <div className="h-5 w-14 rounded-full bg-linkedin-gray-20" />
              </div>
            </div>
          ))
        : sorted.map((ticket) => (
            <TicketCard
              key={ticket.id}
              ticket={ticket}
              onClick={() => onRowClick?.(ticket.id)}
            />
          ))}
    </div>
  );

  /* ---- Desktop table view ---- */
  const tableView = (
    <div className="hidden overflow-x-auto md:block">
      <table className="w-full text-left">
        <thead>
          <tr className="border-b border-linkedin-gray-20 bg-linkedin-gray-10">
            {onSelectionChange && (
              <th className="px-3 py-2.5 w-10">
                <Checkbox
                  checked={allSelected}
                  onChange={handleSelectAll}
                  aria-label="Select all tickets"
                />
              </th>
            )}
            <th className="px-3 py-2.5"><SortHeader label="ID" field="shortId" /></th>
            <th className="px-3 py-2.5"><SortHeader label="Subject" field="subject" /></th>
            <th className="px-3 py-2.5"><SortHeader label="Customer" field="customerName" /></th>
            <th className="px-3 py-2.5"><SortHeader label="Status" field="status" /></th>
            <th className="px-3 py-2.5"><SortHeader label="Priority" field="priority" /></th>
            <th className="px-3 py-2.5"><SortHeader label="Assignee" field="assignee" /></th>
            <th className="px-3 py-2.5"><SortHeader label="Created" field="createdAt" /></th>
            <th className="px-3 py-2.5">SLA</th>
          </tr>
        </thead>
        <tbody>
          {loading
            ? Array.from({ length: 5 }).map((_, i) => (
                <SkeletonRow key={i} />
              ))
            : sorted.map((ticket) => (
                <tr
                  key={ticket.id}
                  onClick={() => onRowClick?.(ticket.id)}
                  className={cn(
                    "border-b border-linkedin-gray-20 transition-colors hover:bg-linkedin-gray-10 cursor-pointer",
                    selectedIds.includes(ticket.id) && "bg-linkedin-blue-bg",
                  )}
                >
                  {onSelectionChange && (
                    <td className="px-3 py-2.5" onClick={(e) => e.stopPropagation()}>
                      <Checkbox
                        checked={selectedIds.includes(ticket.id)}
                        onChange={() => handleToggleRow(ticket.id)}
                        aria-label={`Select ticket ${ticket.shortId}`}
                      />
                    </td>
                  )}
                  <td className="px-3 py-2.5 text-xs font-mono text-linkedin-gray-50">
                    #{ticket.shortId}
                  </td>
                  <td className="px-3 py-2.5 text-sm font-medium text-linkedin-gray-90 max-w-[240px] truncate">
                    {ticket.subject}
                  </td>
                  <td className="px-3 py-2.5">
                    <div className="flex items-center gap-2">
                      <Avatar
                        name={ticket.customerName}
                        src={ticket.customerAvatar}
                        size="xs"
                      />
                      <span className="text-sm text-linkedin-gray-70">
                        {ticket.customerName}
                      </span>
                    </div>
                  </td>
                  <td className="px-3 py-2.5">
                    <TicketStatusBadge status={ticket.status} />
                  </td>
                  <td className="px-3 py-2.5">
                    <TicketPriorityBadge priority={ticket.priority} />
                  </td>
                  <td className="px-3 py-2.5 text-sm text-linkedin-gray-70">
                    {ticket.assignee ?? "Unassigned"}
                  </td>
                  <td className="px-3 py-2.5 text-xs text-linkedin-gray-50">
                    {formatDate(ticket.createdAt)}
                  </td>
                  <td className="px-3 py-2.5">
                    {ticket.slaDeadline ? (
                      <SlaIndicator deadlineIso={ticket.slaDeadline} />
                    ) : (
                      <span className="text-xs text-linkedin-gray-50">&mdash;</span>
                    )}
                  </td>
                </tr>
              ))}
        </tbody>
      </table>

      {!loading && tickets.length === 0 && (
        <div className="py-12 text-center text-sm text-linkedin-gray-50">
          No tickets found.
        </div>
      )}
    </div>
  );

  return (
    <div className={className}>
      {mobileView}
      {tableView}
    </div>
  );
}
