"use client";

import React, { useState, useCallback } from "react";
import { cn } from "@/lib/utils/cn";
import { Paperclip, X, Send } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select } from "@/components/ui/select";
import { Button } from "@/components/ui/button";

interface TicketFormData {
  subject: string;
  description: string;
  category: string;
  priority: string;
  channel: string;
  attachments: File[];
}

interface TicketFormProps {
  initialData?: Partial<TicketFormData>;
  onSubmit: (data: TicketFormData) => void;
  loading?: boolean;
  mode?: "create" | "edit";
  className?: string;
}

interface FormErrors {
  subject?: string;
  description?: string;
  category?: string;
}

const CATEGORY_OPTIONS = [
  { value: "billing", label: "Billing" },
  { value: "technical", label: "Technical Support" },
  { value: "account", label: "Account" },
  { value: "feature_request", label: "Feature Request" },
  { value: "bug", label: "Bug Report" },
  { value: "other", label: "Other" },
];

const PRIORITY_OPTIONS = [
  { value: "low", label: "Low" },
  { value: "medium", label: "Medium" },
  { value: "high", label: "High" },
  { value: "critical", label: "Critical" },
];

const CHANNEL_OPTIONS = [
  { value: "web", label: "Web" },
  { value: "email", label: "Email" },
  { value: "chat", label: "Chat" },
  { value: "phone", label: "Phone" },
];

function validate(data: TicketFormData): FormErrors {
  const errors: FormErrors = {};
  if (!data.subject.trim()) errors.subject = "Subject is required.";
  if (data.subject.length > 200) errors.subject = "Subject must be under 200 characters.";
  if (!data.description.trim()) errors.description = "Description is required.";
  if (!data.category) errors.category = "Please select a category.";
  return errors;
}

export function TicketForm({
  initialData,
  onSubmit,
  loading = false,
  mode = "create",
  className,
}: TicketFormProps) {
  const [data, setData] = useState<TicketFormData>({
    subject: initialData?.subject ?? "",
    description: initialData?.description ?? "",
    category: initialData?.category ?? "",
    priority: initialData?.priority ?? "medium",
    channel: initialData?.channel ?? "web",
    attachments: initialData?.attachments ?? [],
  });
  const [errors, setErrors] = useState<FormErrors>({});

  const update = useCallback(
    <K extends keyof TicketFormData>(field: K, value: TicketFormData[K]) => {
      setData((prev) => ({ ...prev, [field]: value }));
      setErrors((prev) => ({ ...prev, [field]: undefined }));
    },
    [],
  );

  function handleFileChange(e: React.ChangeEvent<HTMLInputElement>) {
    const files = Array.from(e.target.files ?? []);
    update("attachments", [...data.attachments, ...files]);
    e.target.value = "";
  }

  function removeAttachment(index: number) {
    update(
      "attachments",
      data.attachments.filter((_, i) => i !== index),
    );
  }

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const formErrors = validate(data);
    if (Object.keys(formErrors).length > 0) {
      setErrors(formErrors);
      return;
    }
    onSubmit(data);
  }

  return (
    <form
      onSubmit={handleSubmit}
      className={cn("space-y-5", className)}
      noValidate
    >
      <Input
        label="Subject"
        placeholder="Brief summary of the issue"
        value={data.subject}
        onChange={(e) => update("subject", e.target.value)}
        error={errors.subject}
        required
      />

      <Textarea
        label="Description"
        placeholder="Describe your issue in detail..."
        value={data.description}
        onChange={(e) => update("description", e.target.value)}
        error={errors.description}
        rows={5}
        maxCharacters={5000}
        required
      />

      <div className="grid gap-4 sm:grid-cols-3">
        <Select
          label="Category"
          options={CATEGORY_OPTIONS}
          placeholder="Select category"
          value={data.category}
          onChange={(e) => update("category", e.target.value)}
          error={errors.category}
        />

        <Select
          label="Priority"
          options={PRIORITY_OPTIONS}
          value={data.priority}
          onChange={(e) => update("priority", e.target.value)}
        />

        <Select
          label="Channel"
          options={CHANNEL_OPTIONS}
          value={data.channel}
          onChange={(e) => update("channel", e.target.value)}
        />
      </div>

      {/* Attachments */}
      <div>
        <p className="mb-1.5 text-sm font-medium text-linkedin-gray-90">
          Attachments
        </p>
        <label className="inline-flex cursor-pointer items-center gap-2 rounded-lg border border-dashed border-linkedin-gray-30 px-4 py-3 text-sm text-linkedin-gray-50 hover:border-linkedin-blue hover:text-linkedin-blue transition-colors">
          <Paperclip className="h-4 w-4" />
          Choose files
          <input
            type="file"
            multiple
            className="sr-only"
            onChange={handleFileChange}
          />
        </label>

        {data.attachments.length > 0 && (
          <ul className="mt-2 space-y-1">
            {data.attachments.map((file, i) => (
              <li
                key={`${file.name}-${i}`}
                className="flex items-center gap-2 text-sm text-linkedin-gray-70"
              >
                <Paperclip className="h-3 w-3 shrink-0" />
                <span className="truncate">{file.name}</span>
                <button
                  type="button"
                  onClick={() => removeAttachment(i)}
                  className="ml-auto shrink-0 rounded-full p-0.5 text-linkedin-gray-50 hover:text-linkedin-red transition-colors"
                  aria-label={`Remove ${file.name}`}
                >
                  <X className="h-3.5 w-3.5" />
                </button>
              </li>
            ))}
          </ul>
        )}
      </div>

      <div className="flex justify-end">
        <Button
          type="submit"
          loading={loading}
          iconLeft={<Send className="h-4 w-4" />}
        >
          {mode === "create" ? "Submit Ticket" : "Update Ticket"}
        </Button>
      </div>
    </form>
  );
}
