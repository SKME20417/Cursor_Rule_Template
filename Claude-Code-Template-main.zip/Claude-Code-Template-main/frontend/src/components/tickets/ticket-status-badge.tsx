"use client";

import React from "react";
import { cn } from "@/lib/utils/cn";

interface TicketStatusBadgeProps {
  status: "created" | "assigned" | "in_progress" | "resolved" | "closed";
  className?: string;
}

const STATUS_CONFIG: Record<
  string,
  { label: string; dotColor: string; bgColor: string; textColor: string }
> = {
  created: {
    label: "Created",
    dotColor: "bg-linkedin-gray-50",
    bgColor: "bg-linkedin-gray-20",
    textColor: "text-linkedin-gray-70",
  },
  assigned: {
    label: "Assigned",
    dotColor: "bg-linkedin-blue",
    bgColor: "bg-linkedin-blue-bg",
    textColor: "text-linkedin-blue",
  },
  in_progress: {
    label: "In Progress",
    dotColor: "bg-yellow-500",
    bgColor: "bg-yellow-50",
    textColor: "text-yellow-700",
  },
  resolved: {
    label: "Resolved",
    dotColor: "bg-linkedin-green",
    bgColor: "bg-green-50",
    textColor: "text-linkedin-green",
  },
  closed: {
    label: "Closed",
    dotColor: "bg-linkedin-gray-70",
    bgColor: "bg-linkedin-gray-20",
    textColor: "text-linkedin-gray-90",
  },
};

export function TicketStatusBadge({ status, className }: TicketStatusBadgeProps) {
  const config = STATUS_CONFIG[status] ?? STATUS_CONFIG.created;

  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full px-2.5 py-0.5 text-xs font-medium",
        config.bgColor,
        config.textColor,
        className,
      )}
    >
      <span
        className={cn("h-1.5 w-1.5 rounded-full", config.dotColor)}
        aria-hidden="true"
      />
      {config.label}
    </span>
  );
}
