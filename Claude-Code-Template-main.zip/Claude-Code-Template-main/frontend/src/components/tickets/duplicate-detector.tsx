"use client";

import React from "react";
import { cn } from "@/lib/utils/cn";
import { Copy, Eye, XCircle, Link2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { TicketStatusBadge } from "./ticket-status-badge";

interface DuplicateCandidate {
  ticketId: string;
  shortId: string;
  subject: string;
  status: "created" | "assigned" | "in_progress" | "resolved" | "closed";
  confidence: number;
}

interface DuplicateDetectorProps {
  candidates: DuplicateCandidate[];
  onView?: (ticketId: string) => void;
  onLinkDuplicate?: (ticketId: string) => void;
  onDismiss?: (ticketId: string) => void;
  className?: string;
}

export function DuplicateDetector({
  candidates,
  onView,
  onLinkDuplicate,
  onDismiss,
  className,
}: DuplicateDetectorProps) {
  if (candidates.length === 0) return null;

  return (
    <Card padding="none" className={className}>
      <div className="border-b border-linkedin-gray-20 px-4 py-3">
        <h3 className="flex items-center gap-2 text-sm font-semibold text-linkedin-gray-90">
          <Copy className="h-4 w-4 text-linkedin-orange" />
          Potential Duplicates
          <span className="rounded-full bg-linkedin-orange px-1.5 py-0.5 text-[10px] font-bold text-linkedin-white">
            {candidates.length}
          </span>
        </h3>
      </div>

      <ul className="divide-y divide-linkedin-gray-20">
        {candidates.map((candidate) => (
          <li key={candidate.ticketId} className="px-4 py-3">
            <div className="flex items-start justify-between gap-2">
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-medium text-linkedin-gray-90">
                  {candidate.subject}
                </p>
                <div className="mt-1 flex items-center gap-2">
                  <span className="text-xs font-mono text-linkedin-gray-50">
                    #{candidate.shortId}
                  </span>
                  <TicketStatusBadge status={candidate.status} />
                </div>
              </div>
              <span
                className={cn(
                  "shrink-0 rounded-full px-2 py-0.5 text-xs font-bold",
                  candidate.confidence >= 0.8
                    ? "bg-red-50 text-linkedin-red"
                    : candidate.confidence >= 0.6
                      ? "bg-orange-50 text-linkedin-orange"
                      : "bg-yellow-50 text-yellow-700",
                )}
              >
                {Math.round(candidate.confidence * 100)}%
              </span>
            </div>

            <div className="mt-2 flex gap-2">
              <Button
                variant="ghost"
                size="sm"
                iconLeft={<Eye className="h-3 w-3" />}
                onClick={() => onView?.(candidate.ticketId)}
              >
                View
              </Button>
              <Button
                variant="secondary"
                size="sm"
                iconLeft={<Link2 className="h-3 w-3" />}
                onClick={() => onLinkDuplicate?.(candidate.ticketId)}
              >
                Link
              </Button>
              <Button
                variant="ghost"
                size="sm"
                iconLeft={<XCircle className="h-3 w-3" />}
                onClick={() => onDismiss?.(candidate.ticketId)}
              >
                Dismiss
              </Button>
            </div>
          </li>
        ))}
      </ul>
    </Card>
  );
}
