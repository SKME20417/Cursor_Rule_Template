"use client";

import React from "react";
import { cn } from "@/lib/utils/cn";
import {
  AlertTriangle,
  ArrowUp,
  Minus,
  ArrowDown,
} from "lucide-react";

interface TicketPriorityBadgeProps {
  priority: "critical" | "high" | "medium" | "low";
  className?: string;
}

const PRIORITY_CONFIG: Record<
  string,
  { label: string; icon: React.ElementType; bgColor: string; textColor: string }
> = {
  critical: {
    label: "Critical",
    icon: AlertTriangle,
    bgColor: "bg-red-50",
    textColor: "text-linkedin-red",
  },
  high: {
    label: "High",
    icon: ArrowUp,
    bgColor: "bg-orange-50",
    textColor: "text-linkedin-orange",
  },
  medium: {
    label: "Medium",
    icon: Minus,
    bgColor: "bg-yellow-50",
    textColor: "text-yellow-700",
  },
  low: {
    label: "Low",
    icon: ArrowDown,
    bgColor: "bg-green-50",
    textColor: "text-linkedin-green",
  },
};

export function TicketPriorityBadge({ priority, className }: TicketPriorityBadgeProps) {
  const config = PRIORITY_CONFIG[priority] ?? PRIORITY_CONFIG.medium;
  const Icon = config.icon;

  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-xs font-medium",
        config.bgColor,
        config.textColor,
        className,
      )}
    >
      <Icon className="h-3 w-3" aria-hidden="true" />
      {config.label}
    </span>
  );
}
