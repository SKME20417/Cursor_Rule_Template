"use client";

import React, { useMemo } from "react";
import { cn } from "@/lib/utils/cn";
import { Clock, AlertCircle } from "lucide-react";
import { Tooltip } from "@/components/ui/tooltip";

interface SlaIndicatorProps {
  deadlineIso: string;
  policyName?: string;
  className?: string;
}

function formatTimeRemaining(ms: number): string {
  const absMs = Math.abs(ms);
  const hours = Math.floor(absMs / (1000 * 60 * 60));
  const minutes = Math.floor((absMs % (1000 * 60 * 60)) / (1000 * 60));

  if (hours > 24) {
    const days = Math.floor(hours / 24);
    return `${days}d ${hours % 24}h`;
  }
  if (hours > 0) {
    return `${hours}h ${minutes}m`;
  }
  return `${minutes}m`;
}

export function SlaIndicator({
  deadlineIso,
  policyName = "Standard SLA",
  className,
}: SlaIndicatorProps) {
  const { label, color, Icon, pulse } = useMemo(() => {
    const now = Date.now();
    const deadline = new Date(deadlineIso).getTime();
    const diff = deadline - now;

    if (diff <= 0) {
      return {
        label: `${formatTimeRemaining(diff)} overdue`,
        color: "text-linkedin-red bg-red-50",
        Icon: AlertCircle,
        pulse: true,
      };
    }

    const totalSla = deadline - (deadline - 24 * 60 * 60 * 1000);
    const percentLeft = diff / totalSla;

    if (percentLeft < 0.25) {
      return {
        label: `${formatTimeRemaining(diff)} left`,
        color: "text-linkedin-red bg-red-50",
        Icon: AlertCircle,
        pulse: true,
      };
    }

    if (percentLeft < 0.5) {
      return {
        label: `${formatTimeRemaining(diff)} left`,
        color: "text-yellow-700 bg-yellow-50",
        Icon: Clock,
        pulse: false,
      };
    }

    return {
      label: `${formatTimeRemaining(diff)} left`,
      color: "text-linkedin-green bg-green-50",
      Icon: Clock,
      pulse: false,
    };
  }, [deadlineIso]);

  return (
    <Tooltip
      content={
        <span className="text-xs">
          <strong>{policyName}</strong>
          <br />
          Deadline: {new Date(deadlineIso).toLocaleString()}
        </span>
      }
    >
      <span
        className={cn(
          "inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-xs font-medium",
          color,
          pulse && "animate-pulse",
          className,
        )}
      >
        <Icon className="h-3 w-3" aria-hidden="true" />
        {label}
      </span>
    </Tooltip>
  );
}
