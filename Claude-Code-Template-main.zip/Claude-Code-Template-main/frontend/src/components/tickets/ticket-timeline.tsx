"use client";

import React from "react";
import { cn } from "@/lib/utils/cn";
import {
  Plus,
  UserCheck,
  RefreshCw,
  MessageSquare,
  StickyNote,
  ArrowUpRight,
  CheckCircle2,
  type LucideIcon,
} from "lucide-react";
import { formatRelativeTime } from "@/lib/utils/format-date";

interface TimelineEvent {
  id: string;
  type:
    | "created"
    | "assigned"
    | "status_changed"
    | "message_sent"
    | "note_added"
    | "escalated"
    | "resolved";
  description: string;
  actor: string;
  timestamp: string;
}

interface TicketTimelineProps {
  events: TimelineEvent[];
  className?: string;
}

const EVENT_CONFIG: Record<
  string,
  { icon: LucideIcon; color: string; bgColor: string }
> = {
  created: {
    icon: Plus,
    color: "text-linkedin-gray-50",
    bgColor: "bg-linkedin-gray-20",
  },
  assigned: {
    icon: UserCheck,
    color: "text-linkedin-blue",
    bgColor: "bg-linkedin-blue-bg",
  },
  status_changed: {
    icon: RefreshCw,
    color: "text-yellow-700",
    bgColor: "bg-yellow-50",
  },
  message_sent: {
    icon: MessageSquare,
    color: "text-linkedin-blue",
    bgColor: "bg-linkedin-blue-bg",
  },
  note_added: {
    icon: StickyNote,
    color: "text-purple-600",
    bgColor: "bg-purple-50",
  },
  escalated: {
    icon: ArrowUpRight,
    color: "text-linkedin-red",
    bgColor: "bg-red-50",
  },
  resolved: {
    icon: CheckCircle2,
    color: "text-linkedin-green",
    bgColor: "bg-green-50",
  },
};

export function TicketTimeline({ events, className }: TicketTimelineProps) {
  if (events.length === 0) {
    return (
      <p className="py-8 text-center text-sm text-linkedin-gray-50">
        No activity yet.
      </p>
    );
  }

  return (
    <div className={cn("relative", className)}>
      {/* Vertical line */}
      <div className="absolute left-4 top-0 bottom-0 w-px bg-linkedin-gray-20" />

      <ul className="space-y-4">
        {events.map((event) => {
          const config = EVENT_CONFIG[event.type] ?? EVENT_CONFIG.created;
          const Icon = config.icon;

          return (
            <li key={event.id} className="relative flex gap-3 pl-1">
              <div
                className={cn(
                  "relative z-10 flex h-8 w-8 shrink-0 items-center justify-center rounded-full",
                  config.bgColor,
                  config.color,
                )}
              >
                <Icon className="h-4 w-4" aria-hidden="true" />
              </div>

              <div className="flex-1 pt-1">
                <p className="text-sm text-linkedin-gray-90">
                  {event.description}
                </p>
                <p className="mt-0.5 text-xs text-linkedin-gray-50">
                  <span className="font-medium text-linkedin-gray-70">
                    {event.actor}
                  </span>{" "}
                  &middot; {formatRelativeTime(event.timestamp)}
                </p>
              </div>
            </li>
          );
        })}
      </ul>
    </div>
  );
}
