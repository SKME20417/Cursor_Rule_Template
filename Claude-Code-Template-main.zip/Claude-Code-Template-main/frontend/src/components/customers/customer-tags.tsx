"use client";

import React, { useState } from "react";
import { cn } from "@/lib/utils/cn";
import { X, Plus } from "lucide-react";
import { Badge } from "@/components/ui/badge";

interface CustomerTagsProps {
  tags: string[];
  predefinedTags?: string[];
  onChange?: (tags: string[]) => void;
  readOnly?: boolean;
  className?: string;
}

const TAG_COLORS: Record<string, string> = {
  vip: "bg-purple-50 text-purple-700",
  enterprise: "bg-linkedin-blue-bg text-linkedin-blue",
  churning: "bg-red-50 text-linkedin-red",
  new: "bg-green-50 text-linkedin-green",
  trial: "bg-yellow-50 text-yellow-700",
  "high-value": "bg-orange-50 text-linkedin-orange",
};

export function CustomerTags({
  tags,
  predefinedTags = ["vip", "enterprise", "churning", "new", "trial", "high-value"],
  onChange,
  readOnly = false,
  className,
}: CustomerTagsProps) {
  const [inputValue, setInputValue] = useState("");
  const [showSuggestions, setShowSuggestions] = useState(false);

  const availablePredefined = predefinedTags.filter((t) => !tags.includes(t));

  function addTag(tag: string) {
    const normalized = tag.trim().toLowerCase();
    if (!normalized || tags.includes(normalized)) return;
    onChange?.([...tags, normalized]);
    setInputValue("");
    setShowSuggestions(false);
  }

  function removeTag(tag: string) {
    onChange?.(tags.filter((t) => t !== tag));
  }

  function handleKeyDown(e: React.KeyboardEvent) {
    if (e.key === "Enter") {
      e.preventDefault();
      addTag(inputValue);
    }
  }

  return (
    <div className={className}>
      {/* Tag list */}
      <div className="flex flex-wrap gap-1.5">
        {tags.map((tag) => (
          <span
            key={tag}
            className={cn(
              "inline-flex items-center gap-1 rounded-full px-2.5 py-0.5 text-xs font-medium",
              TAG_COLORS[tag] ?? "bg-linkedin-gray-20 text-linkedin-gray-70",
            )}
          >
            {tag}
            {!readOnly && onChange && (
              <button
                type="button"
                onClick={() => removeTag(tag)}
                className="rounded-full p-0.5 hover:bg-black/10 transition-colors"
                aria-label={`Remove tag ${tag}`}
              >
                <X className="h-2.5 w-2.5" />
              </button>
            )}
          </span>
        ))}

        {/* Add tag input */}
        {!readOnly && onChange && (
          <div className="relative">
            <button
              type="button"
              onClick={() => setShowSuggestions(!showSuggestions)}
              className="inline-flex items-center gap-1 rounded-full border border-dashed border-linkedin-gray-30 px-2.5 py-0.5 text-xs text-linkedin-gray-50 hover:border-linkedin-blue hover:text-linkedin-blue transition-colors"
            >
              <Plus className="h-3 w-3" />
              Add
            </button>

            {showSuggestions && (
              <div className="absolute left-0 top-full z-20 mt-1 w-48 rounded-lg border border-linkedin-gray-20 bg-linkedin-white shadow-md">
                <div className="p-2">
                  <input
                    type="text"
                    value={inputValue}
                    onChange={(e) => setInputValue(e.target.value)}
                    onKeyDown={handleKeyDown}
                    placeholder="Custom tag..."
                    className="w-full rounded-md border border-linkedin-gray-30 px-2 py-1 text-xs text-linkedin-gray-90 placeholder:text-linkedin-gray-50 focus:border-linkedin-blue focus:outline-none"
                    autoFocus
                  />
                </div>
                {availablePredefined.length > 0 && (
                  <div className="border-t border-linkedin-gray-20 p-1.5">
                    <p className="px-1.5 pb-1 text-[10px] font-medium uppercase tracking-wide text-linkedin-gray-50">
                      Suggested
                    </p>
                    {availablePredefined.map((tag) => (
                      <button
                        key={tag}
                        type="button"
                        onClick={() => addTag(tag)}
                        className="flex w-full items-center rounded-md px-2 py-1 text-xs text-linkedin-gray-70 hover:bg-linkedin-gray-10 transition-colors"
                      >
                        <span
                          className={cn(
                            "mr-2 h-2 w-2 rounded-full",
                            TAG_COLORS[tag]
                              ? TAG_COLORS[tag].split(" ")[0]
                              : "bg-linkedin-gray-30",
                          )}
                        />
                        {tag}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
