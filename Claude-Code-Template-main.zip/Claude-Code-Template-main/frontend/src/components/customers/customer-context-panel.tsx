"use client";

import React, { useState } from "react";
import { cn } from "@/lib/utils/cn";
import {
  ChevronDown,
  ChevronRight,
  TicketCheck,
  MessageSquare,
  ShoppingBag,
  StickyNote,
  User,
} from "lucide-react";
import { Avatar } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { TicketStatusBadge } from "@/components/tickets/ticket-status-badge";
import { formatRelativeTime } from "@/lib/utils/format-date";

interface RecentTicket {
  id: string;
  shortId: string;
  subject: string;
  status: "created" | "assigned" | "in_progress" | "resolved" | "closed";
  date: string;
}

interface RecentConversation {
  id: string;
  summary: string;
  channel: string;
  date: string;
}

interface CustomerContextPanelProps {
  customer: {
    name: string;
    email: string;
    avatar?: string;
    company?: string;
    plan?: string;
  };
  recentTickets?: RecentTicket[];
  recentConversations?: RecentConversation[];
  accountInfo?: { label: string; value: string }[];
  notes?: string;
  onEditNotes?: (notes: string) => void;
  className?: string;
}

function CollapsibleSection({
  title,
  icon: Icon,
  defaultOpen = true,
  children,
}: {
  title: string;
  icon: React.ElementType;
  defaultOpen?: boolean;
  children: React.ReactNode;
}) {
  const [open, setOpen] = useState(defaultOpen);

  return (
    <div className="border-b border-linkedin-gray-20 last:border-b-0">
      <button
        type="button"
        onClick={() => setOpen(!open)}
        className="flex w-full items-center gap-2 px-4 py-2.5 text-xs font-semibold uppercase tracking-wide text-linkedin-gray-50 hover:text-linkedin-gray-90 transition-colors"
      >
        {open ? (
          <ChevronDown className="h-3.5 w-3.5" />
        ) : (
          <ChevronRight className="h-3.5 w-3.5" />
        )}
        <Icon className="h-3.5 w-3.5" />
        {title}
      </button>
      {open && <div className="px-4 pb-3">{children}</div>}
    </div>
  );
}

export function CustomerContextPanel({
  customer,
  recentTickets = [],
  recentConversations = [],
  accountInfo = [],
  notes = "",
  onEditNotes,
  className,
}: CustomerContextPanelProps) {
  const [noteValue, setNoteValue] = useState(notes);

  return (
    <div
      className={cn(
        "rounded-lg border border-linkedin-gray-20 bg-linkedin-white",
        className,
      )}
    >
      {/* Compact profile header */}
      <div className="flex items-center gap-3 border-b border-linkedin-gray-20 px-4 py-3">
        <Avatar name={customer.name} src={customer.avatar} size="md" />
        <div className="min-w-0 flex-1">
          <p className="truncate text-sm font-semibold text-linkedin-gray-90">
            {customer.name}
          </p>
          <p className="truncate text-xs text-linkedin-gray-50">
            {customer.email}
          </p>
          {customer.plan && (
            <Badge variant="primary" size="sm" className="mt-1">
              {customer.plan}
            </Badge>
          )}
        </div>
      </div>

      {/* Recent tickets */}
      <CollapsibleSection title="Recent Tickets" icon={TicketCheck}>
        {recentTickets.length === 0 ? (
          <p className="text-xs text-linkedin-gray-50">No recent tickets.</p>
        ) : (
          <ul className="space-y-2">
            {recentTickets.slice(0, 3).map((t) => (
              <li key={t.id} className="rounded-md bg-linkedin-gray-10 p-2">
                <p className="truncate text-xs font-medium text-linkedin-gray-90">
                  {t.subject}
                </p>
                <div className="mt-1 flex items-center gap-2">
                  <span className="text-[10px] font-mono text-linkedin-gray-50">
                    #{t.shortId}
                  </span>
                  <TicketStatusBadge status={t.status} />
                </div>
              </li>
            ))}
          </ul>
        )}
      </CollapsibleSection>

      {/* Recent conversations */}
      <CollapsibleSection title="Conversations" icon={MessageSquare}>
        {recentConversations.length === 0 ? (
          <p className="text-xs text-linkedin-gray-50">
            No recent conversations.
          </p>
        ) : (
          <ul className="space-y-2">
            {recentConversations.slice(0, 3).map((c) => (
              <li key={c.id} className="rounded-md bg-linkedin-gray-10 p-2">
                <p className="truncate text-xs text-linkedin-gray-90">
                  {c.summary}
                </p>
                <p className="mt-0.5 text-[10px] text-linkedin-gray-50">
                  {c.channel} &middot; {formatRelativeTime(c.date)}
                </p>
              </li>
            ))}
          </ul>
        )}
      </CollapsibleSection>

      {/* Account info */}
      {accountInfo.length > 0 && (
        <CollapsibleSection title="Account" icon={ShoppingBag} defaultOpen={false}>
          <dl className="space-y-1.5">
            {accountInfo.map((item) => (
              <div key={item.label} className="flex justify-between text-xs">
                <dt className="text-linkedin-gray-50">{item.label}</dt>
                <dd className="font-medium text-linkedin-gray-90">
                  {item.value}
                </dd>
              </div>
            ))}
          </dl>
        </CollapsibleSection>
      )}

      {/* Notes */}
      <CollapsibleSection title="Notes" icon={StickyNote} defaultOpen={false}>
        <textarea
          value={noteValue}
          onChange={(e) => setNoteValue(e.target.value)}
          onBlur={() => onEditNotes?.(noteValue)}
          rows={3}
          placeholder="Add notes about this customer..."
          className="w-full rounded-md border border-linkedin-gray-30 bg-linkedin-white px-2.5 py-1.5 text-xs text-linkedin-gray-90 placeholder:text-linkedin-gray-50 focus:border-linkedin-blue focus:outline-none focus:ring-1 focus:ring-linkedin-blue resize-vertical"
        />
      </CollapsibleSection>
    </div>
  );
}
