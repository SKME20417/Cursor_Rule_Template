"use client";

import React, { useState, useMemo } from "react";
import { cn } from "@/lib/utils/cn";
import { Search, Clock } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Avatar } from "@/components/ui/avatar";
import { Card } from "@/components/ui/card";

interface CustomerResult {
  id: string;
  name: string;
  email: string;
  company?: string;
  avatar?: string;
}

interface CustomerSearchProps {
  customers: CustomerResult[];
  recentlyViewed?: CustomerResult[];
  onSelect: (customerId: string) => void;
  className?: string;
}

export function CustomerSearch({
  customers,
  recentlyViewed = [],
  onSelect,
  className,
}: CustomerSearchProps) {
  const [query, setQuery] = useState("");

  const results = useMemo(() => {
    if (!query.trim()) return [];
    const q = query.toLowerCase();
    return customers.filter(
      (c) =>
        c.name.toLowerCase().includes(q) ||
        c.email.toLowerCase().includes(q) ||
        (c.company?.toLowerCase().includes(q) ?? false),
    );
  }, [query, customers]);

  const showRecent = !query.trim() && recentlyViewed.length > 0;

  return (
    <div className={className}>
      <Input
        variant="search"
        placeholder="Search by name, email, or company..."
        value={query}
        onChange={(e) => setQuery(e.target.value)}
      />

      {/* Recently viewed */}
      {showRecent && (
        <div className="mt-4">
          <h3 className="mb-2 flex items-center gap-1.5 text-xs font-medium uppercase tracking-wide text-linkedin-gray-50">
            <Clock className="h-3.5 w-3.5" />
            Recently Viewed
          </h3>
          <Card padding="none">
            <ul className="divide-y divide-linkedin-gray-20">
              {recentlyViewed.map((c) => (
                <li key={c.id}>
                  <button
                    type="button"
                    onClick={() => onSelect(c.id)}
                    className="flex w-full items-center gap-3 px-4 py-3 text-left hover:bg-linkedin-gray-10 transition-colors"
                  >
                    <Avatar name={c.name} src={c.avatar} size="sm" />
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-medium text-linkedin-gray-90">
                        {c.name}
                      </p>
                      <p className="truncate text-xs text-linkedin-gray-50">
                        {c.email}
                      </p>
                    </div>
                    {c.company && (
                      <span className="text-xs text-linkedin-gray-50">
                        {c.company}
                      </span>
                    )}
                  </button>
                </li>
              ))}
            </ul>
          </Card>
        </div>
      )}

      {/* Search results */}
      {query.trim() && (
        <div className="mt-3">
          {results.length === 0 ? (
            <p className="py-6 text-center text-sm text-linkedin-gray-50">
              <Search className="mx-auto mb-2 h-8 w-8 text-linkedin-gray-30" />
              No customers found for &quot;{query}&quot;.
            </p>
          ) : (
            <Card padding="none">
              <ul className="divide-y divide-linkedin-gray-20">
                {results.slice(0, 10).map((c) => (
                  <li key={c.id}>
                    <button
                      type="button"
                      onClick={() => onSelect(c.id)}
                      className="group flex w-full items-center gap-3 px-4 py-3 text-left hover:bg-linkedin-gray-10 transition-colors"
                    >
                      <Avatar name={c.name} src={c.avatar} size="sm" />
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-sm font-medium text-linkedin-gray-90">
                          {c.name}
                        </p>
                        <p className="truncate text-xs text-linkedin-gray-50">
                          {c.email}
                          {c.company && ` - ${c.company}`}
                        </p>
                      </div>
                    </button>
                  </li>
                ))}
                {results.length > 10 && (
                  <li className="px-4 py-2 text-center text-xs text-linkedin-gray-50">
                    {results.length - 10} more results...
                  </li>
                )}
              </ul>
            </Card>
          )}
        </div>
      )}
    </div>
  );
}
