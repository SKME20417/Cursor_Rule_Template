"use client";

import React from "react";
import { cn } from "@/lib/utils/cn";
import {
  Mail,
  Phone,
  MapPin,
  Building2,
  Star,
  TicketCheck,
  DollarSign,
} from "lucide-react";
import { Avatar } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";

interface CustomerProfileProps {
  customer: {
    id: string;
    name: string;
    email: string;
    phone?: string;
    avatar?: string;
    company?: string;
    plan?: string;
    location?: string;
    tags?: string[];
    totalTickets: number;
    avgCsat: number;
    lifetimeValue: number;
  };
  compact?: boolean;
  className?: string;
}

export function CustomerProfile({
  customer,
  compact = false,
  className,
}: CustomerProfileProps) {
  return (
    <Card padding="none" className={cn("overflow-hidden", className)}>
      {/* Profile banner */}
      <div className="h-16 bg-gradient-to-r from-linkedin-blue to-blue-400" />

      <div className="px-4 pb-4">
        {/* Avatar overlapping banner */}
        <div className="-mt-8 mb-3">
          <Avatar
            name={customer.name}
            src={customer.avatar}
            size={compact ? "lg" : "xl"}
            className="border-4 border-linkedin-white"
          />
        </div>

        {/* Name and title */}
        <h2
          className={cn(
            "font-semibold text-linkedin-gray-90",
            compact ? "text-base" : "text-lg",
          )}
        >
          {customer.name}
        </h2>

        {customer.company && (
          <p className="mt-0.5 flex items-center gap-1 text-sm text-linkedin-gray-50">
            <Building2 className="h-3.5 w-3.5" />
            {customer.company}
          </p>
        )}

        {customer.plan && (
          <Badge variant="primary" size="sm" className="mt-2">
            {customer.plan}
          </Badge>
        )}

        {/* Contact info */}
        <div className="mt-3 space-y-1.5 border-t border-linkedin-gray-20 pt-3">
          <p className="flex items-center gap-2 text-sm text-linkedin-gray-70">
            <Mail className="h-3.5 w-3.5 text-linkedin-gray-50" />
            {customer.email}
          </p>
          {customer.phone && (
            <p className="flex items-center gap-2 text-sm text-linkedin-gray-70">
              <Phone className="h-3.5 w-3.5 text-linkedin-gray-50" />
              {customer.phone}
            </p>
          )}
          {customer.location && (
            <p className="flex items-center gap-2 text-sm text-linkedin-gray-70">
              <MapPin className="h-3.5 w-3.5 text-linkedin-gray-50" />
              {customer.location}
            </p>
          )}
        </div>

        {/* Tags */}
        {customer.tags && customer.tags.length > 0 && (
          <div className="mt-3 flex flex-wrap gap-1">
            {customer.tags.map((tag) => (
              <Badge key={tag} variant="default" size="sm">
                {tag}
              </Badge>
            ))}
          </div>
        )}

        {/* Stats */}
        {!compact && (
          <div className="mt-4 grid grid-cols-3 gap-3 border-t border-linkedin-gray-20 pt-3">
            <div className="text-center">
              <p className="flex items-center justify-center gap-1 text-xs text-linkedin-gray-50">
                <TicketCheck className="h-3 w-3" />
                Tickets
              </p>
              <p className="mt-0.5 text-lg font-semibold text-linkedin-gray-90">
                {customer.totalTickets}
              </p>
            </div>
            <div className="text-center">
              <p className="flex items-center justify-center gap-1 text-xs text-linkedin-gray-50">
                <Star className="h-3 w-3" />
                Avg CSAT
              </p>
              <p className="mt-0.5 text-lg font-semibold text-linkedin-gray-90">
                {customer.avgCsat.toFixed(1)}
              </p>
            </div>
            <div className="text-center">
              <p className="flex items-center justify-center gap-1 text-xs text-linkedin-gray-50">
                <DollarSign className="h-3 w-3" />
                LTV
              </p>
              <p className="mt-0.5 text-lg font-semibold text-linkedin-gray-90">
                ${customer.lifetimeValue.toLocaleString()}
              </p>
            </div>
          </div>
        )}
      </div>
    </Card>
  );
}
