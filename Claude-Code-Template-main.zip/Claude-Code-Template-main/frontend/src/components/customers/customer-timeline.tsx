"use client";

import React, { useState } from "react";
import { cn } from "@/lib/utils/cn";
import {
  TicketCheck,
  MessageSquare,
  Phone,
  Mail,
  type LucideIcon,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { formatRelativeTime } from "@/lib/utils/format-date";

interface InteractionEvent {
  id: string;
  type: "ticket" | "chat" | "call" | "email";
  summary: string;
  date: string;
  channel: string;
  outcome?: string;
}

interface CustomerTimelineProps {
  events: InteractionEvent[];
  className?: string;
}

const TYPE_CONFIG: Record<
  string,
  { icon: LucideIcon; color: string; bgColor: string; label: string }
> = {
  ticket: {
    icon: TicketCheck,
    color: "text-linkedin-blue",
    bgColor: "bg-linkedin-blue-bg",
    label: "Ticket",
  },
  chat: {
    icon: MessageSquare,
    color: "text-linkedin-green",
    bgColor: "bg-green-50",
    label: "Chat",
  },
  call: {
    icon: Phone,
    color: "text-purple-600",
    bgColor: "bg-purple-50",
    label: "Call",
  },
  email: {
    icon: Mail,
    color: "text-linkedin-orange",
    bgColor: "bg-orange-50",
    label: "Email",
  },
};

const TYPE_FILTER_OPTIONS = ["all", "ticket", "chat", "call", "email"] as const;

export function CustomerTimeline({ events, className }: CustomerTimelineProps) {
  const [filter, setFilter] = useState<string>("all");

  const filtered =
    filter === "all" ? events : events.filter((e) => e.type === filter);

  return (
    <div className={className}>
      {/* Filter bar */}
      <div className="mb-4 flex flex-wrap gap-1.5">
        {TYPE_FILTER_OPTIONS.map((opt) => (
          <button
            key={opt}
            type="button"
            onClick={() => setFilter(opt)}
            className={cn(
              "rounded-full px-3 py-1 text-xs font-medium capitalize transition-colors",
              filter === opt
                ? "bg-linkedin-blue text-linkedin-white"
                : "bg-linkedin-gray-20 text-linkedin-gray-70 hover:bg-linkedin-gray-30",
            )}
          >
            {opt}
          </button>
        ))}
      </div>

      {filtered.length === 0 && (
        <p className="py-8 text-center text-sm text-linkedin-gray-50">
          No interactions found.
        </p>
      )}

      {/* Timeline */}
      <div className="relative">
        <div className="absolute left-4 top-0 bottom-0 w-px bg-linkedin-gray-20" />

        <ul className="space-y-4">
          {filtered.map((event) => {
            const config = TYPE_CONFIG[event.type] ?? TYPE_CONFIG.ticket;
            const Icon = config.icon;

            return (
              <li key={event.id} className="relative flex gap-3 pl-1">
                <div
                  className={cn(
                    "relative z-10 flex h-8 w-8 shrink-0 items-center justify-center rounded-full",
                    config.bgColor,
                    config.color,
                  )}
                >
                  <Icon className="h-4 w-4" aria-hidden="true" />
                </div>

                <div className="flex-1 pt-0.5">
                  <div className="flex items-center gap-2">
                    <Badge variant="default" size="sm">
                      {config.label}
                    </Badge>
                    <span className="text-xs text-linkedin-gray-50">
                      {event.channel}
                    </span>
                  </div>
                  <p className="mt-1 text-sm text-linkedin-gray-90">
                    {event.summary}
                  </p>
                  {event.outcome && (
                    <p className="mt-0.5 text-xs text-linkedin-gray-50">
                      Outcome: {event.outcome}
                    </p>
                  )}
                  <p className="mt-1 text-xs text-linkedin-gray-50">
                    {formatRelativeTime(event.date)}
                  </p>
                </div>
              </li>
            );
          })}
        </ul>
      </div>
    </div>
  );
}
