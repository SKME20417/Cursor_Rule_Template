"use client";

import { useState, useCallback } from "react";

type SupportedLocale = "en" | "es" | "fr" | "de" | "ja" | "zh" | "pt";

interface UseLocaleReturn {
  locale: SupportedLocale;
  setLocale: (locale: SupportedLocale) => void;
  t: (key: string) => string;
  supportedLocales: SupportedLocale[];
}

const SUPPORTED_LOCALES: SupportedLocale[] = ["en", "es", "fr", "de", "ja", "zh", "pt"];

const TRANSLATIONS: Record<SupportedLocale, Record<string, string>> = {
  en: {
    "nav.dashboard": "Dashboard",
    "nav.conversations": "Conversations",
    "nav.tickets": "Tickets",
    "nav.analytics": "Analytics",
    "nav.settings": "Settings",
    "nav.knowledge_base": "Knowledge Base",
    "common.search": "Search",
    "common.save": "Save",
    "common.cancel": "Cancel",
    "common.delete": "Delete",
    "common.loading": "Loading...",
    "common.error": "An error occurred",
    "common.empty": "No items found",
    "status.online": "Online",
    "status.away": "Away",
    "status.offline": "Offline",
  },
  es: {
    "nav.dashboard": "Panel",
    "nav.conversations": "Conversaciones",
    "nav.tickets": "Tickets",
    "nav.analytics": "Analitica",
    "nav.settings": "Configuracion",
    "nav.knowledge_base": "Base de Conocimiento",
    "common.search": "Buscar",
    "common.save": "Guardar",
    "common.cancel": "Cancelar",
    "common.delete": "Eliminar",
    "common.loading": "Cargando...",
    "common.error": "Ocurrio un error",
    "common.empty": "No se encontraron elementos",
    "status.online": "En linea",
    "status.away": "Ausente",
    "status.offline": "Desconectado",
  },
  fr: {
    "nav.dashboard": "Tableau de bord",
    "nav.conversations": "Conversations",
    "nav.tickets": "Tickets",
    "nav.analytics": "Analytique",
    "nav.settings": "Parametres",
    "nav.knowledge_base": "Base de connaissances",
    "common.search": "Rechercher",
    "common.save": "Enregistrer",
    "common.cancel": "Annuler",
    "common.delete": "Supprimer",
    "common.loading": "Chargement...",
    "common.error": "Une erreur est survenue",
    "common.empty": "Aucun element trouve",
    "status.online": "En ligne",
    "status.away": "Absent",
    "status.offline": "Hors ligne",
  },
  de: {
    "nav.dashboard": "Dashboard",
    "nav.conversations": "Gespraeche",
    "nav.tickets": "Tickets",
    "nav.analytics": "Analytik",
    "nav.settings": "Einstellungen",
    "nav.knowledge_base": "Wissensdatenbank",
    "common.search": "Suchen",
    "common.save": "Speichern",
    "common.cancel": "Abbrechen",
    "common.delete": "Loeschen",
    "common.loading": "Laden...",
    "common.error": "Ein Fehler ist aufgetreten",
    "common.empty": "Keine Elemente gefunden",
    "status.online": "Online",
    "status.away": "Abwesend",
    "status.offline": "Offline",
  },
  ja: {
    "nav.dashboard": "Dashboard",
    "nav.conversations": "Kaiwa",
    "nav.tickets": "Chiketto",
    "nav.analytics": "Bunseki",
    "nav.settings": "Settei",
    "nav.knowledge_base": "Narejji Beesu",
    "common.search": "Kensaku",
    "common.save": "Hozon",
    "common.cancel": "Kyanseru",
    "common.delete": "Sakujo",
    "common.loading": "Yomikomi-chuu...",
    "common.error": "Eraa ga hassei shimashita",
    "common.empty": "Aitemu ga mitsukarimasen",
    "status.online": "Onrain",
    "status.away": "Riseki-chuu",
    "status.offline": "Ofurain",
  },
  zh: {
    "nav.dashboard": "Yibiaopan",
    "nav.conversations": "Duihua",
    "nav.tickets": "Gongdan",
    "nav.analytics": "Fenxi",
    "nav.settings": "Shezhi",
    "nav.knowledge_base": "Zhishiku",
    "common.search": "Sousuo",
    "common.save": "Baocun",
    "common.cancel": "Quxiao",
    "common.delete": "Shanchu",
    "common.loading": "Jiazai zhong...",
    "common.error": "Fasheng cuowu",
    "common.empty": "Wei zhao dao xiangmu",
    "status.online": "Zaixian",
    "status.away": "Likai",
    "status.offline": "Lixian",
  },
  pt: {
    "nav.dashboard": "Painel",
    "nav.conversations": "Conversas",
    "nav.tickets": "Tickets",
    "nav.analytics": "Analitica",
    "nav.settings": "Configuracoes",
    "nav.knowledge_base": "Base de Conhecimento",
    "common.search": "Pesquisar",
    "common.save": "Salvar",
    "common.cancel": "Cancelar",
    "common.delete": "Excluir",
    "common.loading": "Carregando...",
    "common.error": "Ocorreu um erro",
    "common.empty": "Nenhum item encontrado",
    "status.online": "Online",
    "status.away": "Ausente",
    "status.offline": "Offline",
  },
};

const LOCALE_STORAGE_KEY = "copilot_locale";

export function useLocale(): UseLocaleReturn {
  const [locale, setLocaleState] = useState<SupportedLocale>(() => {
    if (typeof window !== "undefined") {
      const stored = localStorage.getItem(LOCALE_STORAGE_KEY);
      if (stored && SUPPORTED_LOCALES.includes(stored as SupportedLocale)) {
        return stored as SupportedLocale;
      }
    }
    return "en";
  });

  const setLocale = useCallback((newLocale: SupportedLocale) => {
    setLocaleState(newLocale);
    localStorage.setItem(LOCALE_STORAGE_KEY, newLocale);
  }, []);

  const t = useCallback(
    (key: string): string => {
      return TRANSLATIONS[locale]?.[key] ?? key;
    },
    [locale]
  );

  return {
    locale,
    setLocale,
    t,
    supportedLocales: SUPPORTED_LOCALES,
  };
}
