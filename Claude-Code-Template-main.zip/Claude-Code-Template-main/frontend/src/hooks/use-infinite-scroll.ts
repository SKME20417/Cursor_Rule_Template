"use client";

import { useState, useCallback, useEffect, useRef } from "react";

interface UseInfiniteScrollReturn {
  ref: (node: HTMLElement | null) => void;
  hasMore: boolean;
  loadMore: () => void;
  isLoading: boolean;
}

interface UseInfiniteScrollOptions {
  threshold?: number;
  initialHasMore?: boolean;
  onLoadMore: () => Promise<boolean>; // returns true if there are more items
}

export function useInfiniteScroll({
  threshold = 0.8,
  initialHasMore = true,
  onLoadMore,
}: UseInfiniteScrollOptions): UseInfiniteScrollReturn {
  const [hasMore, setHasMore] = useState(initialHasMore);
  const [isLoading, setIsLoading] = useState(false);
  const observerRef = useRef<IntersectionObserver | null>(null);
  const nodeRef = useRef<HTMLElement | null>(null);

  const loadMore = useCallback(async () => {
    if (isLoading || !hasMore) return;

    setIsLoading(true);
    try {
      const moreAvailable = await onLoadMore();
      setHasMore(moreAvailable);
    } finally {
      setIsLoading(false);
    }
  }, [isLoading, hasMore, onLoadMore]);

  const ref = useCallback(
    (node: HTMLElement | null) => {
      if (observerRef.current) {
        observerRef.current.disconnect();
      }

      if (!node) {
        nodeRef.current = null;
        return;
      }

      nodeRef.current = node;

      observerRef.current = new IntersectionObserver(
        (entries) => {
          const entry = entries[0];
          if (entry?.isIntersecting && hasMore && !isLoading) {
            void loadMore();
          }
        },
        { threshold }
      );

      observerRef.current.observe(node);
    },
    [hasMore, isLoading, loadMore, threshold]
  );

  useEffect(() => {
    return () => {
      observerRef.current?.disconnect();
    };
  }, []);

  return { ref, hasMore, loadMore, isLoading };
}
