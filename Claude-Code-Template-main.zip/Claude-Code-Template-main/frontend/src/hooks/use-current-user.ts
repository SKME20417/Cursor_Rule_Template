"use client";

import { useAuth } from "./use-auth";

interface CurrentUser {
  id: string;
  name: string;
  email: string;
  role: "admin" | "agent" | "supervisor" | "viewer";
  avatar: string;
}

interface UseCurrentUserReturn {
  user: CurrentUser | null;
}

export function useCurrentUser(): UseCurrentUserReturn {
  const { user } = useAuth();
  return { user };
}
