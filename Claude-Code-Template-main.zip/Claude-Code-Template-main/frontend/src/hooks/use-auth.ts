"use client";

import { useState, useCallback, useEffect } from "react";

interface User {
  id: string;
  name: string;
  email: string;
  role: "admin" | "agent" | "supervisor" | "viewer";
  avatar: string;
}

interface RegisterData {
  name: string;
  email: string;
  password: string;
  role?: User["role"];
}

interface UseAuthReturn {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<void>;
  logout: () => void;
  register: (data: RegisterData) => Promise<void>;
}

const MOCK_USER: User = {
  id: "usr_001",
  name: "Alex Johnson",
  email: "alex@company.com",
  role: "admin",
  avatar: "/avatars/alex.png",
};

const TOKEN_KEY = "copilot_auth_token";

export function useAuth(): UseAuthReturn {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const token = localStorage.getItem(TOKEN_KEY);
    if (token) {
      // Mock: restore session from token
      setUser(MOCK_USER);
    }
    setIsLoading(false);
  }, []);

  const login = useCallback(async (email: string, _password: string) => {
    setIsLoading(true);
    try {
      // Mock login delay
      await new Promise((resolve) => setTimeout(resolve, 800));
      const mockToken = `mock_token_${Date.now()}`;
      localStorage.setItem(TOKEN_KEY, mockToken);
      setUser({ ...MOCK_USER, email });
    } finally {
      setIsLoading(false);
    }
  }, []);

  const logout = useCallback(() => {
    localStorage.removeItem(TOKEN_KEY);
    setUser(null);
  }, []);

  const register = useCallback(async (data: RegisterData) => {
    setIsLoading(true);
    try {
      await new Promise((resolve) => setTimeout(resolve, 1000));
      const mockToken = `mock_token_${Date.now()}`;
      localStorage.setItem(TOKEN_KEY, mockToken);
      setUser({
        id: `usr_${Date.now()}`,
        name: data.name,
        email: data.email,
        role: data.role ?? "agent",
        avatar: "/avatars/default.png",
      });
    } finally {
      setIsLoading(false);
    }
  }, []);

  return {
    user,
    isAuthenticated: user !== null,
    isLoading,
    login,
    logout,
    register,
  };
}
