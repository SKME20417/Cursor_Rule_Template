"use client";

import { useState, useCallback, useEffect } from "react";
import { useWebSocket } from "./use-websocket";

type ConversationStatus = "active" | "waiting" | "resolved" | "closed";
type ConversationChannel = "chat" | "email" | "phone" | "social";
type Priority = "low" | "medium" | "high" | "urgent";

interface Conversation {
  id: string;
  customerId: string;
  customerName: string;
  customerAvatar: string;
  channel: ConversationChannel;
  status: ConversationStatus;
  priority: Priority;
  subject: string;
  lastMessage: string;
  lastMessageAt: string;
  unreadCount: number;
  assignedTo: string | null;
  tags: string[];
}

interface ConversationFilters {
  status?: ConversationStatus;
  channel?: ConversationChannel;
  priority?: Priority;
  search?: string;
}

interface UseConversationsReturn {
  conversations: Conversation[];
  activeConversation: Conversation | null;
  setActive: (id: string | null) => void;
  filters: ConversationFilters;
  setFilters: (filters: ConversationFilters) => void;
  isLoading: boolean;
}

const MOCK_CONVERSATIONS: Conversation[] = [
  {
    id: "conv_001",
    customerId: "cust_001",
    customerName: "Sarah Chen",
    customerAvatar: "/avatars/sarah.png",
    channel: "chat",
    status: "active",
    priority: "high",
    subject: "Subscription renewal issue",
    lastMessage: "Yes please, how do I do that?",
    lastMessageAt: new Date(Date.now() - 120000).toISOString(),
    unreadCount: 1,
    assignedTo: "usr_001",
    tags: ["billing", "subscription"],
  },
  {
    id: "conv_002",
    customerId: "cust_002",
    customerName: "Mike Williams",
    customerAvatar: "/avatars/mike.png",
    channel: "email",
    status: "waiting",
    priority: "medium",
    subject: "API integration help",
    lastMessage: "I keep getting a 403 error on the /users endpoint",
    lastMessageAt: new Date(Date.now() - 3600000).toISOString(),
    unreadCount: 2,
    assignedTo: "usr_001",
    tags: ["api", "technical"],
  },
  {
    id: "conv_003",
    customerId: "cust_003",
    customerName: "Emily Rodriguez",
    customerAvatar: "/avatars/emily.png",
    channel: "phone",
    status: "active",
    priority: "urgent",
    subject: "Account security concern",
    lastMessage: "I noticed unauthorized access on my account",
    lastMessageAt: new Date(Date.now() - 60000).toISOString(),
    unreadCount: 0,
    assignedTo: "usr_001",
    tags: ["security", "account"],
  },
  {
    id: "conv_004",
    customerId: "cust_004",
    customerName: "David Park",
    customerAvatar: "/avatars/david.png",
    channel: "chat",
    status: "resolved",
    priority: "low",
    subject: "Feature request: dark mode",
    lastMessage: "Thanks for forwarding this to the product team!",
    lastMessageAt: new Date(Date.now() - 86400000).toISOString(),
    unreadCount: 0,
    assignedTo: "usr_001",
    tags: ["feature-request"],
  },
  {
    id: "conv_005",
    customerId: "cust_005",
    customerName: "Lisa Thompson",
    customerAvatar: "/avatars/lisa.png",
    channel: "social",
    status: "waiting",
    priority: "medium",
    subject: "Refund request for order #4521",
    lastMessage: "It's been 3 days and I haven't received a response",
    lastMessageAt: new Date(Date.now() - 7200000).toISOString(),
    unreadCount: 3,
    assignedTo: null,
    tags: ["refund", "billing"],
  },
];

export function useConversations(): UseConversationsReturn {
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [activeId, setActiveId] = useState<string | null>(null);
  const [filters, setFilters] = useState<ConversationFilters>({});
  const [isLoading, setIsLoading] = useState(true);
  const { subscribe } = useWebSocket();

  useEffect(() => {
    setIsLoading(true);
    const timer = setTimeout(() => {
      setConversations(MOCK_CONVERSATIONS);
      setIsLoading(false);
    }, 600);

    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    const unsubscribe = subscribe("new_conversation", (data) => {
      const conv = data as Conversation;
      setConversations((prev) => [conv, ...prev]);
    });

    return unsubscribe;
  }, [subscribe]);

  const filteredConversations = conversations.filter((conv) => {
    if (filters.status && conv.status !== filters.status) return false;
    if (filters.channel && conv.channel !== filters.channel) return false;
    if (filters.priority && conv.priority !== filters.priority) return false;
    if (
      filters.search &&
      !conv.subject.toLowerCase().includes(filters.search.toLowerCase()) &&
      !conv.customerName.toLowerCase().includes(filters.search.toLowerCase())
    ) {
      return false;
    }
    return true;
  });

  const setActive = useCallback((id: string | null) => {
    setActiveId(id);
  }, []);

  const activeConversation =
    filteredConversations.find((c) => c.id === activeId) ?? null;

  return {
    conversations: filteredConversations,
    activeConversation,
    setActive,
    filters,
    setFilters,
    isLoading,
  };
}
