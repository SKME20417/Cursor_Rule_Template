"use client";

import { useState, useEffect } from "react";

interface UseRealTimeMetricsReturn {
  activeConversations: number;
  queuedTickets: number;
  onlineAgents: number;
  avgResponseTime: number;
}

function randomDelta(base: number, variance: number): number {
  return Math.max(0, base + Math.floor(Math.random() * variance * 2 - variance));
}

export function useRealTimeMetrics(): UseRealTimeMetricsReturn {
  const [activeConversations, setActiveConversations] = useState(23);
  const [queuedTickets, setQueuedTickets] = useState(8);
  const [onlineAgents, setOnlineAgents] = useState(12);
  const [avgResponseTime, setAvgResponseTime] = useState(45);

  useEffect(() => {
    const interval = setInterval(() => {
      setActiveConversations((prev) => randomDelta(prev, 3));
      setQueuedTickets((prev) => randomDelta(prev, 2));
      setOnlineAgents((prev) => Math.max(1, randomDelta(prev, 1)));
      setAvgResponseTime((prev) => Math.max(10, randomDelta(prev, 5)));
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  return {
    activeConversations,
    queuedTickets,
    onlineAgents,
    avgResponseTime,
  };
}
