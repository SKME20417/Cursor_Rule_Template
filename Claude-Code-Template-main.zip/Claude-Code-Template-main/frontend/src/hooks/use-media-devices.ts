"use client";

import { useState, useCallback, useEffect, useRef } from "react";

interface MediaDevice {
  deviceId: string;
  label: string;
  kind: "audioinput" | "audiooutput" | "videoinput";
}

interface UseMediaDevicesReturn {
  stream: MediaStream | null;
  hasPermission: boolean;
  requestPermission: () => Promise<void>;
  devices: MediaDevice[];
}

export function useMediaDevices(): UseMediaDevicesReturn {
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [hasPermission, setHasPermission] = useState(false);
  const [devices, setDevices] = useState<MediaDevice[]>([]);
  const streamRef = useRef<MediaStream | null>(null);

  useEffect(() => {
    return () => {
      streamRef.current?.getTracks().forEach((track) => track.stop());
    };
  }, []);

  const enumerateDevices = useCallback(async () => {
    try {
      if (typeof navigator !== "undefined" && navigator.mediaDevices) {
        const deviceInfos = await navigator.mediaDevices.enumerateDevices();
        const mapped: MediaDevice[] = deviceInfos
          .filter(
            (d): d is MediaDeviceInfo & { kind: "audioinput" | "audiooutput" | "videoinput" } =>
              d.kind === "audioinput" ||
              d.kind === "audiooutput" ||
              d.kind === "videoinput"
          )
          .map((d) => ({
            deviceId: d.deviceId,
            label: d.label || `${d.kind} (${d.deviceId.slice(0, 8)})`,
            kind: d.kind,
          }));
        setDevices(mapped);
      }
    } catch {
      // Mock fallback devices
      setDevices([
        { deviceId: "mock_mic_1", label: "Built-in Microphone", kind: "audioinput" },
        { deviceId: "mock_cam_1", label: "Built-in Camera", kind: "videoinput" },
        { deviceId: "mock_spk_1", label: "Built-in Speakers", kind: "audiooutput" },
      ]);
    }
  }, []);

  const requestPermission = useCallback(async () => {
    try {
      if (typeof navigator !== "undefined" && navigator.mediaDevices) {
        const mediaStream = await navigator.mediaDevices.getUserMedia({
          audio: true,
          video: true,
        });
        streamRef.current = mediaStream;
        setStream(mediaStream);
        setHasPermission(true);
        await enumerateDevices();
      } else {
        // Mock: simulate permission granted
        setHasPermission(true);
        await enumerateDevices();
      }
    } catch {
      setHasPermission(false);
    }
  }, [enumerateDevices]);

  return {
    stream,
    hasPermission,
    requestPermission,
    devices,
  };
}
