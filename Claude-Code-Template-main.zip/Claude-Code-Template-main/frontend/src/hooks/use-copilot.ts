"use client";

import { useState, useCallback, useEffect } from "react";

interface Suggestion {
  id: string;
  type: "reply" | "action" | "knowledge";
  content: string;
  confidence: number;
  source: string | null;
}

interface UseCopilotProps {
  conversationId: string;
}

interface UseCopilotReturn {
  suggestions: Suggestion[];
  draft: string | null;
  summary: string | null;
  isLoading: boolean;
  generateDraft: (prompt?: string) => Promise<void>;
  refreshSuggestions: () => Promise<void>;
  submitFeedback: (suggestionId: string, helpful: boolean) => void;
}

const MOCK_SUGGESTIONS: Suggestion[] = [
  {
    id: "sug_001",
    type: "reply",
    content:
      "I can walk you through updating your payment method. Go to Settings > Billing > Payment Methods and click 'Add new card'.",
    confidence: 0.92,
    source: "knowledge_base",
  },
  {
    id: "sug_002",
    type: "reply",
    content:
      "I've applied a 7-day extension to your subscription while we resolve this billing issue.",
    confidence: 0.85,
    source: "policy_engine",
  },
  {
    id: "sug_003",
    type: "action",
    content: "Escalate to billing team - customer has been waiting 48+ hours",
    confidence: 0.78,
    source: "workflow_engine",
  },
  {
    id: "sug_004",
    type: "knowledge",
    content:
      "Related KB article: 'How to update payment methods' (last updated 2 days ago)",
    confidence: 0.95,
    source: "knowledge_base",
  },
];

const MOCK_SUMMARY =
  "Customer Sarah Chen is experiencing issues with subscription renewal due to an expired payment card. She has been a customer for 2 years with a Pro plan. Previous interactions show timely payments with no prior billing issues.";

export function useCopilot({ conversationId }: UseCopilotProps): UseCopilotReturn {
  const [suggestions, setSuggestions] = useState<Suggestion[]>([]);
  const [draft, setDraft] = useState<string | null>(null);
  const [summary, setSummary] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    setIsLoading(true);
    setSuggestions([]);
    setDraft(null);
    setSummary(null);

    const timer = setTimeout(() => {
      setSuggestions(MOCK_SUGGESTIONS);
      setSummary(MOCK_SUMMARY);
      setIsLoading(false);
    }, 1000);

    return () => clearTimeout(timer);
  }, [conversationId]);

  const generateDraft = useCallback(async (prompt?: string) => {
    setIsLoading(true);
    await new Promise((resolve) => setTimeout(resolve, 1200));

    const generatedDraft = prompt
      ? `Based on your request: ${prompt}\n\nHi Sarah,\n\nI understand you're having trouble with your subscription renewal. I've looked into your account and can see the issue. Let me help you resolve this right away.\n\nBest regards,\nAlex`
      : "Hi Sarah,\n\nThank you for reaching out about your subscription. I can see that your payment method on file has expired. Here's how to update it:\n\n1. Navigate to Settings > Billing\n2. Click 'Update Payment Method'\n3. Enter your new card details\n\nOnce updated, your subscription will renew automatically. I've also applied a 7-day extension so you won't lose access.\n\nLet me know if you need anything else!\n\nBest,\nAlex";

    setDraft(generatedDraft);
    setIsLoading(false);
  }, []);

  const refreshSuggestions = useCallback(async () => {
    setIsLoading(true);
    await new Promise((resolve) => setTimeout(resolve, 800));
    // Shuffle suggestions to simulate refresh
    setSuggestions([...MOCK_SUGGESTIONS].sort(() => Math.random() - 0.5));
    setIsLoading(false);
  }, []);

  const submitFeedback = useCallback(
    (suggestionId: string, _helpful: boolean) => {
      setSuggestions((prev) => prev.filter((s) => s.id !== suggestionId));
    },
    []
  );

  return {
    suggestions,
    draft,
    summary,
    isLoading,
    generateDraft,
    refreshSuggestions,
    submitFeedback,
  };
}
