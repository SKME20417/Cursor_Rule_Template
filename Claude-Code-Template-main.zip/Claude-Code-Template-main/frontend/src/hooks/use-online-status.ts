"use client";

import { useState, useCallback, useEffect } from "react";

type AgentStatus = "online" | "away" | "offline";

interface UseOnlineStatusReturn {
  status: AgentStatus;
  setStatus: (status: AgentStatus) => void;
}

const STATUS_STORAGE_KEY = "copilot_agent_status";

export function useOnlineStatus(): UseOnlineStatusReturn {
  const [status, setStatusState] = useState<AgentStatus>(() => {
    if (typeof window !== "undefined") {
      const stored = localStorage.getItem(STATUS_STORAGE_KEY);
      if (stored === "online" || stored === "away" || stored === "offline") {
        return stored;
      }
    }
    return "online";
  });

  useEffect(() => {
    localStorage.setItem(STATUS_STORAGE_KEY, status);
  }, [status]);

  const setStatus = useCallback((newStatus: AgentStatus) => {
    setStatusState(newStatus);
  }, []);

  return { status, setStatus };
}
