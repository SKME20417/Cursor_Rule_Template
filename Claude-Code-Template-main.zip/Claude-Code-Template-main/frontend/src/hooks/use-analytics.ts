"use client";

import { useState, useEffect } from "react";

type TimeRange = "1h" | "24h" | "7d" | "30d" | "90d";
type Metric =
  | "response_time"
  | "resolution_rate"
  | "customer_satisfaction"
  | "ticket_volume"
  | "agent_performance";

interface DataPoint {
  label: string;
  value: number;
}

interface AnalyticsData {
  metric: Metric;
  timeRange: TimeRange;
  points: DataPoint[];
  total: number;
  average: number;
  trend: number; // percentage change
}

interface UseAnalyticsProps {
  timeRange: TimeRange;
  metric: Metric;
}

interface UseAnalyticsReturn {
  data: AnalyticsData | null;
  isLoading: boolean;
  error: string | null;
}

function generateMockData(metric: Metric, timeRange: TimeRange): AnalyticsData {
  const pointCounts: Record<TimeRange, number> = {
    "1h": 12,
    "24h": 24,
    "7d": 7,
    "30d": 30,
    "90d": 12,
  };

  const labelFormats: Record<TimeRange, (i: number) => string> = {
    "1h": (i) => `${i * 5}m`,
    "24h": (i) => `${i}:00`,
    "7d": (i) => `Day ${i + 1}`,
    "30d": (i) => `Day ${i + 1}`,
    "90d": (i) => `Week ${i + 1}`,
  };

  const ranges: Record<Metric, [number, number]> = {
    response_time: [30, 180],
    resolution_rate: [60, 98],
    customer_satisfaction: [3.5, 5.0],
    ticket_volume: [10, 150],
    agent_performance: [50, 100],
  };

  const count = pointCounts[timeRange];
  const [min, max] = ranges[metric];
  const format = labelFormats[timeRange];

  const points: DataPoint[] = Array.from({ length: count }, (_, i) => ({
    label: format(i),
    value: Math.round((min + Math.random() * (max - min)) * 100) / 100,
  }));

  const values = points.map((p) => p.value);
  const total = values.reduce((sum, v) => sum + v, 0);
  const average = Math.round((total / values.length) * 100) / 100;
  const trend = Math.round((Math.random() * 20 - 5) * 100) / 100;

  return { metric, timeRange, points, total, average, trend };
}

export function useAnalytics({ timeRange, metric }: UseAnalyticsProps): UseAnalyticsReturn {
  const [data, setData] = useState<AnalyticsData | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    setIsLoading(true);
    setError(null);

    const timer = setTimeout(() => {
      try {
        const generated = generateMockData(metric, timeRange);
        setData(generated);
      } catch {
        setError("Failed to load analytics data");
      } finally {
        setIsLoading(false);
      }
    }, 700);

    return () => clearTimeout(timer);
  }, [timeRange, metric]);

  return { data, isLoading, error };
}
