"use client";

import { useState, useCallback, useEffect, useRef } from "react";

type CallState = "idle" | "ringing" | "active" | "on_hold" | "ended";

interface UseCallReturn {
  callState: CallState;
  startCall: (contactId: string) => void;
  endCall: () => void;
  mute: () => void;
  hold: () => void;
  transfer: (targetAgentId: string) => void;
  duration: number;
  isMuted: boolean;
}

export function useCall(): UseCallReturn {
  const [callState, setCallState] = useState<CallState>("idle");
  const [duration, setDuration] = useState(0);
  const [isMuted, setIsMuted] = useState(false);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const clearTimer = useCallback(() => {
    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }
  }, []);

  useEffect(() => {
    return clearTimer;
  }, [clearTimer]);

  const startTimer = useCallback(() => {
    clearTimer();
    setDuration(0);
    timerRef.current = setInterval(() => {
      setDuration((prev) => prev + 1);
    }, 1000);
  }, [clearTimer]);

  const startCall = useCallback(
    (_contactId: string) => {
      setCallState("ringing");
      setIsMuted(false);
      // Mock: auto-answer after 2s
      const answerTimer = setTimeout(() => {
        setCallState("active");
        startTimer();
      }, 2000);

      return () => clearTimeout(answerTimer);
    },
    [startTimer]
  );

  const endCall = useCallback(() => {
    clearTimer();
    setCallState("ended");
    setIsMuted(false);
    // Reset to idle after brief delay
    const resetTimer = setTimeout(() => {
      setCallState("idle");
      setDuration(0);
    }, 1500);

    return () => clearTimeout(resetTimer);
  }, [clearTimer]);

  const mute = useCallback(() => {
    setIsMuted((prev) => !prev);
  }, []);

  const hold = useCallback(() => {
    setCallState((prev) => {
      if (prev === "active") return "on_hold";
      if (prev === "on_hold") return "active";
      return prev;
    });
  }, []);

  const transfer = useCallback(
    (_targetAgentId: string) => {
      // Mock: simulate transfer
      setCallState("ended");
      clearTimer();
      setTimeout(() => {
        setCallState("idle");
        setDuration(0);
      }, 1500);
    },
    [clearTimer]
  );

  return {
    callState,
    startCall,
    endCall,
    mute,
    hold,
    transfer,
    duration,
    isMuted,
  };
}
