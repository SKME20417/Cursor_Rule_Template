"use client";

import { useState, useCallback } from "react";

interface UseScreenShareReturn {
  isSharing: boolean;
  sharingUser: string | null;
  startSharing: () => Promise<void>;
  stopSharing: () => void;
}

export function useScreenShare(): UseScreenShareReturn {
  const [isSharing, setIsSharing] = useState(false);
  const [sharingUser, setSharingUser] = useState<string | null>(null);

  const startSharing = useCallback(async () => {
    // Mock: in real implementation would call navigator.mediaDevices.getDisplayMedia
    setIsSharing(true);
    setSharingUser("usr_001");
  }, []);

  const stopSharing = useCallback(() => {
    setIsSharing(false);
    setSharingUser(null);
  }, []);

  return {
    isSharing,
    sharingUser,
    startSharing,
    stopSharing,
  };
}
