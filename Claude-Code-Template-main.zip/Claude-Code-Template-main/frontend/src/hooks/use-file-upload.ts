"use client";

import { useState, useCallback, useRef } from "react";

interface UseFileUploadReturn {
  upload: (file: File) => Promise<string>;
  progress: number;
  isUploading: boolean;
  error: string | null;
  reset: () => void;
}

export function useFileUpload(): UseFileUploadReturn {
  const [progress, setProgress] = useState(0);
  const [isUploading, setIsUploading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const clearSimulation = useCallback(() => {
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }
  }, []);

  const upload = useCallback(
    async (file: File): Promise<string> => {
      const MAX_SIZE = 50 * 1024 * 1024; // 50MB
      if (file.size > MAX_SIZE) {
        const msg = "File size exceeds 50MB limit";
        setError(msg);
        throw new Error(msg);
      }

      setIsUploading(true);
      setProgress(0);
      setError(null);

      return new Promise<string>((resolve, reject) => {
        let currentProgress = 0;

        intervalRef.current = setInterval(() => {
          currentProgress += Math.random() * 15 + 5;
          if (currentProgress >= 100) {
            currentProgress = 100;
            setProgress(100);
            clearSimulation();
            setIsUploading(false);
            resolve(`/uploads/mock_${Date.now()}_${file.name}`);
          } else {
            setProgress(Math.round(currentProgress));
          }
        }, 200);

        // Simulate possible failure for very large files
        if (file.size > 40 * 1024 * 1024) {
          setTimeout(() => {
            if (Math.random() > 0.7) {
              clearSimulation();
              const msg = "Upload failed: network error";
              setError(msg);
              setIsUploading(false);
              reject(new Error(msg));
            }
          }, 1500);
        }
      });
    },
    [clearSimulation]
  );

  const reset = useCallback(() => {
    clearSimulation();
    setProgress(0);
    setIsUploading(false);
    setError(null);
  }, [clearSimulation]);

  return { upload, progress, isUploading, error, reset };
}
