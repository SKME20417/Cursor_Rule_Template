"use client";

import { useState, useCallback, useEffect } from "react";

type TicketStatus = "open" | "in_progress" | "pending" | "resolved" | "closed";
type TicketPriority = "low" | "medium" | "high" | "urgent";

interface Ticket {
  id: string;
  title: string;
  description: string;
  status: TicketStatus;
  priority: TicketPriority;
  customerId: string;
  customerName: string;
  assignedTo: string | null;
  assignedName: string | null;
  category: string;
  tags: string[];
  createdAt: string;
  updatedAt: string;
  conversationId: string | null;
}

interface TicketFilters {
  status?: TicketStatus;
  priority?: TicketPriority;
  assignedTo?: string;
  search?: string;
}

interface Pagination {
  page: number;
  pageSize: number;
  total: number;
  totalPages: number;
}

interface CreateTicketData {
  title: string;
  description: string;
  priority: TicketPriority;
  customerId: string;
  customerName: string;
  category: string;
  tags?: string[];
}

interface UpdateTicketData {
  title?: string;
  description?: string;
  status?: TicketStatus;
  priority?: TicketPriority;
  assignedTo?: string | null;
  assignedName?: string | null;
  tags?: string[];
}

interface UseTicketsReturn {
  tickets: Ticket[];
  createTicket: (data: CreateTicketData) => Promise<Ticket>;
  updateTicket: (id: string, data: UpdateTicketData) => Promise<Ticket>;
  closeTicket: (id: string) => Promise<void>;
  filters: TicketFilters;
  setFilters: (filters: TicketFilters) => void;
  isLoading: boolean;
  pagination: Pagination;
}

const MOCK_TICKETS: Ticket[] = [
  {
    id: "tkt_001",
    title: "Cannot access billing dashboard",
    description: "User reports 500 error when navigating to billing page",
    status: "open",
    priority: "high",
    customerId: "cust_001",
    customerName: "Sarah Chen",
    assignedTo: "usr_001",
    assignedName: "Alex Johnson",
    category: "billing",
    tags: ["bug", "billing"],
    createdAt: new Date(Date.now() - 3600000).toISOString(),
    updatedAt: new Date(Date.now() - 1800000).toISOString(),
    conversationId: "conv_001",
  },
  {
    id: "tkt_002",
    title: "API rate limit too low for enterprise plan",
    description: "Enterprise customer needs higher API rate limits",
    status: "in_progress",
    priority: "medium",
    customerId: "cust_002",
    customerName: "Mike Williams",
    assignedTo: "usr_001",
    assignedName: "Alex Johnson",
    category: "api",
    tags: ["enhancement", "enterprise"],
    createdAt: new Date(Date.now() - 86400000).toISOString(),
    updatedAt: new Date(Date.now() - 43200000).toISOString(),
    conversationId: "conv_002",
  },
  {
    id: "tkt_003",
    title: "Unauthorized login attempts detected",
    description: "Multiple failed login attempts from unknown IPs",
    status: "open",
    priority: "urgent",
    customerId: "cust_003",
    customerName: "Emily Rodriguez",
    assignedTo: null,
    assignedName: null,
    category: "security",
    tags: ["security", "urgent"],
    createdAt: new Date(Date.now() - 1800000).toISOString(),
    updatedAt: new Date(Date.now() - 900000).toISOString(),
    conversationId: "conv_003",
  },
  {
    id: "tkt_004",
    title: "Feature request: Export analytics to CSV",
    description: "Customer wants to export analytics dashboard data",
    status: "pending",
    priority: "low",
    customerId: "cust_004",
    customerName: "David Park",
    assignedTo: "usr_002",
    assignedName: "Jordan Lee",
    category: "feature-request",
    tags: ["feature-request", "analytics"],
    createdAt: new Date(Date.now() - 172800000).toISOString(),
    updatedAt: new Date(Date.now() - 172800000).toISOString(),
    conversationId: null,
  },
  {
    id: "tkt_005",
    title: "Refund request for double charge",
    description: "Customer was charged twice for monthly subscription",
    status: "resolved",
    priority: "high",
    customerId: "cust_005",
    customerName: "Lisa Thompson",
    assignedTo: "usr_001",
    assignedName: "Alex Johnson",
    category: "billing",
    tags: ["refund", "billing"],
    createdAt: new Date(Date.now() - 259200000).toISOString(),
    updatedAt: new Date(Date.now() - 86400000).toISOString(),
    conversationId: "conv_005",
  },
];

export function useTickets(): UseTicketsReturn {
  const [tickets, setTickets] = useState<Ticket[]>([]);
  const [filters, setFilters] = useState<TicketFilters>({});
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    setIsLoading(true);
    const timer = setTimeout(() => {
      setTickets(MOCK_TICKETS);
      setIsLoading(false);
    }, 600);

    return () => clearTimeout(timer);
  }, []);

  const filteredTickets = tickets.filter((ticket) => {
    if (filters.status && ticket.status !== filters.status) return false;
    if (filters.priority && ticket.priority !== filters.priority) return false;
    if (filters.assignedTo && ticket.assignedTo !== filters.assignedTo)
      return false;
    if (
      filters.search &&
      !ticket.title.toLowerCase().includes(filters.search.toLowerCase()) &&
      !ticket.customerName.toLowerCase().includes(filters.search.toLowerCase())
    ) {
      return false;
    }
    return true;
  });

  const createTicket = useCallback(async (data: CreateTicketData): Promise<Ticket> => {
    await new Promise((resolve) => setTimeout(resolve, 500));
    const newTicket: Ticket = {
      id: `tkt_${Date.now()}`,
      title: data.title,
      description: data.description,
      status: "open",
      priority: data.priority,
      customerId: data.customerId,
      customerName: data.customerName,
      assignedTo: null,
      assignedName: null,
      category: data.category,
      tags: data.tags ?? [],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      conversationId: null,
    };
    setTickets((prev) => [newTicket, ...prev]);
    return newTicket;
  }, []);

  const updateTicket = useCallback(
    async (id: string, data: UpdateTicketData): Promise<Ticket> => {
      await new Promise((resolve) => setTimeout(resolve, 300));
      let updated: Ticket | undefined;
      setTickets((prev) =>
        prev.map((t) => {
          if (t.id === id) {
            updated = { ...t, ...data, updatedAt: new Date().toISOString() };
            return updated;
          }
          return t;
        })
      );
      if (!updated) throw new Error(`Ticket ${id} not found`);
      return updated;
    },
    []
  );

  const closeTicket = useCallback(async (id: string): Promise<void> => {
    await new Promise((resolve) => setTimeout(resolve, 300));
    setTickets((prev) =>
      prev.map((t) =>
        t.id === id
          ? { ...t, status: "closed" as const, updatedAt: new Date().toISOString() }
          : t
      )
    );
  }, []);

  const pagination: Pagination = {
    page: 1,
    pageSize: 20,
    total: filteredTickets.length,
    totalPages: Math.ceil(filteredTickets.length / 20),
  };

  return {
    tickets: filteredTickets,
    createTicket,
    updateTicket,
    closeTicket,
    filters,
    setFilters,
    isLoading,
    pagination,
  };
}
