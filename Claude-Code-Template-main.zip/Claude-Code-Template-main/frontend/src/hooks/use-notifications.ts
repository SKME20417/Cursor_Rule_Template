"use client";

import { useState, useCallback, useEffect } from "react";

type NotificationType = "info" | "warning" | "success" | "error";

interface Notification {
  id: string;
  type: NotificationType;
  title: string;
  message: string;
  read: boolean;
  createdAt: string;
}

interface UseNotificationsReturn {
  notifications: Notification[];
  unreadCount: number;
  markAsRead: (id: string) => void;
  markAllRead: () => void;
  dismiss: (id: string) => void;
}

const MOCK_NOTIFICATIONS: Notification[] = [
  {
    id: "notif_001",
    type: "warning",
    title: "Urgent ticket assigned",
    message: "Ticket #TKT-003: Unauthorized login attempts detected",
    read: false,
    createdAt: new Date(Date.now() - 300000).toISOString(),
  },
  {
    id: "notif_002",
    type: "info",
    title: "New conversation",
    message: "Sarah Chen started a new chat conversation",
    read: false,
    createdAt: new Date(Date.now() - 600000).toISOString(),
  },
  {
    id: "notif_003",
    type: "success",
    title: "Ticket resolved",
    message: "Ticket #TKT-005 has been resolved and closed",
    read: false,
    createdAt: new Date(Date.now() - 3600000).toISOString(),
  },
  {
    id: "notif_004",
    type: "info",
    title: "Shift reminder",
    message: "Your shift starts in 30 minutes",
    read: true,
    createdAt: new Date(Date.now() - 7200000).toISOString(),
  },
  {
    id: "notif_005",
    type: "error",
    title: "SLA breach warning",
    message: "Ticket #TKT-002 is approaching SLA breach (2 hours remaining)",
    read: false,
    createdAt: new Date(Date.now() - 1800000).toISOString(),
  },
];

export function useNotifications(): UseNotificationsReturn {
  const [notifications, setNotifications] = useState<Notification[]>([]);

  useEffect(() => {
    const timer = setTimeout(() => {
      setNotifications(MOCK_NOTIFICATIONS);
    }, 300);

    return () => clearTimeout(timer);
  }, []);

  const unreadCount = notifications.filter((n) => !n.read).length;

  const markAsRead = useCallback((id: string) => {
    setNotifications((prev) =>
      prev.map((n) => (n.id === id ? { ...n, read: true } : n))
    );
  }, []);

  const markAllRead = useCallback(() => {
    setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
  }, []);

  const dismiss = useCallback((id: string) => {
    setNotifications((prev) => prev.filter((n) => n.id !== id));
  }, []);

  return {
    notifications,
    unreadCount,
    markAsRead,
    markAllRead,
    dismiss,
  };
}
