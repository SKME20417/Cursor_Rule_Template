"use client";

import { useState, useEffect, useRef } from "react";

interface TranscriptSegment {
  id: string;
  speaker: "agent" | "customer";
  speakerName: string;
  text: string;
  timestamp: string;
  confidence: number;
}

interface UseLiveTranscriptReturn {
  segments: TranscriptSegment[];
  isTranscribing: boolean;
  currentSpeaker: "agent" | "customer" | null;
}

const MOCK_TRANSCRIPT_STREAM: Omit<TranscriptSegment, "id" | "timestamp">[] = [
  {
    speaker: "customer",
    speakerName: "Sarah Chen",
    text: "Hi, I need help with my account.",
    confidence: 0.95,
  },
  {
    speaker: "agent",
    speakerName: "Alex Johnson",
    text: "Of course, I'd be happy to help. Can you tell me what's going on?",
    confidence: 0.98,
  },
  {
    speaker: "customer",
    speakerName: "Sarah Chen",
    text: "I can't seem to update my payment method. The page just keeps loading.",
    confidence: 0.92,
  },
  {
    speaker: "agent",
    speakerName: "Alex Johnson",
    text: "Let me check that for you. Could you verify your email address?",
    confidence: 0.97,
  },
  {
    speaker: "customer",
    speakerName: "Sarah Chen",
    text: "Sure, it's sarah.chen@email.com.",
    confidence: 0.88,
  },
  {
    speaker: "agent",
    speakerName: "Alex Johnson",
    text: "I found the issue. There was a temporary service disruption. It should be working now.",
    confidence: 0.96,
  },
];

export function useLiveTranscript(): UseLiveTranscriptReturn {
  const [segments, setSegments] = useState<TranscriptSegment[]>([]);
  const [isTranscribing, setIsTranscribing] = useState(false);
  const [currentSpeaker, setCurrentSpeaker] = useState<"agent" | "customer" | null>(null);
  const indexRef = useRef(0);

  useEffect(() => {
    setIsTranscribing(true);

    const streamSegment = () => {
      if (indexRef.current >= MOCK_TRANSCRIPT_STREAM.length) {
        setIsTranscribing(false);
        setCurrentSpeaker(null);
        return;
      }

      const segment = MOCK_TRANSCRIPT_STREAM[indexRef.current];
      if (!segment) return;

      setCurrentSpeaker(segment.speaker);

      const newSegment: TranscriptSegment = {
        id: `seg_${Date.now()}_${indexRef.current}`,
        ...segment,
        timestamp: new Date().toISOString(),
      };

      setSegments((prev) => [...prev, newSegment]);
      indexRef.current += 1;
    };

    // Stream segments every 3 seconds
    const interval = setInterval(streamSegment, 3000);

    // Start the first segment immediately
    streamSegment();

    return () => {
      clearInterval(interval);
    };
  }, []);

  return {
    segments,
    isTranscribing,
    currentSpeaker,
  };
}
