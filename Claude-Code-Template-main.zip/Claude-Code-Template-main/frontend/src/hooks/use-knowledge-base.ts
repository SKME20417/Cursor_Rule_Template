"use client";

import { useState, useCallback, useEffect } from "react";

interface KBArticle {
  id: string;
  title: string;
  content: string;
  category: string;
  tags: string[];
  updatedAt: string;
  viewCount: number;
}

interface KBCategory {
  id: string;
  name: string;
  articleCount: number;
}

interface UseKnowledgeBaseReturn {
  articles: KBArticle[];
  categories: KBCategory[];
  search: (query: string) => void;
  isLoading: boolean;
}

const MOCK_ARTICLES: KBArticle[] = [
  {
    id: "kb_001",
    title: "How to update payment methods",
    content:
      "Navigate to Settings > Billing > Payment Methods. Click 'Add new card' and enter your details. Your subscription will automatically use the new payment method.",
    category: "Billing",
    tags: ["billing", "payment", "subscription"],
    updatedAt: new Date(Date.now() - 172800000).toISOString(),
    viewCount: 1523,
  },
  {
    id: "kb_002",
    title: "API Authentication Guide",
    content:
      "All API requests require a Bearer token in the Authorization header. Generate tokens from Settings > API Keys. Tokens expire after 90 days.",
    category: "API",
    tags: ["api", "authentication", "tokens"],
    updatedAt: new Date(Date.now() - 604800000).toISOString(),
    viewCount: 2841,
  },
  {
    id: "kb_003",
    title: "Account security best practices",
    content:
      "Enable two-factor authentication, use strong passwords, review active sessions regularly, and set up login notifications.",
    category: "Security",
    tags: ["security", "2fa", "account"],
    updatedAt: new Date(Date.now() - 86400000).toISOString(),
    viewCount: 987,
  },
  {
    id: "kb_004",
    title: "Refund policy and procedures",
    content:
      "Refunds can be requested within 30 days of purchase. Pro-rated refunds are available for annual plans. Contact support for enterprise refund requests.",
    category: "Billing",
    tags: ["billing", "refund", "policy"],
    updatedAt: new Date(Date.now() - 2592000000).toISOString(),
    viewCount: 654,
  },
  {
    id: "kb_005",
    title: "Integrating with Slack",
    content:
      "Install our Slack app from the marketplace. Authorize with your workspace. Configure notification channels in Settings > Integrations > Slack.",
    category: "Integrations",
    tags: ["integrations", "slack", "notifications"],
    updatedAt: new Date(Date.now() - 432000000).toISOString(),
    viewCount: 1102,
  },
];

const MOCK_CATEGORIES: KBCategory[] = [
  { id: "cat_001", name: "Billing", articleCount: 12 },
  { id: "cat_002", name: "API", articleCount: 8 },
  { id: "cat_003", name: "Security", articleCount: 6 },
  { id: "cat_004", name: "Integrations", articleCount: 15 },
  { id: "cat_005", name: "Getting Started", articleCount: 10 },
];

export function useKnowledgeBase(): UseKnowledgeBaseReturn {
  const [articles, setArticles] = useState<KBArticle[]>([]);
  const [categories] = useState<KBCategory[]>(MOCK_CATEGORIES);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    setIsLoading(true);
    const timer = setTimeout(() => {
      setArticles(MOCK_ARTICLES);
      setIsLoading(false);
    }, 500);

    return () => clearTimeout(timer);
  }, []);

  const search = useCallback((query: string) => {
    setIsLoading(true);
    const timer = setTimeout(() => {
      if (!query.trim()) {
        setArticles(MOCK_ARTICLES);
      } else {
        const lower = query.toLowerCase();
        const filtered = MOCK_ARTICLES.filter(
          (a) =>
            a.title.toLowerCase().includes(lower) ||
            a.content.toLowerCase().includes(lower) ||
            a.tags.some((t) => t.includes(lower))
        );
        setArticles(filtered);
      }
      setIsLoading(false);
    }, 300);

    return () => clearTimeout(timer);
  }, []);

  return {
    articles,
    categories,
    search,
    isLoading,
  };
}
