"use client";

import { useAuth } from "./use-auth";

type Action = "view" | "create" | "edit" | "delete";
type Resource =
  | "tickets"
  | "conversations"
  | "analytics"
  | "agents"
  | "settings"
  | "knowledge_base";

type Role = "admin" | "agent" | "supervisor" | "viewer";

interface UsePermissionsReturn {
  can: (action: Action, resource: Resource) => boolean;
  role: Role | null;
}

const PERMISSION_MATRIX: Record<Role, Record<Resource, Action[]>> = {
  admin: {
    tickets: ["view", "create", "edit", "delete"],
    conversations: ["view", "create", "edit", "delete"],
    analytics: ["view", "create", "edit", "delete"],
    agents: ["view", "create", "edit", "delete"],
    settings: ["view", "create", "edit", "delete"],
    knowledge_base: ["view", "create", "edit", "delete"],
  },
  supervisor: {
    tickets: ["view", "create", "edit", "delete"],
    conversations: ["view", "create", "edit"],
    analytics: ["view"],
    agents: ["view", "edit"],
    settings: ["view"],
    knowledge_base: ["view", "create", "edit"],
  },
  agent: {
    tickets: ["view", "create", "edit"],
    conversations: ["view", "create", "edit"],
    analytics: ["view"],
    agents: [],
    settings: [],
    knowledge_base: ["view"],
  },
  viewer: {
    tickets: ["view"],
    conversations: ["view"],
    analytics: ["view"],
    agents: [],
    settings: [],
    knowledge_base: ["view"],
  },
};

export function usePermissions(): UsePermissionsReturn {
  const { user } = useAuth();
  const role = user?.role ?? null;

  const can = (action: Action, resource: Resource): boolean => {
    if (!role) return false;
    const allowed = PERMISSION_MATRIX[role]?.[resource] ?? [];
    return allowed.includes(action);
  };

  return { can, role };
}
