"use client";

import { useState, useCallback, useEffect, useRef } from "react";
import { useWebSocket } from "./use-websocket";

interface ChatMessage {
  id: string;
  conversationId: string;
  sender: "agent" | "customer" | "bot";
  senderName: string;
  content: string;
  timestamp: string;
  status: "sent" | "delivered" | "read";
}

interface UseChatProps {
  conversationId: string;
}

interface UseChatReturn {
  messages: ChatMessage[];
  sendMessage: (content: string) => void;
  isTyping: boolean;
  setTyping: (typing: boolean) => void;
  loadMore: () => void;
  isLoading: boolean;
}

const MOCK_MESSAGES: ChatMessage[] = [
  {
    id: "msg_001",
    conversationId: "conv_001",
    sender: "customer",
    senderName: "Sarah Chen",
    content: "Hi, I'm having trouble with my subscription renewal.",
    timestamp: new Date(Date.now() - 600000).toISOString(),
    status: "read",
  },
  {
    id: "msg_002",
    conversationId: "conv_001",
    sender: "bot",
    senderName: "Support Bot",
    content: "I can help with subscription issues. Let me look up your account.",
    timestamp: new Date(Date.now() - 540000).toISOString(),
    status: "read",
  },
  {
    id: "msg_003",
    conversationId: "conv_001",
    sender: "agent",
    senderName: "Alex Johnson",
    content: "Hi Sarah, I see your renewal failed due to an expired card. Would you like to update your payment method?",
    timestamp: new Date(Date.now() - 300000).toISOString(),
    status: "delivered",
  },
  {
    id: "msg_004",
    conversationId: "conv_001",
    sender: "customer",
    senderName: "Sarah Chen",
    content: "Yes please, how do I do that?",
    timestamp: new Date(Date.now() - 120000).toISOString(),
    status: "read",
  },
];

export function useChat({ conversationId }: UseChatProps): UseChatReturn {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [isTyping, setIsTyping] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const messageCountRef = useRef(0);
  const { subscribe } = useWebSocket();

  useEffect(() => {
    // Load mock messages for the conversation
    setIsLoading(true);
    const timer = setTimeout(() => {
      const filtered = MOCK_MESSAGES.filter(
        (m) => m.conversationId === conversationId
      );
      setMessages(filtered.length > 0 ? filtered : MOCK_MESSAGES);
      setIsLoading(false);
    }, 500);

    return () => clearTimeout(timer);
  }, [conversationId]);

  useEffect(() => {
    const unsubscribe = subscribe("new_message", (data) => {
      const message = data as ChatMessage;
      if (message.conversationId === conversationId) {
        setMessages((prev) => [...prev, message]);
      }
    });

    return unsubscribe;
  }, [conversationId, subscribe]);

  const sendMessage = useCallback(
    (content: string) => {
      messageCountRef.current += 1;
      const newMessage: ChatMessage = {
        id: `msg_${Date.now()}_${messageCountRef.current}`,
        conversationId,
        sender: "agent",
        senderName: "Alex Johnson",
        content,
        timestamp: new Date().toISOString(),
        status: "sent",
      };
      setMessages((prev) => [...prev, newMessage]);

      // Mock: simulate customer typing response
      setIsTyping(true);
      const typingTimer = setTimeout(() => {
        setIsTyping(false);
      }, 2000);

      return () => clearTimeout(typingTimer);
    },
    [conversationId]
  );

  const loadMore = useCallback(() => {
    setIsLoading(true);
    const timer = setTimeout(() => {
      // Mock: no older messages to load
      setIsLoading(false);
    }, 500);

    return () => clearTimeout(timer);
  }, []);

  return {
    messages,
    sendMessage,
    isTyping,
    setTyping: setIsTyping,
    loadMore,
    isLoading,
  };
}
