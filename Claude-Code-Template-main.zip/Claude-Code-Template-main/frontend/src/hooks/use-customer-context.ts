"use client";

import { useState, useEffect } from "react";

interface Customer {
  id: string;
  name: string;
  email: string;
  company: string;
  plan: string;
  customerSince: string;
  lifetimeValue: number;
  avatar: string;
}

interface CustomerTicket {
  id: string;
  title: string;
  status: "open" | "in_progress" | "resolved" | "closed";
  createdAt: string;
}

interface CustomerConversation {
  id: string;
  subject: string;
  channel: "chat" | "email" | "phone" | "social";
  status: "active" | "resolved";
  lastMessageAt: string;
}

interface UseCustomerContextProps {
  customerId: string;
}

interface UseCustomerContextReturn {
  customer: Customer | null;
  tickets: CustomerTicket[];
  conversations: CustomerConversation[];
  isLoading: boolean;
}

const MOCK_CUSTOMERS: Record<string, Customer> = {
  cust_001: {
    id: "cust_001",
    name: "Sarah Chen",
    email: "sarah.chen@email.com",
    company: "TechCorp Inc.",
    plan: "Pro",
    customerSince: "2024-03-15",
    lifetimeValue: 4800,
    avatar: "/avatars/sarah.png",
  },
  cust_002: {
    id: "cust_002",
    name: "Mike Williams",
    email: "mike.w@startup.io",
    company: "StartupIO",
    plan: "Enterprise",
    customerSince: "2023-08-01",
    lifetimeValue: 24000,
    avatar: "/avatars/mike.png",
  },
};

const MOCK_CUSTOMER_TICKETS: Record<string, CustomerTicket[]> = {
  cust_001: [
    {
      id: "tkt_001",
      title: "Cannot access billing dashboard",
      status: "open",
      createdAt: new Date(Date.now() - 3600000).toISOString(),
    },
    {
      id: "tkt_010",
      title: "Password reset not working",
      status: "resolved",
      createdAt: new Date(Date.now() - 2592000000).toISOString(),
    },
  ],
  cust_002: [
    {
      id: "tkt_002",
      title: "API rate limit too low",
      status: "in_progress",
      createdAt: new Date(Date.now() - 86400000).toISOString(),
    },
  ],
};

const MOCK_CUSTOMER_CONVERSATIONS: Record<string, CustomerConversation[]> = {
  cust_001: [
    {
      id: "conv_001",
      subject: "Subscription renewal issue",
      channel: "chat",
      status: "active",
      lastMessageAt: new Date(Date.now() - 120000).toISOString(),
    },
    {
      id: "conv_010",
      subject: "Onboarding help",
      channel: "email",
      status: "resolved",
      lastMessageAt: new Date(Date.now() - 5184000000).toISOString(),
    },
  ],
  cust_002: [
    {
      id: "conv_002",
      subject: "API integration help",
      channel: "email",
      status: "active",
      lastMessageAt: new Date(Date.now() - 3600000).toISOString(),
    },
  ],
};

export function useCustomerContext({
  customerId,
}: UseCustomerContextProps): UseCustomerContextReturn {
  const [customer, setCustomer] = useState<Customer | null>(null);
  const [tickets, setTickets] = useState<CustomerTicket[]>([]);
  const [conversations, setConversations] = useState<CustomerConversation[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    setIsLoading(true);
    setCustomer(null);
    setTickets([]);
    setConversations([]);

    const timer = setTimeout(() => {
      setCustomer(MOCK_CUSTOMERS[customerId] ?? null);
      setTickets(MOCK_CUSTOMER_TICKETS[customerId] ?? []);
      setConversations(MOCK_CUSTOMER_CONVERSATIONS[customerId] ?? []);
      setIsLoading(false);
    }, 500);

    return () => clearTimeout(timer);
  }, [customerId]);

  return { customer, tickets, conversations, isLoading };
}
