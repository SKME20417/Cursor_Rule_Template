import { NextRequest, NextResponse } from "next/server";

/** Paths that do not require authentication. */
const PUBLIC_PATHS = ["/login", "/register", "/forgot-password", "/reset-password"];

/** Role-based route access. */
const ROLE_ROUTE_MAP: Record<string, string[]> = {
  customer: [],
  agent: ["/agent"],
  admin: ["/agent", "/admin"],
};

/**
 * Extracts the role from a JWT token by decoding the payload (middle segment).
 * Returns the role string or null if decoding fails.
 */
function extractRoleFromJwt(token: string): string | null {
  try {
    const parts = token.split(".");
    if (parts.length !== 3) {
      return null;
    }

    // Base64url decode the payload (second segment)
    const payload = parts[1];
    const decoded = atob(payload.replace(/-/g, "+").replace(/_/g, "/"));
    const parsed = JSON.parse(decoded) as Record<string, unknown>;

    if (typeof parsed.role === "string") {
      return parsed.role.toLowerCase();
    }

    return null;
  } catch {
    return null;
  }
}

export function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl;

  // Let static assets, API routes, and public files pass through
  if (
    pathname.startsWith("/_next") ||
    pathname.startsWith("/api") ||
    pathname.startsWith("/icons") ||
    pathname === "/manifest.json" ||
    pathname === "/favicon.ico"
  ) {
    return NextResponse.next();
  }

  const response = NextResponse.next();

  // Add correlation ID for request tracing
  response.headers.set("X-Correlation-ID", crypto.randomUUID());

  // Check for auth token
  const token = request.cookies.get("auth-token")?.value;
  const isPublicPath =
    pathname === "/" || PUBLIC_PATHS.some((p) => pathname.startsWith(p));

  // Redirect unauthenticated users to login (allow landing page)
  if (!token && !isPublicPath) {
    const loginUrl = new URL("/login", request.url);
    loginUrl.searchParams.set("redirect", pathname);
    return NextResponse.redirect(loginUrl);
  }

  // Extract the role from the JWT token
  const role = token ? extractRoleFromJwt(token) : null;

  // Redirect authenticated users away from auth pages
  if (token && isPublicPath) {
    const home =
      role === "admin" ? "/admin" : role === "agent" ? "/agent" : "/customer";
    return NextResponse.redirect(new URL(home, request.url));
  }

  // Role-based routing guard
  if (token && role) {
    const isAgentRoute = pathname.startsWith("/agent") || pathname.match(/^\/(agent)\//);
    const isAdminRoute = pathname.startsWith("/admin") || pathname.match(/^\/(admin)\//);

    // Customer cannot access /agent/* or /admin/*
    if (role === "customer" && (isAgentRoute || isAdminRoute)) {
      return NextResponse.redirect(new URL("/", request.url));
    }

    // Agent cannot access /admin/*
    if (role === "agent" && isAdminRoute) {
      return NextResponse.redirect(new URL("/", request.url));
    }
  }

  return response;
}

export const config = {
  matcher: [
    /*
     * Match all request paths except:
     * - _next/static (static files)
     * - _next/image (image optimization)
     * - favicon.ico
     * - public files (icons, manifest, etc.)
     */
    "/((?!_next/static|_next/image|favicon\\.ico|icons/|manifest\\.json).*)",
  ],
};
